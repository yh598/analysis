import json
import azure.functions as func
from shared import get_gremlin_client

def _q(req, key, default=None):
    v = req.params.get(key)
    return v if v is not None and v != "" else default

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        provider_id = _q(req, "providerId")
        if not provider_id:
            return func.HttpResponse(json.dumps({"error":"providerId is required"}), mimetype="application/json", status_code=400)

        limit = int(_q(req, "limit", "50"))
        limit = max(1, min(limit, 200))

        g = get_gremlin_client()

        q = """g.V().hasLabel('provider').has('providerId','%s').
          out('rendered_by').
          hasLabel('claim').
          project('id','claimId','memberId','amount','serviceDate','ui_color','risk_reason','risk_score','risk_rule').
            by(id()).
            by(values('claimId')).
            by(values('memberId')).
            by(values('amount')).
            by(values('serviceDate')).
            by(coalesce(values('ui_color'), constant('green'))).
            by(coalesce(values('risk_reason'), constant(''))).
            by(coalesce(values('risk_score'), constant(0))).
            by(coalesce(values('risk_rule'), constant(''))).
          limit(%d)""" % (provider_id.replace("'","\\'"), limit)

        rs = g.submit(q).all().result()
        return func.HttpResponse(
            json.dumps({"providerId": provider_id, "items": rs}, default=str),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500
        )
