#!/bin/sh

echo "POST Deploy SCRIPT Start"

databricks bundle validate

echo "Current working directory: $(pwd)"

databricks bundle run -t ${BITBUCKET_DEPLOYMENT_ENVIRONMENT} ce_call_intent_ifp_job

echo "POST Deploy SCRIPT End"
