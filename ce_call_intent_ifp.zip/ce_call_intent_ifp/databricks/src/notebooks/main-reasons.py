# Databricks notebook source
# MAGIC %md
# MAGIC Import System Module and Append Path

# COMMAND ----------

# MAGIC %run "./package_installer"

# COMMAND ----------

import sys
sys.path.append("./CII Pipeline")

# COMMAND ----------

# MAGIC %run "./CII Pipeline/generic_pipeline/actionable_insights_main"

# COMMAND ----------

# MAGIC %run "./utils-reasons"

# COMMAND ----------

# MAGIC %run "./config-reasons"

# COMMAND ----------

# MAGIC %md
# MAGIC Retrieve Log file path

# COMMAND ----------

# Retrieve the log_file_path parameter set in the previous task
log_file_path = dbutils.jobs.taskValues.get("Call_Driver", "staged_log_file_path")

# Print or use the log_file_path as needed
print(f"The log file path is: {log_file_path}")

# COMMAND ----------

# log_file_path="/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_intent_workspace/medicare_lob/2024-10-23/25102024_staged_logging_status.csv"

# COMMAND ----------

# MAGIC %md
# MAGIC Retrieve the output file path

# COMMAND ----------

# Retrieve the op_file_path parameter set in the previous task
op_file_path = dbutils.jobs.taskValues.get("Call_Driver", "op_file_path")

# Print or use the op_file_paths as needed
print(f"The output file path is: {op_file_path}")

# COMMAND ----------

# op_file_path="/Volumes/dbc_adv_anlaytics_dev/surveyspeechextraction/call_driver_poc/sagility_test_folder/Sagility_Feb_Processed/Provider/2025-02-18/output"

# COMMAND ----------

# Log the start of the stage
start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
try:
    print(f"op_file_path: {op_file_path}")
    # Log the end of the stage
    log_stage("Retrieved Output file path", start_time, "Success", "Op file path was set")
except Exception as e:
    print(f"Error: {e}")
    # Log the error
    log_stage("Retrieved Output file path", start_time, "Failed", f"Op file path processing failed with error: {e}")

# COMMAND ----------

# MAGIC %run "./expected_delta_table_schema_reasons"

# COMMAND ----------

# MAGIC %md
# MAGIC Setting the Schema

# COMMAND ----------


schema = get_Expected_schema_reasons()

# Log the start of the stage
start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
try:
    schema = get_Expected_schema_reasons()
    # Log the end of the stage
    log_stage("Schema for Reasons", start_time, "Success", "Schema for Reasons was set")
except Exception as e:
    print(f"Error: {e}")
    # Log the error
    log_stage("Schema for Reasons", start_time, "Failed", f"Schema for Reasons processing failed with error: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC Processing Reasons and Actionable

# COMMAND ----------

start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
log_stage("Process Actionable Insights", start_time, "Started", "Processing actionable insights started")

try:
    df, final_status = process_actionable_insights(op_file_path)

    # Check if df is None
    if df is None:
        log_stage("Process Actionable Insights", start_time, "Failed", "DataFrame 'df' is None. Please check the data processing step.")
        print("DataFrame 'df' is None. Please check the data processing step.")
    else:
        log_stage("Process Actionable Insights", start_time, "Completed", "Processing actionable insights completed successfully")
except Exception as e:
    print(f"Error: {e}")
    # Log the error
    log_stage("Process Actionable Insights", start_time, "Failed", f"Processing actionable insights failed with error: {e}")


# COMMAND ----------

df.head(2)

# COMMAND ----------

# MAGIC %md
# MAGIC Update delta table

# COMMAND ----------

# update_delta_table(spark_df, CATALOG_NAME, SCHEMA_NAME, TABLE_NAME)
# Log the start of the stage
start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
log_stage("Update Delta Table", start_time, "Started", "Updating Delta table started")

try:
    # Import necessary modules
    from pyspark.sql import DataFrame
    from pyspark.sql.functions import col

    # Check if df is a Spark DataFrame
    if not isinstance(df, DataFrame):
        # Assuming df is a Pandas DataFrame and schema is defined
        # Disable Arrow-based columnar data transfers
        spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "false")

        # Convert Pandas DataFrame to Spark DataFrame
        df = spark.createDataFrame(df, schema=schema)

    # Check if DataFrame is not empty
    if df.rdd.isEmpty():
        print("DataFrame is empty. Please check the data processing step.")
    
    
    # Select and alias the necessary columns
    df = df.select(
        col("SNO"),
        col("NAME_OF_TOP_DRIVER"),
        col("CALL_CATEGORY"),
        col("PERCENTAGE_OF_CALLS"),
        col("CALL_INTENT_TIER1"),
        col("CALL_INTENT_TIER2"),
        col("CALL_INTENT_TIER3"),
        col("CALL_INTENT_TIER4"),
        col("CALL_INTENT_TIER5"),
        col("DESCRIPTIVE_TAG1"),
        col("DESCRIPTIVE_TAG2"),
        col("CONVERSATION_START_DATE"),
        col("CONVERSATION_PROCESSED_DATE"),
        col("INSIGHTS"),
        col("INSIGHTS_1")
    )

    display(df)

    # Check if the Delta table exists
    table_exists = spark._jsparkSession.catalog().tableExists(f"{CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}")

    if table_exists:
        update_delta_table(df, CATALOG_NAME, SCHEMA_NAME, TABLE_NAME)
        print(f"Delta table updated successfully: {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}")
        log_stage("Update Delta Table", start_time, "Completed", "Updating Delta table completed successfully")
    else:
        # Create the Delta table if it does not exist
        df.write.format("delta").mode("overwrite").saveAsTable(f"{CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}")
        print(f"Delta table created successfully: {CATALOG_NAME}.{SCHEMA_NAME}.{TABLE_NAME}")
        log_stage("Create Delta Table", start_time, "Completed", "Creating Delta table completed successfully")

except Exception as e:
    print(f"Error: {e}")
    # Log the error
    log_stage("Update Delta Table", start_time, "Failed", f"Updating Delta table failed with error: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC Logging for Stages

# COMMAND ----------

write_log_to_file(log_file_path)