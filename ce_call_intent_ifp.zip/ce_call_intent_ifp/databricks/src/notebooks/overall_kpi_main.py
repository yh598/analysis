# Databricks notebook source
# MAGIC %md
# MAGIC For IVR, Projected Calls and Containment Rate

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import current_date
from pyspark.sql.types import StructType, StructField, IntegerType, DateType

# COMMAND ----------

# Define the schema
schema = StructType([
    StructField("no_of_ivr_calls", IntegerType(), True),
    StructField("no_of_projected_calls", IntegerType(), True),
    StructField("containment_rate", IntegerType(), True),
    StructField("date", DateType(), True)
])

# COMMAND ----------

# Define the queries
queries = {
    "no_of_ivr_calls": "SELECT COUNT(IVR_CONNECT) AS no_of_ivr_calls FROM [repository].[dbo].[BSCContact]",
    "no_of_projected_calls": "<YOUR_QUERY_FOR_PROJECTED_CALLS>",
    "containment_rate": "<YOUR_QUERY_FOR_CONTAINMENT_RATE>"
}

# COMMAND ----------

# JDBC connection properties for the first database
jdbc_url_1 = "jdbc:sqlserver://;serverName=wsql40514p;port=50101;databaseName=repository"
connection_properties_1 = {
    "user": "<username>",
    "password": "<password>",
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}

# JDBC connection properties for the second database
jdbc_url_2 = "jdbc:sqlserver://;serverName=wsql40083p;port=50101;databaseName=OZ"
connection_properties_2 = {
    "user": "<username>",
    "password": "<password>",
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}


# COMMAND ----------


def create_df(query: str, jdbc_url: str, connection_properties: dict) -> DataFrame:
    """Create a DataFrame from a SQL query."""
    return spark.read.jdbc(
        url=jdbc_url,
        table=f"({query}) AS subquery",
        properties=connection_properties
    )

def add_date_column(df: DataFrame) -> DataFrame:
    """Add the current date column to the DataFrame."""
    return df.withColumn("date", current_date())

def save_to_delta(df: DataFrame, path: str):
    """Save the DataFrame to a Delta table."""
    df.write.format("delta").save(path)

def process_no_of_ivr_calls(query: str) -> DataFrame:
    """Process the query for the number of IVR calls."""
    return create_df(query, jdbc_url_1, connection_properties_1)

def process_no_of_projected_calls(query: str) -> DataFrame:
    """Process the query for the number of projected calls."""
    return create_df(query, jdbc_url_2, connection_properties_2)

def process_containment_rate(query: str) -> DataFrame:
    """Process the query for the containment rate."""
    return create_df(query, jdbc_url_2, connection_properties_2)

def process_queries(queries: dict) -> DataFrame:
    """Process the queries and combine the results into a single DataFrame."""
    try:
        # Process each query separately
        df_ivr_calls = process_no_of_ivr_calls(queries["no_of_ivr_calls"])
        df_projected_calls = process_no_of_projected_calls(queries["no_of_projected_calls"])
        df_containment_rate = process_containment_rate(queries["containment_rate"])

        # Combine the DataFrames into a single DataFrame
        combined_df = df_ivr_calls.crossJoin(df_projected_calls).crossJoin(df_containment_rate)

        # Add the current date column
        combined_df = add_date_column(combined_df)

        # Apply the schema to the DataFrame
        combined_df = spark.createDataFrame(combined_df.rdd, schema)

        return combined_df
    except Exception as e:
        print(f"An error occurred while processing queries: {e}")
        raise


# COMMAND ----------


def main():
    """Main function to execute the data processing and saving."""
    try:
        # Process the queries and get the combined DataFrame
        combined_df = process_queries(queries)

        # Write the DataFrame to a Delta table
        save_to_delta(combined_df, "/path/to/delta-table")

        # Display the DataFrame
        display(combined_df)
    except Exception as e:
        print(f"An error occurred in the main function: {e}")
    finally:
        print("Job completed")

# Run the main function
main()