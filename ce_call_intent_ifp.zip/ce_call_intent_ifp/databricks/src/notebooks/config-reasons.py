# Databricks notebook source
# MAGIC %md
# MAGIC Set Up Parameters for Delta Table

# COMMAND ----------

#parameters for delta table (DO NOT CHANGE)
# CATALOG_NAME = "dbc_adv_anlaytics_dev"
# SCHEMA_NAME = "surveyspeechextraction"
# TABLE_NAME =  "ifp_work_call_insights"
CATALOG_NAME = config['catalog_name']
SCHEMA_NAME = config['schema_name']
TABLE_NAME = config['REASONS_TABLE_NAME']

# COMMAND ----------

# DO NOT CHANGE BELOW CODE
import os
model_gpt_4o_mini = config['model_gpt_4o_mini']
model_gpt_4o = config['model_gpt_4o']
model_api_version = "2024-10-21"
model_host = 'https://oai-pn-its-aoai-eus2-455.openai.azure.com'
bearer_token_provider_url = "https://cognitiveservices.azure.com/.default"