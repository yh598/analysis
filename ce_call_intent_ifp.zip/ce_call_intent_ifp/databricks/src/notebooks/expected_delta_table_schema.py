# Databricks notebook source
# MAGIC %md
# MAGIC Import Required Libraries

# COMMAND ----------

from pyspark.sql.functions import explode, col
from pyspark.sql.types import StructType, StructField, StringType, FloatType, LongType, DoubleType, IntegerType


# COMMAND ----------

# MAGIC %md
# MAGIC Define Schema for Expected Delta Table

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DoubleType, LongType, IntegerType, ArrayType

def get_expected_table_schema() -> StructType:
    """
    Returns the expected schema for the table.
    """
    schema = StructType([
        StructField("ID", StringType(), True),
        StructField("CONVERSATION_FILENAME", StringType(), True),
        StructField("CONVERSATION_LENGTH_SEC", DoubleType(), True),
        StructField("CONVERSATION_LANGUAGE", StringType(), True),
        StructField("CONVERSATION_START_DATE", StringType(), True),
        StructField("CONVERSATION_END_DATE", StringType(), True),
        StructField("CONVERSATION_START_TIME", StringType(), True),
        StructField("CONVERSATION_END_TIME", StringType(), True),
        StructField("CONVERSATION_PROCESSED_DATE", StringType(), True),
        StructField("CONVERSATION_PROCESS_TIME", StringType(), True),
        StructField("AGENT_TALK_TIME_IN_SEC", DoubleType(), True),
        StructField("CUSTOMER_TALK_TIME_IN_SEC", DoubleType(), True),
        
        StructField("AUDIO_START_TIME", StringType(), True),
        StructField("SOURCE_DB", StringType(), True),
        StructField("SID", LongType(), True),
        StructField("SITE_ID", LongType(), True),
        StructField("AUDIO_CH_NUM", LongType(), True),
        StructField("AUDIO_MODULE_NUM", LongType(), True),
        StructField("AUDIO_START_TIME_GMT", StringType(), True),
        StructField("TRANSACTION_ID", StringType(), True),
        StructField("CONTACTID", StringType(), True),
        StructField("PERSONAL_ID", StringType(), True),
        StructField("ORG_ID", StringType(), True),
        StructField("DIRECTION", LongType(), True),
        StructField("LOCAL_AUDIO_START_TIME", StringType(), True),
        StructField("LOCAL_AUDIO_END_TIME", StringType(), True),
        StructField("WRAPUP_TIME", StringType(), True),
        StructField("AGENT_NAME", StringType(), True),
        StructField("TOTAL_HOLD_TIME", StringType(), True),
        StructField("PBX_LOGIN_ID", StringType(), True),
        StructField("ANI", StringType(), True),
        StructField("EXTENSION", StringType(), True),
        StructField("STRING_EXTENSION", StringType(), True),
        StructField("SWITCH_CALL_ID", StringType(), True),
        StructField("SWITCH_ID", StringType(), True),
        StructField("DURATION_SECONDS", LongType(), True),
        StructField("WRAPUP_TIME_IN_SECONDS", StringType(), True),
        StructField("DNIS", StringType(), True),
        StructField("NUMBER_OF_CONFERENCES", StringType(), True),
        StructField("NUMBER_OF_HOLDS", StringType(), True),
        StructField("NUMBER_OF_TRANSFERS", StringType(), True),
        StructField("PERCENT_OF_AGENT_CALL", StringType(), True),
        StructField("PERCENT_OF_OTHER_CALL", StringType(), True),
        StructField("PERCENT_OF_MUTUAL_SILENCE", StringType(), True),
        StructField("NUM_OF_AGENT_CROSS", StringType(), True),
        StructField("NUM_OF_OTHER_CROSS", StringType(), True),
        StructField("LANGUAGE_CODE", StringType(), True),
        StructField("ISEXCEPTION", LongType(), True),
        StructField("CD6", StringType(), True),
        StructField("CD8", StringType(), True),
        StructField("CD48", StringType(), True),
        StructField("CD69", StringType(), True),
        StructField("CD93", StringType(), True),

        # Flatten speech_module_output
        StructField("CALL_TRANSCRIPT", StringType(), True),

        # Flatten overall_level
        StructField("CALL_TRANSCRIPT_SUMMARY", StringType(), True),
        StructField("CALL_INTENT", ArrayType(StringType()), True),
        StructField("CALL_INTENT_TIER1", StringType(), True),
        StructField("CALL_INTENT_TIER2", StringType(), True),
        StructField("CALL_INTENT_TIER3", StringType(), True),
        StructField("CALL_INTENT_TIER4", StringType(), True),
        StructField("CALL_INTENT_TIER5", StringType(), True),
        StructField("DESCRIPTIVE_TAG1", StringType(), True),
        StructField("DESCRIPTIVE_TAG2", StringType(), True),
        StructField("NUMBER_OF_INTENTS", StringType(), True),
        StructField("COMBINATION_OF_ALL_TIER1_INTENTS", StringType(), True),
        StructField("COMBINATION_OF_ALL_TIER1_TIER2_INTENTS", StringType(), True),
        StructField("COMBINATION_OF_ALL_INTENTS", StringType(), True),

        # New additional fields
        StructField("CALLBACK_REQUEST", StringType(), True),
        StructField("CALLBACK_REQUEST_BY", StringType(), True),
        StructField("CALLBACK_EXPLANATION", StringType(), True),
        StructField("CALL_COMPLEXITY_ENGINE_GENERATED", StringType(), True),
        StructField("CALL_COMPLEXITY_EXPLANATION_ENGINE_GENERATED", StringType(), True),
        StructField("CALL_COMPLEXITY_EXPLANATION_ENGINE_GENERATED_DECISION_LOGIC", StringType(), True),
        StructField("CUSTOMER_ATTRITION_INDICATOR", StringType(), True),
        StructField("REASON_FOR_CUSTOMER_ATTRITION_INDICATOR", StringType(), True),
        StructField("CUSTOMER_SENTIMENT_AT_END_OF_CALL", StringType(), True),
        StructField("CUSTOMER_SENTIMENT_AT_END_OF_CALL_EXPLANATION", StringType(), True),
        StructField("CUSTOMER_SENTIMENT_TOWARDS_BSC", StringType(), True),
        StructField("CUSTOMER_SENTIMENT_TOWARDS_BSC_REASON", StringType(), True),
        StructField("CUSTOMER_SUB_SENTIMENT_TOWARDS_BSC", StringType(), True),
        StructField("CUSTOMER_SUB_SENTIMENT_TOWARDS_BSC_REASON", StringType(), True),
        StructField("PRESENCE_OF_CALL_INTENT", StringType(), True),

        StructField("IS_ACTIVE", DoubleType(), True),

        # Additional fields 
        StructField("MEMBER_ID", StringType(), True),                       
        StructField("MEMBER_REGISTERED", StringType(), True),               
        StructField("MEMER_LAST_ONLINE", StringType(), True),                     
        StructField("CALL_SATISFACTION_SCORE", IntegerType(), True),                   
        StructField("MEMBER_NPS", IntegerType(), True),  
        StructField("NPS_GROUP", IntegerType(), True),  
        StructField("SURVEY_DATE", IntegerType(), True),                           
        StructField("MEMBER_TENURE", IntegerType(), True),                        
        StructField("MEMBER_PLAN", StringType(), True),                            
        StructField("MEMBER_GEO_COUNTY", StringType(), True),
        StructField("MEMBER_STATE", StringType(), True), 
        StructField("MEMBER_LOB", StringType(), True), 
        StructField("MEMBER_AGE", StringType(), True),   
        StructField("GROUP_NUM", StringType(), True), 
        StructField("GROUP_NAME", StringType(), True),                    
        StructField("SKILL_NAMES", StringType(), True)
    ])
    return schema