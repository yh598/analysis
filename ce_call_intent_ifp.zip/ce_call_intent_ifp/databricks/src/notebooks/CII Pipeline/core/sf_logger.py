import time
import logging
from logging import handlers
import sys

from core import main_config
ROLLOVER = False


def get_logger_generic(app_name):
    global ROLLOVER
    logger = logging.getLogger(app_name)
    level_name = main_config.logging_level.upper()
    level = logging.getLevelName(level_name)
    logger.setLevel(level)
    format = logging.Formatter("%(asctime)s - [%(name)s] - [%(levelname)s] - %(message)s")

    # Print the logs
    if not logger.hasHandlers():
        stdout_handler  = logging.StreamHandler(sys.stdout)
        stdout_handler.setFormatter(format)
        logger.addHandler(stdout_handler)
    return logger


def get_logger_benchmark(app_name):
    log = logging.getLogger(app_name)
    level = logging.getLevelName(main_config.logging_level.upper())
    log.setLevel(level)
    format = logging.Formatter("")

    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(format)
    log.addHandler(ch)


def get_logger(app_name):
    if main_config.logging_type == "Benchmark":
        return get_logger_benchmark(app_name)
    else:
        return get_logger_generic(app_name)


def benchmark_timer(logger):
    def timeit(method):
        def timed(*args, **kw):
            if main_config.logging_type != "Benchmark":
                return method(*args, **kw)
            ts = time.time()
            result = method(*args, **kw)
            te = time.time()

            logger.info('%r,%2.4f sec' % \
                (method.__name__, te-ts))
            return result

        return timed
    return timeit


if __name__ == "__main__":
    get_logger("test")

