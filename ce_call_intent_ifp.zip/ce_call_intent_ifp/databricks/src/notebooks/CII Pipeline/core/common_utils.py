import os
import time
import tiktoken
from functools import wraps

def get_env_value(key):
    try:
        return os.environ[key]
    except:
        raise Exception(f"unable to find the environment variable {key}")
    
def validate_columns(column_name, df):
    if column_name not in df.columns:
        raise Exception(f"column `{column_name}` not found")

def get_num_tokens(text):
    encoding = tiktoken.encoding_for_model('gpt-3.5-turbo')
    num_tokens = len(encoding.encode(str(text)))
    return num_tokens

# def get_single_list_elements(input_data, tmp=list()):
#     if isinstance(input_data, list):
#         for item in input_data:
#             tmp.append(get_single_list_elements(item, tmp))
#         print("final tmp", tmp)
#         return tmp
#     else:
#         return input_data
    

def get_single_list_elements(input_data, tmp=list()):
    for item in input_data:
        if isinstance(item, list):
            tmp.extend(item)
        else:
            tmp.append(item)
    return tmp
    
