from openai import AzureOpenAI, OpenAI
import os
import json

from core.common_utils import get_env_value
import time
from retry import retry
from core.sf_beans import AnalyticsManager
from azure.identity import DefaultAzureCredential, get_bearer_token_provider

class OpenAIClient:
    def __init__(self, api_url=None, api_key=None, model_name=None,bearer_token = None, token_auth=False, analytics = False, db_client=None, llm_analytics_table_name="llm_analytics"):
        self.analytics = analytics
        self.token_auth=token_auth
        self.bearer_token = bearer_token
        if api_url == None:
            self.api_url = get_env_value("openai_url")
        else:
            self.api_url = api_url

        if api_key == None:
            self.api_key = get_env_value("openai_key")
        else:
            self.api_key = api_key
        
        # if api_version == None:
        #     self.api_version = get_env_value("openai_version")
        # else:
        #     self.api_version = api_version

        if model_name == None:
            self.model_name = get_env_value("openai_model_name")
        else:
            self.model_name = model_name

        if self.analytics:
            if db_client == None:
                raise Exception("db_client can be none, when analytics is True")
            self.analytics_manager = AnalyticsManager(db_client=db_client, llm_analytics_table_name=llm_analytics_table_name)

        self.client = self.get_openai_client()

    def llm_tracker(method):
        def analytics(self, *args, **kw):
            input_messages = args[0]
            analytics_manager = args[1]
            module_name = args[2]
            analytics_manager.add_name(module_name)
            analytics_manager.add_llm_input_tokens(input_messages)
            st = time.time()
            response, error = method(self, *args, **kw)
            end = time.time()
            analytics_manager.add_llm_output_tokens(response)
            analytics_manager.add_llm_duration(end - st)
            analytics_manager.save_llm_request()
            return response, error
        return analytics

    def get_openai_client(self):
        try:
            if self.token_auth:
                # token_provider = get_bearer_token_provider( DefaultAzureCredential(), self.bearer_token_provider_url)
                client = OpenAI(
                    api_key = self.bearer_token,
                    base_url = self.api_url
                )
            else:
                client = OpenAI(
                        base_url = self.api_url
                    )
        except:
            print(f"unable to find openai credentials in the environment variable, Please ensure the following environment variables (openai_base_url, openai_api_key, openai_api_version) are provided")
        return client

    @retry(Exception , tries=3, delay=2)
    def get_llm_output(self, messages):
        try:
            output = self.client.chat.completions.create(
                model = self.model_name,
                messages = messages,
                temperature=0.0,
                seed=42
            )
            return output
        except Exception as e:
            raise

    def generate_llm_response(self, messages):
        try:
            st = time.time()
            output = self.get_llm_output(messages)
            end = time.time()
            response=output.choices[0].message.content
            return response, "",{"messages":messages,"raw_output":response,"llm_time_taken":end - st,"input_token_size":output.usage.prompt_tokens,"output_token_size":output.usage.completion_tokens}
        except Exception as e:
            print(f"Exception occured while generating llm response: {e}")
            return None, str(e),{}
        
    @llm_tracker
    def generate_llm_response_with_analytics(self, messages, analytics_manager, module_name):
        try:
            completion = self.client.chat.completions.create(
                model = self.model_name,
                messages = messages,
                temperature = 0.0,
                top_p = 0.95,
                seed = 42,
                stream=True,
            )
            response_messages = []
            for chunk in completion:
                if chunk is None or chunk.choices is None:
                    continue
                if len(chunk.choices) > 0 and chunk.choices[0].delta.content is not None:
                    response_messages.append(chunk.choices[0].delta.content)

            if len(response_messages) == 0:
                raise Exception
            return "".join(response_messages), ""
        except Exception as e:
            return "", e

    def generate(self, messages, module_name=""):
        if self.analytics:
            return self.generate_llm_response_with_analytics(messages, self.analytics_manager, module_name=module_name)
        else:
            return self.generate_llm_response(messages=messages)
    
