import copy
from concurrent.futures import ThreadPoolExecutor, as_completed

from core import llm_clients
from core.text_analytics import prompt_handler
from core.text_analytics import utils
from core import sf_logger
from core.text_analytics.utils import validate_input_dict_data

logger = sf_logger.get_logger(__name__)

class Groups:
    def __init__(self, groups, max_workers=5):
        self.groups = groups
        self.max_workers = max_workers

    def start(self):
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = []
            outputs = []
            group_errors=[]
            for group in self.groups:
                future = executor.submit(group.generate)
                futures.append(future)
            
            for future in as_completed(futures):
                try:
                    output = future.result()
                    outputs.append(output)
                except Exception as e:
                    # group name
                    print(f"An error occurred: {e}")
                    group_errors.append(str(e))
            # print("outputs debug", outputs)
            return outputs,group_errors
        # outputs = []
        # for group in self.groups:
        #     outputs.append(group.generate())
        # return outputs
            

class Policy:
    def __init__(self, modules_execution_order):
        self.modules_execution_order = modules_execution_order


class InsightsGroup:
    def __init__(self, group_name, transcript_id, transcript, llm_client=None, use_default=False):
        self.transcript = transcript
        self.transcript_id = transcript_id
        self.insights = dict()
        self.Error_Details = []
        self.group_name = group_name
        self.policy = None

        if llm_client == None:
            self.llm_client = llm_clients.OpenAIClient()
        else:
            self.llm_client = llm_client

        if use_default:
            self.insights_generation_modules = self.register_modules(get_default_insights_modules())
        self.final_insights = dict()

    def generate(self):
        self.generate_insights()
        return {self.group_name: {"result": self.final_insights}}

    def register_modules(self, modules, policy=None):
        self.insight_generation_modules = dict()
        
        for module in modules:
            self.insight_generation_modules[module.name] = module

        if policy == None:
            self.policy = Policy(self.insight_generation_modules.keys())
        else:
            self.policy = policy


    def check_modules_list(self, modules, use_default):
        if use_default or modules == None:
            modules = get_default_insights_modules()

        if not use_default and modules == None:
            raise Exception("modules cannot be none, Please provide the modules for insights generation")

        return modules

    def generate_insights(self):
        for i, module_name in enumerate(self.policy.modules_execution_order, 1):
            insight_module = self.insight_generation_modules[module_name]
            # logger.info(f"Generating insight[{insight_module.name}]: {i} of {len(self.insights_generation_modules)}")
            if isinstance(insight_module, IntermediateInsightHandler):
                errors, output = insight_module.create(self, i)
            else:
                errors, output,llm_analytics = insight_module.generate(self)
            if insight_module.name not in self.final_insights:
                self.final_insights[insight_module.name] = dict()
            self.final_insights[insight_module.name]["errors"] = errors
            self.final_insights[insight_module.name]["output"] = output
            self.final_insights[insight_module.name]["llm_analytics"] = llm_analytics


    def insert_intermediate_modules(self, name, index, modules_list):
        # if len(self.insights_generation_modules) >= index:
        #     self.insights_generation_modules.append(index, IntermetiateInsights(name, modules_list))
        # else:
        self.policy.modules_execution_order.insert(index, name)
        self.insight_generation_modules[name] = IntermetiateInsights(name, modules_list)

class Insight:
    def __init__(self, module_name, prompt_function, parsing_method, policy=None, prompt_message_list=None, metadata=None):
        self.name = module_name
        self.prompt_function = prompt_function
        self.parser = parsing_method
        self.metadata = metadata
        self.errors = list()
        self.prompt_message_list = prompt_message_list
        self.policy = policy

    def generate(self, insight_module):
        if self.prompt_message_list == None:
            prompt_messages = self.prompt_function(insight_module)
        else:
            prompt_messages = self.prompt_message_list
        if prompt_messages == None:
            tmp_dict = {"exception_name": "Invalid prompt input", "exception": f"Invalid prompt input, Required input not available"}
            self.errors.append(str(tmp_dict))
            return self.errors, InsightResponse(""),{}
        elif isinstance(prompt_messages, str):
            prompt_messages = [{"role": "user", "content": prompt_messages}]
        output, error , llm_analytics = insight_module.llm_client.generate(prompt_messages, module_name=self.name )
        if len(str(error).strip()) == 0 and output != None:
            if self.metadata == None:
                output, error = self.parser(output)
            else:
                output, error = self.parser(output, self.metadata)
            # print("name: ",self.name,"intermediate: ",output,"error: ",error)
            if len(str(error).strip()) > 0:
                tmp_dict = {"exception_name": "parser_exception", "exception": f"{error}"}
                self.errors.append(str(tmp_dict))
        else:
            tmp_dict = {"exception_name": "llm_exception", "exception": f"{str(error)}","output": output}
            if output == None and "The response was filtered due to the prompt triggering Azure OpenAI's content management policy." in str(error):
                tmp_dict = {"exception_name": "llm_exception", "exception": f"Content filter issue: {str(error)}","output": output}
            elif output == None:
                tmp_dict = {"exception_name": "llm_exception", "exception": "Openai returned NoneType output","output": output}
            self.errors.append(str(tmp_dict))
        return self.errors, InsightResponse(output),llm_analytics
    
class IntermetiateInsights:
    def __init__(self, module_name, modules):
        self.name = module_name
        self.modules = modules

    def generate(self, insight_module):
        final_output = []
        final_errors = []
        final_llm_analytics=[]
        for module in self.modules:
            if isinstance(module, Insight):
                errors, output,llm_analytics = module.generate(insight_module)
                llm_analytics['prompt_name']=module.name
            elif isinstance(module, InsightResponse):
                output = module.response
                errors = []
                llm_analytics={}
            else:
                raise Exception("Got unsupported module instance")
            final_output.append(output)
            final_errors.append(errors)
            final_llm_analytics.append(llm_analytics)
        return final_errors, InsightResponse(final_output),final_llm_analytics
    
class IntermediateInsightHandler:
    def __init__(self, module_name, intermediate_call_function):
        self.name = module_name
        self.call_function = intermediate_call_function
        self.errors = list()

    def create(self, insight_module, index):
        try:
            modules_list = self.call_function(insight_module)
            insight_module.insert_intermediate_modules(self.name, index, modules_list)
            return "", "success"
        except Exception as e:
            print(e)
            return str(e), "failure"
        
class InsightResponse:
    def __init__(self, response):
        self.response = response

def get_insight_response(insight_response_object):
    if isinstance(insight_response_object, list):
        return [get_insight_response(item) for item in insight_response_object]

    if isinstance(insight_response_object, dict):
        for k, v in insight_response_object.items():
            insight_response_object[k] = get_insight_response(v)
        return insight_response_object

    while isinstance(insight_response_object, InsightResponse):
        insight_response_object = get_insight_response(insight_response_object.response)
    return insight_response_object

def create_custom_insights_module(module_name, parsing_method, prompt_function=None, prompt_message_list=None, metadata=None):
    custom_insights_module = Insight(module_name=module_name, prompt_function = prompt_function, parsing_method=parsing_method, prompt_message_list=prompt_message_list, metadata=metadata)
    return custom_insights_module

def create_custom_insights_response(response):
    return InsightResponse(response)

def get_default_insights_modules():
    default_insights_modules = list()
    default_insights_modules.append(create_custom_insights_module(module_name="generic_insights_generation", prompt_function=prompt_handler._get_generic_insight_prompt, parsing_method= utils.parse_generic_insight))
    default_insights_modules.append(create_custom_insights_module(module_name="overall_sentiment_insights_generation", prompt_function=prompt_handler._get_sentiment_prompt, parsing_method= utils.get_generic_sentiment_output))
    return default_insights_modules