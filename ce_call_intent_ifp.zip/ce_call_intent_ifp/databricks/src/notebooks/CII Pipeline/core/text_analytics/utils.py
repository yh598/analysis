from datetime import datetime, date
from xml.etree import ElementTree as ET
import re, uuid #torch
import pandas as pd
import os, re ,json
import gc
from core import sf_logger
logger = sf_logger.get_logger(__name__)

def validate_input_dict_data(input_name, input, valid_metadata_data):
    if isinstance(valid_metadata_data, dict):
        for k, v in valid_metadata_data.items():
            if k in input:
                validate_input_dict_data(input_name, input[k], valid_metadata_data[k])
            elif v == "not required":
                pass
            else:
                raise Exception(f"required input key: '{k}' not found in the {input_name}")

def check_value(input_text):
    if input_text== None or input_text.strip() == "":
        return "generic"
    return input_text.strip()

def get_current_date_and_time():
    current_date = datetime.now()

    # Format the date in "dd/mm/yyyy" format
    datetime_stamp = current_date.strftime("%Y-%m-%d %H:%M:%S")
    formatted_date = current_date.strftime("%d-%m-%Y")
    formatted_time = current_date.time().strftime("%H:%M:%S")
    return datetime_stamp, formatted_date, formatted_time

def parse_generic_insight(output):

    try:
        parser_output = {"additional_insights": {"customer": {}, "agent": {}}}

        input_string = output.replace("\n","")
        start_index = input_string.find('<')
        end_index = input_string.rfind('>')
        if start_index != -1 and end_index != -1 and start_index < end_index:
            xml_string = input_string[start_index:end_index+1]
            start = "<schema>"
            end = "</schema>"
            if start in xml_string and end in xml_string:
                xml_string = xml_string[xml_string.find(start) +  len(start) : xml_string.rfind(end)]
                root = ET.fromstring(xml_string)
            else:
                root = ET.fromstring(xml_string)
        else:
            raise Exception("No valid xml found in the input string")

        primary_reason_element = root.find('primary_reason')

        if primary_reason_element is not None:
            primary_reason =[primary_reason_element.text]
            call_driver_sentence = ""
            for i in range(len(primary_reason)):
                call_driver_sentence += str(i+1) + ". " + str(primary_reason[i]) + "\n"

            prefix = "Here are the Call Drivers: "
            if call_driver_sentence != "":
                call_driver_sentence = prefix + call_driver_sentence
            parser_output["call_driver_details"] = {"primary_reasons": primary_reason}


        final_output_json = {"Products/Services Mentioned": "", "Callback Scheduled Indicator": "", "Customer Attrition Indicator": "", "Supervisor Escalation": "", "summary": ""}
        products = []
        products_element = root.find('products')
        if products_element is not None:
            if products_element.text is not None and products_element.text.strip()!="":
                products.append(products_element.text)
            for product in products_element:
                products.append(product.text)
            final_output_json["Products/Services Mentioned"]=products

        callback_request_element = root.find('customer_callback_request')
        if callback_request_element is not None:
            callback_request = {}
            response_element = callback_request_element.find('response')
            if response_element is not None:
                callback_request['response'] = response_element.text
            explanation_element = callback_request_element.find('explanation')
            if explanation_element is not None:
                callback_request['explanation'] = explanation_element.text
            final_output_json["Callback Scheduled Indicator"] = callback_request


        attrition_indicator_element = root.find('customer_attrition_indicator')
        if attrition_indicator_element is not None:
            attrition_indicator = {}
            response_element = attrition_indicator_element.find('response')
            if response_element is not None:
                attrition_indicator['response'] = response_element.text
            explanation_element = attrition_indicator_element.find('explanation')
            if explanation_element is not None:
                attrition_indicator['explanation'] = explanation_element.text
            final_output_json["Customer Attrition Indicator"] = attrition_indicator

        escalation_element = root.find('supervisor_escalation')
        if escalation_element is not None:
            escalation = {}
            response_element = escalation_element.find('response')
            if response_element.text is not None:
                escalation['response'] = response_element.text
            explanation_element = escalation_element.find('explanation')
            if explanation_element is not None:
                escalation['explanation'] = explanation_element.text
            final_output_json["Supervisor Escalation"] = escalation

        summary_element = root.find('summary')
        if summary_element is not None:
            final_output_json["summary"] = summary_element.text

        resolutions = []
        resolutions_element = root.find('resolutions')
        if resolutions_element is not None:
            if resolutions_element.text is not None and resolutions_element.text.strip()!="":
                resolutions.append(resolutions_element.text )
            for resolution in resolutions_element:
                resolutions.append(resolution.text)
            final_output_json['resolutions'] = resolutions

        parser_output["additional_insights"]["customer"]["requested_callback"] = final_output_json["Callback Scheduled Indicator"]
        parser_output["additional_insights"]["customer"]["supervisor_escalation"] = final_output_json["Supervisor Escalation"]
        parser_output["additional_insights"]["customer"]["attrition_indicator"] = final_output_json["Customer Attrition Indicator"]
        parser_output["additional_insights"]["customer"]["competitor_mention"] = final_output_json["Products/Services Mentioned"]
        parser_output["summary"] = final_output_json["summary"]
        parser_output["additional_insights"]['agent']["resolutions"] = final_output_json["resolutions"]
        return parser_output, ""
    except Exception as e:
        return "", e

def get_generic_sentiment_output(output):
    try:
        final_insights = {"additional_insights": 
                          {"customer": {"customer_overall_sentiment": {}}, 
                            "agent": {"agent_overall_sentiment": {}}}}
        def parse_sentiment_output(input_string):
            input_string = input_string.replace("\n","")
            # Find the last occurrence of '{' and '}'
            start_index = input_string.rfind('{')
            end_index = input_string.rfind('}')

            # Ensure both '{' and '}' are found
            if start_index != -1 and end_index != -1 and start_index < end_index:
                # Extract the substring containing the last JSON object
                json_string = input_string[start_index:end_index+1]

                try:
                    # Parse the JSON string
                    extracted_json = json.loads(json_string)
                    return extracted_json, ""
                except json.JSONDecodeError as e:
                    try:
                        import ast
                        extracted_json = ast.literal_eval(json_string)
                        return extracted_json, ""
                    except Exception as e:
                        return {}, f"Error decoding JSON: {e}"
            else:
                return {}, "No valid JSON found in the input string"

        parsed_output, parse_error = parse_sentiment_output(output)

        final_output_json = {"customer_overall_sentiment": "", "agent_overall_sentiment": "", }
        if "customer_overall_sentiment" in parsed_output:
            final_output_json["customer_overall_sentiment"] = parsed_output["customer_overall_sentiment"]
        if "agent_overall_sentiment" in parsed_output:
            final_output_json["agent_overall_sentiment"] = parsed_output["agent_overall_sentiment"]
        final_insights["additional_insights"]["customer"]["customer_overall_sentiment"] = final_output_json["customer_overall_sentiment"]
        final_insights["additional_insights"]["agent"]["agent_overall_sentiment"] = final_output_json["agent_overall_sentiment"]
        return final_insights, ""
    except Exception as e:
        return "", e