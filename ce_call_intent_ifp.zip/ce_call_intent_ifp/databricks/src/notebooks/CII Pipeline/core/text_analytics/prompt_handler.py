from core.text_analytics import prompts


def _get_sentiment_prompt(insight_generation_module):
    user_prompt = prompts.sentiment_prompt
    user_prompt = user_prompt.format(
            transcript = insight_generation_module.transcript
        )

    system_prompt = prompts.system_prompt
    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    return message


def _get_generic_insight_prompt(insight_generation_module):
    user_prompt = prompts.generic_insights_prompt
    user_prompt = user_prompt
    system_prompt = prompts.generic_insights_system_prompt
    system_prompt = system_prompt.format(
        transcript = insight_generation_module.transcript
        )
    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    return message        


def summary_generation_prompt(insights_generation_module):
    summary_prompt = prompts.summary
    user_prompt = f"""{insights_generation_module.transcript}"""
    message = [{"role": "system", "content": summary_prompt},        
               {"role":"user","content": user_prompt}]
    return message
