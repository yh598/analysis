generic_insights_prompt = """
  Act as expert analyst for USAA bank who answers in XML format. Here's the xml schema you must adhere to:

  <schema>
  <transcript_analysis>
  <summary>Summary of the transcript</summary>
  <primary_reason>
  </primary_reason>
  <products>
  <product_one>Product 1</product_one>
  <product_two>Product 2</product_two>
  <product_third>Product 3</product_third>
              .
              .
  <product_nth>Product N</product_nth>
  </products>
  <customer_callback_request>
  <response>Yes / No response</response>
  <explanation>Explanation for Yes / No.</explanation>
  </customer_callback_request>
  <customer_attrition_indicator>
  <response>Yes / No response</response>
  <explanation>Explanation for Yes / No.</explanation>
  </customer_attrition_indicator>
  <supervisor_escalation>
  <response>Yes / No response</response>
  <explanation>Explanation for Yes / No.</explanation>
  </supervisor_escalation>
  <resolutions>
  <resolution_one>Resolution 1</resolution_one>
  <resolution_two>Resolution 2</resolution_two>
  <resolution_third>Resolution 3</resolution_third>
              .
              .
              .
  <resolution_nth>Resolution N</resolution_nth>
  </resolutions>
  </transcript_analysis>
  </schema>"""

generic_insights_system_prompt = """
  Transcript: ```{transcript}```
  ```Instruction```:
  Generate the following output:
  1. Comprehensive summary of the transcript. --> xml_tag: <summary>
  2. Primary reason because of which Customer called. --> xml_tag: <primary_reason>
  3. Was there an indication of customer attrition? Yes / No, along with explanation. xml tag structure: <customer_attrition_indicator><response>Yes/No response</response><explanation>explanation of the response</explanation></customer_attrition_indicator>
  4. Products mentioned in the transcript. xml tag: <products>
  5. Was there a supervisor escalation situation in the call? Yes / No, along with explanation. xml tag structure: <supervisor_escalation><response>Yes/No response</response><explanation>explanation of the response</explanation></supervisor_escalation>
  6. Did the customer request callback? Yes / No, along with explanation. xml tag structure: <customer_callback_request><response>Yes/No response</response><explanation>explanation of the response</explanation></customer_callback_request>
  7. What were the resolutions provided by the agent? xml_tag: <resolutions>
  Ensure all xml_tag are kept as mentioned and put it under a parent xml tag '<transcript_analysis>'.
  Ensure there no extra explainatio or notes or comments.
  Response in xml format:"""

system_prompt = """
  You are an intelligent Assistant who is an expert in Analyzing Transcripts."""

sentiment_prompt = """
  Transcript: {transcript}

  Analyze the above ```Transcript``` and always mandatorily responds a valid JSON output. JSON Structure must contain 'customer_overall_sentiment', 'agent_overall_sentiment' as described below:
  
  1. customer_overall_sentiment: Classify the Customer overall sentiment in the call into ['Positive', 'Negative', 'Neutral'].
  2. agent_overall_sentiment: Classify the agent overall sentiment in the call into ['Positive', 'Negative', 'Neutral'].

  Starting from the next line, please provide a Valid JSON output. Compulsorily keep 'customer_overall_sentiment', 'agent_overall_sentiment' as described above STRICTLY. Use double quotes for keys and values. Please provide only the valid JSON response with no additional text, explanation or comments. STRICTLY DON'T GENERATE ANYTHING OTHER THAN THE JSON RESPONSE STRUCTURE SPECIFIED."""  

entity_intent_generation = """
  Sentence: {sentence}

  Analyze the sentence and generate a ontology for it containing topic, subtopic and the intent related to it.
  Important Notes:
    First level (topic) shoul be vroader category.
    Second Level (sub topic) should denote the entity mentioned in sentence in normalized and concise way.
    Third Level should denote the intent related to Second Level present in Sentence.
  
  Here are some examples to Understand:
    Sample Sentence: I want to close my credit card account
    Sample Output: Account/Credit Card/Close

    Sample Setence: I want to change my doctor.
    Sample Output: Access to Care/Physician/Change.

  Only the string output containing the final Ontology, do not generate any extra details or notes."""


summary = """You are HealthCare expert. You task is to analyze the conversation between agent and customer and give a brief summary of what all issues or requests were mentioned by the customer and what all resolutions was provided by the agent.
Answer within the <summary></summary> tag."""