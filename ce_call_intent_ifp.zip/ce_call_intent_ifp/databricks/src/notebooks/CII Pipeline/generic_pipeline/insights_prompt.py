### Call Complexity
call_complexity_user_prompt = """
    Transcript```: ```{input_text}```

    Analyze the transcript and classify if the call is an "informational call" or "non informational call". Non informational calls are those which requires a deeper level of support or resolution. Do not assume a deeper level of support unless explicitly mentioned in the transcript.

    Put the classification within this tag: <type_of_call></type_of_call>
    Put the explanation within this tag: <explanation></explanation>
"""


#### End of Call Complexity ###


#### Attrition Indicator ###

attrition_indicator_system_prompt="""You are an intelligent Assistant from BSC who is an expert in Analyzing Transcripts."""
attrition_indicator_user_prompt="""
Transcript: {transcript}

  Analyze the above ```Transcript``` and always mandatorily responds a valid JSON output. JSON Structure must contain 'customer_attrition_check','reason_for_customer_attrition'as described below:
  
  1. customer_attrition_check: Check whether the customer has explicitly shown attrition intent. Give the answer as 'yes' or 'no'. 
  2. reason_for_customer_attrition: Provide a reason for the above classification.
  
  Notes:
    - Do Not Say yes by blindly seeing plan cancel or claims issue intent. Understand reason for that intent.

  Starting from the next line, please provide a Valid JSON output. Compulsorily keep 'customer_attrition_check','reason_for_customer_attrition' as described above STRICTLY. Use double quotes for keys and values. Please provide only the valid JSON response with no additional text, explanation or comments. STRICTLY DON'T GENERATE ANYTHING OTHER THAN THE JSON RESPONSE STRUCTURE SPECIFIED."""
  
attrition_evaluation_system_prompt = """You are an expert quality evaluator specializing in assessing whether customer has explicitly mentioned to cancel their plan or terminate their coverage. Your are working for Blueshield of California. You Do not make any assumptions or suggesttions. Consider explicit mentions only. Cancelling some other services does not mean cancel plan."""
attrition_evaluation_user_prompt = """Here is a transcript of a customer interaction to a Blue Shield of California service:
transcript: ```{transcript}```
  Answer the following questions:
    1.	Did the customer explicitly state they want to cancel their plan?"""

attrition_evaluation_system_prompt2 = """You are an intelligent Assistant from BSC who is an expert in Analyzing Transcripts. Your task is to analyze the transcript and determine whether the customer explicitly mentions that they have previously cancelled their plan. You Do not make any assumptions or suggestions. Consider explicit mentions only."""
attrition_evaluation_user_prompt2 = """Here is a transcript of a customer interaction to a Blue Shield of California service:
transcript: ```{transcript}```
  Answer the following questions:
    1.	Did customer mentions that they have previously cancelled their plan. Give the answer as 'yes' or 'no'.

"""

### End of Attrition Indicator ###


### Customer Sentiment at end of call ###

customer_sentiment_at_end_of_call_system_prompt = """You are a healthcare expert for Blue Shield of California. You are an expert in identifying if the customer finally left the call in a 'positive note' or 'negative note' or 'neutral note'."""

customer_sentiment_at_end_of_call_user_prompt ="""```Transcript``` : ```{input_text}```

Analyze the ```Transcript``` and answer below questions:

Question 1 : What was final sentiment of the Customer when he left the call? Answer with 'Positive', 'Negative' or 'Neutral'. Focus only on the end sentiment towards the services or issues customer mentioned. Answer within this tag : <final_customer_sentiment></final_customer_sentiment> .

Question 2 : Explain the reason behind the answer generated for Question 1. Answer within this tag : <final_customer_sentiment_explanation></final_customer_sentiment_explanation> .

"""


### End of customer sentiment at end of call ###

### Call back Prompt ###

callback_system_prompt1 = """You are a healthcare expert for Blue Shield of California. You are an expert in identifying if there was a request from customer to get a callback, or agent suggested a callback as because of some reason issue was not resolved.
 
Expected output format:
<callback_details>
<customer_requested_callback>: Value should be 'Yes'/'No'. If customer clearly asked for a callback say 'Yes'.
<agent_suggested_callback>: Value should be 'Yes'/'No'. If the agent clearly suggested a callback say 'Yes'.
<is_customer_requested_callback_derived>: Value should be 'Yes'/'No'. If customer has not clearly stated the requirement to callback, but we can derive based on context say 'Yes'.
<is_agent_suggested_callback_derived>: Value should be 'Yes'/'No'. If agent has not clearly stated the requirement to callback, but we can derive based on context say 'Yes'.
</callback_details>"""

callback_user_prompt1 = """ ```Transcript``` : ```{input_text}```

Please analyse the ```Transcript``` and get the '<callback_details>'.

"""

callback_summarizer_system_prompt = """You are an expert in USA health insurance for Blue Shield of California. You can analyze the transcripts, read through the details and extract relevant details.""" 

callback_summarizer_user_prompt = """$Transcript: ```{input_text}```

    Given the transcript in $Transcript variable, extract all details related to 'Callback'. Give me a paragraph should help understand two primary things 
    a. Did customer explicitly requested a callback from agent or blue shield of california to get update or status from agent?
    b. Did agent explicitly mentioned callback to customer later, to provide update or status on the issue?
    If there is no details just say no details.
    Analyze minutely!
    """

callback_final_system_prompt = """You are an expert in USA health insurance for Blue Shield of California. You can analyze the summary, read through the details and answer the details."""

callback_final_user_prompt = """$Summary: ```{input_text}```

    Given the transcript in $Transcript variable, Answer the following question:
    a. Did customer explicitly requested a callback from agent or blue shield of california to get update or status from agent?  Give it in <answer1>Yes/No</answer1>,<explain1></explain1>
    b. Did agent explicitly mentioned callback to the customer later, to provide update or status on the issue to customer? Giving only call back number for reference or call back number for only if call disconnected, Stricly give as 'No'. Give it in <answer2>Yes/No</answer2>,<explain2></explain2>
    """

### End of Callback ###

### Customer Sentiment towards BSC ###
sentiment_towards_bsc_system_prompt =  """You are a sentiment detection expert in USA for Blue Sheild of California."""
sentiment_towards_bsc_user_prompt = """Transcript: {input_text}

  Analyze the above ```Transcript``` and always mandatorily responds a valid JSON output. JSON Structure must contain 'customer_overall_sentiment_towards_bsc','reason_for_sentiment_towards_bsc'as described below:
  
  1. customer_overall_sentiment_towards_bsc: Classify the Customer overall sentiment towards services provided by BSC into ['Positive', 'Negative', 'Neutral'].
  2. reason_for_sentiment_towards_bsc: Provide a reason for the above sentiment towards BSC.
  Starting from the next line, please provide a Valid JSON output. Compulsorily keep 'customer_overall_sentiment_towards_bsc','reason_for_sentiment_towards_bsc' as described above STRICTLY. Use double quotes for keys and values. Please provide only the valid JSON response with no additional text, explanation or comments. STRICTLY DON'T GENERATE ANYTHING OTHER THAN THE JSON RESPONSE STRUCTURE SPECIFIED."""


  

sub_sentiment_towards_bsc_positive_system_prompt = """You are a sentiment detection expert in USA for Blue Sheild of California."""
sub_sentiment_towards_bsc_positive_user_prompt = """Transcript: {input_text}

  Analyze the above ```Transcript``` and always mandatorily responds a valid JSON output. JSON Structure must contain 'customer_final_sentiment_towards_bsc','reason_for_final_sentiment_towards_bsc' as described below:
  
  1. customer_final_sentiment_towards_bsc: Classify the Customer final sentiment towards services provided by BSC in the call into ['joy','gratitude & thankfulness','satisfied','surprise'].
  2. reason_for_sentiment_towards_bsc: Provide a reason for the above sentiment towards BSC.
  Starting from the next line, please provide a Valid JSON output. Compulsorily keep 'customer_final_sentiment_towards_bsc','reason_for_sentiment_towards_bsc' as described above STRICTLY. Use double quotes for keys and values. Please provide only the valid JSON response with no additional text, explanation or comments. STRICTLY DON'T GENERATE ANYTHING OTHER THAN THE JSON RESPONSE STRUCTURE SPECIFIED."""


sub_sentiment_towards_bsc_negative_system_prompt = """You are a sentiment detection expert in USA for Blue Sheild of California."""
sub_sentiment_towards_bsc_negative_user_prompt = """Transcript: {input_text}

  Analyze the above ```Transcript``` and always mandatorily responds a valid JSON output. JSON Structure must contain 'customer_final_sentiment_towards_bsc','reason_for_final_sentiment_towards_bsc' as described below:
  1. customer_final_sentiment_towards_bsc: Classify the Customer final sentiment towards services provided by BSC in the call into ['frustration and anger',frustration','fear','surprise']
  2. reason_for_sentiment_towards_bsc: Provide a reason for the above sentiment towards BSC
  Starting from the next line, please provide a Valid JSON output. Compulsorily keep 'customer_final_sentiment_towards_bsc','reason_for_sentiment_towards_bsc' as described above STRICTLY. Use double quotes for keys and values. Please provide only the valid JSON response with no additional text, explanation or comments. STRICTLY DON'T GENERATE ANYTHING OTHER THAN THE JSON RESPONSE STRUCTURE SPECIFIED."""

### End of Customer Sentiment towards BSC ###

