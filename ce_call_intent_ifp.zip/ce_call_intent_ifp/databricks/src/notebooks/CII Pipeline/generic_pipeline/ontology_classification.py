from collections import Counter
import json
import re
import ast
import copy
import pandas as pd
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from openai import AzureOpenAI, OpenAI
import os
import time
from retry import retry
from generic_pipeline import ontology_prompt_and_definitions



ontology_df = None
llm_client = None


### LLM Client
def get_llm_client():
    client = OpenAI(
        api_key = os.environ['openai_databricks_token'],
        base_url = os.environ['base_url']
       
    )
    return client

## generate output from llm

@retry(Exception , tries=3, delay=2)
def output_from_llm(client, messages, deployment_id, max_tokens=None):
    try:
        if max_tokens==None:
            response = client.chat.completions.create(
                model = deployment_id,
                messages = messages,
                temperature=0.0,
                seed=42
            )
        else:
            response = client.chat.completions.create(
                model = deployment_id,
                messages=messages,
                seed=42,
                temperature=0.0,
                max_tokens=max_tokens
            )
        end = time.time()
        return response
    except Exception as e:
        raise
    

## get output using the mentioned model
def get_llm_output(client, messages, max_tokens=None):
    try:
        deployment_id = os.environ['model_gpt_4o']
        st = time.time()
        response = output_from_llm(client, messages, deployment_id, max_tokens)
        output = response.choices[0].message.content
        end = time.time()
        analytics = {"messages":messages,"raw_output":output,"llm_time_taken":end - st,"input_token_size":response.usage.prompt_tokens,"output_token_size":response.usage.completion_tokens}
        error = ""
    except Exception as e:
        output = ""
        error = str(e)
        analytics = {}
    return output, error, analytics

llm_client = None


### Get the respective tiers for the selected category
def get_tier_list(sub_tier=None, descriptive_tags=False, descriptive_tag_level="First", descriptive_tag_level1_value = ""):
    # #print(list(ontology_df.columns))
    temp_tier_list = []
    if descriptive_tags:
        temp_sub_tiers=sub_tier.strip("/").strip().split("/")
        if len(temp_sub_tiers)>=1:
            temp_df=ontology_df[ontology_df['Tier1'].astype(str).str.strip().str.lower()==temp_sub_tiers[0].strip().lower()]
        if len(temp_sub_tiers)>=2:
            temp_df=temp_df[temp_df['Tier2'].astype(str).str.strip().str.lower()==temp_sub_tiers[1].strip().lower()]
        if len(temp_sub_tiers)>=3:
            temp_df=temp_df[temp_df['Tier3'].astype(str).str.strip().str.lower()==temp_sub_tiers[2].strip().lower()]
        if len(temp_sub_tiers)>=4:
            temp_df=temp_df[temp_df['Tier4'].astype(str).str.strip().str.lower()==temp_sub_tiers[3].strip().lower()]
        if len(temp_sub_tiers)>=5:
            temp_df=temp_df[temp_df['Tier5'].astype(str).str.strip().str.lower()==temp_sub_tiers[4].strip().lower()]
        if descriptive_tag_level=="First":
            temp_tier_list=temp_df['DescriptiveTag1'].astype(str).str.strip().unique().tolist()
        else:
            temp_df=temp_df[temp_df['DescriptiveTag1'].astype(str).str.strip().str.lower()==descriptive_tag_level1_value.strip().lower()]
            temp_tier_list=temp_df['DescriptiveTag2'].astype(str).str.strip().unique().tolist()
        ##print(temp_tier_list)

    else:
        if sub_tier==None:
            tier1=ontology_df['Tier1'].astype(str).str.strip().unique().tolist()
            return tier1
        else:
            temp_sub_tiers=sub_tier.strip("/").strip().split("/")
            if len(temp_sub_tiers)>=1:
                temp_df=ontology_df[ontology_df['Tier1'].astype(str).str.strip().str.lower()==temp_sub_tiers[0].strip().lower()]
                temp_tier_list=temp_df['Tier2'].astype(str).str.strip().unique().tolist()
            if len(temp_sub_tiers)>=2:
                temp_df=temp_df[temp_df['Tier2'].astype(str).str.strip().str.lower()==temp_sub_tiers[1].strip().lower()]
                temp_tier_list=temp_df['Tier3'].astype(str).str.strip().unique().tolist()
            if len(temp_sub_tiers)>=3:
                temp_df=temp_df[temp_df['Tier3'].astype(str).str.strip().str.lower()==temp_sub_tiers[2].strip().lower()]
                temp_tier_list=temp_df['Tier4'].astype(str).str.strip().unique().tolist()
            if len(temp_sub_tiers)>=4:
                temp_df=temp_df[temp_df['Tier4'].astype(str).str.strip().str.lower()==temp_sub_tiers[3].strip().lower()]
                temp_tier_list=temp_df['Tier5'].astype(str).str.strip().unique().tolist()
    return temp_tier_list
      
     
def check_value(relevant_categories,value):
    if isinstance(value, str) and value !=None and len(value.strip())!=0:
        matched_items = [category.strip() for category in relevant_categories if value.strip().lower() in category.strip().lower()]
        if len(matched_items) > 0:
            return [matched_items[0]]
        else:
            return ["Others"]
    elif isinstance(value, list):
        updated_parsed_output = []
        for i in value:
            if len(i.strip())!=0:
                matched_items = [category.strip() for category in relevant_categories if i.strip().lower() in category.strip().lower()]
                if len(matched_items) > 0:
                    updated_parsed_output.append(matched_items[0])
        if len(updated_parsed_output)==0:
            return ["Others"]
        return updated_parsed_output
    else:
        #print("check method error", type(value), value)
        return ["Others"]
   

### method to get tier1 description
def tier_1_evaluation_description(tiers, all_tiers=False):
    descriptions = ontology_prompt_and_definitions.tier1_definition_dict
    required_descriptions = ""
    if all_tiers:
        for key, value in descriptions.items():
            required_descriptions = required_descriptions + f"""{key}: {value} + '\n\n'"""
    else:
        if isinstance(tiers, str):
            tiers =[tiers]
        tiers = list(set(tiers))
        for key, value in descriptions.items():
            if key in tiers:
                required_descriptions = required_descriptions + f"""{key}: {value} + '\n\n'"""

    return required_descriptions.strip("\n").strip()
    


### Parsing method for tier 1 classification
def parse_tier1_categories(input_string):
    pattern = r"<(selected_category_\d+)>\s*<category_value>(.*?)</category_value>\s*<category_explanation>(.*?)</category_explanation>\s*<derived_from>(.*?)</derived_from>"

    # Find all matches
    matches = re.findall(pattern, input_string, re.DOTALL)
    # #print(matches)

    # Construct JSON-like structure
    categories = {}
    for match in matches:
        category_name = match[0]
        categories[category_name] = {
            "category_value": match[1].strip(),
            "category_explanation": match[2].strip(),
            "is_derived": match[3].strip()
        }

    return categories

def get_tier1_prompt_message(input_text, categories, descriptions):
    system_prompt =  ontology_prompt_and_definitions.tier1_system_prompt

    user_prompt = ontology_prompt_and_definitions.tier1_user_prompt.format(input_text = input_text, categories = categories, descriptions = descriptions)

    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    return message


    

def parse_tier1_evaluator_output(input_string):
    # Regular expression pattern to parse the categories

    pattern = r"<(answer_\d+)>\s*<category_value>(.*?)</category_value>\s*<category_rating>(.*?)</category_rating>\s*<category_rating_explanation>(.*?)</category_rating_explanation>"

    # Find all matches
    matches = re.findall(pattern, input_string, re.DOTALL)
    ##print(matches)

    # Construct JSON-like structure
    categories = {}
    for match in matches:
        category_name = match[0]
        categories[category_name] = {
            "category_value": match[1].strip(),
            "category_rating": match[2].strip(),
            "category_rating_explanation": match[3].strip()
        }

    return categories

def get_tier1_evaluator_prompt(input_text, category):
    required_descriptions = tier_1_evaluation_description(category)
    system_prompt = ontology_prompt_and_definitions.tier1_evaluation_system_prompt

    user_prompt = ontology_prompt_and_definitions.tier1_evaluation_user_prompt.format(input_text = input_text, category = category, required_descriptions = required_descriptions)

    message = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    llm_client = get_llm_client()
    output, error, llm_analytics = get_llm_output(llm_client, message)
    return output, error, llm_analytics

def get_tier1_classification(input_text): 
    final_output={}
    defination = tier_1_evaluation_description([], True)
    tier1s=get_tier_list(sub_tier=None)
    message = get_tier1_prompt_message(input_text, tier1s,defination)
    llm_client = get_llm_client()
    raw_output, error1, llm_analytics1 = get_llm_output(llm_client, message)

    parsed_output = parse_tier1_categories(raw_output)

    not_derived_categories = []
    final_categories_mapping = {}
    tier1s_selected = []
    tier1s_selected_explanation={}
    for key, value in parsed_output.items():
        if value["category_value"] != "Others":
            tier1s_selected.append(value["category_value"])
        if value["category_value"] != "Others" and (("customer issue" in value["is_derived"]) or ("customer request" in value["is_derived"])):
            not_derived_categories.append(value["category_value"])
            tier1s_selected_explanation[value["category_value"]]=value["category_explanation"]
            
    not_derived_categories=check_value(tier1s,not_derived_categories)
    tier1_evaluator_output, error2, llm_analytics2 =get_tier1_evaluator_prompt(input_text,not_derived_categories)
    tier_1_evaluator_parsed_output = parse_tier1_evaluator_output(tier1_evaluator_output)
    error = [error1, error2]
    llm_analytics = [llm_analytics1, llm_analytics2]

    for key, value in tier_1_evaluator_parsed_output.items():
        if value["category_rating"]!="0" and "category_value" in value and len(value["category_value"].strip())!=0:
            temp_list=check_value(tier1s,value["category_value"])
            if len(temp_list)>0 and "Others" not in temp_list:
                ## commented line is to use explanation from tier modelling
                # matched_items = [category.strip() for category in tier1s_selected_explanation.keys() if temp_list[0].strip().lower() in category.strip().lower()]
                # explanation=value["category_rating_explanation"]
                # if len(matched_items)>0:
                #     explanation=tier1s_selected_explanation[matched_items[0]]
                # final_output[temp_list[0]] = {"explanation": explanation, "rating": value["category_rating"]}

                ## this is to use tier1 evaluator explanation
                final_output[temp_list[0]] = {"explanation": value["category_rating_explanation"], "rating": value["category_rating"]}

    final_list = []
    for key,value in final_output.items():
        dict_ = {"category_value": key,
                 "category_rating_explanation": value["explanation"],
                 "category_rating": value["rating"]}
        final_list.append(dict_.copy())

    final_output = final_list

    return raw_output, parsed_output, not_derived_categories, tier1_evaluator_output, tier_1_evaluator_parsed_output, error, llm_analytics,final_output

import ast, json
def parse_json(input_string):
    input_string = input_string.replace("\n","")
    # Find the last occurrence of '{' and '}'
    start_index = input_string.rfind('{')
    end_index = input_string.rfind('}')

    extracted_json = {}
    # Ensure both '{' and '}' are found
    if start_index != -1 and end_index != -1 and start_index < end_index:
        # Extract the substring containing the last JSON object
        json_string = input_string[start_index:end_index+1]

        try:
            # Parse the JSON string
            extracted_json = json.loads(json_string)
            return extracted_json, ""
        except Exception as e:
            try:
                import ast
                extracted_json = ast.literal_eval(json_string)
                return extracted_json, ""
            except Exception as e:
                extracted_json = {}
                error = str(e)
                return {}, error
            
def parse_json2(input_string):
    input_string = input_string.replace("\n","")
    # Find the last occurrence of '{' and '}'
    start_index = input_string.rfind('[')
    end_index = input_string.rfind(']')
    extracted_json = {}
    json_string = input_string[start_index:end_index+1]
    output = ast.literal_eval(json_string)
    return output, ""
    
def parse_sub_tier_details(input_string):
    pattern = r'<sub_level>\s*<reasoning>(.*?)</reasoning>\s*<sub_level_name>(.*?)</sub_level_name>\s*</sub_level>'

    # Find all matches
    matches = re.findall(pattern, input_string, re.DOTALL)
    output_list = list()
    for match in matches:
        reason, category_name = match
        tmp = dict()
        tmp["classified_subtopic"] = category_name
        tmp["explanation"] = reason
        output_list.append(tmp)
    return output_list

def sub_tier_prompt(relevant_categories, issues_summary, tier1):
    #print("===================",tier1)
    system_prompt =ontology_prompt_and_definitions.entity_system_prompt
    u_input = ontology_prompt_and_definitions.entity_user_prompt.format(summary = issues_summary, tier1 = tier1, sub_topics = relevant_categories)
    message = [{"role": "system", "content":system_prompt }, {"role": "user", "content": u_input}]
    llm_client = get_llm_client()
    output, error, llm_analytics = get_llm_output(llm_client, message)
    return output, error, llm_analytics


def parse_entity_evaluation_output(raw_output_evaluation):
    category_check = -1
    entity_check = -1
    intent_check = -1
    output_temp=raw_output_evaluation.split("\n\n")
    for output_temp_i in output_temp:
        if output_temp_i.startswith("Entity:"):
            if "Yes" in output_temp_i:
                entity_check=1
            else:
                entity_check=0
        elif output_temp_i.startswith("Category:"):
            if "Yes" in output_temp_i:
                category_check=1
            else:
                category_check=0
        elif output_temp_i.startswith("Intent:"):
            if "Yes" in output_temp_i:
                intent_check=1
            else:
                intent_check=0
    if entity_check==1 and category_check==1 and intent_check==1:
        return "Yes"
    elif entity_check==-1 and category_check==-1 and intent_check==-1:
        return "No"
    return "No"

def parse_final_evaluation_output(input_string):
    # Regular expression pattern to parse the categories
    try:
        pattern = r"<(answer_\d+)>\s*<category_value>(.*?)</category_value>\s*<category_rating>(.*?)</category_rating>\s*<category_rating_explanation>(.*?)</category_rating_explanation>"

        # Find all matches
        matches = re.findall(pattern, input_string, re.DOTALL)
        ##print(matches)

        # Construct JSON-like structure
        categories = {}
        for match in matches:
            category_name = match[0]
            categories[category_name] = {
                "category_value": match[1].strip(),
                "category_rating": match[2].strip(),
                "category_rating_explanation": match[3].strip()
            }
        
        return categories

    except Exception as e:
        return ""

def get_entity_evaluator_prompt_1(input_text, tier1, category):
    required_descriptions = tier_1_evaluation_description(tier1, False)
    # #print("Entity evaluation description:",required_descriptions)

    user_prompt = ontology_prompt_and_definitions.entity_evaluation_user_prompt.format(input_text = input_text, category = category, required_descriptions = required_descriptions)

    message = [{"role": "system", "content": ontology_prompt_and_definitions.entity_evaluation_system_prompt}, {"role": "user", "content": user_prompt}]
    llm_client = get_llm_client()
    output, error, llm_analytics = get_llm_output(llm_client, message)
    return output, error, llm_analytics



def get_sub_entity_output(input_text, summary, sub_tier_to_pass, tier1, current_category):
    errors=[]
    analytics_list=[]
    raw_output, error, analytics = sub_tier_prompt(sub_tier_to_pass, input_text, current_category)
    #print("entity output", raw_output)
    errors.append(error)
    analytics_list.append(analytics)
    parsed_output = parse_sub_tier_details(raw_output)
    final_entities = []
    for item in parsed_output:
        final_entities.append(item["classified_subtopic"])
    updated_entities = []
    for item in final_entities:
        updated_value = check_value(sub_tier_to_pass, item)
        updated_entities.append(updated_value[0])
    final_entities = list(set(updated_entities))

    final_outputs=[]
    evaluation_raw_outputs = []
    evaluation_parsed_outputs = []
    for entity in final_entities:
        raw_output_evaluation, error, analytics = get_entity_evaluator_prompt_1(input_text, tier1, current_category+"/"+entity)
        errors.append(error)
        analytics_list.append(analytics)
        parsed_output_evaluation = parse_final_evaluation_output(raw_output_evaluation)#parse_entity_evaluation_output(raw_output_evaluation)
        evaluation_raw_outputs.append(raw_output_evaluation)
        for key, value in parsed_output_evaluation.items():
            ##print("value:", value)
            if entity in value["category_value"].strip():
                evaluation_parsed_outputs.append(value)
                final_output_ = {"selected_category":entity, "evaluation_output":value}
                final_outputs.append(final_output_)
                break

    return raw_output, parsed_output, evaluation_raw_outputs, evaluation_parsed_outputs, final_outputs, errors, analytics_list

def get_remaining_tiers_output(summary, classified_category):
    selected_tier1 = classified_category["tier1"]
    explanation = classified_category["explanation"]
    current_category = classified_category["category"]
    relevant_categories = get_tier_list(sub_tier = current_category)#list(set(df[df["tier1"==selected_tier1]].reset_index(drop=True)["Tier2"])
    ##print(f"{classified_category} : {relevant_categories}\n\n")
    relevant_categories = list(set([item for item in relevant_categories if (isinstance(item,str) and item.strip()!="")]))
    if 'nan' in relevant_categories:
        relevant_categories.remove('nan')
    ##print(len(relevant_categories))
    if len(relevant_categories) == 0:
        return None, None, None, None ,None,[],[], False
    elif (len(relevant_categories) == 1): #and (len(current_category.split("/"))>2):
        relevant_categories.append("Others")
        raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output ,errors, analytics = get_sub_entity_output(explanation, summary, relevant_categories, selected_tier1, current_category)

        for item2 in final_output:
            ##print(item2)
            if ("evaluation_output" in item2) and ('selected_category' in item2):
                # category_rating
                if item2["evaluation_output"]["category_rating"] in ["1"]:
                    if item2["selected_category"]==relevant_categories[0]:
                        final_output = [{"evaluation_output": {"category_rating": "1"}, "selected_category":relevant_categories[0]}]
                        return None, None, None, None, final_output, [], [], True

        return None, None, None, None ,None,[],[], False
    
    else: 
        #relevant_categories.append("Others")
        raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output ,errors, analytics = get_sub_entity_output(explanation, summary, relevant_categories, selected_tier1, current_category)
        return raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, errors, analytics, True
    
def get_descriptive_tags_output(summary, classified_category, tag_level, descriptive_tag_level1_value=""):
    selected_tier1 = classified_category["tier1"]
    explanation = classified_category["explanation"]
    current_category = classified_category["category"]
    relevant_categories = get_tier_list(sub_tier = current_category, descriptive_tags=True, descriptive_tag_level=tag_level, descriptive_tag_level1_value = descriptive_tag_level1_value)
    relevant_categories = list(set([item for item in relevant_categories if (isinstance(item,str) and item.strip()!="")]))
    if 'nan' in relevant_categories:
        relevant_categories.remove('nan')
    if len(relevant_categories) == 0:
        return None, None, None, None ,None,[],[], False
    elif len(relevant_categories) == 1:
        final_output = [{"evaluation_output": {"category_rating": "1"}, "selected_category":relevant_categories[0]}]
        ##print("final_output", final_output)
        return None, None, None, None, final_output, [], [], True
    else: 
        raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output ,errors, analytics = get_sub_entity_output(explanation, summary, relevant_categories, selected_tier1, selected_tier1)
        return raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, errors, analytics, True
    
def get_output(summary):
    category_list = []
    tier1_details = {}
    tier2_details = {}
    tier3_details = {}
    tier4_details = {}
    ### Tier 1
    raw_output, parsed_output, not_derived_categories, tier1_evaluator_output, tier1_evaluator_parsed_output, error, llm_analytics, tier1_output = get_tier1_classification(summary)

    tier1_details['raw_output'] = raw_output
    tier1_details['parsed_output'] = parsed_output
    tier1_details['tier1_evaluator_output'] = tier1_evaluator_output
    tier1_details['tier1_output'] = tier1_evaluator_parsed_output 
    tier1_details['error'] = error
    tier1_details['llm_analytics'] = llm_analytics
    tier1_details['final_output'] = tier1_output ## [Billing and Payment, Appeals and Grievances]
    # #print(tier1_output)

    ### Tier 2
    tier2_output = {}
    tier2_output['raw_output']=[]
    tier2_output['parsed_output']=[]
    tier2_output['evaluator_output'] = []
    tier2_output['evaluator_output_parsed'] =  []
    tier2_output["final_output"] = []  ## 
    tier2_output["error"] =  []
    tier2_output["llm_analytics"] = []

    if 'Tier2' in (ontology_df.columns):
        for item in tier1_output:
            count = 0
            dict_ = {"tier1": item["category_value"], "tier2": "", "tier3": "", "tier4": "", "tier5": "", "descriptive_tag1": "", "descriptive_tag2": "","category": item["category_value"], "explanation": item["category_rating_explanation"]}
            raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, errors, analytics, categories_to_classify = get_remaining_tiers_output(item["category_rating_explanation"], dict_.copy())
            if categories_to_classify:
                ##print("final", final_output)
                for item2 in final_output:
                    ##print(item2)
                    if ("evaluation_output" in item2) and ('selected_category' in item2):
                        # category_rating
                        if item2["evaluation_output"]["category_rating"] in ["0.5","1"]:
                            dict_["tier2"] = item2["selected_category"]
                            dict_["category"] = f'{dict_["tier1"]}/{dict_["tier2"]}'
                            count = count + 1
                            category_list.append(dict_.copy())

            else:
                category_list.append(dict_.copy())
                count = count +1
            if count == 0:
                dict_ = {"tier1": item["category_value"], "tier2": "Others", "tier3": "", "tier4": "", "tier5": "", "descriptive_tag1": "", "descriptive_tag2": "","category": f'{item["category_value"]}/Others', "explanation": item["category_rating_explanation"]}
                category_list.append(dict_.copy())
            
            tier2_output['raw_output'].append(raw_output)
            tier2_output['parsed_output'].append(parsed_output)
            tier2_output['evaluator_output'].append(raw_output2)
            tier2_output['evaluator_output_parsed'].append(parsed_output_evaluation)
        
            tier2_output["error"].append(errors)
            tier2_output["llm_analytics"].append(analytics)
        tier2_output["final_output"] = category_list.copy()
    ##print("Tier 2 Complete")

     ### Tier 3
    tier3_output = {}
    tier3_output['raw_output'] = []
    tier3_output['parsed_output'] = []
    tier3_output['evaluator_output'] = []
    tier3_output['evaluator_output_parsed'] =  []
    tier3_output["final_output"] = []
    tier3_output["error"] = []
    tier3_output["llm_analytics"] = []
    updated_list = []
    if 'Tier3' in (ontology_df.columns):
        ##print("output at start of tier3",category_list)
        for item in category_list:
            count = 0
            raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, errors, analytics, categories_to_classify = get_remaining_tiers_output(item["explanation"], item.copy())
            ##print("Tier start")
            ##print(raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, categories_to_classify)
            if categories_to_classify:
                for item2 in final_output:
                    if ("evaluation_output" in item2) and ('selected_category' in item2):
                        if item2["evaluation_output"]["category_rating"] in ["0.5","1"]:
                            item["tier3"] = item2["selected_category"]
                            item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}'
                            count = count + 1
                            updated_list.append(item.copy())

            else:

                updated_list.append(item.copy())
                count = count +1
            if count == 0:
                item["tier3"] = "Others"
                item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}'
                updated_list.append(item.copy())
        
            tier3_output['raw_output'].append(raw_output)
            tier3_output['parsed_output'].append(parsed_output)
            tier3_output['evaluator_output'].append(raw_output2)
            tier3_output['evaluator_output_parsed'].append(parsed_output_evaluation)
        
            tier3_output["error"].append(errors)
            tier3_output["llm_analytics"].append(analytics)
        category_list = updated_list.copy()
            
        tier3_output["final_output"] = category_list.copy()
    ##print("Tier 3 Complete")

    ### Tier 4
    tier4_output = {}
    tier4_output['raw_output']=[]
    tier4_output['parsed_output']=[]
    tier4_output['evaluator_output'] = []
    tier4_output['evaluator_output_parsed'] =  []
    tier4_output["final_output"] = []
    tier4_output["error"] =  []
    tier4_output["llm_analytics"] = []
    updated_list = []
    if 'Tier4' in (ontology_df.columns):
        for item in category_list:
            count=0
            raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, errors, analytics, categories_to_classify = get_remaining_tiers_output(item["explanation"], item.copy())
            if categories_to_classify:
                for item2 in final_output:
                    if ("evaluation_output" in item2) and ('selected_category' in item2):
                        if item2["evaluation_output"]["category_rating"] in ["0.5","1"]:
                            item["tier4"] = item2["selected_category"]
                            item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}/{item["tier4"]}'
                            count = count + 1
                            updated_list.append(item.copy())
            else:
                updated_list.append(item.copy())
                count = count +1
            if count == 0:
                item["tier4"] = "Others"
                item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}/{item["tier4"]}'
                updated_list.append(item.copy()) 
            tier4_output['raw_output'].append(raw_output)
            tier4_output['parsed_output'].append(parsed_output)
            tier4_output['evaluator_output'].append(raw_output2)
            tier4_output['evaluator_output_parsed'].append(parsed_output_evaluation)
        
            tier4_output["error"].append(errors)
            tier4_output["llm_analytics"].append(analytics)

        category_list = updated_list.copy()
            
        tier4_output["final_output"] = category_list.copy()


    ### Tier 5
    tier5_output = {}
    tier5_output['raw_output']=[]
    tier5_output['parsed_output']=[]
    tier5_output['evaluator_output'] = []
    tier5_output['evaluator_output_parsed'] =  []
    tier5_output["final_output"] = []
    tier5_output["error"] =  []
    tier5_output["llm_analytics"] = []
    updated_list = []
    if 'Tier5' in (ontology_df.columns):
        for item in category_list:
            count=0
            raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, errors, analytics, categories_to_classify = get_remaining_tiers_output(item["explanation"], item.copy())
            if categories_to_classify:
                for item2 in final_output:
                    if ("evaluation_output" in item2) and ('selected_category' in item2):
                        if item2["evaluation_output"]["category_rating"] in ["0.5","1"]:
                            item["tier5"] = item2["selected_category"]
                            item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}/{item["tier4"]}/{item["tier5"]}'
                            count = count + 1
                            updated_list.append(item.copy())
            else:
                updated_list.append(item.copy())
                count = count +1
            if count == 0:
                item["tier5"] = "Others"
                item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}/{item["tier4"]}/{item["tier5"]}'
                updated_list.append(item.copy()) 
            tier5_output['raw_output'].append(raw_output)
            tier5_output['parsed_output'].append(parsed_output)
            tier5_output['evaluator_output'].append(raw_output2)
            tier5_output['evaluator_output_parsed'].append(parsed_output_evaluation)
        
            tier5_output["error"].append(errors)
            tier5_output["llm_analytics"].append(analytics)

        category_list = updated_list.copy()
            
        tier5_output["final_output"] = category_list.copy()

    ##print("Tier classification complete", category_list)

    
    ## Descriptive Tag1
    tag1_output = {}
    tag1_output['raw_output']=[]
    tag1_output['parsed_output']=[]
    tag1_output['evaluator_output'] = []
    tag1_output['evaluator_output_parsed'] =  []
    tag1_output["final_output"] = []
    tag1_output["error"] =  []
    tag1_output["llm_analytics"] = []
    updated_list = []
    if "DescriptiveTag1" in (ontology_df.columns):
        for item in category_list:
            count=0
            raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, errors, analytics, categories_to_classify = get_descriptive_tags_output(item["explanation"], item.copy(), "First")
            ##print("in tag1 1", final_output)
            if categories_to_classify:
                for item2 in final_output:
                    if ("evaluation_output" in item2) and ('selected_category' in item2):
                        if item2["evaluation_output"]["category_rating"] in ["0.5","1"]:
                            item["descriptive_tag1"] = item2["selected_category"]
                            item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}/{item["tier4"]}/{item["tier5"]}/{item["descriptive_tag1"]}'
                            count = count + 1
                            updated_list.append(item.copy())
            else:
                updated_list.append(item.copy())
                count = count +1
            if count == 0:
                item["descriptive_tag1"] = "Others"
                item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}/{item["tier4"]}/{item["tier5"]}/{item["descriptive_tag1"]}'
                updated_list.append(item.copy()) 
            tag1_output['raw_output'].append(raw_output)
            tag1_output['parsed_output'].append(parsed_output)
            tag1_output['evaluator_output'].append(raw_output2)
            tag1_output['evaluator_output_parsed'].append(parsed_output_evaluation)
        
            tag1_output["error"].append(errors)
            tag1_output["llm_analytics"].append(analytics)

        category_list = updated_list.copy()
            
        tag1_output["final_output"] = category_list.copy()
    ##print("Tag1  classification complete", category_list)

    tag2_output = {}
    tag2_output['raw_output']=[]
    tag2_output['parsed_output']=[]
    tag2_output['evaluator_output'] = []
    tag2_output['evaluator_output_parsed'] =  []
    tag2_output["final_output"] = []
    tag2_output["error"] =  []
    tag2_output["llm_analytics"] = []
    updated_list = []
    if "DescriptiveTag2" in (ontology_df.columns):
        ## Descriptive Tag2
        for item in category_list:
            count=0
            raw_output, parsed_output, raw_output2, parsed_output_evaluation, final_output, errors, analytics, categories_to_classify = get_descriptive_tags_output(item["explanation"], item.copy(), "Second", item["descriptive_tag1"])
            if categories_to_classify:
                for item2 in final_output:
                    if ("evaluation_output" in item2) and ('selected_category' in item2):
                        if item2["evaluation_output"]["category_rating"] in ["0.5","1"]:
                            item["descriptive_tag2"] = item2["selected_category"]
                            item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}/{item["tier4"]}/{item["tier5"]}/{item["descriptive_tag1"]}/{item["descriptive_tag2"]}'
                            count = count + 1
                            updated_list.append(item.copy())
            else:
                updated_list.append(item.copy())
                count = count +1
            if count == 0:
                item["descriptive_tag1"] = "Others"
                item["category"] = f'{item["tier1"]}/{item["tier2"]}/{item["tier3"]}/{item["tier4"]}/{item["tier5"]}/{item["descriptive_tag1"]}/{item["descriptive_tag2"]}'
                updated_list.append(item.copy()) 
            tag2_output['raw_output'].append(raw_output)
            tag2_output['parsed_output'].append(parsed_output)
            tag2_output['evaluator_output'].append(raw_output2)
            tag2_output['evaluator_output_parsed'].append(parsed_output_evaluation)
        
            tag2_output["error"].append(errors)
            tag2_output["llm_analytics"].append(analytics)

        category_list = updated_list.copy()
            
        tag2_output["final_output"] = category_list.copy()
    ##print("Tag2 classification complete", category_list)
    return category_list, tier1_details, tier2_output, tier3_output, tier4_output, tier5_output, tag1_output, tag2_output

def parse_summary(input_string):
    try:
        parsed_output = input_string.replace('\n','').replace('Summary:','').strip()
        splitted_sentences = parsed_output.split(".")
        splitted_sentences = [item.strip() for item in splitted_sentences if item.strip()!=""]
        updated_sentences_list = []
        for item in splitted_sentences:
            if not updated_sentences_list or item != updated_sentences_list[-1]:
                updated_sentences_list.append(item)
        ## Required for dashboard
        limited_summary = ""
        for item in updated_sentences_list:
            if len(item) + len(limited_summary) < 5000:
                limited_summary = limited_summary + f"{item}. "
            else:
                break
        return limited_summary, ""
    except Exception as e:
        return "", str(e)

def generate_issues(transcript):
    system_prompt = ontology_prompt_and_definitions.summary_system_prompt
    user_prompt = ontology_prompt_and_definitions.summary_user_prompt.format(transcript=transcript)

    messages = [{"role": "system", "content": system_prompt}, {"role":"user", "content": user_prompt}]
    error=[]
    output, error1, llm_analytics = get_llm_output(llm_client, messages)
    error.append(error1)
    if error1=="":
        parsed_output,error2=parse_summary(output)
        error.append(error2)
        return parsed_output,error,llm_analytics
    return "",error,{}

### Check for customer intent in other cases

def parse_check_for_customer_intent_output(input_string):
    pattern = r"<answer>(.*?)</answer>"
    matches = re.findall(pattern, input_string, re.DOTALL)

    for match in matches:
        check = match.strip()
        if "yes" in check.lower():
            return "Yes"
        else:
            return "No"
    return "Yes"

def check_for_customer_intent(input_text):
    system_prompt = ontology_prompt_and_definitions.presence_of_intent_system_prompt
 
    user_prompt = ontology_prompt_and_definitions.presence_of_intent_user_prompt.format(input_text = input_text)
 
    messages = [{"role": "system", "content": system_prompt}, {"role":"user", "content": user_prompt}]
    error=[]
    output, error1, llm_analytics = get_llm_output(llm_client, messages)
    error.append(error1)
    if error1=="":
        parsed_output=parse_check_for_customer_intent_output(output)
        return parsed_output,error,llm_analytics
    return "",error,{}

def generate_intent_reasons(input_text, category):
    system_prompt = ontology_prompt_and_definitions.reasons_system_prompt

    user_prompt = ontology_prompt_and_definitions.reasons_user_prompt.format(summary = input_text, category = category)

    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    error=[]
    output, error1, llm_analytics = get_llm_output(llm_client, messages)
    error.append(error1)
    return output, error, llm_analytics
    
def update_json_list(json_list):
    updated_list = []
    already_generated_categories = []
    len_ = len(json_list)
    for item in json_list:
        if len_>1 and item["tier1"] == "Others":
            continue
        if item["tier1"]!="":
            if item["category"] not in already_generated_categories:
                already_generated_categories.append(item["category"])
                updated_list.append(item)
    json_list = updated_list
    # Group entries by tier1
    grouped = {}
    
    for entry in json_list:
        tier1_value = entry["tier1"]
        if tier1_value not in grouped:
            grouped[tier1_value] = []
        grouped[tier1_value].append(entry)
    
    filtered_json = []
    
    # Process each group
    for tier1_value, group in grouped.items():
        # Check if there are entries with tier2 == "Others" and tier3 == ""
        valid_entries = []
        for entry in group:
            if entry["tier2"] == "Others" and entry["tier3"] == "":
                # Only keep "Others" with empty tier3 if there are no valid alternatives
                if not any(e["tier2"] != "Others" or e["tier3"] != "" for e in group):
                    valid_entries.append(entry)
            else:
                valid_entries.append(entry)
        
        # Add valid entries for this tier1 group
        filtered_json.extend(valid_entries)
    
    return filtered_json


def get_overall_evaluation_prompt_messages(summary, hierarchies, description):
    description = f"```Description: {description}```"
    system_prompt = ontology_prompt_and_definitions.final_evaluation_system_prompt

    user_prompt = ontology_prompt_and_definitions.final_evaluation_user_prompt.format(input_text = summary, hierarchies = hierarchies, description = description)

    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    return messages

def parse_final_evaluation_outputv2(input_text):
    pattern = r'<validation_result>\s*<hierarchy>(.*?)</hierarchy>\s*<reasoning>(.*?)</reasoning>\s*<score>(.*?)</score>\s*</validation_result>'

    # Find all matches
    matches = re.findall(pattern, input_text, re.DOTALL)

    # Create a list of JSON objects from the matches
    json_output = []
    for match in matches:
        hierarchy, reasoning, score = match
        json_output.append({
            'hierarchy': hierarchy.strip(),
            'reasoning': reasoning.strip(),
            'score': int(score.strip())
        })
    return json_output


def get_final_evaluated_output(classified_category, summary):
    tier1s = []
    categories = []
    for item in classified_category:
        tier1s.append(item["tier1"])
        val = item["category"]
        if item["tier4"].strip()!="":
            val = val + "/" + item["tier4"].strip()
        if item["tier5"].strip()!="":
            val = val + "/" + item["tier5"].strip()
        item["full_category"] = val
        categories.append(val)
    descriptions = tier_1_evaluation_description(list(set(tier1s)))
    message = get_overall_evaluation_prompt_messages(summary, categories, descriptions)
    llm_client = get_llm_client()
    raw_output, error1, llm_analytics1 = get_llm_output(llm_client, message)

    parsed_output = parse_final_evaluation_outputv2(raw_output)

    updated_categories = []
    for item in classified_category:
        flag = 0
        for item1 in parsed_output:
            if item["full_category"].strip() == item1["hierarchy"].strip():
                if item1["score"] == 1:
                    flag = 1
        if flag ==1 :
            updated_categories.append(item)
    return updated_categories,parsed_output

def remove_others(classified_category):
    classified_category_list=[]
    temp_classified_category=[]
    for temp_category in classified_category:
        temp_full_category= temp_category["tier1"]
        if temp_category["tier2"].strip() != "":
            temp_full_category = temp_full_category + "/" + temp_category['tier2'].strip()
        if temp_category["tier3"].strip() != "":
            temp_full_category = temp_full_category + "/" + temp_category['tier3'].strip()
        if temp_category["tier4"].strip() != "":
            temp_full_category = temp_full_category + "/" + temp_category['tier4'].strip()
        if temp_category["tier5"].strip() != "":
            temp_full_category = temp_full_category + "/" + temp_category['tier5'].strip()
        if temp_category["descriptive_tag1"].strip() != "":
            temp_full_category = temp_full_category + "/" + temp_category['descriptive_tag1'].strip()
        if temp_category["descriptive_tag2"].strip() != "":
            temp_full_category = temp_full_category + "/" + temp_category['descriptive_tag2'].strip()

        temp_full_category=temp_full_category.strip("/")
        temp_category['full_category']=temp_full_category
        temp_classified_category.append(temp_category)
        classified_category_list.append(temp_full_category)

    tier1_count=Counter(temp['tier1'] for temp in temp_classified_category)
    valid_tier1=set()
    for temp in temp_classified_category:
        if "Others" not in temp['full_category']:
            valid_tier1.add(temp['tier1'])

    filtered_data=[]
    for temp in temp_classified_category:
        if tier1_count[temp['tier1']]>=2 and "Others" in temp['full_category'] and temp['tier1'] in valid_tier1:
            continue
        filtered_data.append(temp)
    return filtered_data

def get_replaced_correct_hierarchy(category, explanation):
    system_prompt = ontology_prompt_and_definitions.partially_correct_system_prompt
    user_prompt = ontology_prompt_and_definitions.partially_correct_user_prompt.format(category = category, explanation = explanation)

    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}] 
    llm_client = get_llm_client()
    raw_output, error1, llm_analytics1 = get_llm_output(llm_client, messages)
    parsed_output = re.findall(r'<corrected_hierachy>(.*?)</corrected_hierachy>', raw_output, re.DOTALL)
    if len(parsed_output) == 0:
        return ""
    return parsed_output[0].strip()

def keep_single_tier1(classified_category,evaluated_output):
    added_tier1=[]
    filtered_data=[]
    for temp in classified_category:
        if temp['tier1'] not in added_tier1:
            val = temp["category"]
            if temp["tier4"].strip()!="":
                val = val + "/" + temp["tier4"].strip()
            if temp["tier5"].strip()!="":
                val = val + "/" + temp["tier5"].strip()
            #print("vall: ",val)
            temp['full_category']=val
            temp['reasoning']=""
            for item in evaluated_output:
                if val == item["hierarchy"].strip():
                    if "reasoning" in item:
                        temp['reasoning']=item['reasoning']
                    break
            filtered_data.append(temp)
            added_tier1.append(temp['tier1'])

    filtered_data_1=[]
    for temp in filtered_data:
        if temp['reasoning']!="":
            temp_category=get_replaced_correct_hierarchy(temp['full_category'],temp['reasoning'])
            if temp_category!="":
                valid_level=[]
                splited_temp=temp_category.split("/")
                for i in range(0,len(splited_temp)):
                    current_tier=splited_temp[i]
                    if current_tier.lower().strip()=="incorrect" or current_tier.lower().strip()!=temp[f'tier{i+1}'].lower().strip():
                        break
                    valid_level.append(current_tier)
                if len(valid_level)!=0:
                    if len(valid_level)==1:
                        temp["tier2"]="Others"
                        temp["tier3"]=""
                        temp["tier4"]=""
                        temp["tier5"]=""
                    elif len(valid_level)==2:
                        temp["tier3"]="Others"
                        temp["tier4"]=""
                        temp["tier5"]=""
                    elif len(valid_level)==3:
                        temp["tier4"]="Others"
                        temp["tier5"]=""
                    elif len(valid_level)==4:
                        temp["tier5"]="Others"
                category=temp["tier1"]
                if temp["tier2"]!="":
                    category = category + "/" + temp["tier2"]
                if temp["tier3"]!="":
                    category = category + "/" + temp["tier3"]
                temp['category']=category
                temp['full_category']=""
                temp['descriptive_tag1']=""
                temp['descriptive_tag2']=""
                temp['other_flag']=True
                filtered_data_1.append(temp)
            else:
                temp['tier2']="Others"
                temp['tier3']=""
                temp['tier4']=""
                temp['tier5']=""
                temp['category']=temp['tier1']+"/Others"
                temp['full_category']=temp['tier1']+"/Others"
                temp['descriptive_tag1']=""
                temp['descriptive_tag2']=""
                temp['other_flag']=True
                filtered_data_1.append(temp)
        else:
            temp['tier2']="Others"
            temp['tier3']=""
            temp['tier4']=""
            temp['tier5']=""
            temp['category']=temp['tier1']+"/Others"
            temp['full_category']=temp['tier1']+"/Others"
            temp['descriptive_tag1']=""
            temp['descriptive_tag2']=""
            temp['other_flag']=True
            filtered_data_1.append(temp)
    if len(filtered_data_1)==1:
        if filtered_data_1[0]['category']=="":
            return [{"category": "Unidentified", "tier1": "Unidentified", "tier2": "", "tier3": "", "tier4": "", "tier5": "", "descriptive_tag1": "", "descriptive_tag2": "","reason":""}]
    return filtered_data_1
        
def change_others_to_unidentified(input_list):
    for i in range(len(input_list)):
        if input_list[i]['tier2'] == "Others":
            input_list[i]['tier2'] = "Unidentified"
        if input_list[i]['tier3'] == "Others":
            input_list[i]['tier3'] = "Unidentified"
        if input_list[i]['tier4'] == "Others":
            input_list[i]['tier4'] = "Unidentified"
        if input_list[i]['tier5'] == "Others":
            input_list[i]['tier5'] = "Unidentified"
        temp_full_category= input_list[i]["tier1"]
        if input_list[i]["tier2"].strip() != "":
            temp_full_category = temp_full_category + "/" + input_list[i]['tier2'].strip()
        if input_list[i]["tier3"].strip() != "":
            temp_full_category = temp_full_category + "/" + input_list[i]['tier3'].strip()
        input_list[i]['category'] = temp_full_category
    return input_list


def strip_dataframe(df):
    df = df.apply(lambda x: x.str.strip() if isinstance(x, str) else x)
    return df

def ontology_classification(transcript, transcript_id):
    global ontology_df, llm_client
    if ontology_df is None:
        ontology_df = pd.read_excel(os.environ['ontology_sheet_path'], sheet_name=os.environ['ontology_sheet_name'])
        ontology_df = strip_dataframe(ontology_df)
    if llm_client is None:
        llm_client = get_llm_client()
        
    result = {'issues_summary': {}, 'tier1_classification': {}, 'evaluation_output': {}}
    issue_summary, error, llm_analytics = generate_issues(transcript)
    # issue_summary, error, llm_analytics = transcript,"",{}
    result["issues_summary"]['output'] = issue_summary
    result["issues_summary"]['error'] = error
    result["issues_summary"]['llm_analytics'] = llm_analytics

    category_list, tier1_output, tier2_output, tier3_output, tier4_output, tier5_output, tag1_output, tag2_output = get_output(issue_summary)

    result["tier1_classification"] = tier1_output
    result["tier2_classification"] = tier2_output
    result["tier3_classification"] = tier3_output
    result["tier4_classification"] = tier4_output 
    result["tier5_classification"] = tier5_output 
    result["descriptive_tag1_classification"] = tag1_output 
    result["descriptive_tag2_classification"] = tag2_output 

    #print(category_list)
    result["final_output"] = update_json_list(category_list.copy())
    #print(category_list)
    if len(result["final_output"]) == 0:
        result["final_output"] = [{"category": "Unidentified", "tier1": "Unidentified", "tier2": "", "tier3": "", "tier4": "", "tier5": "", "descriptive_tag1": "", "descriptive_tag2": ""}]
    result["reasons"]=[]
    ## Generate reasons for categorization
    for i in range(len(result["final_output"])): 
        if result["final_output"][i]["category"] != "Unidentified" or result["final_output"][i]["tier1"] != "Unidentified":
            output ,error, analytics = generate_intent_reasons(issue_summary, "Others")
        else:
            output ,error, analytics = generate_intent_reasons(issue_summary, result["final_output"][i]["category"])
        result["final_output"][i]["reason"] = output
        result["reasons"].append({"error": error, "llm_analytics": analytics, "raw_output": output})
    ##print(result["final_output"])
    for i in range(len(result["final_output"])):
        if result["final_output"][i]["category"] != "Unidentified" or result["final_output"][i]["tier1"] != "Unidentified":
            category=result["final_output"][i]["tier1"]
            if result["final_output"][i]["tier2"]!="":
                category = category + "/" + result["final_output"][i]["tier2"]
            if result["final_output"][i]["tier3"]!="":
                category = category + "/" + result["final_output"][i]["tier3"]
            result["final_output"][i]["category"] = category

    result['final_output']=remove_others(result["final_output"])
    if len(result["final_output"]) ==1 and result["final_output"][0]["category"] == "Unidentified" or result["final_output"][0]["tier1"] == "Unidentified":
        pass
    else:
        evaluate_output,parsed_output=get_final_evaluated_output(result["final_output"], result["issues_summary"]['output'])
        result["final_evaluate_output"] = parsed_output
        if len(evaluate_output) != 0:
            result["final_output"] = evaluate_output
        else:
            result["final_output"] = keep_single_tier1(result["final_output"],parsed_output)

    if len(result["final_output"]) == 0 or (len(result["final_output"])==1 and result["final_output"][0]['category'] == "Unidentified"):
        customer_intent_present, error, llm_analytics = check_for_customer_intent(issue_summary)
    else:
        customer_intent_present = "Yes"
    result['final_output'] = change_others_to_unidentified(result['final_output'])
    result["evaluation_output"]["customer_intent_present"] = customer_intent_present
    ##print(f"\n\n\n###Summary: {result['issues_summary']['output']}\n\nOntology Process Complete\n######\n\n\n{result['final_output']}")
    return result