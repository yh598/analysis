import json
import re
import ast
import copy
import pandas as pd
from openai import AzureOpenAI, OpenAI
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
import os
import time
from retry import retry
from generic_pipeline.insights_prompt import call_complexity_user_prompt

percentile_for_simple = 300
percentile_for_complex = 1440

simple_intent_list=[]

def get_simple_intent_list():
    global simple_intent_list
    simple_intent_df = pd.read_excel(os.environ['simple_intent_list_path'])
    simple_intent_list= list(simple_intent_df['SimpleIntents'])
    simple_intent_list = [x.lower().strip("/").strip() for x in simple_intent_list]
    if "nan" in simple_intent_list:
        simple_intent_list.remove("nan")
llm_client = None


### LLM Client
def get_llm_client():
    client = OpenAI(
        api_key = os.environ['openai_databricks_token'],
        base_url = os.environ['base_url']
       
    )
    return client
## generate output from llm

@retry(Exception , tries=3, delay=2)
def output_from_llm(client, messages, deployment_id, max_tokens=None):
    try:
        if max_tokens==None:
            response = client.chat.completions.create(
                model = deployment_id,
                messages = messages,
                temperature=0.0,
                seed=42
            )
        else:
            response = client.chat.completions.create(
                model = deployment_id,
                messages=messages,
                seed=42,
                temperature=0.0,
                max_tokens=max_tokens
            )
        end = time.time()
        return response
    except Exception as e:
        raise
    

## get output using the mentioned model
def get_llm_output(client, messages, max_tokens=None):
    try:
        deployment_id = os.environ['model_gpt_4o_mini']
        st = time.time()
        response = output_from_llm(client, messages, deployment_id, max_tokens)
        output = response.choices[0].message.content
        end = time.time()
        analytics = {"messages":messages,"raw_output":output,"llm_time_taken":end - st,"input_token_size":response.usage.prompt_tokens,"output_token_size":response.usage.completion_tokens}
        error = ""
    except Exception as e:
        output = ""
        error = str(e)
        analytics = {}
    return output, error, analytics


def check_the_intent_list(full_category_list):
    global simple_intent_list 
    for item in full_category_list:
        if item.strip().lower() not in simple_intent_list:
            return False
    return True

### Step 1: check if call duration is less than 20th percentile, if yes, Tends to be Simple
def check_call_length(metadata): 
    time_in_seconds = metadata["Duration_seconds"]
    if int(time_in_seconds) < percentile_for_simple:
        return {"call_complexity": "Tends to be Simple", "explanation": f"call duration less than 20 th percentile ({percentile_for_simple} seconds)", "decision_logic": "rule based"}
    else:
        return {"call_complexity": "not determined", "explanation": "", "decision_logic": ""}


### Step 2 , check for 80th percentile, if yes tag call as complex.
def compare_call_duration_with_80th_percentile(metadata):
    if int(metadata["Duration_seconds"]) > percentile_for_complex:
        return {"call_complexity": "Tends to be Complex", "explanation": f"call duration more than 80th percentile ({percentile_for_complex} seconds)", "decision_logic": "rule based"}
    return {"call_complexity": "not determined", "explanation": "", "decision_logic": ""}


### Step 3: Check the number of intents present
def check_number_of_intents(metadata, classified_category):
    max_threshold_value = 5
    if len(classified_category)>=max_threshold_value:
        if check_the_intent_list(classified_category):
            return {"call_complexity": "Tends to be Simple", "explanation": f"All intents are part of simple intent list", "decision_logic": "rule based"}
        else:
            return {"call_complexity": "Tends to be Complex", "explanation": "contains more than five complex intents", "decision_logic": "rule based"}
    return {"call_complexity": "not determined", "explanation": "", "decision_logic": ""}
    
### Step 4: Cehck using LLM

def parse_call_complexity(output):
    
    try:
        # explanation = output.split("<explanation>")[1].split("</explanation>")[0].strip()
        explanation = output.replace("<type_of_call>","").replace("</type_of_call>","").replace("<explanation>","").replace("</explanation>","").strip("\n").strip()
        if "<type_of_call>informational call</type_of_call>" in output:
            parsed_output = {"call_complexity":"Tends to be Simple","explanation":explanation, "decision_logic": "llm based"}
        else:
            parsed_output = {"call_complexity":"Tends to be Complex","explanation":explanation, "decision_logic": "llm based"}
        return parsed_output, ""
    except Exception as e:
        return  {"call_complexity":"Tends to be Simple","explanation":output, "decision_logic": "llm based"}, str(e)


def call_complexity_prompt_v1(transcript):
    user_prompt = call_complexity_user_prompt.format(input_text = transcript)
   
    message = [{"role": "user", "content": user_prompt}]
    global llm_client
    if llm_client is None:
        llm_client = get_llm_client()
    output, error, analytics=get_llm_output(llm_client,message) 
    parsed_output, error2 = parse_call_complexity(output)
    return output, parsed_output, error,analytics


def call_complexity_output(transcript, metadata, classified_category):
    ### Check for 20th percentile
    output = check_call_length(metadata)
    #Tends to be Simple
    if output["call_complexity"] == "Tends to be Simple":
        ## if this condition is passed continue for next steps
        pass
    else:
        ## if call duration is mre than 80th percetile, return the output
        output = compare_call_duration_with_80th_percentile(metadata)
        if output["call_complexity"] == "Tends to be Complex":
            return output,"",{}
        else:
            ## if number of intents for current is five or more than five and is not part of simple intent list, return the output.
            output = check_number_of_intents(metadata, classified_category)
            if output["call_complexity"] == "Tends to be Complex":
                return output,"",{}
            
    ## call which does not satisfy above condition and output is still undetermined, then we use llm to determine.
    if output["call_complexity"] != "Tends to be Simple" and output["call_complexity"] != "Tends to be Complex":
        output, parsed_output, error,analytics = call_complexity_prompt_v1(transcript)
        ## if model predicts complex, then return the output
        if parsed_output["call_complexity"] ==  "Tends to be Complex":
            return parsed_output, error,analytics
    
    ##further calssify tend s to be simple calls into Simples and Moderate.

    if check_the_intent_list(classified_category):
        return {"call_complexity": "Very Simple", "explanation": f"All intents are part of simple intent list", "decision_logic": "llm + rule based"}, "",{}
    else:
        return {"call_complexity": "Moderately Simple", "explanation": f"Intents not part of simple ntent list", "decision_logic": "llm + rule based"}, "",{}
    
def get_call_complexity(transcript, metadata, classified_category): 
    if len(simple_intent_list)==0:
        get_simple_intent_list()
    output,error,analytics = call_complexity_output(transcript, metadata, classified_category)
    return {"errors":error, "llm_analytics":analytics, "call_complexity":output["call_complexity"], "explanation":output["explanation"], "decision_logic":output["decision_logic"]}



