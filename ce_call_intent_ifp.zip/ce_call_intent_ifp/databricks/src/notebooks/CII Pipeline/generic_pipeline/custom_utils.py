from datetime import datetime
import shutil
import json
import os
import tiktoken
from dateutil import parser
from collections import Counter


from generic_pipeline.lob_map import lob_mapping
class SFUtils:
    def __init__(self, config=None):
        self.config = config
    def get_input_values(self, data):
        #print("reading data")
        try:
            if isinstance(data, dict):
                #print(data)
                start_time,start_date=self.parse_date_time(data["metadata"]["Local_audio_start_time"])
                end_time,end_date=self.parse_date_time(data["metadata"]["Local_audio_end_time"])
                if "metadata" in data:
                    return data["mediaId"], data["plainTextTime"]["verbatims"], data["language"], start_time,start_date, end_time, end_date , data["metadata"]["Agent_name"], data["metadata"]["Direction"], data["metadata"], ""
                else:
                    return None, None, None, None, None, None, None , None, None, None, "Data Issue"

            else:
                return None, None, None, None, None, None, None , None, None, None, "Data not present in dictonary"
        except Exception as e:
            return None, None, None, None, None, None, None , None, None, None, "Data Issue"

    def get_lob_name(self, org_id):
            try:
                if str(org_id) in [org["org_id"] for org in lob_mapping]:
                    return [org["name"] for org in lob_mapping if org["org_id"] == str(org_id)][0]
                else:
                    return ""
            except Exception as e:
                return ""

    def clean_transcript(self,transcript):
        clean_transcript=""
        for i in range(len(transcript)):
            if  transcript[i]["sp"]=="Customer":
                text= "Customer: "+transcript[i]["w"]
            elif  transcript[i]["sp"] == "Agent":
                text= "Agent: "+ transcript[i]["w"]
            else:
                text=  transcript[i]["sp"] + ": " + transcript[i]["w"]
            clean_transcript+=text+"\n"
        return clean_transcript
    
    def get_speaker_talk_time(self,utterances):
        self.agent_talk_time_in_secs = 0.0
        self.customer_talk_time_in_secs = 0.0
        for utterance in utterances:
            start_time = utterance['start_time']
            end_time  = utterance['end_time']
            if utterance["speaker"] == "Agent":
                self.agent_talk_time_in_secs+=(end_time-start_time)
            else:
                self.customer_talk_time_in_secs+=(end_time-start_time)
    def get_token_count(self, outputs):
        number_of_hit=0
        total_input_token=0
        total_output_token=0
        try:
            for ouput in outputs:
                for k,v in ouput.items():
                    result=v['result']
                    for k1,v1 in result.items():
                        if 'llm_analytics' in v1 and isinstance(v1['llm_analytics'], list):
                            for i in v1['llm_analytics']:
                                if 'llm_time_taken' in i:
                                    number_of_hit += 1
                                    total_input_token += i['input_token_size']
                                    total_output_token += i['output_token_size']  
                        elif 'llm_analytics' in v1 :
                            if 'llm_time_taken' in v1:
                                number_of_hit += 1
                                total_input_token += v1['llm_analytics']['input_token_size']
                                total_output_token += v1['llm_analytics']['output_token_size']
        except Exception as e:
            print(e)
        return number_of_hit, total_input_token, total_output_token


    def get_call_direction(self, call_direction_digit):
        if call_direction_digit==1:
            direction="Inbound"
        elif call_direction_digit==2:
            direction="Outbound"
        elif call_direction_digit==3:
            direction="Internal"
        else:
            direction=""
        return direction
    
    def standardize_call_reasons(self, call_reasons):
        for i in range(len(call_reasons)):
            ontology = ""
            if call_reasons[i]['tier1'] != "":
                ontology = call_reasons[i]['tier1']
            if call_reasons[i]['tier2'] != "":
                ontology = ontology + "/" + call_reasons[i]['tier2']
            if call_reasons[i]['tier3'] != "":
                ontology = ontology + "/" + call_reasons[i]['tier3']
            call_reasons[i]['category'] = ontology
        return call_reasons
    
    def to_final_json(self,outputs,transcript,transcript_id, original_transcript, language, start_time, start_date, end_time, end_date, agent_name, call_direction, meta_data,total_time_taken,number_of_hit,total_input_token,total_output_token):
        self.transcript = transcript
        cii_output = {"cii_output": dict()}
        #print("in final json method")
        utterances = self.get_utterances(original_transcript)
        self.get_speaker_talk_time(utterances)
        process_date, process_time=self.get_current_date_and_time()
        info_dict = dict()  
        speech_module_dict = dict()
        info_dict['id'] = transcript_id
        info_dict['conversation_filename'] = transcript_id
        info_dict['conversation_length_sec'] = meta_data["Duration_seconds"]
        info_dict['conversation_language'] = language
        info_dict['conversation_start_date'] = start_date
        info_dict['conversation_end_date'] = end_date
        info_dict['conversation_start_time'] = start_time
        info_dict['conversation_end_time'] = end_time
        info_dict['conversation_processed_date'], info_dict['conversation_process_time'] = process_date, process_time
        info_dict['agent_talk_time_in_sec'] = self.agent_talk_time_in_secs  
        info_dict['customer_talk_time_in_sec'] = self.customer_talk_time_in_secs
        info_dict['total_time_taken'] = total_time_taken
        info_dict['total_number_of_llm_hit'] =number_of_hit
        info_dict['total_input_token'] = total_input_token
        info_dict['total_output_token'] = total_output_token
        if "CD93" not in meta_data:
            meta_data["CD93"] = ""
        if "CD48" not in meta_data:
            meta_data["CD48"] = ""
        if "CD6" not in meta_data:
            meta_data["CD6"] = ""
        if "CD69" not in meta_data:
            meta_data["CD69"] = ""
        if "CD8" not in meta_data:
            meta_data["CD8"] = ""
        info_dict['source_metadata'] = meta_data
        info_dict["LOB"] = self.get_lob_name(meta_data['org_id'])
        speech_module_dict['transcript'] = transcript
        speech_module_dict['utterance_level'] = utterances
        cii_output['cii_output']['info'] = info_dict
        cii_output['cii_output']['speech_module_output'] = speech_module_dict
        overall_level = {}
        overall_level['insights_module_output'] = outputs
        overall_level['call_driver_hierarchy']= self.populate_insights(outputs)
        cii_output['cii_output']['overall_level']=overall_level
        return cii_output
    
    def check_len(self, list_):
        updated_list = []
        current_list = []
        for item in list_:
            current_len = len("\n\n".join(current_list))
            if len("\n\n"+item)<(100000-current_len):
                current_list.append(item)
            else:
                updated_list.append(current_list)
                current_list = []
                current_list.append(item)
        updated_list.append(current_list)
        return updated_list
    
    def get_full_category_string(self, classifed_category, tag1, tag2):
        if isinstance(tag1, float) or tag1.strip()=="":
            return f"""{classifed_category}"""
        else:
            if isinstance(tag2, float) or tag2.strip()=="":
                return f"""{classifed_category}\nDescriptive Tag1: {tag1}"""
            else:
                return f"""{classifed_category}\nDescriptive Tag1: {tag1}\nDescriptive Tag2: {tag2}"""
            
    def get_category_combo(self, ontology):
        categories = []
        for onto in ontology:
            categories.append(self.get_full_category_string(onto["category"], onto["descriptive_tag1"], onto["descriptive_tag2"]))
            #categories.append(self.get_full_category_string(onto["category"],"", ""))
        categories = self.check_len(categories)
        return categories
            
    def remove_others():
        ""
    
    def get_additional_category_values(self,  ontology):
        tier1 = []
        tier1_2_list = []
        full_category = [] 
        for i in range(len(ontology)): 
            value = ""
            tier1_2 = ""
            if ontology[i]['tier1']!="":
                value = ontology[i]['tier1']
                if ontology[i]['tier1'] not in tier1:
                    tier1.append(ontology[i]['tier1'])
                tier1_2 = ontology[i]['tier1']
            if ontology[i]['tier2']!="":
                value = value + "/" + ontology[i]['tier2']
                tier1_2 = tier1_2 + "/" + ontology[i]['tier2']
            if ontology[i]['tier3']!="":
                value = value + "/" + ontology[i]['tier3']
            if ontology[i]['descriptive_tag1']!="":
                value = value + "/" + ontology[i]['descriptive_tag1']
            if ontology[i]['descriptive_tag2']!="":
                value = value + "/" + ontology[i]['descriptive_tag2']
            full_category.append(value)
            if tier1_2 not in tier1_2_list:
                tier1_2_list.append(tier1_2)
        full_category_string_list = self.get_category_combo(ontology)
        return "\n\n".join(tier1), "\n\n".join(tier1_2_list), "\n".join(full_category), full_category_string_list

    def check_sentiment(self, insights):
        if insights['customer_sentiment_towards_bsc'] == "Neutral" or insights['customer_sentiment_towards_bsc'] == "":
            insights['customer_sentiment_towards_bsc'] = "Neutral"
            insights['customer_sentiment_towards_bsc_reason'] = ""
            insights['customer_sub_sentiment_towards_bsc'] = "Neutral"
            insights['customer_sub_sentiment_towards_bsc'] = ""
        # if insights['customer_sentiment_towards_agent'] == "Neutral" or insights['customer_sentiment_towards_agent'] == "":
        #     insights['customer_sentiment_towards_agent'] = "Neutral"
        #     insights['customer_sentiment_towards_agent_reason'] = ""
        #     insights['customer_sub_sentiment_towards_agent'] = "Neutral"
        #     insights['customer_sub_sentiment_towards_agent_reason'] = ""
        
        if insights['customer_sub_sentiment_towards_bsc'] == "Neutral" or insights['customer_sub_sentiment_towards_bsc'] == "":
            insights['customer_sentiment_towards_bsc'] = "Neutral"
            insights['customer_sentiment_towards_bsc_reason'] = ""
            insights['customer_sub_sentiment_towards_bsc'] = "Neutral"
            insights['customer_sub_sentiment_towards_bsc'] = ""
        # if insights['customer_sub_sentiment_towards_agent'] == "Neutral" or insights['customer_sub_sentiment_towards_agent'] == "":
        #     insights['customer_sentiment_towards_agent'] = "Neutral"
        #     insights['customer_sentiment_towards_agent_reason'] = ""
        #     insights['customer_sub_sentiment_towards_agent'] = "Neutral"
        #     insights['customer_sub_sentiment_towards_agent_reason'] = ""
        return insights

    def populate_insights(self,outputs):
        insights={}
        #print("in populate insights")
        for ouput in outputs:
            for k,v in ouput.items():
                if k == "Callback Insight":
                    if len(self.transcript.split("\n")) > 12 and "agent: " in self.transcript.lower(): 
                        if isinstance(v['result']['final_callback_request']['output'], list):
                            if len(v['result']['final_callback_request']['output']) > 0:
                                v['result']['final_callback_request']['output']=v['result']['final_callback_request']['output'][0]
                        insights['callback_request']=v['result']['final_callback_request']['output']['additional_insights']['callback_request']
                        insights['callback_request_speaker']=v['result']['final_callback_request']['output']['additional_insights']['callback_request_speaker']
                        insights['callback_explanation']=v['result']['final_callback_request']['output']['additional_insights']['callback_request_explanation']
                    else:
                        insights['callback_request']="No"
                        insights['callback_request_speaker']="NA"
                        insights['callback_explanation']=""
                elif k == "Additional Insights":
                    if len(self.transcript.split("\n")) > 5 and "agent: " in self.transcript.lower(): 
                        insights['customer_attrition_indicator']=v['result']['evaluate_attrition_indicator2']['output'][0]['customer_attrition_check'].lower().replace("y", "Y").replace("n", "N")
                        insights['reason_for_customer_attrition_indicator']=v['result']['evaluate_attrition_indicator2']['output'][0]['customer_attrition_check_explanation'] 
                    else:
                        insights['customer_attrition_indicator'] = "No"
                        insights['reason_for_customer_attrition_indicator'] = ""
                elif k == "Sentiment Insight":
                    if len(self.transcript.split("\n")) > 5 and "agent: " in self.transcript.lower():

                        insights['customer_sentiment_towards_bsc']=v['result']['sentiment_bsc']['output']['sentiment']
                        insights['customer_sentiment_towards_bsc_reason']=v['result']['sentiment_bsc']['output']['explanation']
                        # insights['customer_sentiment_towards_agent']=v['result']['sentiment_agent']['output']['sentiment']
                        # insights['customer_sentiment_towards_agent_reason']=v['result']['sentiment_agent']['output']['explanation']

                        insights['customer_sub_sentiment_towards_bsc']=v['result']['sub_sentiment_classification']['output'][0]['customer_sub_sentiment_towards_bsc']
                        insights['customer_sub_sentiment_towards_bsc_reason']=v['result']['sub_sentiment_classification']['output'][0]['customer_sub_sentiment_towards_bsc_explanation']


                    else:
                        insights['customer_sentiment_towards_bsc'] = "Neutral"
                        insights['customer_sentiment_towards_bsc_reason'] = ""
                        # insights['customer_sentiment_towards_agent'] = "Neutral"
                        # insights['customer_sentiment_towards_agent_reason'] = ""
                        
                        insights['customer_sub_sentiment_towards_bsc'] = "Neutral"
                        insights['customer_sub_sentiment_towards_bsc_reason']= ""

                        # insights['customer_sub_sentiment_towards_agent'] = "Neutral"
                        # insights['customer_sub_sentiment_towards_agent_reason'] = ""
                    insights = self.check_sentiment(insights)
                elif k == "Customer Sentiment at end of Call Insight":
                    if len(self.transcript.split("\n")) > 5 and "agent: " in self.transcript.lower():
                        insights["customer_sentiment_at_end_of_call"] = v['result']['customer_sentiment_at_end_of_call']["output"]["final_customer_sentiment"]
                        insights["customer_sentiment_at_end_of_call_explanation"] = v['result']['customer_sentiment_at_end_of_call']["output"]["final_customer_sentiment_explanation"]
                    else:
                        insights["customer_sentiment_at_end_of_call"] = "Neutral"
                        insights["customer_sentiment_at_end_of_call_explanation"] = ""

                elif k == "Ontology Classification":
                    #print(v['result'])
                    # print("\n\n\n########Final _output: ",v["result"] )
                    insights['summary']=v['result']['issues_summary']["output"]
                    insights['call_driver_sentence']=v['result']['issues_summary']["output"]
                    insights["raw_output"] = v["result"]
                    
                    intent_outputs=v['result']["final_output"]
                    # print(intent_outputs)
                    insights['marked_cases'] = 1#v['result']['evaluation_output']["marking"]
                    insights['presence_of_customer_intent'] = v['result']['evaluation_output']["customer_intent_present"]
                    # new_intent_outputs = list() 
                    # for intent in intent_outputs:
                    #     if isinstance(intent, list):
                    #         new_intent_outputs.extend(intent)
                    #     else:
                    #         new_intent_outputs.append(intent) 
                    # for intent in new_intent_outputs:
                    #     category={'tier1':'','tier2':'','tier3':'','tier4':'','tier5': ''}
                    #     if 'category' in intent and intent['tier1']!="":
                    #         intent['category'] = intent['category'].strip("/")
                    #         tiers = intent['category'].split("/")
                    #         for i, k in enumerate(category.keys()):
                    #             if i < len(tiers):
                    #                 category[k] = tiers[i]
                    #             else:
                    #                 break
                    #         category['category']=intent['category'] 
                    #         ontology.append(category)
                    insights['raw_classified_category']=intent_outputs
                    insights['classified_category']= intent_outputs
                    insights["Number_of_intents_Call_level"] = len(insights['classified_category'])
                    insights["tier1_combo"] ,insights["tier1_2_combo"],  insights["category_with_descriptive_tag_call_level"], full_category_string_list = self.get_additional_category_values(insights['classified_category'])
                    insights["category_combo1"] = ""
                    insights["category_combo2"] = ""
                    insights["category_combo3"] = ""
                    insights["category_combo4"] = ""
                    insights["category_combo5"] = ""
                    for k in range(len(full_category_string_list)):
                        if k==0:
                            insights["category_combo1"] = "\n\n".join(full_category_string_list[k])
                        if k==1:
                            insights["category_combo2"] = "\n\n" + "\n\n".join(full_category_string_list[k])
                        if k==2:
                            insights["category_combo3"] = "\n\n" + "\n\n".join(full_category_string_list[k])
                        if k==3:
                            insights["category_combo4"] = "\n\n" + "\n\n".join(full_category_string_list[k])
                        if k==4:
                            insights["category_combo5"] = "\n\n" + "\n\n".join(full_category_string_list[k])

        return insights

    def get_current_date_and_time(self):
        current_date = datetime.now()
        formatted_date = current_date.strftime("%Y-%m-%d")
        formatted_time = current_date.time().strftime("%H:%M:%S")
        return formatted_date, formatted_time

    def save_log_json(self, data, output_path, transcript_path):
        try:
            print(output_path)
            if not os.path.exists(output_path):
                os.makedirs(output_path)
            file_name = transcript_path.split("/")[-1]
            if "Sagility" in transcript_path:
                output_path = os.path.join(output_path, "Sagility")            
            elif "TTec" in transcript_path:
                output_path = os.path.join(output_path, "TTec")

            elif "Verint" in transcript_path:
                output_path = os.path.join(output_path, "Verint")
            if not os.path.exists(output_path):
                os.makedirs(output_path)
            print(output_path)
            with open(os.path.join(output_path, file_name), 'w', encoding = 'utf-8') as f:
                json.dump(data, f, ensure_ascii = False, indent = 4)
        except Exception as e:
            print(f"error saving logs {str(e)}")

    def move_to_archive(self, output_path, transcript_path):
        try:
            if not os.path.exists(output_path):
                os.makedirs(output_path)
            file_name = transcript_path.split("/")[-1]
            if "Sagility" in transcript_path:
                output_path = os.path.join(output_path, "Sagility")            
            elif "TTec" in transcript_path:
                output_path = os.path.join(output_path, "TTec")
            elif "Verint" in transcript_path:
                output_path = os.path.join(output_path, "Verint")
            if not os.path.exists(output_path):
                os.makedirs(output_path)
            shutil.copy(transcript_path, output_path)
        except Exception as e:
            print(f"Error in moving file to Archive: {transcript_path}")


    def time_difference_in_string_values(self, time_str1, time_str2):
        try:
            time_format = "%H:%M:%S"
            time1 = datetime.strptime(time_str1, time_format)
            time2 = datetime.strptime(time_str2, time_format)

            # Calculate the time difference
            time_difference = (time2 - time1).total_seconds()
        except Exception as e:
            print(f"Error in 'time_difference_in_string_values' --> {e}")
            time_difference = 0.0
        return time_difference

    
    def parse_date_time(self, input_str):
        #parsed_datetime = datetime.fromisoformat(input_str)
        parsed_datetime = parser.parse(input_str)
        # Extract date and time components
        date_part = parsed_datetime.strftime('%Y-%m-%d')
        time_part = parsed_datetime.strftime('%H:%M:%S')

        return time_part, date_part
        
                
    def read_json(self, filepath):
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            return data
        except FileNotFoundError as fnf:
            return "Input file not found"
        except ValueError:
            return "Error Decoding input JSON"
        
    def get_utterances(self,transcript):
        utterance_level = []
        for i in range(len(transcript)):
            utterance_dict = dict()
            utterance_dict['utterances_id'] = i+1
            utterance_dict['speaker'], utterance_dict['utterance_text'] =transcript[i]["sp"],transcript[i]["w"]
            if isinstance(transcript[i]["s"], str):
                utterance_dict['start_time'] =int(transcript[i]["s"])/1000
                utterance_dict['end_time'] =int(transcript[i]["e"])/1000
            else:
                utterance_dict['start_time'] = transcript[i]["s"]/1000
                utterance_dict['end_time'] = transcript[i]["e"]/1000
            utterance_level.append(utterance_dict)
        return utterance_level
    
    def get_entity_hierarchy_using_tier1(self, tier1, entity_category_dict):
        tier1_lower = [item.lower() for item in tier1]
        
        relevant_entity_list = []
        
        for item in tier1_lower:
            for key in entity_category_dict.keys():
                if item == key.lower():
                    relevant_entity_list.extend(entity_category_dict[key])
                    break
        return relevant_entity_list


    def get_intents(self, entity_intent_dict, classified_entities):
        filtered_intents = []
        classified_entities = list(set(classified_entities))
        for item in classified_entities:
            if item in entity_intent_dict:
                if len(entity_intent_dict[item])==0:
                    filtered_intents.append(item)
                else:
                    for intent in entity_intent_dict[item]:
                        filtered_intents.append(item + "/" + intent)
            else:
                print(f"No entity like: {item}")
        return filtered_intents

    def save_json(self, output_path, file_name, json_dict, transcript_path):
        if not os.path.exists(output_path):
            os.makedirs(output_path)
        if "Sagility" in transcript_path:
            output_path = os.path.join(output_path, "Sagility")
        elif "TTec" in transcript_path:
            output_path = os.path.join(output_path, "TTec")
        elif "Verint" in transcript_path:
            output_path = os.path.join(output_path, "Verint")
        if not os.path.exists(output_path):
            os.makedirs(output_path)
        try:
            file_name = file_name + ".json"
            with open(os.path.join(output_path, file_name), 'w', encoding = 'utf-8') as f:
                json.dump(json_dict, f, ensure_ascii = False, indent = 4)
            return True,""
        except Exception as e:
           return False,str(e)
    
    def error_check(self,insights_module_outputs):
        error_list = []
        error_status=False
        for module_output in insights_module_outputs:
            for k , v in module_output.items():
                if k=="Ontology Classification":
                    continue
                output_dict = v['result']
                for k1, v1 in output_dict.items():
                    errors=v1['errors']
                    temp={"module":k,"error":errors}
                    error_list.append(temp)
                    if isinstance(errors, list):
                        for error2 in errors:
                            if isinstance(error2, list):
                                for e in error2:
                                    if len(e)>0:
                                        error_status=True
                            elif isinstance(error2, str) and len(error2)>0 :
                                error_status=True
                            elif isinstance(error2, dict):
                                if 'exception_name' in error2 and isinstance(errors['exception_name'], str) and len(error2['exception_name'])>0:
                                    error_status=True
                    elif isinstance(errors, str) and len(errors)>0:
                        error_status=True
                    elif isinstance(errors, dict):
                        if 'exception_name' in errors and isinstance(errors['exception_name'], str) and len(errors['exception_name'])>0:
                            error_status=True
        return error_status ,error_list
    def get_missing_kpis(self,output,check_list):
        missing_kpis = []
        for check in check_list:
            if check not in output or output[check] is None:
                missing_kpis.append(check)
        return missing_kpis
    
tokenizer = tiktoken.encoding_for_model("gpt-35-turbo-16k")
def get_limited_input_text(input_text):
    tokens = tokenizer.encode(input_text)
    if len(tokens) > 15000:
        tokens = tokens[:15000]
        input_text = tokenizer.decode(tokens)
    return input_text