### Summary Prompt ###
summary_system_prompt = """You are an intelligent Assistant from BSC who is an expert in Analyzing Transcripts."""

summary_user_prompt = """Transcript: {transcript}

Analyze the above ```Transcript``` and generate a summary for the ```Transcript```. Summary should be detailed and paragraph focussed on all issues / requests / inquiries discussed in the call by the customer and their respective resolutions provided by the agent.

Note: Do not add Customer name in the summary."""


### End of Summary Prompt ###

### Tier 1 Prompt ###

tier1_system_prompt = """Your are a Healthcare expert for Blue Shield of California. Your task is analyze the conversation summary, and select the categories applicable to it using the category list."""

tier1_user_prompt = """You will be given a summary of a conversation between agent and customer and a list of categories. Your task is to identify which categories are applicable to the customer issues and requests. Think wisely.

    ``````
    Summary : {input_text}
    ``````

    ``````
    Categories : {categories}
    ``````

    ``````
    Categories Definition : {descriptions}
    ``````

    ``````
    Instructions : Analyze the Summary and answer following questions :
    Question 1 : Based on the understanding of the conversation summary, which categories are applicable to the customer issues and requests? Think wisely.
    Question 2 : Give explanation for each selected category in a brief manner. Make sure to always include the reason customer has mentioned with all related entities and intentions.
    Question 3 :  For each category selected, answer if the category is selected from 'customer issue', 'customer request', 'customer provding details', 'agent providing details', 'agent resolutions', 'derived based on the context'.
   

    Point to note: 
    - If no category is relevant, then answer with 'Others'.
    
    ``````

    ``````
    Output Format: Answer within following xml tags:
    <categories_identification>
    <selected_category_1>
    <category_value></category_value>
    <category_explanation></category_explanation>
    <derived_from></derived_from>
    </selected_category_1>
    <selected_category_2>
    <category_value></category_value>
    <category_explanation></category_explanation>
    <derived_from></derived_from>
    </selected_category_2>
    </categories_identification>
    ``````

    ``````
    Output Format Explanation:
    - answer of question 1 will come between this tag: <category_value></category_value>.
    - answer of question 2 will come between this tag: <category_explanation></category_explanation>.
    - answer of question 3 will come between this tag: <derived_from></derived_from>
    ``````
    """

### End of Tier 1 Prompt ###




### Entity Prompt ###


entity_system_prompt = """Your are an expert in building hierarchy for healthcare. You will be provided with healthcare call summary between a agent and a customer with a hierarchy levels seperated by '/' and list of next possible sub-levels. Your task is to understand the hierarchy and pick the next sub-levels based on the summary. Provide reasoning for each selected sub-level that 'by adding that sub-level will represents a issue/request of the customer which is explictly mentioned in the summary


Provide XML output:

Example Output:

<analysis>
<customer_intentions>
Do Reasoning: First understand and identify the explicitly mentioned customer intentions in the overall context of the summary.

List the n intentions in brief sentences as customer intention sentences, 

customer intention sentences:
1. ..

Note: Only list the primary intentions which are explictly mentioned in the summary.
</customer_intentions>
<next_sub_levels> (Provide the sub_level for each customer intention sentences.)
<sub_level>
<reasoning>reasoning</reasoning> (Do reasoning: Understand each sub-levels meaning. Think whether by adding this sub-level will represents that customer intention which is explictly mentioned in the summary.)
<sub_level_name>The sub-level name</sub_level_name>
<sub_level>
</next_sub_levels>
</analysis>"""

entity_system_prompt = """Your are an expert in building hierarchy for healthcare. You will be provided with healthcare call summary between a agent and a customer with a hierarchy levels seperated by '/' and list of next possible sub-levels. Your task is to understand the hierarchy and pick the next sub-levels based on the summary. Provide reasoning for each selected sub-level that 'by adding that sub-level will represents a issue/request of the customer which is explictly mentioned in the summary


Provide XML output, 

Example Output:

<next_sub_levels>
<sub_level>
<reasoning>Do reasoning, Understand each sub-levels meaning. Think by adding which sub-level to the hierarchy as the next-level will tell the exact 'issue or request mentioned by the customer explicitly in the summary' in a hierarchy representation.</reasoning>
<sub_level_name>Provide that sub-level name</sub_level_name>
<sub_level>
</next_sub_levels>"""

entity_user_prompt = """
```Call Summary```: ```{summary}```

```Hierarchy```: ```{tier1}```

```Sub-levels```: ```{sub_topics}```

Output:

"""
 
### Check for Presence of intent ###
presence_of_intent_system_prompt = """You are an expert in US healthcare space."""

presence_of_intent_user_prompt = """```
    Conversation Summary : {input_text}
    ```

    ```
    Question : Please analyze the conversation summary and identify if there is any intents related to healtcare domain present in customer issues and requests. Reply with Yes or No. Answer within this tag: <answer></answer>.
    Notes: 
    - Call transfer, call back request, call escalation, department details, are not issues related to healthcare domain.
    - These are the healthcare domains: Access to care, insurance plan, insurance plan benefits and covergae, billing issues, claims issues, authorization issues, account management
    ```
    """


### Tier 1 Evaluation Prompt ###
tier1_evaluation_system_prompt = """Act as an expert Healthcare evaluator. You can read summaries and check the categories mentioned are correct or incorrect"""
tier1_evaluation_user_prompt = """
    You will be given a summary of a conversation between agent and customer and a list of categories extracted from the summary. Your task is to rate the categories based on the provided scale. 
    Please make sure you read and understand these instructions very carefully.

    ``````
    Summary: {input_text}
    ``````

    ``````
    Categories: {category}
    ``````

    ``````
    Evaluation Scale: Please follow following steps to rate a category:
    1. Understand the issues or requests or assistance mentioned by the customer in the summary.
    2. If the customer issues or request or assistance mentioned in the summary matches with category, mark it as '1'.
    3. If the customer issues or request or assistance mentioned in the summary is not at all relevant to the category, mark it as '0'.
    4. Give explanation for the marking also. In explanation always mention the entity action regarding which the issue is about. 

    Note: 
    - Please avoid any phrase by agent. Use following descriptions to better understand:
    {required_descriptions}

    ``````

    ``````
    Output Format: Answer within following xml tags:
    <categories_evaluation>
    <answer_1>
    <category_value></category_value>
    <category_rating></category_rating>
    <category_rating_explanation></category_rating_explanation>
    </answer_1>
    <answer_2>
    <category_value></category_value>
    <category_rating></category_rating>
    <category_rating_explanation></category_rating_explanation>
    </answer_2>
    </categories_evaluation>
    ``````

    ``````
    Output Format Explanation:
    - put each category value between this tag <category_value></category_value>.
    - put the category rating between this tag <category_rating></category_rating>.
    - put category rating explantion between this tag <category_rating_explanation></category_rating_explanation>.
    ``````

    """


### End  of Tier 1 Evaluation Prompt ###

### Entity Evaluation Prompt ###
entity_evaluation_system_prompt = """Act as an expert Healthcare evaluator. You can read summaries and check the categories mentioned are correct, incorrect or partially correct."""

entity_evaluation_user_prompt = """
    You will be given a summary of a conversation between agent and customer and a category extracted from the summary. Your task is to rate the category based on the provided scale. 
    Please make sure you read and understand these instructions very carefully.

    ``````
    Summary: {input_text}
    ``````

    ``````
    Category: {category}
    ``````

    ```````
    Parent Category Description: {required_descriptions}
    ```````

    ``````
    Categories structure explanation: Each category is separated by a comma. Each category is composed of multiple levels. Each level is separated by a '/'. If a category has two '/' that means it has three levels, if a category has three '/' then the category has four levels.
    ``````

    ``````
    Evaluation Scale: Please follow following steps to rate a category:
    1. Understand the issues or requests or assistance mentioned by the customer in the summary.
    2. If the customer issues or request or assistance mentioned in the summary matches with category, mark it as '1'.
    3. If the customer issues or request or assistance mentioned in the summary partially matches with category, mark it as '0.5'.
    4. If the customer issues or request or assistance mentioned in the summary is not at all relevant to the category, mark it as '0'.
    5. Give explanation for the marking also.

    Note: Please avoid any phrase by agent.
    ``````

    ``````
    Output Format: Answer within following xml tags:
    <categories_evaluation>
    <answer_1>
    <category_value></category_value>
    <category_rating></category_rating>
    <category_rating_explanation></category_rating_explanation>
    </answer_1>
    <answer_2>
    <category_value></category_value>
    <category_rating></category_rating>
    <category_rating_explanation></category_rating_explanation>
    </answer_2>
    </categories_evaluation>
    ``````

    ``````
    Output Format Explanation:
    - put each category value between this tag <category_value></category_value>.
    - put the category rating between this tag <category_rating></category_rating>.
    - put category rating explantion between this tag <category_rating_explanation></category_rating_explanation>.
    ``````
    """
### End of Entity Evaluator Prompt ###


### Final Evaluation Prompt ####

final_evaluation_system_prompt = """You are responsible for validating the `hierarchy` representation of the entity-intent of the `summary`. The hierarchy is a multiple levels of entity-intent represented in a hierarchical structure. Your task is to validate and provide the following validation results:
    
Provide XML output:

Provide validation result with hierarchy, reasoning, score for each hierarchy in the hierarchies list, Example Output:

<validation_results>
<validation_result>
<hierarchy>
The entity-intent hierarchy. 
</hierarchy>
<reasoning>
Analyze and understand the `summary` and do reason on 'whether the entity and intent is actually matching with the `summary` or not, also the overall hierarchy is telling the exact scenario that the user has explicitly mentioned as a issue or request with respect to the context of the summary and finalize the score.
</reasoning>
<score>
1 only if the entity-intent hierarchy is fully valid, 0 if the hierarchy is not fully valid.
</score>
</validation_result>
</validation_results>"""

final_evaluation_user_prompt = """```Hierarchies list: {hierarchies}```

```Summary: {input_text}```

```Tier 1 Description: {description}```
    
Tier 1 Description is only provided to better understand the Hierarchies list.

"""

### End  of FInal Evaluation Prompt ###

### Get Partially correct cases ###

partially_correct_system_prompt = """You are an expert in correcting incorrect healthcare entity-intent hierarchy separated with '/'. You will be provided with an  incorrect entity-intent hierarchy and incorret explanation. You should understand the incorrect level in the hierarchy based on the given incorrect explanation and replace that level with 'incorrect' tag.

Provide XML output, with the correct entity-intent hierarchy replaced by 'incorrect' tag.
Example Output:
<corrected_hierachy>The corrected hieirarchy (String Type) </corrected_hierachy>"""

partially_correct_user_prompt = """ `Incorret_Hierachy`: {category}
`Incorrect Explanation`: {explanation}

Output:

"""

### End of partially correct cases ###

### reasons and topics generation ###


reasons_system_prompt = """You will be provided with a call summary and a category extracted from the summary. Your task is to extract the customer reason focusing on the 'Category' Provide this reason to help the healtcare provider and address the issues. Just provide the customer reason for the provided Category in a short line of few words, no other explanations. Reason should strictly extracted from customer reasons. Ignore any other reasons or issues from agent or others."""


reasons_user_prompt = """```Summary```: ```{summary}```

```Category```: ```{category}````"""


### Tier 1 Defination ###
tier1_definition_dict = {"Access to Care": """Description: The 'Access to care' label applies to cases where the customer is seeking information on healthcare providers, attempting to take action to receive clinical care, or trying to request a change in primary care physician or any specialist. The customer may be in the process of researching if a doctor, other healthcare provider or extended healthcare service vendor is 'accessible' based on their participation in a provider network. Similarly, a customer may be indicating a desire to change a healthcare provider such as a primary care doctor. The customer may also express an intent to receive or 'access' clinical care such as scheduling an appointment with a doctor/provider, visiting a hospital or healthcare facility, or filling a drug prescription.

    Examples:
        - Find a Doctor
        - make changes or change ot doctor
        - Scheduling appointments
        - Teladoc or virtual care
        - Urgent care facility or home health serivces
        - access to prescriptions
        - access to doctor you want

    Things to watch out for:
        - This label may occasionally overlap with comments related to Benefits & Eligibility. Cases where customer is asking about doctor or specialist coverage or medicine coverage then it will be classified under  'Benefits & Eligibility'. You should apply judgment to discern if the customer's intent is to seek clinical care or determine if the services are covered under the benefits. A person checking if a provider is in network has intent to seek clinical care, whereas a person inquiring about their own financial liability if they were to receive some service may only be interested in benefits and eligibility. Assess the imminence of the member's intent to receive clinical care. However, it is possible for both labels to be simultaneously applied.
        - Changing doctor in portal or account will be classified under 'Account Management' not 'Access to care'.
        - Note that some usage of keywords like 'access' are purely coincidental and do not indicate customer's Access to care.""",

    "Account Management": """Description: The 'Account Management' label applies to cases where the Customer is attempting to update his/her user account info. This includes: address, phone number, email address, doctor info, and other contact or demographic information in account. It also includes updating communication preferences (i.e. paperless, SMS/text approval, etc.), communication letters, and member id card related queries. This includes account authorization actions like revoking , authorize family members.

    Examples:
        - Update contact info (name, phone, email, address, doctor info in account etc.)
        - Communication preferences (paperless, SMS, phone, etc.)
        - Email reminders
        - Family or third party authorization to account
        - new, replace, incorrect info in ID Card

    Things to watch out for:
        - The 'Account Management' should NOT be applied to comments related to changing a PCP, checking on a claim status, changing plans or coverage, make a payment, experiencing technical difficulties or other situations where a member might want to view/change/act upon an aspect of their account where they do not have direct authority to make a change. 
        - The customer mentioned having trouble with their insurance being changed without their knowledge. This is not Account Management.
        - Any changes related to insurance plan will not come under 'Account Management'.
        - updating doctor information in online account comes under 'Account Management' but changing doctor comes under 'Access to care' label.""",

    """Appeals & Grievances""" : """Description: Any customer issues grievances or appeals for claims, benefits, plans, Durable Medical Equipment (DME), Authorizations.

    Examples:
        - Appeal or greivance towards health plan.
        - Appeal or grievance towards the benefits of the plan or policy.
        - Appeal or grievance towards the claim process.
        - Appeal or grievance towards the authorization process.

    Things to watch out for:
        - Customer can express frustration or dissapointment towards the customer service or representative or supervisor, but that does not count as Appeals & Grievances.""",

    """Authorization""": """Description: For many medical services a member must receive authorization in advance of the services being provided to have those services covered by insurance. The Authorization driver label should be applied to any comments that relate to the authorization of services. This should include authorization requests, status of an authorization request, denial of an authorization request, or an appeal of an authorization denial. 

    Examples:
        - Authorization request
        - Authorization status
        - Authorization appeal
        - Pre-authorization, pre-auth, PA, RX PA, auth
        - Denied services, approved services
        - Vacation override request
        - Authorization denial

    Things to watch out for:
        - the "Authorization" driver label should not be applied to comments specific to claims, benefits & eligibility or any other issue that is not specific to authorizations.""",

    """Benefits & Eligibility""": """Description: The "Benefits & Eligibility" label should be applied for any comments that relate to the customer’s mention of health plan type or benefits, covered, partially covered, or not covered as well as one’s eligibility to receive those benefits. The "Benefits & Eligibility" label will be applied to all applicable commentary mentioning benefits, level/amount of coverage for medical (including Mental Health, Prescriptions/Pharmacy and other specialized coverages), dental, vision, and other benefit coverages.  In addition, "Benefits & Eligibility" includes deductibles, co-pays, coinsurance, and the Coordination of Benefits (CoB) when there is more than one insurance provider involved.  Finally, "Benefits & Eligibility" includes plan richness or limits to coverage within the accumulation period (calendar year). As an example, if the customer expresses that they have an HMO and want to know if they can go directly to a Specialist without getting a referral from their PCP, the comment would be labeled as "Benefits & Eligibility". Below are a few examples of terminology to be captured under "Benefits & Eligibility":

    Examples:
        - Coverage (medical, dental, vision, mental health, etc.)
        - Deductible, copayment or coinsurance discussion for a service which is not yet recieved.
        - Prescription coverage
        - Understand my plan
        - Network
        - Coordination of benefits (i.e. primary and secondary insurance)
        - Understand what benefits my plan covers

    Things to watch out for:
        - The 'Benefits & Eligibility' should NOT be applied to comments related to changing a PCP, checking on a claim status, making a payment, experiencing technical difficulties or other situations where a member might want to view/change/action on an aspect of their health insurance experience where it is not directly related to benefits and eligibility. 
        - If there is a deductible, copayment, coinsurance, total patient responsibility discussion for a service which is yet not recieved by customer and they are just inquiring before receiving the service, then it will go under 'Benefits & Eligibility' label. If the discussion about the explanation of benefits (eob letter) , deductible, copayment, coinsurance, total patient responsibility is for a serivce or a bill that customer has already recieved then it will go under 'Claims' label.
        - If the customer is asking about the network of the insurance plan or coverage of a doctor then it will go under 'Benefits & Eligibility' label. If the customer is asking about the network of the PCP, then it will go under 'Access to care' label.""",

    "Billing and Payment": """Description: The Billing and Payment  driver label should be applied for any comments that relate to a member's monthly premium billing and/or payment. If the comment expresses that they are unable to make a payment online, then Billing and Payment should be applied. Also, this driver label should be applied to any comment that relates to Auto-Pay or recurring payment.

    Examples:
        - Unable to view current bill
        - It will not let me bay my bill
        - Accept additional credit cards like American Express
        - Tried to enter a new card payment method but it did not work
        - Pay bill, autopay, premium, make a payment, credit card, method of payment, monthly bill
        - explaining the payment required, or due payment.

    Things to watch out for:
        - If a bill is discussed regarding a service received by customer, then the label is 'Claims' not 'Billing and Payment'. Another way to identify this is, if customer mentions a bill and then discuss about the copay or deductible amount then it is 'Claims' not 'Billing and Payment'. If the claims word is mentioned for a bill or amount then it is 'Claims' not 'Billing and Payment'.""",

    """Claims""": """Description: Any comment aligning with a member having trouble submitting a claim, viewing the status, appealing/denial, not receiving communication about, not understanding, or not being able to pay a claim. This may relate to medical, dental, vision, or mental health claims. An explanation of benefits or EOB is documentation associated with a claim and should fall under 'Claims,' not 'Benefits & Eligibility.  

    Examples:
        - Claim status
        - Claim submission
        - Explanation of Benefits (EOB) letter
        - Deductible, copayment , total patient responsibility for a bill
        - Appeal info/appeal status
        - Denial details
        - Claims payment details
        - Copay clarification, deductible clarification, total patient responsibility is part of EOB (Explanation of Benefits).

    Things to watch out for:
        - If there is deductible, copayment, coinsurance, total patient responsibility discussion for a service which is yet not recieved by customer and they are just inquiring before receiving the service, then it will go under 'Benefits & Eligibility' label. If the discussion about the explanation of benefits (eob) letter, deductible, copayment, coinsurance, total patient responsibility is for a serivce or a bill that customer has already recieved then it will go under 'Claims' label.
        - If a bill is discussed regarding a service received by customer, then the label is 'Claims' not 'Billing and Payment'. Another way to identify this is, if customer mentiones a bill and then discuss about the copay or deductible amount then it is 'Claims' not 'Billing and Payment'.
        - If the claims word is mentioned for a bill or amount then it is 'Claims'.
        - If there is a mention of Explanation of benefits letter, then the discussion is regarding 'Claims' not 'Benefits & Eligibility'.""",

    """Plan (Excludes Coverage)""": """Description: The start, cancelation, or change of plan or benefit structure, and/or the adding/removing of dependents to a policy.  

    Examples:
        - Shop for new plan
        - Renew plan
        - Change plan
        - Cancel plan
        - Reinstate plan
        - Policy change
        - Application status
        - changing medical groups

    Things to watch out for:
        - Any discussion around the benefits or eligibility of plan should fall under 'Benefits & Eligibility'.
        - If customer is inquiring about the clariifcation of plan or why plan or policy is inactive, then it should go under 'Plan (Excludes Coverage)'.""",

    "Digital Channels & Self-Service": """Description: Digital channels and self service refers to online platform and tools that allows user to access various health information, receive notification, make requests without the need of direct human interaction. This includes web portal, mobile apps, self help portals and automated systems.

    Examples:
        - Issues or requests associated with web portal like navigation issues, etc.
        - Need assistance in registering account online.
        - Need assistance in resetting username, password for online account.
        - self service functionality

    Things to watch out for:
        - The 'Digital Channels & Self-Service' driver label should NOT be applied to cases where customer is asking to update details in the account. It should come under Account Management. But if the customer is facing issue while accessing information on the account or resetting username or password, it should come under Digital Channels & Self-Service.""",

    "Communications": """Description: Communications refers to various ways to communicate (or convey information) with the customer. This could be through emails, phone, text messages, push notifications.

    Examples:
        - Communication with customer- Customer requesting to convey information using through emails, phone, text messages, push notifications.

    Things to watch out for:
        - If the customer just mentions that they did not recieve any communication, will not come under 'Communications'. Customer needs to explicitly mention that want the informtion to be be communicated to them.
    """
        }