# Databricks notebook source
# MAGIC %md
# MAGIC Define Schema for Expected Reasons

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DoubleType, LongType, ArrayType

def get_Expected_schema_reasons() -> StructType:
    # Define the schema
    schema = StructType([
        StructField("SNO", LongType(), True),
        StructField("NAME_OF_TOP_DRIVER", StringType(), True),
        StructField("CALL_CATEGORY", StringType(), True),
        StructField("REASONS", ArrayType(StringType(), True), True),
        StructField("REASONS_WITH_ID", ArrayType(StringType(), True), True),
        StructField("PERCENTAGE_OF_CALLS", DoubleType(), True),
        StructField("CALL_INTENT_TIER1", StringType(), True),
        StructField("CALL_INTENT_TIER2", StringType(), True),
        StructField("CALL_INTENT_TIER3", StringType(), True),
        StructField("CALL_INTENT_TIER4", StringType(), True),
        StructField("CALL_INTENT_TIER5", StringType(), True),
        StructField("DESCRIPTIVE_TAG1", StringType(), True),
        StructField("DESCRIPTIVE_TAG2", StringType(), True),
        StructField("CONVERSATION_START_DATE", StringType(), True),
        StructField("CONVERSATION_PROCESSED_DATE", StringType(), True),
        StructField("INSIGHTS", StringType(), True),
        StructField("ACTIONABLES", StringType(), True),
        StructField("ERROR_LIST", StringType(), True),
        StructField("ANALYTICS", StringType(), True),
        StructField("INSIGHTS_1", StringType(), True),
        StructField("ACTIONABLES_1", StringType(), True),
        StructField("INSIGHTS_2", StringType(), True),
        StructField("ACTIONABLES_2", StringType(), True),
        StructField("INSIGHTS_3", StringType(), True),
        StructField("ACTIONABLES_3", StringType(), True),
        StructField("INSIGHTS_4", StringType(), True),
        StructField("ACTIONABLES_4", StringType(), True),
        StructField("INSIGHTS_5", StringType(), True),
        StructField("ACTIONABLES_5", StringType(), True)
    ])
    return schema