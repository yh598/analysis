# Databricks notebook source
# MAGIC %md
# MAGIC Install Required libraries

# COMMAND ----------


!pip install azure-identity
!pip install python-dotenv
!pip install PyYaml
!pip install dotmap
!pip install pandas
!pip install requests
!pip install openai
!pip install boto3
!pip install tiktoken
!pip install openpyxl
!pip install nzpy
!pip install retry
dbutils.library.restartPython()