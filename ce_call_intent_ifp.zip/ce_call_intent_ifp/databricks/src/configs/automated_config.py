import subprocess
import json
import os
import yaml


def get_current_user():

    """Fetch the current Databricks user information."""

    result = subprocess.run(['databricks', 'current-user', 'me'], capture_output=True, text=True)
    try:

        user_info = json.loads(result.stdout)
        user_email = user_info.get("userName", "")
        user_name = user_email.split('@')[0]  # Get the part before the '@'
        return user_email, user_name

    except json.JSONDecodeError:
        print("Error decoding JSON output.")
        return None, None

    except Exception as e:
        print(f"An error occurred: {e}")
        return None, None

 

def update_yaml_file(file_path, replacements):

    """Update specific keys in a YAML file with replacements."""
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file) or {}

 
    # Update the keys that are present in the replacements dictionary
    for key, value in replacements.items():
        if key in data:
            data[key] = value

 
    # Write the updated data back to the YAML file, preserving existing order
    with open(file_path, 'w') as file:
        yaml.dump(data, file, default_flow_style=False, sort_keys=False)

 

def config_DEV():
    
    print("Changing Configuration for DEV: 039")
    
    # Load parameters from YAML file
    config_yml_path = os.path.join(os.getcwd(), 'config.yaml')
    with open(config_yml_path, 'r') as file:
        config_data = yaml.safe_load(file)

 
    existing_user_name = config_data.get("user_name", "")
    existing_schema_name = config_data.get("schema_name", "")

 
    if not existing_user_name or not existing_schema_name:
        print("Error: user_name or schema_name not found in config.yaml.")
        return


    # Extract username from existing user name
    old_user_name = existing_user_name
    print(f"Old username extracted: {old_user_name}")

    # Get the current Databricks user
    print("Detecting current user ... ")
    user_email, current_user_name = get_current_user()
    if user_email is None:
        print("Failed to fetch user information.")
        return


    print(f"User Email: {user_email}")
    print(f"User Name: {current_user_name}")
    print(f"We are going to change all settings and config from old user [{old_user_name}] to current Databricks user [{current_user_name}]!")
    confirm = input("Is the above information correct? Please give your consent (y/n): ").strip().lower()

    if confirm == 'y':
        new_username = current_user_name
        print("User configuration changed!")

    else:
        new_username = old_user_name
        print("User configuration unchanged!")

    # Set catalog_name = poc, Default for DEV
    catalog_name = "poc"
    
    # Prepare replacements for YAML
    replacements_data = {
        'user_name': new_username,
        'schema_name': new_username,  # Update schema_name to the new user name
        'catalog_name': catalog_name
    }

    # Update YAML file
    update_yaml_file(config_yml_path, replacements_data)
    print("YAML file has been updated successfully for DEV Environment.")


def config_STAGE():

    print("Changing Configuration for STAGE: 439")
    
    
def config_QA():

    print("Changing Configuration for QA: 239")

 
def config_PROD():

    print("Changing Configuration for PROD: 939")

 

def main():

    env_options = {'1': config_DEV,'2': config_STAGE,'3': config_QA,'4': config_PROD}

    print("Please select the environment:")
    print("1. DEV")
    print("2. STAGE")
    print("3. QA")
    print("4. PROD")

    choice = input("Enter your choice (1-4): ")

    if choice in env_options:
        env_options[choice]()  # Call the selected configuration function
    else:
        print("Invalid choice. Please select a valid option.")
        
if __name__ == "__main__":

    main()