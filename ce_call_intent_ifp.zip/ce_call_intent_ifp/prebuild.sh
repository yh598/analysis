echo "PRE BUILD SCRIPT"

cp -R databricks dist/du_full

echo "Pre Build Stage Successful for ce_call_intent_ifp!"