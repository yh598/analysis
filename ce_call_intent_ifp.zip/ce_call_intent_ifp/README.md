
# MLOps Readme Document

## Overview
This document outlines the steps necessary to deploy and run the Bitbucket CI/CD. Please follow each step to ensure proper setup and configuration.


---
### Step 1: Create Your Own Branch

Before proceeding, create a new branch from the latest Bitbucket branch associated with your assigned JIRA task.

**Link to the Bitbucket Repository:**
[Repository](https://bitbucket.org/blueshieldca/ce_call_intent_ifp/src/master/)

 
### Step 2: Clone the Branch to Local Directory

Clone your branch into your local directory using the command below. Replace `<your_branch_name>` with your actual branch name.

```bash
git clone https://rajanyadav1@bitbucket.org/blueshieldca/ce_call_intent_ifp.git -b <your_branch_name>
```

### Step 3: Update requirements.txt

If you're going to use any specific Python packages, update the `requirements.txt` file accordingly. This will ensure your virtual environment has all the necessary dependencies.Users can install the required dependencies locally by running the command:

```bash
pip install -r requirements.txt.
```

### Step 4: Update ce_call_intent_ifp_job.yml

Update the `ce_call_intent_ifp_job.yml` file located in the `resources` directory.Adjust Notebooks and python script name and file path according to your project directory structure.

```yaml
- task_key: ce_call_intent_ifp_task
  existing_cluster_id: ${resources.clusters.new_job_cluster.id} # Configured in databricks.yml
  libraries:
    - pypi:
        package: PyYAML>=6.0
  spark_python_task:
    python_file: ../src/notebooks/python_script.py

```

### Step 5: Navigate to configs directory and execute automated_config.py (Local Setup)
This step will automatically detect <user_name> for the current user(if databricks cli loggedin to userspace), and do required changes in config.yaml and other required configuration changes (like changes in user_name, schema_name etc).

## Running Projects/Jobs Via Databricks Asset Bundle

### Step 6: Validate project Asset Bundle 
From the databricks directory, use the Databricks CLI to run the bundle validate command, as follows: 

```bash
databricks bundle validate
```

### Step 7: Deploy the local project to remote dev workspace
This will deploy the project to databricks dev environment, However, it depends on the configuration presents in databricks.yml and target specified with `deploy` command

```bash
databricks bundle deploy -t dev
```
Check for .bundle in Databricks workspace. The location of deployed artifacts will be at below location

    /Workspace/Users/<user_name>@blueshieldca.com/.bundle/costofcare/dev/files/resources

IF its not dev or if it is deployed using service priciple/Bit Bucket CICD, refer `databricks.yml` root_path field

### Step 8: Run first job using Databricks CLI manually
Now, Since the project is already deployed in Workspace, users can execute `run` command.

```bash
databricks bundle run -t dev ce_call_intent_ifp_job
```

### Step 9: Create Schema and Directory

This is for first time user who wants to setup entire project from scratch in any environment.
This step can be achieved by running create_schema_and_directory.py from databricks CLI, under config directory.
(if schema is already present it will skip the schema creation)

### Step 10: Run deployed Workflow
This step will run the jobs as pipeline.User can create as many jobs they want based on their projects

```bash
databricks bundle run -t dev ce_call_intent_ifp_job

```



### Additional Resources

- [ QuickStart Guide ](https://blueshieldca.atlassian.net/wiki/spaces/CDE/pages/416154170/QuickStart+Guide)

- [ Azure Databricks Workflows ](https://blueshieldca.atlassian.net/wiki/spaces/CDE/pages/385155126/Azure+Databricks+Workflows)

- [ Setup Git, Python, VSCode, Databricks and Databricks CLI - BSC](https://blueshieldca.atlassian.net/wiki/spaces/CDE/pages/396265519/Setup+Git+Python+VSCode+Databricks+and+Databricks+CLI+-+BSC)

- [ Automated configuration management for BSC Projects ](https://blueshieldca.atlassian.net/wiki/spaces/CDE/pages/405114157/Automated+configuration+management+for+BSC+Projects)

- [ Create Databricks Asset Bundle ](https://blueshieldca.atlassian.net/wiki/spaces/CDE/pages/398950661/Create+Databricks+Asset+Bundle)

For any questions or contributions, please feel free to reach out to the team!!!


