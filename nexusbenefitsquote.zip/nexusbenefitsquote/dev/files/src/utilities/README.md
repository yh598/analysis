# Nexus Benefits Quote - Utilities Documentation

## Project Overview

The Nexus Benefits Quote utilities module provides a comprehensive set of reusable functions and system integration scripts for managing data pipelines, LLM-based agents, and database operations within the Databricks environment. This module is designed to support the end-to-end workflow of ingesting, transforming, and serving health insurance benefits data through AI-powered agents.

### Key Features

* **Data Pipeline Utilities**: Ingestion, transformation, and embedding generation for plan data
* **LLM Pipeline Utilities**: MLflow-based agent deployment with LangGraph orchestration
* **Database Utilities**: Delta Lake and PostgreSQL (Lakebase) integration clients
* **Configuration Management**: Centralized configuration store for multi-environment support
* **Vector Search Integration**: Databricks Vector Search for semantic similarity
* **Multi-Environment Support**: Dev, QA, Stage, and Production configurations

### Project Structure

```
utilities/
├── README.md (this file)
├── manifest.mf
├── config_store.py
├── delta_table_utils.py
├── lakebase_utils.py
├── data_pipeline/
│   ├── ingestion.py
│   ├── transformation.py
│   └── embeddings.py
└── LLM_pipeline/
    ├── benefit_agent_mlflow_utils_log.py
    └── benefit_agent_mlflow_utils_context_log.py
```

---

## Installation & Setup

### Prerequisites

* Databricks Runtime 13.3 LTS or higher
* Python 3.10 or higher
* Unity Catalog enabled workspace
* Required Python packages:
  * `pyspark`
  * `mlflow`
  * `langchain-core`
  * `langgraph`
  * `databricks-sdk`
  * `databricks-langchain`
  * `databricks-vectorsearch`
  * `pydantic`
  * `requests`
  * `pyyaml`

### Quick Start

1. **Import utilities** into your notebook or script:
   ```python
   from utilities.config_store import ConfigStore
   from utilities.delta_table_utils import DeltaTableClient
   from utilities.data_pipeline.ingestion import fetch_ppdd, prepare_volume_dataframe
   ```

2. **Configure environment** using ConfigStore:
   ```python
   ConfigStore.set(
       catalog_name="dev_adb",
       VS_ENDPOINT="benefits_quote_mvp1_vs_endpoint",
       LLM_ENDPOINT="azure-gpt-4o-2024-08-06-sp"
   )
   ```

3. **Use utility functions** in your workflows

---

## Module Documentation

### Core Utilities

The core utilities provide foundational functionality for configuration management and database operations.

#### Configuration Store (`config_store.py`)

Centralized configuration management for multi-environment deployments.

**Detailed Documentation**: See [Configuration Store Details](#configuration-store-details) below

#### Delta Table Utilities (`delta_table_utils.py`)

Comprehensive Delta Lake table operations including CRUD, merge, and optimization.

**Detailed Documentation**: See [Delta Table Utilities Details](#delta-table-utilities-details) below

#### Lakebase Utilities (`lakebase_utils.py`)

JDBC-based PostgreSQL integration for chat history synchronization.

**Detailed Documentation**: See [Lakebase Utilities Details](#lakebase-utilities-details) below

---

### Data Pipeline Module

The data pipeline module handles the complete ETL workflow for plan data, from API ingestion to vector embeddings.

#### Ingestion (`data_pipeline/ingestion.py`)

API data fetching, JSON artifact creation, and volume-based data preparation.

**Key Functions**:
* `fetch_ppdd()` - Fetch plan data from external API
* `prepare_volume_dataframe()` - Read JSON files from Unity Catalog volumes
* `compute_data_issue()` - Validate data completeness

**Detailed Documentation**: See [Data Pipeline Ingestion Details](#data-pipeline-ingestion-details) below

#### Transformation (`data_pipeline/transformation.py`)

PySpark-based data transformations for plan details, EOC categories, and sections.

**Key Functions**:
* `process_plan_details()` - Extract and flatten plan metadata
* `process_eoc_categories()` - Process Evidence of Coverage categories
* `process_eoc_sections()` - Process EOC sections and items
* `update_ready_flags_master_table()` - Update processing status flags

**Detailed Documentation**: See [Data Pipeline Transformation Details](#data-pipeline-transformation-details) below

#### Embeddings (`data_pipeline/embeddings.py`)

Vector embedding generation for semantic search (implementation details in separate file).

---

### LLM Pipeline Module

The LLM pipeline module provides MLflow-based agent deployment with LangGraph orchestration for intelligent benefits querying.

#### Benefit Agent with MLflow Logging (`LLM_pipeline/benefit_agent_mlflow_utils_log.py`)

Full-featured LangGraph agent with comprehensive logging and retry policies.

**Key Components**:
* `State` - TypedDict for agent state management
* `BenefitCostResponsesAgent` - MLflow ResponsesAgent implementation
* `build_graph()` - LangGraph workflow construction

**Detailed Documentation**: See [Benefit Agent MLflow Logging Details](#benefit-agent-mlflow-logging-details) below

#### Benefit Agent with Context Logging (`LLM_pipeline/benefit_agent_mlflow_utils_context_log.py`)

Simplified agent implementation focused on context-aware answer generation.

**Detailed Documentation**: See [Benefit Agent Context Logging Details](#benefit-agent-context-logging-details) below

---

## Configuration Store Details

### Class: `ConfigStore`

A singleton-style class for managing application configuration across modules without passing parameters.

**Location**: `config_store.py`

### Methods

#### `ConfigStore.set(**kwargs)`

Sets or updates configuration values in the global store.

**Parameters**:
* `**kwargs` (dict): Key-value pairs to store in configuration

**Returns**: None

**Description**:

This class method updates the internal configuration dictionary with the provided key-value pairs. It's typically called once during application initialization to load environment-specific settings.

**Example**:

```python
from utilities.config_store import ConfigStore

# Set configuration values
ConfigStore.set(
    env="dev",
    catalog_name="dev_adb",
    VS_ENDPOINT="benefits_quote_mvp1_vs_endpoint",
    LLM_ENDPOINT="azure-gpt-4o-2024-08-06-sp",
    BENEFIT_INDEX="dev_adb.nexusbenefitsquote_gold_mvp1.tbl_eoc_categories_index",
    DEFAULT_PLAN=28115
)
```

---

#### `ConfigStore.get(key, default=None)`

Retrieves a configuration value by key.

**Parameters**:
* `key` (str): Configuration key to retrieve
* `default` (Any, optional): Default value if key not found. Default: None

**Returns**:
* `Any`: Configuration value or default

**Description**:

This class method retrieves a single configuration value from the store. If the key doesn't exist, it returns the provided default value.

**Example**:

```python
# Retrieve configuration values
catalog = ConfigStore.get("catalog_name")  # "dev_adb"
endpoint = ConfigStore.get("VS_ENDPOINT")  # "benefits_quote_mvp1_vs_endpoint"
timeout = ConfigStore.get("timeout", 30)   # 30 (default)
```

---

#### `ConfigStore.all()`

Returns a copy of the entire configuration dictionary.

**Parameters**: None

**Returns**:
* `dict`: Copy of all configuration key-value pairs

**Description**:

This class method returns a shallow copy of the entire configuration store, useful for debugging or passing configuration to other components.

**Example**:

```python
# Get all configuration
config = ConfigStore.all()
print(f"Environment: {config.get('env')}")
print(f"Catalog: {config.get('catalog_name')}")
```

---

### Usage Pattern

The ConfigStore is designed to be initialized once at application startup (typically in MLflow's `load_context` method) and accessed globally throughout the codebase:

```python
# Initialization (in MLflow agent or notebook setup)
import yaml
from utilities.config_store import ConfigStore

with open("configs/dev_config.yml") as f:
    config = yaml.safe_load(f)
    ConfigStore.set(**config)

# Access anywhere in the codebase
from utilities.config_store import ConfigStore

vs_endpoint = ConfigStore.get("VS_ENDPOINT")
llm_endpoint = ConfigStore.get("LLM_ENDPOINT")
```

---

## Delta Table Utilities Details

### Class: `DeltaTableClient`

A comprehensive utility class for working with Delta Lake tables via Unity Catalog or filesystem paths.

**Location**: `delta_table_utils.py`

### Constructor

#### `DeltaTableClient(spark, identifier, *, is_path=False, partition_by=None)`

**Parameters**:
* `spark` (SparkSession): Active Spark session
* `identifier` (str): Unity Catalog table name (e.g., 'catalog.schema.table') or filesystem path
* `is_path` (bool, optional): Set True if identifier is a path. Default: False
* `partition_by` (List[str], optional): Columns to partition by on initial write. Default: None

**Description**:

Initializes a Delta table client for performing CRUD operations, merges, and maintenance tasks.

**Example**:

```python
from pyspark.sql import SparkSession
from utilities.delta_table_utils import DeltaTableClient

spark = SparkSession.builder.getOrCreate()

# Unity Catalog table
client = DeltaTableClient(
    spark,
    "dev_adb.nexusbenefitsquote_silver_mvp1.tbl_plan_details",
    partition_by=["effective_date"]
)

# Filesystem path
path_client = DeltaTableClient(
    spark,
    "/mnt/delta/plan_details",
    is_path=True,
    partition_by=["effective_date"]
)
```

---

### Methods

#### `ensure_table(df, *, schema_evolve=True)`

Creates the Delta table if it doesn't exist by writing an empty DataFrame with the correct schema.

**Parameters**:
* `df` (DataFrame): DataFrame with the desired schema
* `schema_evolve` (bool, optional): Allow schema evolution. Default: True

**Returns**: None

**Description**:

This method ensures the target table exists before performing operations. If the table already exists, it's a no-op. If not, it creates an empty table with the schema from the provided DataFrame.

**Example**:

```python
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Define schema
schema = StructType([
    StructField("facets_product_id", StringType(), False),
    StructField("effective_date", StringType(), False),
    StructField("plan_name", StringType(), True),
    StructField("nexusId", IntegerType(), True)
])

df = spark.createDataFrame([], schema)
client.ensure_table(df)
```

---

#### `overwrite(df, *, schema_evolve=True, replace_where=None)`

Overwrites the table with the provided DataFrame, optionally using dynamic partition overwrite.

**Parameters**:
* `df` (DataFrame): Data to write
* `schema_evolve` (bool, optional): Allow schema evolution. Default: True
* `replace_where` (str, optional): Condition for dynamic partition overwrite. Default: None

**Returns**: None

**Description**:

Performs a full or partial overwrite of the table. When `replace_where` is provided, only matching partitions/rows are replaced (Delta's `replaceWhere` feature). If the table doesn't exist, it's created.

**Example**:

```python
# Full overwrite
client.overwrite(new_data_df)

# Dynamic partition overwrite (only replace specific partitions)
client.overwrite(
    incremental_df,
    replace_where="effective_date >= '2025-01-01'"
)
```

---

#### `merge_upsert(source_df, *, keys, updates="*", insert_when_not_matched=True, delete_when_not_matched_by_source=False, predicate=None, schema_evolve=True)`

Performs an upsert (update + insert) operation using Delta MERGE.

**Parameters**:
* `source_df` (DataFrame): Source data to merge
* `keys` (str | Iterable[str]): Join keys for matching records
* `updates` (str | Dict[str, str], optional): Update mapping. "*" for all columns or dict of target_col -> expr. Default: "*"
* `insert_when_not_matched` (bool, optional): Insert unmatched source rows. Default: True
* `delete_when_not_matched_by_source` (bool, optional): Delete target rows not in source. Default: False
* `predicate` (str, optional): Additional merge condition. Default: None
* `schema_evolve` (bool, optional): Allow schema evolution. Default: True

**Returns**: None

**Description**:

Executes a Delta MERGE operation to synchronize the target table with source data. Supports complex update logic, conditional merges, and hard sync (delete unmatched).

**Example**:

```python
# Simple upsert on primary key
client.merge_upsert(
    source_df,
    keys=["facets_product_id", "effective_date"]
)

# Custom update logic with hard sync
client.merge_upsert(
    source_df,
    keys=["facets_product_id", "effective_date"],
    updates={
        "plan_name": "src.plan_name",
        "last_updated": "current_timestamp()",
        "status": "src.status"
    },
    delete_when_not_matched_by_source=True,
    predicate="src.is_active = true"
)
```

---

#### `optimize(zorder_by=None)`

Runs OPTIMIZE and optional ZORDER BY on the table.

**Parameters**:
* `zorder_by` (List[str], optional): Columns to ZORDER by. Default: None

**Returns**: None

**Description**:

Compacts small files and optionally applies Z-ordering for improved query performance. Only works with Unity Catalog table names.

**Example**:

```python
# Basic optimize
client.optimize()

# Optimize with Z-ordering
client.optimize(zorder_by=["facets_product_id", "effective_date"])
```

---

#### `vacuum(retention_hours=168)`

Removes old data files that are no longer referenced by the table.

**Parameters**:
* `retention_hours` (int, optional): Retention period in hours. Default: 168 (7 days)

**Returns**: None

**Description**:

Cleans up old data files to reclaim storage space. Default retention is 7 days to support time travel.

**Example**:

```python
# Vacuum with default 7-day retention
client.vacuum()

# Vacuum with custom retention
client.vacuum(retention_hours=24)  # 1 day
```

---

#### `history()`

Returns the Delta table history as a DataFrame.

**Parameters**: None

**Returns**:
* `DataFrame`: Table history with version, timestamp, operation, etc.

**Description**:

Retrieves the transaction log history for auditing and debugging.

**Example**:

```python
history_df = client.history()
display(history_df.select("version", "timestamp", "operation", "operationMetrics"))
```

---

## Lakebase Utilities Details

### Class: `LakebaseJDBCTableClient`

JDBC-based client for PostgreSQL operations with Databricks Lakebase integration.

**Location**: `lakebase_utils.py`

### Constructor

#### `LakebaseJDBCTableClient(*, instance, username, table, columns, conflict_keys, dbname="databricks_postgres", port=5432, sslmode="require", driver="org.postgresql.Driver")`

**Parameters**:
* `instance` (str): PostgreSQL server instance name
* `username` (str): Database username
* `table` (str): Target table name
* `columns` (Sequence[str]): List of column names in order
* `conflict_keys` (Sequence[str]): Primary key columns for merge operations
* `dbname` (str, optional): Database name. Default: "databricks_postgres"
* `port` (int, optional): PostgreSQL port. Default: 5432
* `sslmode` (str, optional): SSL mode. Default: "require"
* `driver` (str, optional): JDBC driver class. Default: "org.postgresql.Driver"

**Description**:

Initializes a JDBC client for PostgreSQL operations using Databricks Lakebase temporary credentials.

**Example**:

```python
from pyspark.sql import SparkSession
from utilities.lakebase_utils import LakebaseJDBCTableClient

spark = SparkSession.builder.getOrCreate()

client = LakebaseJDBCTableClient(
    instance="db-benefits-ci-cd-test",
    username="databricks_user",
    table="chat_history",
    columns=["session_id", "question_id", "user_id", "question", "answer", "timestamp"],
    conflict_keys=["session_id", "question_id"]
)
```

---

### Methods

#### `read_all(spark)`

Reads the entire table as a Spark DataFrame.

**Parameters**:
* `spark` (SparkSession): Active Spark session

**Returns**:
* `DataFrame`: Complete table data

**Description**:

Fetches all rows from the PostgreSQL table via JDBC and returns them as a Spark DataFrame with columns in the specified order.

**Example**:

```python
# Read entire table
df = client.read_all(spark)
display(df)
```

---

#### `insert_rows(spark, df, mode="append")`

Appends rows from a DataFrame to the PostgreSQL table.

**Parameters**:
* `spark` (SparkSession): Active Spark session
* `df` (DataFrame): Data to insert (must have exactly the columns specified in constructor)
* `mode` (str, optional): Write mode ("append" or "overwrite"). Default: "append"

**Returns**: None

**Description**:

Writes DataFrame rows to PostgreSQL via JDBC. The DataFrame must contain exactly the columns specified during client initialization.

**Example**:

```python
from pyspark.sql import Row

# Create data to insert
new_rows = spark.createDataFrame([
    Row(session_id="sess_001", question_id="q_001", user_id="user_123",
        question="What is the copay?", answer="$20", timestamp="2025-01-15 10:30:00")
])

# Insert rows
client.insert_rows(spark, new_rows)
```

---

#### `merge_rows(spark, df, stage_table=None)`

Performs a server-side MERGE operation using a staging table.

**Parameters**:
* `spark` (SparkSession): Active Spark session
* `df` (DataFrame): Source data to merge
* `stage_table` (str, optional): Staging table name. Default: auto-generated

**Returns**: None

**Description**:

Writes data to a temporary staging table, executes a PostgreSQL 16+ native MERGE statement to upsert records, then drops the staging table. Updates all non-key columns on conflict; inserts otherwise.

**Example**:

```python
# Upsert chat history
updated_history = spark.createDataFrame([
    Row(session_id="sess_001", question_id="q_001", user_id="user_123",
        question="What is the copay?", answer="$20 for primary care", timestamp="2025-01-15 10:35:00")
])

# Merge (update existing, insert new)
client.merge_rows(spark, updated_history)
```

---

### Usage Pattern

The LakebaseJDBCTableClient is designed for synchronizing chat history between Delta Lake and PostgreSQL:

```python
from utilities.lakebase_utils import LakebaseJDBCTableClient

# Initialize client
client = LakebaseJDBCTableClient(
    instance="db-benefits-ci-cd-test",
    username="databricks_user",
    table="chat_history",
    columns=["session_id", "question_id", "user_id", "question", "answer", "timestamp"],
    conflict_keys=["session_id", "question_id"]
)

# Read from PostgreSQL
pg_data = client.read_all(spark)

# Process in Delta Lake
delta_data = spark.table("dev_adb.nexusbenefitsquote_gold_mvp1.chat_history")

# Sync back to PostgreSQL
client.merge_rows(spark, delta_data)
```

---

## Data Pipeline Ingestion Details

### Module: `data_pipeline/ingestion.py`

Comprehensive data ingestion utilities for fetching plan data from external APIs and preparing it for processing.

### Functions

#### `fetch_ppdd(facets_product_id, effective_date, API_BASE)`

Fetches a single PPDD (Plan Product Data Definition) record from the external API.

**Parameters**:
* `facets_product_id` (str): Unique product identifier
* `effective_date` (str): Product effective date (YYYY-MM-DD format)
* `API_BASE` (str): Base URL for the API endpoint

**Returns**:
* `Tuple[Optional[Dict[str, Any]], Optional[str]]`: (payload_dict, error_message)
  * `payload_dict`: Normalized dictionary with product data, or None on error
  * `error_message`: None on success; error description on failure

**Description**:

Makes an HTTP GET request to fetch plan data from the external Product Search API. Handles various error conditions including HTTP errors, SSL errors, timeouts, and unexpected JSON formats.

**Example**:

```python
from utilities.data_pipeline.ingestion import fetch_ppdd

API_BASE = "https://app-prdsrch-npn-to-bncp-cus-452.azurewebsites.net/api/v2/PPDD"

# Fetch plan data
payload, error = fetch_ppdd(
    facets_product_id="28115",
    effective_date="2025-01-01",
    API_BASE=API_BASE
)

if error:
    print(f"Error fetching data: {error}")
else:
    print(f"Product: {payload.get('productLineOfBusiness')}")
    print(f"Plan Name: {payload.get('planName')}")
```

---

#### `build_master_rows_from_api_result(facets_product_id, product_effective_date, api_item, error_msg, output_dir, REQUESTER_ID, lob)`

Maps API result (or error) to a master table row and writes JSON artifact.

**Parameters**:
* `facets_product_id` (str): Product identifier
* `product_effective_date` (str): Effective date
* `api_item` (dict): API response payload (or None on error)
* `error_msg` (str): Error message (or None on success)
* `output_dir` (str): Directory path for JSON artifacts
* `REQUESTER_ID` (str): Identifier of the requester
* `lob` (str): Line of business

**Returns**:
* `Dict[str, Any]`: Master table row as a dictionary

**Description**:

Transforms API response into a standardized master table row format. If the API call succeeded, it also writes a JSON artifact to the specified output directory.

**Example**:

```python
from utilities.data_pipeline.ingestion import build_master_rows_from_api_result

row = build_master_rows_from_api_result(
    facets_product_id="28115",
    product_effective_date="2025-01-01",
    api_item=payload,
    error_msg=None,
    output_dir="/Volumes/dev_adb/nexusbenefitsquote_bronze_mvp1/plan_data_mvp1",
    REQUESTER_ID="data_engineer_001",
    lob="Small"
)

print(row)
# Output: {'facets_product_id': '28115', 'product_effective_date': '2025-01-01', ...}
```

---

#### `prepare_volume_dataframe(spark, master_df, volume_path, *, key1_col, key2_col, product_type_col, multiline=False)`

Reads JSON files from a Unity Catalog volume that match keys in the master DataFrame.

**Parameters**:
* `spark` (SparkSession): Active Spark session
* `master_df` (DataFrame): Master table with keys to match
* `volume_path` (str): Unity Catalog volume path
* `key1_col` (str): First key column name (e.g., "facets_product_id")
* `key2_col` (str): Second key column name (e.g., "effective_date")
* `product_type_col` (str): Product type column name
* `multiline` (bool, optional): Enable multiline JSON parsing. Default: False

**Returns**:
* `DataFrame`: Parsed JSON data from matching files

**Description**:

Constructs expected filenames from master_df keys, checks which files exist in the volume, and reads only those files. Skips missing files gracefully.

**Example**:

```python
from utilities.data_pipeline.ingestion import prepare_volume_dataframe

# Master table with keys
master_df = spark.table("dev_adb.nexusbenefitsquote_bronze_mvp1.master_table")

# Read matching JSON files from volume
volume_df = prepare_volume_dataframe(
    spark=spark,
    master_df=master_df,
    volume_path="/Volumes/dev_adb/nexusbenefitsquote_bronze_mvp1/plan_data_mvp1",
    key1_col="facets_product_id",
    key2_col="product_effective_date",
    product_type_col="product_type",
    multiline=True
)

display(volume_df)
```

---

#### `compute_data_issue(df)`

Validates data completeness by checking for empty or null array fields.

**Parameters**:
* `df` (DataFrame): DataFrame with nested `row_value` struct containing array fields

**Returns**:
* `DataFrame`: Input DataFrame with added `data_issue` and `bronze_ready_flag` columns

**Description**:

Examines array fields (eocSections, eocCategories) within the row_value struct and flags records with empty or null arrays. Sets bronze_ready_flag to 'Y' if no issues, 'N' otherwise.

**Example**:

```python
from utilities.data_pipeline.ingestion import compute_data_issue

# Validate data
validated_df = compute_data_issue(volume_df)

# Filter ready records
ready_df = validated_df.filter("bronze_ready_flag = 'Y'")
display(ready_df)
```

---

#### `read_csv_keys_as_df(spark, csv_path)`

Reads a CSV file containing product keys and normalizes column names.

**Parameters**:
* `spark` (SparkSession): Active Spark session
* `csv_path` (str): Path to CSV file

**Returns**:
* `DataFrame`: Normalized DataFrame with columns: facets_product_id, product_effective_date, productLineOfBusiness

**Description**:

Reads CSV with flexible column name matching (case-insensitive, with/without underscores). Falls back to positional parsing if headers are missing.

**Example**:

```python
from utilities.data_pipeline.ingestion import read_csv_keys_as_df

keys_df = read_csv_keys_as_df(
    spark,
    "/Volumes/dev_adb/nexusbenefitsquote_bronze_mvp1/plan_data_mvp1/product_keys.csv"
)

display(keys_df)
```

---

## Data Pipeline Transformation Details

### Module: `data_pipeline/transformation.py`

PySpark-based transformation functions for processing plan data into structured tables.

### Functions

#### `process_plan_details(df)`

Extracts and flattens plan metadata from nested JSON structure.

**Parameters**:
* `df` (DataFrame): Input DataFrame with nested `row_value` struct

**Returns**:
* `DataFrame`: Flattened plan details with mapped medical network

**Description**:

Selects and flattens plan-level fields from the nested row_value structure. Maps medical network values to standardized categories (PPO, HMO, HMO Access+).

**Example**:

```python
from utilities.data_pipeline.transformation import process_plan_details

# Process plan details
plan_details_df = process_plan_details(volume_df)

display(plan_details_df.select(
    "facets_product_id",
    "effective_date",
    "planName",
    "medicalNetwork",
    "mapped_medical_network"
))
```

---

#### `process_eoc_categories(df)`

Processes Evidence of Coverage categories by exploding nested arrays.

**Parameters**:
* `df` (DataFrame): Input DataFrame with nested eocCategories array

**Returns**:
* `DataFrame`: Exploded EOC categories with unique benefit_id

**Description**:

Explodes the eocCategories array and creates a unique benefit_id by concatenating plan nexusId with category nexusId. Serializes all category fields to JSON.

**Example**:

```python
from utilities.data_pipeline.transformation import process_eoc_categories

# Process EOC categories
eoc_categories_df = process_eoc_categories(volume_df)

display(eoc_categories_df.select(
    "facets_product_id",
    "effective_date",
    "nexusId",
    "benefit_id",
    "eoc_categories_all_fields"
))
```

---

#### `process_eoc_program_categories(df)`

Processes program categories from nested structure.

**Parameters**:
* `df` (DataFrame): Input DataFrame with nested programCategories array

**Returns**:
* `DataFrame`: Exploded program categories with unique program_id

**Description**:

Explodes the programCategories array and creates a unique program_id. Serializes program details to JSON for downstream processing.

**Example**:

```python
from utilities.data_pipeline.transformation import process_eoc_program_categories

# Process program categories
program_df = process_eoc_program_categories(volume_df)

display(program_df.select(
    "facets_product_id",
    "effective_date",
    "nexusId",
    "program_id",
    "combined_eoc_program_categories"
))
```

---

#### `process_eoc_sections(df)`

Processes EOC sections and items from nested structure.

**Parameters**:
* `df` (DataFrame): Input DataFrame with nested eocSections array

**Returns**:
* `DataFrame`: Exploded EOC sections with unique section_id

**Description**:

Explodes the eocSections array and creates a unique section_id. Serializes section details including eocItems to JSON.

**Example**:

```python
from utilities.data_pipeline.transformation import process_eoc_sections

# Process EOC sections
sections_df = process_eoc_sections(volume_df)

display(sections_df.select(
    "facets_product_id",
    "effective_date",
    "nexusId",
    "section_id",
    "eoc_sections_combined"
))
```

---

#### `update_plan_fields(df, master_table_path, spark)`

Updates master table with plan metadata fields.

**Parameters**:
* `df` (DataFrame): Source DataFrame with plan fields
* `master_table_path` (str): Unity Catalog path to master table
* `spark` (SparkSession): Active Spark session

**Returns**: None

**Description**:

Executes SQL UPDATE statement to populate plan_type, product_description, and plan_id in the master table based on matching facets_product_id and effective_date.

**Example**:

```python
from utilities.data_pipeline.transformation import update_plan_fields

update_plan_fields(
    df=plan_details_df,
    master_table_path="dev_adb.nexusbenefitsquote_bronze_mvp1.master_table",
    spark=spark
)
```

---

#### `update_ready_flags_master_table(df, master_table_path, spark)`

Updates processing status flags in master table.

**Parameters**:
* `df` (DataFrame): Source DataFrame with processed records
* `master_table_path` (str): Unity Catalog path to master table
* `spark` (SparkSession): Active Spark session

**Returns**: None

**Description**:

Sets dbr_silver_layer_ready and vector_db_ready flags to 'Y' for records that have been successfully processed.

**Example**:

```python
from utilities.data_pipeline.transformation import update_ready_flags_master_table

update_ready_flags_master_table(
    df=processed_df,
    master_table_path="dev_adb.nexusbenefitsquote_bronze_mvp1.master_table",
    spark=spark
)
```

---

## Benefit Agent MLflow Logging Details

### Module: `LLM_pipeline/benefit_agent_mlflow_utils_log.py`

Comprehensive LangGraph-based agent implementation with MLflow deployment support and retry policies.

### Key Components

#### `State` (TypedDict)

State management for the LangGraph agent workflow.

**Fields**:
* `messages` (list): Conversation message history
* `input` (str): Current user input
* `expanded_question` (str): Expanded/clarified question
* `original_question` (str): Original user question
* `plan_nexus` (str): Plan identifier
* `plan_name` (str): Human-readable plan name
* `plan_type` (str): Plan type (PPO, HMO, etc.)
* `followup` (str): Follow-up indicator
* `intent` (list): Classified user intent
* `cost_share` (List[Dict]): Cost sharing information
* `def_cost_share` (List[Dict]): Definition cost shares
* `exclusion` (List[Dict]): Exclusion information
* `program_details` (List[Dict]): Program category details
* `uid` (str): User ID
* `sid` (str): Session ID
* `question_id` (str): Question identifier
* `facets_product_id` (str): Product ID
* `effective_date` (str): Effective date
* `error` (str): Error message

---

### Node Functions

#### `detect_plan(state)`

Detects and loads plan metadata based on facets_product_id and effective_date.

**Parameters**:
* `state` (State): Current agent state

**Returns**:
* `State`: Updated state with plan information

**Description**:

Invokes PlanDetectTool to fetch plan metadata including nexusId, cost shares, plan name, and plan type.

**Example**:

```python
# Node function (called by LangGraph)
state = detect_plan(state)
print(f"Plan: {state['plan_name']}")
print(f"Type: {state['plan_type']}")
```

---

#### `fetch_intent(state)`

Classifies user intent and expands the question for better understanding.

**Parameters**:
* `state` (State): Current agent state

**Returns**:
* `State`: Updated state with intent and expanded question

**Description**:

Uses ClassifyIntentTool to determine user intent (EoCCategory, BenefitCostShares, ProgramCategories, GenericDefinition, Exclusions) and expand the question with context.

**Example**:

```python
# Node function (called by LangGraph)
state = fetch_intent(state)
print(f"Intent: {state['intent']}")
print(f"Expanded: {state['expanded_question']}")
```

---

#### `fetch_cost_share(state)`

Retrieves cost sharing information relevant to the user's question.

**Parameters**:
* `state` (State): Current agent state

**Returns**:
* `State`: Updated state with cost_share data

**Description**:

Invokes CopayCoinsuranceTool to search vector indexes for relevant cost sharing information.

---

#### `fetch_exclusion(state)`

Retrieves exclusion information for the plan.

**Parameters**:
* `state` (State): Current agent state

**Returns**:
* `State`: Updated state with exclusion data

**Description**:

Invokes ExclusionCheckTool to fetch plan exclusions and limitations.

---

#### `fetch_programcategory(state)`

Retrieves program category details (wellness, preventive care, etc.).

**Parameters**:
* `state` (State): Current agent state

**Returns**:
* `State`: Updated state with program_details data

**Description**:

Invokes ProgrammanagementTool to fetch program-related information.

---

#### `generate_answer(state)`

Generates the final answer using LLM with all gathered context.

**Parameters**:
* `state` (State): Current agent state with all gathered information

**Returns**:
* `State`: Updated state with generated answer

**Description**:

Invokes GenerateAnswerTool with all context (plan metadata, cost shares, exclusions, program details) to generate a comprehensive answer. Includes retry policy for robustness.

---

#### `route_to_next_tool(state)`

Conditional routing function to determine next node based on intent.

**Parameters**:
* `state` (State): Current agent state

**Returns**:
* `str`: Next node name ("get_cost_share", "get_definition", "get_programdetail", "fallback")

**Description**:

Routes the workflow based on classified intent. Handles both single intent strings and lists of intents.

---

### Class: `BenefitCostResponsesAgent`

MLflow ResponsesAgent implementation for deployment.

#### `__init__(env="dev")`

**Parameters**:
* `env` (str, optional): Environment name. Default: "dev"

**Description**:

Initializes the agent with environment configuration.

---

#### `load_context(context)`

Loads configuration and initializes the LangGraph agent.

**Parameters**:
* `context` (PythonModelContext): MLflow model context with artifacts

**Returns**: None

**Description**:

Loads environment-specific configuration from artifacts, initializes ConfigStore, sets global variables, and builds the LangGraph workflow.

**Example**:

```python
# Called automatically by MLflow during model loading
# Artifacts structure:
# - configs/ (folder with dev_config.yml, qa_config.yml, etc.)
# - run_cfg (JSON file with {"env": "dev"})
```

---

#### `predict(request)`

Processes a user request and returns an agent response.

**Parameters**:
* `request` (ResponsesAgentRequest): MLflow Responses API request

**Returns**:
* `ResponsesAgentResponse`: Agent response with answer

**Description**:

Extracts user input and custom inputs (user_id, session_id, question_id, facets_product_id, effective_date), invokes the LangGraph agent, and returns the formatted response.

**Example**:

```python
# Called by MLflow serving endpoint
# Request format:
# {
#   "input": [{"role": "user", "content": [{"text": "What is the copay?"}]}],
#   "custom_inputs": {
#     "user_id": "user_123",
#     "session_id": "sess_001",
#     "question_id": "q_001",
#     "facets_product_id": "28115",
#     "effective_date": "2025-01-01"
#   }
# }
```

---

### Function: `build_graph()`

Constructs the LangGraph workflow.

**Parameters**: None

**Returns**:
* `CompiledGraph`: Compiled LangGraph workflow

**Description**:

Builds a StateGraph with nodes for plan detection, intent classification, cost share retrieval, exclusion checking, program details, and answer generation. Includes conditional routing and retry policies.

**Example**:

```python
# Graph structure:
# START -> detect_plan -> classify_intent -> [conditional routing]
#   -> get_cost_share -> fetch_exclusion -> generate_answer -> END
#   -> get_definition -> generate_answer -> END
#   -> get_programdetail -> generate_answer -> END
#   -> fallback -> END
```

---

### Deployment Example

```python
import mlflow
from utilities.LLM_pipeline.benefit_agent_mlflow_utils_log import BenefitCostResponsesAgent

# Log model with artifacts
with mlflow.start_run():
    mlflow.pyfunc.log_model(
        artifact_path="agent",
        python_model=BenefitCostResponsesAgent(),
        artifacts={
            "configs": "configs/",  # folder with env configs
            "run_cfg": "run_config.json"  # {"env": "dev"}
        },
        pip_requirements=[
            "langchain-core",
            "langgraph",
            "databricks-langchain",
            "databricks-vectorsearch",
            "mlflow",
            "pydantic"
        ]
    )

# Register model
model_uri = f"runs:/{mlflow.active_run().info.run_id}/agent"
mlflow.register_model(model_uri, "benefit_cost_agent")
```

---

## Benefit Agent Context Logging Details

### Module: `LLM_pipeline/benefit_agent_mlflow_utils_context_log.py`

Simplified agent implementation focused on context-aware answer generation without retry policies.

### Key Differences from Full Logging Version

* **No Retry Policy**: Removed retry logic from generate_answer node
* **Simplified State**: Removed `original_question` field from State
* **Context-Focused**: Emphasizes context retrieval over error handling
* **Streamlined Routing**: Simplified conditional routing logic

### Usage

This version is suitable for:
* Development and testing environments
* Scenarios where retry logic is handled externally
* Faster iteration during development

### Example

```python
# Same deployment pattern as full version
from utilities.LLM_pipeline.benefit_agent_mlflow_utils_context_log import BenefitCostResponsesAgent

agent = BenefitCostResponsesAgent(env="dev")
# ... rest of deployment code
```

---

## Best Practices

### Configuration Management

1. **Initialize ConfigStore Early**: Set configuration at application startup
2. **Environment Isolation**: Use separate configs for dev/qa/prod
3. **Secret Management**: Never commit secrets; use Databricks secrets
4. **Validation**: Validate required config keys after initialization

### Delta Table Operations

1. **Use Merge for Updates**: Prefer merge_upsert over overwrite for incremental updates
2. **Partition Wisely**: Partition by date columns for time-series data
3. **Optimize Regularly**: Run OPTIMIZE after large writes
4. **Schema Evolution**: Enable schema evolution for flexibility

### Data Pipeline

1. **Error Handling**: Always check for errors in fetch_ppdd responses
2. **Data Validation**: Use compute_data_issue before processing
3. **Incremental Processing**: Use left_anti_not_loaded to avoid reprocessing
4. **Artifact Storage**: Store raw JSON artifacts for debugging

### LLM Agent Deployment

1. **Artifact Organization**: Keep configs in a separate folder
2. **Environment Configuration**: Use run_cfg.json to specify environment
3. **Retry Policies**: Use retry policies for production deployments
4. **Logging**: Enable comprehensive logging for debugging

---

## Troubleshooting

### Common Issues

**Issue**: ConfigStore returns None for existing keys
```
Solution: Ensure ConfigStore.set() was called before accessing values
```

**Issue**: Delta merge fails with schema mismatch
```
Solution: Enable schema_evolve=True or align DataFrame schema with target table
```

**Issue**: Lakebase JDBC connection timeout
```
Solution: Check network connectivity and SSL mode; verify instance name
```

**Issue**: Vector search returns no results
```
Solution: Verify index exists and is synced; check score_threshold setting
```

**Issue**: MLflow agent fails to load context
```
Solution: Verify artifacts are logged correctly; check run_cfg.json format
```

---

## Support & Contact

For questions or issues related to this utilities module, please contact the MVP1 team.

