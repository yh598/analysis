# delta_table_utils.py
from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Union
from pyspark.sql import DataFrame, SparkSession, functions as F
from delta.tables import DeltaTable


class DeltaTableClient:
    """
    Utility for working with Delta tables via either a Unity Catalog table name
    (e.g., 'catalog.schema.table') or a filesystem path ('/mnt/...').

    Parameters
    ----------
    spark : SparkSession
    identifier : str
        UC table identifier or filesystem path.
    is_path : bool, default False
        Set True if `identifier` is a path. Otherwise it's treated as a table name.
    partition_by : Optional[List[str]]
        Columns to partition by on initial write (if table doesn’t exist).
    """

    def __init__(
        self,
        spark: SparkSession,
        identifier: str,
        *,
        is_path: bool = False,
        partition_by: Optional[List[str]] = None,
    ) -> None:
        self.spark = spark
        self.identifier = identifier
        self.is_path = is_path
        self.partition_by = partition_by or []

    # ---------------------------
    # Helpers
    # ---------------------------
    def _table_exists(self) -> bool:
        if self.is_path:
            try:
                dt = DeltaTable.forPath(self.spark, self.identifier)
                _ = dt.toDF().limit(1).count()
                return True
            except Exception:
                return False
        else:
            try:
                return self.spark.catalog.tableExists(self.identifier)
            except Exception:
                return False

    def _as_delta_table(self) -> DeltaTable:
        if self.is_path:
            return DeltaTable.forPath(self.spark, self.identifier)
        return DeltaTable.forName(self.spark, self.identifier)

    def _write_builder(self, df: DataFrame):
        wb = (
            df.write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
        )
        if self.partition_by:
            wb = wb.partitionBy(*self.partition_by)
        return wb

    # ---------------------------
    # Public API
    # ---------------------------
    def ensure_table(self, df: DataFrame, *, schema_evolve: bool = True) -> None:
        """
        Create the Delta table if it does not exist by writing `df` as an empty table
        with the right schema/partitions. No-op if it exists.
        """
        if self._table_exists():
            return

        empty_df = df.limit(0)
        if self.is_path:
            writer = self._write_builder(empty_df)
            if schema_evolve:
                writer = writer.option("mergeSchema", "true")
            writer.save(self.identifier)
        else:
            writer = self._write_builder(empty_df)
            if schema_evolve:
                writer = writer.option("mergeSchema", "true")
            writer.saveAsTable(self.identifier)

    def overwrite(
        self,
        df: DataFrame,
        *,
        schema_evolve: bool = True,
        replace_where: Optional[str] = None,
    ) -> None:
        """
        Overwrite the table with `df`.
        - If `replace_where` is provided, performs **dynamic partition overwrite**
          of only matching partitions/rows (Delta's `replaceWhere`).
        - If the table doesn't exist, it is created.

        Example:
            client.overwrite(df, replace_where="ingestion_date >= '2025-10-01'")
        """
        self.ensure_table(df, schema_evolve=schema_evolve)

        writer = (
            df.write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true" if schema_evolve else "false")
        )
        if self.partition_by:
            writer = writer.partitionBy(*self.partition_by)
        if replace_where:
            writer = writer.option("replaceWhere", replace_where)

        if self.is_path:
            writer.save(self.identifier)
        else:
            writer.saveAsTable(self.identifier)

    def merge_upsert(
        self,
        source_df: DataFrame,
        *,
        keys: Union[str, Iterable[str]],
        updates: Union[str, Dict[str, str]] = "*",
        insert_when_not_matched: bool = True,
        delete_when_not_matched_by_source: bool = False,
        predicate: Optional[str] = None,
        schema_evolve: bool = True,
    ) -> None:
        """
        Upsert `source_df` into the target Delta table using MERGE.

        Parameters
        ----------
        keys : str | Iterable[str]
            Join keys. Example: ["id"] or ["id", "effective_date"]
        updates : "*" to update all columns, or mapping target_col -> expr (as SQL string)
            Example: {"last_updated_ts": "current_timestamp()", "status": "src.status"}
        insert_when_not_matched : bool
        delete_when_not_matched_by_source : bool
            If True, delete target rows that are unmatched by source (i.e., hard sync).
        predicate : Optional[str]
            Extra condition appended to the merge ON clause (e.g., "src.is_current = true").
        schema_evolve : bool
            If True, allow schema evolution during merge (new columns).

        Notes
        -----
        - When `updates="*"`, all columns from source replace target columns by name.
        - To evolve schema (new columns), Delta requires `spark.databricks.delta.schema.autoMerge.enabled = true`
          or option("mergeSchema", "true") on writes; we temporarily set the conf if needed.
        """
        self.ensure_table(source_df, schema_evolve=schema_evolve)

        # Build ON clause
        key_list = [keys] if isinstance(keys, str) else list(keys)
        on = " AND ".join([f"t.`{k}` <=> src.`{k}`" for k in key_list])  # null-safe equality
        if predicate:
            on = f"({on}) AND ({predicate})"

        # Prepare DeltaTable
        target = self._as_delta_table()
        merge_builder = target.alias("t").merge(source_df.alias("src"), on)

        # When matched -> UPDATE
        if updates == "*":
            merge_builder = merge_builder.whenMatchedUpdateAll()
        else:
            # Convert dict into column/expr mapping
            if not isinstance(updates, dict):
                raise TypeError("updates must be '*' or Dict[target_col -> sql_expr]")
            merge_builder = merge_builder.whenMatchedUpdate(set=updates)

        # Optionally delete unmatched-by-source rows (hard sync)
        if delete_when_not_matched_by_source:
            merge_builder = merge_builder.whenNotMatchedBySourceDelete()

        # When not matched -> INSERT
        if insert_when_not_matched:
            if updates == "*":
                merge_builder = merge_builder.whenNotMatchedInsertAll()
            else:
                # If custom updates, default insert maps all source columns unless specified:
                insert_map = {c: f"src.`{c}`" for c in source_df.columns}
                merge_builder = merge_builder.whenNotMatchedInsert(values=insert_map)

        # Schema evolution (session-level flag for merge)
        prev = self.spark.conf.get("spark.databricks.delta.schema.autoMerge.enabled", "false")
        try:
            if schema_evolve:
                self.spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
            merge_builder.execute()
        finally:
            # restore previous conf
            self.spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", prev)

    # ---------------------------
    # Maintenance (optional)
    # ---------------------------
    def optimize(self, zorder_by: Optional[List[str]] = None) -> None:
        """
        Runs OPTIMIZE and optional ZORDER BY (SQL). Works for UC table names only.
        """
        if self.is_path:
            raise ValueError("OPTIMIZE is only supported for tables, not paths.")
        if zorder_by:
            self.spark.sql(f"OPTIMIZE {self.identifier} ZORDER BY ({', '.join(zorder_by)})")
        else:
            self.spark.sql(f"OPTIMIZE {self.identifier}")

    def vacuum(self, retention_hours: int = 168) -> None:
        """
        VACUUM the table. Default retention 7 days.
        """
        if self.is_path:
            self.spark.sql(f"VACUUM delta.`{self.identifier}` RETAIN {retention_hours} HOURS")
        else:
            self.spark.sql(f"VACUUM {self.identifier} RETAIN {retention_hours} HOURS")

    def history(self) -> DataFrame:
        """
        Return Delta history as a DataFrame.
        """
        return self._as_delta_table().history()
