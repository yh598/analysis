import uuid
from typing import Sequence, Optional

from databricks.sdk import WorkspaceClient
from pyspark.sql import DataFrame, SparkSession


class LakebaseJDBCTableClient:
    """
    JDBC-based client with exactly three operations:
      1) read_all(spark)                  -> Spark DataFrame (whole table)
      2) insert_rows(spark, df)           -> append rows from Spark DF
      3) merge_rows(spark, df)            -> server-side MERGE using staging table (PostgreSQL 16+)

    Notes:
      - Assumes the PostgreSQL JDBC driver is available on the cluster.
      - Uses Lakebase temp creds via Databricks WorkspaceClient.
      - df MUST contain exactly the columns in `columns` (same names/order).
    """

    def __init__(
        self,
        *,
        instance: str,
        username: str,
        table: str,
        columns: Sequence[str],
        conflict_keys: Sequence[str],
        dbname: str = "databricks_postgres",
        port: int = 5432,
        sslmode: str = "require",
        driver: str = "org.postgresql.Driver",
    ):
        self.instance = instance
        self.username = username
        self.table = table
        self.columns = list(columns)
        self.conflict_keys = list(conflict_keys)
        self.dbname = dbname
        self.port = port
        self.sslmode = sslmode
        self.driver = driver

        self._w = WorkspaceClient()

    # ---- Internal helpers -----------------------------------------------------
    def _jdbc_url_and_props(self):
        inst = self._w.database.get_database_instance(name=self.instance)
        cred = self._w.database.generate_database_credential(
            request_id=str(uuid.uuid4()), instance_names=[self.instance]
        )
        url = f"jdbc:postgresql://{inst.read_write_dns}:{self.port}/{self.dbname}"
        props = {
            "user": self.username,
            "password": cred.token,
            "sslmode": self.sslmode,
            "driver": self.driver,
        }
        return url, props

    def _java_props(self, spark: SparkSession, props: dict):
        jprops = spark._sc._jvm.java.util.Properties()
        for k, v in props.items():
            jprops.setProperty(k, v)
        return jprops

    def _exec_jdbc_sql(self, spark: SparkSession, sql: str) -> None:
        """
        Execute a non-SELECT SQL (e.g., MERGE / DDL) via JDBC using the JVM.
        """
        url, props = self._jdbc_url_and_props()
        jv = spark._sc._jvm
        DriverManager = jv.java.sql.DriverManager
        jprops = self._java_props(spark, props)
        conn = None
        stmt = None
        try:
            conn = DriverManager.getConnection(url, jprops)
            stmt = conn.createStatement()
            stmt.execute(sql)
            conn.commit()
        finally:
            try:
                if stmt is not None:
                    stmt.close()
            finally:
                if conn is not None:
                    conn.close()

    # ---- 1) READ WHOLE TABLE --------------------------------------------------
    def read_all(self, spark: SparkSession) -> DataFrame:
        """
        Returns the entire table as a Spark DataFrame.
        """
        url, props = self._jdbc_url_and_props()
        return (spark.read
                .jdbc(url=url, table=self.table, properties=props)
                .select(*self.columns))  # enforce column order

    # ---- 2) INSERT INTO TABLE (append) ----------------------------------------
    def insert_rows(self, spark: SparkSession, df: DataFrame, mode: str = "append") -> None:
        """
        Appends rows from `df` into the target table via JDBC.
        `df` must have exactly `self.columns` with compatible types.
        """
        url, props = self._jdbc_url_and_props()
        (df.select(*self.columns)
           .write
           .mode(mode)           # "append" (default) or "overwrite" if you really want to replace
           .jdbc(url=url, table=self.table, properties=props))

    # ---- 3) MERGE (server-side, via staging table) ----------------------------
    def merge_rows(self, spark: SparkSession, df: DataFrame, stage_table: Optional[str] = None) -> None:
        """
        Writes `df` to a temporary staging table via JDBC, then runs a single
        MERGE INTO target using PostgreSQL 16+ native MERGE, and finally drops the stage.

        Conflict resolution: updates ALL non-key columns; inserts otherwise.
        """
        if stage_table is None:
            stage_table = f"stage_{self.table}_{uuid.uuid4().hex[:8]}"

        non_conflict = [c for c in self.columns if c not in self.conflict_keys]
        if not non_conflict:
            raise ValueError("No updatable columns outside conflict_keys.")

        # 1) Write staging table
        url, props = self._jdbc_url_and_props()
        (df.select(*self.columns)
           .write
           .mode("overwrite")
           .jdbc(url=url, table=stage_table, properties=props))

        # 2) Build MERGE SQL
        on_clause   = " AND ".join([f"t.{k} = s.{k}" for k in self.conflict_keys])
        set_clause  = ", ".join([f"{c} = s.{c}" for c in non_conflict])
        insert_cols = ", ".join(self.columns)
        insert_vals = ", ".join([f"s.{c}" for c in self.columns])

        merge_sql = f"""
        MERGE INTO {self.table} AS t
        USING {stage_table} AS s
        ON {on_clause}
        WHEN MATCHED THEN
          UPDATE SET {set_clause}
        WHEN NOT MATCHED THEN
          INSERT ({insert_cols}) VALUES ({insert_vals});
        """

        # 3) Execute MERGE + drop stage
        try:
            self._exec_jdbc_sql(spark, merge_sql)
        finally:
            self._exec_jdbc_sql(spark, f"DROP TABLE IF EXISTS {stage_table};")
