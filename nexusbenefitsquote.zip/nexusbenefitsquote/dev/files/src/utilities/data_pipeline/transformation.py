from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct, udf,when
from pyspark.sql.types import StringType
import pyspark.sql.functions as F
import re

def clean_text(text):
    # 1. Remove <...>digit\t<...>
    text = re.sub(r'<[^>]*>\d+\\t<[^>]*>', '', text)
    # 2. Remove all HTML tags except anchor tags
    text = re.sub(r'</?(?!A\b)[^>]+>', ' ', text, flags=re.IGNORECASE)
    #3.Remove all extra space with one space
    text = re.sub(r'\s+', ' ', text).strip()
    #4.Remove space after dot,colon,semicolon
    text = re.sub(r"([.:;])\s+", r"\1", text)
    return text

clean_text_udf = udf(clean_text, StringType())

def process_plan_details(df):
    try:
        plan_details_df = df.select(
            "facets_product_id",
            "effective_date",
            "product_line_of_business",
            "file_name",
            col("row_value.nexusId").cast("string").alias("nexusId"),
            "row_value.lastPublished",
            "row_value.publishedBy",
            "row_value.facetsProductDescription",
            "row_value.facetsPlanId",
            "row_value.planType",
            "row_value.marketType",
            "row_value.commercialMarketStatus",
            "row_value.planName",
            "row_value.planANumber",
            "row_value.sourceSystemCode",
            "row_value.account",
            "row_value.accountType",
            "row_value.planStructureType",
            "row_value.planStructureTypeCode",
            "row_value.productConfigurationType",
            "row_value.productClassification",
            "row_value.fundingMethodType",
            "row_value.accumulatorPeriodCode",
            "row_value.opportunityType",
            "row_value.exchangeStatus",
            "row_value.medicalNetwork",
            "row_value.pharmacyNetwork",
            "row_value.regulatoryAgency",
            "row_value.drugFormulary",
            "row_value.medicarePartDStatus",
            "row_value.customProviderNetworks",
            "row_value.customerServicePhone",
            "row_value.drugFormularyId",
            F.to_json(col("row_value.planCostShares")).alias("planCostShares")
        )
        plan_details_df = plan_details_df.withColumn(
              "mapped_medical_network",
       when(
        col("medicalNetwork").isin("Full", "Tandem", "Exclusive"), "PPO"
    ).when(
        col("medicalNetwork").isin("IFP Trio HMO", "Trio ACO"), "HMO"
    ).when(
        col("medicalNetwork").isin("Access+", "Local Access+"), "HMO Access+"
    ).otherwise(col("medicalNetwork"))
                                )
        return plan_details_df
    except Exception as e:
        print(f"Error in process_plan_details: {e}")
        return None
    
def process_eoc_categories(df):
    try:
        exploded = df.select(
            "facets_product_id",
            "effective_date",
            col("row_value.nexusId").alias("nexusId"),
            explode(col("row_value.eocCategories")).alias("cat"),
        )
        benefits_flat = exploded.select(
            "facets_product_id",
            "effective_date",
            "nexusId",
            concat_ws("_", col("nexusId"), col("cat.nexusId")).cast("string").alias("benefit_id"),
            F.to_json(struct(
                col("cat.nexusId").alias("eocCategories_nexusId"),
                col("cat.name").alias("eocCategories_name"),
                col("cat.content").alias("eocCategories_content"),
                col("cat.benefitSubCategories").alias("eocCategories_benefitSubCategories"),
            )).alias("eoc_categories_all_fields")
        )
        return benefits_flat
    except Exception as e:
        print(f"Error in process_eoc_categories: {e}")
        return None
    
def process_eoc_program_categories(df):
    try:
        exploded = df.select(
            "facets_product_id",
            "effective_date",
            col("row_value.nexusId").alias("nexusId"),
            explode(col("row_value.programCategories")).alias("pc"),
        )
        result_program = exploded.select(
            "facets_product_id",
            "effective_date",
            "nexusId",
            concat_ws("_", col("nexusId"), col("pc.nexusId")).cast("string").alias("program_id"),
            F.to_json(struct(
                col("pc.nexusId").alias("eoc_program_categories_nexusId"),
                col("pc.name").alias("eoc_program_categories_name"),
                col("pc.programs").alias("eoc_program_categories_programs"),
            )).alias("combined_eoc_program_categories")
        )
        return result_program
    except Exception as e:
        print(f"Error in process_eoc_program_categories: {e}")
        return None
    
def process_eoc_sections(df):
    try:
        exploded = df.select(
            "facets_product_id",
            "effective_date",
            col("row_value.nexusId").alias("nexusId"),
            explode(col("row_value.eocSections")).alias("sec"),
        )
        result_sections = exploded.select(
            "facets_product_id",
            "effective_date",
            "nexusId",
            concat_ws("_", col("nexusId"), col("sec.nexusId")).cast("string").alias("section_id"),
            clean_text_udf(
                F.to_json(struct(
                    col("sec.nexusId").alias("eoc_sections_nexusId"),
                    col("sec.name").alias("eoc_sections_name"),
                    col("sec.code").alias("eoc_sections_code"),
                    col("sec.eocItems").alias("eoc_sections_eocItems"),
                ))
            ).alias("eoc_sections_combined")
        )
        return result_sections
    except Exception as e:
        print(f"Error in process_eoc_sections: {e}")
        return None
    
def update_plan_fields(df, master_table_path, spark):
    ids = df.select(
        "facets_product_id",
        "effective_date",
        "mapped_medical_network",
        "facetsProductDescription",
        "facetsPlanId"
    )
    ids.createOrReplaceTempView("temp_ids")
    
    spark.sql(f"""
        UPDATE {master_table_path} AS m
        SET plan_type = (
                SELECT t.mapped_medical_network
                FROM temp_ids AS t
                WHERE m.facets_product_id = t.facets_product_id
                  AND m.product_effective_date = t.effective_date limit 1
            ),
            product_description = (
                SELECT t.facetsProductDescription
                FROM temp_ids AS t
                WHERE m.facets_product_id = t.facets_product_id
                  AND m.product_effective_date = t.effective_date limit 1
            ),
            plan_id = (
                SELECT t.facetsPlanId
                FROM temp_ids AS t
                WHERE m.facets_product_id = t.facets_product_id
                  AND m.product_effective_date = t.effective_date limit 1
            )
        WHERE EXISTS (
            SELECT 1
            FROM temp_ids AS t
            WHERE m.facets_product_id = t.facets_product_id
              AND m.product_effective_date = t.effective_date
        )
    """)

def update_ready_flags_master_table(df, master_table_path, spark):
    ids = df.select(
        "facets_product_id",
        "effective_date"
    )
    ids.createOrReplaceTempView("temp_ids")
    
    spark.sql(f"""
        UPDATE {master_table_path} AS m
        SET dbr_silver_layer_ready = 'Y',
            vector_db_ready = 'Y'
        WHERE EXISTS (
            SELECT 1
            FROM temp_ids AS t
            WHERE m.facets_product_id = t.facets_product_id
              AND m.product_effective_date = t.effective_date
        )
    """)
