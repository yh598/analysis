import os
import uuid
import json
import requests
from datetime import datetime, timezone
from typing import Dict, Any, Optional, Tuple, List
import pyspark.sql.functions as F
from databricks.sdk.runtime import *

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import *
def ensure_output_dir(path: str) -> None:
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        # On DBFS Volumes, intermediate dirs typically exist; ignore race conditions
        pass


def fetch_ppdd(
    facets_product_id: str,
    effective_date: str,
    API_BASE: str
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Fetch a single PPDD record from the API.
    Returns: (payload_dict, error_message)
      - payload_dict: normalized dict with 'productLineOfBusiness' etc., or None on error
      - error_message: None on success; reason string on error
    """
    url = f"{API_BASE}/{facets_product_id}/{effective_date}"
    headers = {
        "Accept": "application/json"
    }
    try:
        resp = requests.get(url, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, list) and data:
            item = data[0]
        elif isinstance(data, dict):
            item = data
        else:
            return None, "Empty or unexpected JSON shape"
        return item, None
    except requests.exceptions.HTTPError as he:
        try:
            detail = resp.text[:300]
        except Exception:
            detail = str(he)
        return None, f"HTTP {resp.status_code}: {detail}"
    except requests.exceptions.SSLError as ssl_err:
        return None, f"SSL error: {ssl_err}"
    except requests.exceptions.Timeout:
        return None, "Timeout"
    except Exception as e:
        return None, f"Request failed: {e}"


def build_master_rows_from_api_result(
    facets_product_id: str,
    product_effective_date: str,
    api_item,
    error_msg,
    output_dir,
    REQUESTER_ID,
    lob
) -> Dict[str, Any]:
    """
    Map API result (or error) to a single master_table row (as a Python dict).
    Also writes a JSON artifact to OUTPUT_DIR if api_item is present.
    """
    now_ts = datetime.now(timezone.utc).replace(tzinfo=None)  # naive UTC for TIMESTAMP
    product_type = lob
    comments = None
    data_issue = None
   
    if api_item is not None:
        product_type = api_item.get("productLineOfBusiness")
        comments = ""

        if output_dir:
            ensure_output_dir(output_dir)
            name = f"{facets_product_id}_{product_effective_date}_{product_type or 'unknown'}"
            payload = {
                "facets_product_id": facets_product_id,
                "effective_date": product_effective_date,
                "product_line_of_business": product_type,
                "file_name": name,
                "row_value": api_item,
            }
            fp = os.path.join(output_dir, f"{name}.json")
            try:
                with open(fp, "w") as f:
                    json.dump(payload, f, indent=2)
            except Exception:
                # If writing fails, don't break the flow.
                pass
    else:
        data_issue = error_msg or "Unknown error"

    return {
        "facets_product_id": facets_product_id,
        "product_effective_date": product_effective_date,
        "product_type": product_type,
        "requested_time": now_ts,
        "requester_id": REQUESTER_ID,
        # If API succeeded, we consider raw row fetched/ready; otherwise leave as None or 'N'
        "bronze_ready_load": None ,
        "dbr_silver_layer_ready": None,
        "vector_db_ready": None,
        "ready_for_agent": None,
        "comments": comments,
        "data_issue": data_issue,
    }


def master_schema() -> StructType:
    return StructType([
        StructField("facets_product_id",     StringType(),  False),
        StructField("product_effective_date", StringType(),  False),
        StructField("product_type",           StringType(),  True),
        StructField("requested_time",         TimestampType(), True),
        StructField("requester_id",           StringType(),  True),
        StructField("bronze_ready_load",      StringType(),  True),
        StructField("dbr_silver_layer_ready", StringType(),  True),
        StructField("vector_db_ready",        StringType(),  True),
        StructField("ready_for_agent",        StringType(),  True),
        StructField("comments",               StringType(),  True),
        StructField("data_issue",             StringType(),  True),
    ])


def read_master_ready(spark: SparkSession, client) -> DataFrame:
    """
    Read the whole master table and filter to bronze_ready_load == 'Y' (case-insensitive).
    """
    df_master = client.read_all(spark)
    # Normalize/lower bronze flag, treat 'Y' as ready.
    return (df_master
            .withColumn("bronze_ready_load_norm", F.upper(F.coalesce(F.col("bronze_ready_load"), F.lit(""))))
            .filter(F.col("bronze_ready_load_norm") == F.lit("Y"))
            .drop("bronze_ready_load_norm"))


import pyspark.sql.functions as F

def read_csv_keys_as_df(spark, csv_path):
    raw = (
        spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .csv([csv_path])
    )
    # Find columns by lower-case name
    id_col = next((c for c in raw.columns if c.lower() in ("facetsproductid", "facets_product_id")), None)
    dt_col = next((c for c in raw.columns if c.lower() in ("effectivedate", "product_effective_date")), None)
    lob_col = next((c for c in raw.columns if c.lower() in ("productlineofbusiness", "product_line_of_business")), None)

    if id_col is None or dt_col is None or lob_col is None:
        # Fallback: assume order and no header
        raw = (
            spark.read
            .option("header", "false")
            .csv([csv_path])
            .toDF("facetsProductId", "effectiveDate", "productLineOfBusiness")
        )
        id_col, dt_col, lob_col = "facetsProductId", "effectiveDate", "productLineOfBusiness"

    keys = (
        raw
        .select(
            F.col(id_col).cast("string").alias("facets_product_id"),
            F.col(dt_col).cast("string").alias("product_effective_date"),
            F.col(lob_col).cast("string").alias("productLineOfBusiness"),
        )
        .dropna(subset=["facets_product_id", "product_effective_date", "productLineOfBusiness"])
        .dropDuplicates(["facets_product_id", "product_effective_date", "productLineOfBusiness"])
    )
    return keys


def left_anti_not_loaded(spark: SparkSession, csv_keys: DataFrame, master_ready: DataFrame) -> DataFrame:
    """
    Left-anti: keys from CSV that are NOT already present in master (as ready).
    """
    return (csv_keys.alias("k")
            .join(master_ready.select("facets_product_id", "product_effective_date","product_type").alias("m"),
                  on=["facets_product_id", "product_effective_date"],
                  how="left_anti"))


def fetch_and_build_rows_df(spark: SparkSession, keys_df: DataFrame, output_dir: Optional[str],api_base,REQUESTER_ID) -> DataFrame:
    """
    Iterate over 'keys_df' (facets_product_id, product_effective_date),
    fetch the API, and build a Spark DF aligned to MASTER_COLUMNS.
    """
    rows: List[Dict[str, Any]] = []

    for r in keys_df.toLocalIterator():
        fid = r["facets_product_id"]
        eff = r["product_effective_date"]
        lob = r["productLineOfBusiness"]

        api_item, err = fetch_ppdd(fid, eff,api_base)
        row_dict = build_master_rows_from_api_result(
            facets_product_id=fid,
            product_effective_date=eff,
            api_item=api_item,
            error_msg=err,
            output_dir=output_dir,
            REQUESTER_ID=REQUESTER_ID,
            lob=lob
        )
        rows.append(row_dict)

    return spark.createDataFrame(rows, schema=master_schema())

from pyspark.sql import DataFrame, SparkSession, functions as F

def _with_data_issue(df: DataFrame) -> DataFrame:
    """
    Adds a `data_issue` column listing columns that are NULL, empty "" or "{}".
    """
    for c in df.columns:
        df = df.withColumn(c, F.when(F.col(c) == "", None).otherwise(F.col(c)))

    issue_flags = [
        F.when(F.col(c).isNull() | (F.col(c) == "{}"), F.lit(f"{c} missing"))
         .otherwise(F.lit(None))
        for c in df.columns
    ]
    issues = F.array_remove(F.array(*issue_flags), F.lit(None))
    return df.withColumn(
        "data_issue",
        F.when(F.size(issues) > 0, F.concat_ws("; ", issues)).otherwise(F.lit(None))
    )



def prepare_volume_dataframe(
    spark: SparkSession,
    master_df: DataFrame,
    volume_path: str,
    *,
    key1_col: str,
    key2_col: str,
    product_type_col: str,
    multiline: bool = False,
) -> DataFrame:
    """
    Reads ONLY those JSON files from a UC Volume whose names match keys in master_df,
    and skips those not physically present in the volume.
    """
    # expected filenames from master_df
    names_df = master_df.select(
        F.concat_ws("_", F.col(key1_col), F.col(key2_col), F.col(product_type_col)).alias("stem")
    ).dropDuplicates()

    filenames = [r.stem + ".json" for r in names_df.collect()]
    filenames = [fname.replace("SMALL", "Small") for fname in filenames]

    # ---- list actual files in the volume ----
    try:
        files_in_volume = [f.name for f in dbutils.fs.ls(volume_path)]
    except Exception as e:
        raise RuntimeError(f"Could not list files in {volume_path}: {e}")

    # keep only filenames that exist in volume
    existing_files = [fname for fname in filenames if fname in files_in_volume]
    print(existing_files)

    if not existing_files:
        print("No matching files found in volume.")
        return spark.createDataFrame(
            [], schema=f"{key1_col} string, {key2_col} string, {product_type_col} string"
        ).limit(0)

    # build paths only for existing files
    paths = [f"{volume_path}/{fname}" for fname in existing_files]
    print(f"Reading {len(paths)} files from volume...")

    # read JSON
    raw = raw = spark.read.json(paths,multiLine=True)

    return raw

def compute_data_isssue(df):
    row_value_schema = df.schema["row_value"].dataType


    # Identify array type fields in the struct

    array_fields = [
        field.name
        for field in row_value_schema.fields
        if (
            isinstance(field.dataType, ArrayType)
            and field.name.lower() in ["eocsections", "eoccategories"]
        )
    ]

    # Build conditions to check if arrays are empty or null
    empty_checks = []
    for field in array_fields:
        # Check if array is null or empty
        condition = (
            F.col(f"row_value.{field}").isNull() | 
            (F.size(F.col(f"row_value.{field}")) == 0)
        )
        empty_checks.append(
            F.when(condition, F.lit(f"{field} is empty")).otherwise(F.lit(None))
        )

    # Combine all empty field names into data_issue column
    df_with_issues = df.withColumn(
        "data_issue",
        F.concat_ws(", ", *empty_checks) if empty_checks else F.lit(None)
    )

    # Add bronze_flag: 'yes' if no data issues, otherwise 'no' or null
    df_final = df_with_issues.withColumn(
        "bronze_ready_flag",
        F.when(
            (F.col("data_issue").isNull()) | (F.col("data_issue") == ""),
            F.lit("Y")
        ).otherwise(F.lit("N"))
    )
    return df_final



