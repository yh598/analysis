# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
from uuid import uuid4
from typing import *
from dataclasses import asdict
import requests

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.types import RetryPolicy

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker

# MLflow imports
import mlflow
import mlflow.deployments
from mlflow.pyfunc import PythonModel, PythonModelContext, ResponsesAgent
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
)


# Logging configuration
logging.basicConfig(level=logging.INFO)


def _load_file(fp: str):
    with open(fp, "r") as f:
        if fp.endswith((".yml", ".yaml")):
            return yaml.safe_load(f)
        elif fp.endswith(".json"):
            return json.load(f)
        else:
            raise ValueError(f"Unsupported config type: {fp}")


from tool_desc.core.config_store import ConfigStore
from tool_desc.core.classifyintenttool import *
from tool_desc.core.generateanswertool import *
from tool_desc.core.vector_search import *
from tool_desc.core.plandetecttool import *
from tool_desc.core.exclusionchecktool import *
from tool_desc.core.copaycoinsurancetool import *

from tool_desc.core.definitiontool import *
from tool_desc.core.fallbackagenttool import *
from tool_desc.core.programmanagementtool import *




class State(TypedDict):
    messages: Annotated[list, add_messages]
    productid_effectivedate_product:str
    input: str
    expanded_question:str
    original_question:str
    plan_nexus: Optional[str]
    plan_name: Optional[str]
    followup: Optional[str]
    plan_cost_share:Optional[str]
    scenarios:Optional[list]
    plan_meta: Optional[str]
    benefits: Optional[str]
    cost_share: Optional[List[Dict[str, Any]]]
    def_cost_share: Optional[List[Dict[str, Any]]]
    exclusion: Optional[List[Dict[str, Any]]]
    intent: Optional[list]
    prompt:Optional[str]
    templates:Optional[str]
    uid:Optional[str]
    sid:Optional[str]
    question_id:Optional[str]
    facets_product_id:Optional[str]
    effective_date:Optional[str]
    product_line_of_business:Optional[str]
    plan_type:Optional[str]
    program_details: Optional[List[Dict[str, Any]]]
    error:Optional[str]
    


def detect_plan(state: State) -> State:
    tool = PlanDetectTool()
    result = tool.invoke({"facets_product_id": state["facets_product_id"],"effective_date":state["effective_date"]})
    parsed = json.loads(result)
    state["plan_nexus"] = parsed.get("plan_nexus")
    state["plan_cost_share"] = parsed.get("plan_cost_share")
    state["plan_name"] = parsed.get("plan_name")
    state["plan_type"]=parsed.get("plan_type")
    
    return state

def fetch_intent(state: State) -> State:
    tool   = ClassifyIntentTool()
    result = tool.invoke({
        "input":      state["input"],
        "uid":    state["uid"],
        "sid": state["sid"],
        "question_id":state["question_id"],
        
    })


    state["intent"] = result.get("intent", "none")
    state["expanded_question"] = result.get("expanded_question", state.get("input", ""))
    state["followup"] = result.get("followup", "")
    return state

def fallback_answer(state: State) -> State:
    tool = FallbackAgentTool()
    txt  = tool.invoke({"question": state["input"]})
    state["answer"] = txt
    state["messages"].append(AIMessage(content=txt))
    return state
def route_to_next_tool(state: State) -> str:
    intent = state["intent"]

    print(f"[Routing] Intent detected: '{intent}'")

    # Handle if intent is a list
    if isinstance(intent, list):
        # Flatten list to string for matching, or check each item
        if any("EoCCategory" in i or "BenefitCostShares" in i  or "Exclusions" in i for i in intent):
            return "get_cost_share"
        elif any("ProgramCategories" in i for i in intent):
            return "get_programdetail"
        elif any("GenericDefinition" in i for i in intent):
            return "generate_answer"
        else:
            return "fallback"
    else:
        if "EoCCategory" in intent or "BenefitCostShares" in intent or "Exclusions" in intent:
            return "get_cost_share"
        elif intent == "definition":
            return "generate_answer"
        elif "internt"=="ProgramCategories":
            return "get_programdetail"
        elif "internt"=="Exclusions":
            return "get_cost_share"
        else:
            return "fallback"
def fetch_cost_share(state: State) -> State:
    tool   = CopayCoinsuranceTool()
    result = tool.invoke({
        "input":      state["expanded_question"],
        "plan_nexus": state["plan_nexus"],
    })
    # result is a JSON string of list[dict]
    try:
        parsed = json.loads(result) if result else []
    except Exception:
        parsed = []
    state["cost_share"] = parsed   # <-- list[dict]
    return state
    #ProgrammanagementTool
def fetch_programcategory(state: State) -> State:
    tool   = ProgrammanagementTool()
    result = tool.invoke({
        "input":      state["expanded_question"],
        "plan_nexus": state["plan_nexus"],
        "plan_type": state["plan_type"]
    })
    try:
        parsed = result if result else []
    except Exception:
        parsed = []
   
    state["program_details"] = parsed
    
    return state
def fetch_exclusion(state: State) -> State:
    tool   = ExclusionCheckTool()
    result = tool.invoke({
       
        "plan_nexus": state["plan_nexus"],
    })
    # result is a JSON string of list[dict]
    try:
        parsed = json.loads(result) if result else []
    except Exception:
        parsed = []
    state["exclusion"] = parsed   # <-- list[dict]
    return state
def generate_answer(state: State) -> State:
    tool = GenerateAnswerTool()
    
    answer = tool.invoke({
        "input": state["input"],
        "question":        state["expanded_question"],
        "plan_meta":       state.get("plan_cost_share", ""),
        "plan_type":      state["plan_type"],
        "plan_name":       state["plan_name"],
        "followup":        state["followup"],
        "uid" : state["uid"],
        "sid":state["sid"],
        "question_id":state["question_id"],
        "intent": state["intent"],
        "exclusion": state.get("exclusion", []),
        "cost_share": state.get("cost_share", []),
        "def_cost_share": state.get("def_cost_share", []),
        "program_details": state.get("program_details", [])
       
   
    })
    
    state["answer"] = answer
    state["messages"].append(AIMessage(content=answer))
    return state

def retry_on_any_exception(exc:BaseException)->bool:
    return True
def build_graph():
    # --- Build Graph ---
    builder = StateGraph(State)

    builder.add_node("detect_plan", detect_plan)
    builder.add_node("classify_intent", fetch_intent)
    builder.add_node("fallback", fallback_answer)
    builder.add_node("get_cost_share", fetch_cost_share)
    builder.add_node("fetch_exclusion", fetch_exclusion)
    builder.add_node(
    "generate_answer",
    generate_answer,
    retry=RetryPolicy(max_attempts=2,retry_on=retry_on_any_exception)
)

    builder.add_node("get_programdetail", fetch_programcategory)
    

    # Conditional routing
    builder.set_entry_point("detect_plan")
    builder.add_edge("detect_plan","classify_intent")
    
    
    builder.add_conditional_edges("classify_intent", route_to_next_tool, {
        "get_cost_share": "get_cost_share",
        "generate_answer": "generate_answer",
        "get_programdetail": "get_programdetail",
        "fallback":       "fallback"
        
    })
    
 
    builder.add_edge("fallback", END)      
    
    builder.add_edge("get_cost_share", "fetch_exclusion")
    builder.add_edge("fetch_exclusion", "generate_answer")
    builder.add_edge("get_programdetail", "generate_answer")

    builder.add_edge("generate_answer", END)
   

    graph = builder.compile()
    return graph






#from databricks.sdk import WorkspaceClient
#w = WorkspaceClient()
#DATABRICKS_HOST= w.config.host


  
def _extract_text_from_content_parts(parts) -> str:
    if not parts:
        return ""
    chunks = []
    for p in parts:
        if hasattr(p, "text"):       # pydantic ResponseInputTextParam
            chunks.append(p.text)
        elif isinstance(p, dict):    # plain dict
            t = p.get("text")
            if isinstance(t, str):
                chunks.append(t)
    return "\n".join(chunks).strip()

def _last_user_text(request: ResponsesAgentRequest) -> str:
    msgs = request.input or []
    for m in reversed(msgs):
        role = getattr(m, "role", None) if not isinstance(m, dict) else m.get("role")
        if role == "user":
            content = getattr(m, "content", None) if not isinstance(m, dict) else m.get("content")
            return _extract_text_from_content_parts(content)
    if msgs:
        m = msgs[-1]
        content = getattr(m, "content", None) if not isinstance(m, dict) else m.get("content")
        return _extract_text_from_content_parts(content)
    return ""
class BenefitCostResponsesAgent(ResponsesAgent):
    def __init__(self, env: str = "dev"):
        self.env = env
        self.cfg = None
    def load_context(self, context: PythonModelContext):
        cfg_dir = context.artifacts["configs"]   # folder you logged above
        run_cfg_path = context.artifacts["run_cfg"]
        run_cfg = _load_file(run_cfg_path)
        env = (run_cfg.get("env") or "dev").lower()

        # 2) load the right env YAML from the 'configs' artifact folder
        cfg_dir = context.artifacts["configs"]
        for name in (f"{env}_config.yml", f"{env}_config.yaml", f"{env}_config.json"):
            candidate = os.path.join(cfg_dir, name)
            if os.path.exists(candidate):
                cfg = _load_file(candidate)
                break
        else:
            raise FileNotFoundError(f"No config file for env='{env}' in {cfg_dir}")

        # 3) publish globally so ANY imported file can read without changing signatures
        ConfigStore.set(env=env, **cfg)
        #self.cfg={}
       
        #print(access_token)
        
        #os.environ["DATABRICKS_TOKEN"] =access_token
   

        #os.environ["DATABRICKS_TOKEN"]=dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
        mlflow.set_tracking_uri("databricks")
    
        
        global VS_ENDPOINT, BENEFIT_INDEX, PLAN_INDEX, DEFAULT_PLAN, DEFAULT_PLAN_NAME, LLM_ENDPOINT, CURRENT_PLAN_NEXUS,EXCLUSION_INDEX,PROGRAM_INDEX,client_id,ws_url,client_secret
        #os.environ["DATABRICKS_HOST"] = "https://adb-640321604414221.1.azuredatabricks.net/"
        
        VS_ENDPOINT         = ConfigStore.get("VS_ENDPOINT")
        BENEFIT_INDEX       = ConfigStore.get("BENEFIT_INDEX")
        PLAN_INDEX          = ConfigStore.get("PLAN_INDEX")
        DEFAULT_PLAN        = ConfigStore.get("DEFAULT_PLAN")
        DEFAULT_PLAN_NAME   = ConfigStore.get("DEFAULT_PLAN_NAME")
        LLM_ENDPOINT        = ConfigStore.get("LLM_ENDPOINT")
        EXCLUSION_INDEX     = ConfigStore.get("EXCLUSION_INDEX")
        PROGRAM_INDEX       = ConfigStore.get("PROGRAM_INDEX")
        client_id       = ConfigStore.get("client_id")
        client_secret       = ConfigStore.get("client_secret")
        ws_url       = ConfigStore.get("ws_url")
        CURRENT_PLAN_NEXUS  = DEFAULT_PLAN
        #access_token=get_token(client_id,ws_url,client_secret)
        #print(access_token)
        #os.environ["DATABRICKS_HOST"] = ws_url
        """
        if '370726302632140' in DATABRICKS_HOST:
            #Below if for QA
            os.environ["DATABRICKS_TOKEN"]= "dapi9760122b7ad777fe87a315867d57f0ed-2"
        elif '640321604414221' in DATABRICKS_HOST:
            #Below if for dev
            os.environ["DATABRICKS_TOKEN"]= "dapib3c336f309333d011d48fe287f98f9c9-2"
        elif '3693588177658856' in DATABRICKS_HOST:
            #os.environ["DATABRICKS_TOKEN"]= ""
        """


        
       
       
        self.agent = build_graph()   

    def initialize(self):           
        self.load_with_artifacts({})
    
           

    def predict(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
        if self.agent is None:
            self.initialize()

        ci = request.custom_inputs or {}
        print(ci)
        self.uid = ci.get("user_id")
     
        self.sid = ci.get("session_id")
        self.question_id = ci.get("question_id")
        print(self.question_id)
        self.facets_product_id = ci.get("facets_product_id")
        self.effective_date = ci.get("effective_date")
      

        # last user text from Responses schema
        user_q = _last_user_text(request)
        print({"input": user_q,"uid":self.uid,"sid":self.sid,"question_id":self.question_id,"facets_product_id":self.facets_product_id,"effective_date":self.effective_date})
        # run LangGraph
        final_state = self.agent.invoke({"input": user_q,"uid":self.uid,"sid":self.sid,"question_id":self.question_id,"facets_product_id":self.facets_product_id,"effective_date":self.effective_date})

        # extract assistant reply
        reply = ""
        for m in reversed(final_state.get("messages", [])):
            if isinstance(m, AIMessage):
                reply = m.content
                break
        if not reply:
            reply = "[EMPTY RESPONSE]"

        out = self.create_text_output_item(text=reply, id=str(uuid4()))
        ci = {k: v for k, v in ci.items() if k in ("session_id", "question_id")}
        #return {"content": reply}
        return ResponsesAgentResponse(output=[out], custom_outputs=ci)
        #return 


# Tell MLflow logging where to find your chain.
mlflow.models.set_model(model=BenefitCostResponsesAgent())
  





