# Benefit Quote Agent - LLM Pipeline Documentation

Welcome to the Benefit Quote Agent project documentation. This is an AI-powered agent system built on Databricks that provides intelligent responses to benefit insurance queries using LangGraph, MLflow, and vector search capabilities.

## Overview

This project implements an end-to-end LLM agent pipeline for answering benefit insurance questions. The system uses:

* **LangGraph**: For building stateful, multi-step agent workflows
* **MLflow**: For model logging, versioning, and deployment
* **Databricks Vector Search**: For semantic search over benefit documentation
* **Custom Tools**: Specialized tools for intent classification, plan detection, copay/coinsurance lookup, and more

## Project Structure

```
notebook/
├── 04_build_llm_chain.py                          # LLM chain construction
├── 05_model_logging&deployment_langraph.py        # Model registration and deployment
├── 05_model_logging&deployment_langraph_context.py # Context-aware deployment
├── 4.1 llm_model_testing.py                       # Model testing utilities
├── 6.1 llm_judge_mlflow_v1.py                     # LLM-based evaluation
├── manifest.mf                                     # Project manifest
├── model_config.json                               # Model configuration
├── runtime_cfg.json                                # Runtime configuration
├── run_cfg.json                                    # Run-specific configuration
└── tool_desc/                                      # Tool descriptions and implementations
    ├── core/                                       # Core tool implementations
    │   ├── chat_history.py                         # Chat history management
    │   ├── classifyintenttool.py                   # Intent classification
    │   ├── config_store.py                         # Configuration management
    │   ├── copaycoinsurancetool.py                 # Copay/coinsurance lookup
    │   ├── custom_metrics.py                       # Custom evaluation metrics
    │   ├── definitiontool.py                       # Term definition lookup
    │   ├── exclusionchecktool.py                   # Coverage exclusion checks
    │   ├── fallbackagenttool.py                    # Fallback handling
    │   ├── generateanswertool.py                   # Answer generation
    │   ├── generateanswertool_context.py           # Context-aware answer generation
    │   ├── limitText_and_bscMaxText_replacer.py    # Text processing utilities
    │   ├── ndcg_metrics.py                         # NDCG evaluation metrics
    │   ├── plandetecttool.py                       # Plan detection
    │   ├── programmanagementtool.py                # Program management queries
    │   ├── referral_script.py                      # Referral handling
    │   ├── special_cases.py                        # Special case handling
    │   ├── vector_search.py                        # Vector search utilities
    │   └── __init__.py                             # Module initialization
    └── templates/                                  # Response templates
        ├── generic_template.json                   # Generic response template
        ├── hmo_template.json                       # HMO-specific template
        └── ppo_template.json                       # PPO-specific template
```

## Installation

### Prerequisites

* Python 3.8+
* Databricks Runtime 13.3 LTS or higher
* Access to Databricks Vector Search
* MLflow 3.1.3+
* Unity Catalog enabled workspace

### Setup

1. **Install Dependencies**

Run the following in your Databricks notebook:

```python
%pip install --upgrade \
  mlflow[databricks]>=3.1.3 \
  databricks-langchain \
  langchain>=0.3.0 \
  langgraph \
  databricks-vectorsearch>=0.40 \
  pyyaml \
  psycopg[binary] \
  databricks-agents \
  rapidfuzz \
  ftfy

dbutils.library.restartPython()
```

2. **Configure Environment**

Create a configuration file (e.g., `dev_config.yml`) in the `configs/` directory:

```yaml
project_name: "Benefit_Quote_MVP1"
warehouse: "your_warehouse_name"
schema_name_gold: "nexusbenefitsquote_gold_mvp1"
schema_name_silver: "nexusbenefitsquote_silver_mvp1"
LLM_ENDPOINT_PRIMARY: "databricks-meta-llama-3-1-70b-instruct"
LLM_ENDPOINT_SECONDARY: "databricks-meta-llama-3-1-405b-instruct"
```

3. **Set Notebook Widgets**

```python
dbutils.widgets.text("config_file", "dev_config.yml")
dbutils.widgets.text("environment", "dev")
```

## Quick Start

### 1. Build LLM Chain

Run `04_build_llm_chain.py` to construct the agent workflow with LangGraph.

### 2. Log and Deploy Model

Run `05_model_logging&deployment_langraph.py` to:
* Log the model to MLflow with all dependencies
* Register the model in Unity Catalog
* Deploy as a Model Serving endpoint

```python
# Example: Log model with MLflow
with mlflow.start_run(run_name="register-agent_langraph"):
    mlflow.pyfunc.log_model(
        artifact_path="benefit_agent_langraph",
        python_model="benefit_agent_mlflow_utils_log.py",
        code_paths=["tool_desc"],
        artifacts={"configs": "../configs", "run_cfg": "runtime_cfg.json"},
        resources=[
            DatabricksVectorSearchIndex(index_name="..."),
            DatabricksServingEndpoint(endpoint_name="..."),
            DatabricksSQLWarehouse(warehouse_id="..."),
        ],
        registered_model_name="dev_adb.nexusbenefitsquote_gold_mvp1.mvp1-gpt5"
    )
```

### 3. Test the Model

Use `4.1 llm_model_testing.py` to test model predictions:

```python
input_example = {
    "input": [
        {
            "role": "user",
            "content": [
                {"type": "input_text", "text": "what is the cost share for emergency room?"}
            ],
        }
    ],
    "custom_inputs": {
        "user_id": "u-123",
        "username": "Priyanka",
        "session_id": "s-456",
        "question_id": "q-789",
        "facets_product_id": "MG011320",
        "effective_date": "20240101"
    },
}

model = mlflow.pyfunc.load_model(f"models:/{model_name}/{version}")
response = model.predict(input_example)
```

### 4. Deploy Agent

Deploy the agent using Databricks Agents SDK:

```python
from databricks import agents

deployment = agents.deploy(
    registered_model_name,
    version,
    workload_size="Medium",
    scale_to_zero=False
)

agents.set_review_instructions(
    registered_model_name,
    "Thank you for testing Benefit insurance agent. Ask an appropriate question and use your domain expertise to evaluate and give feedback on the agent's responses."
)
```

## Module Documentation

### [Tool Description Module (`tool_desc/`)](#tool-description-module)

The `tool_desc` module contains all custom tools and utilities used by the agent. It is organized into:

* **Core Tools**: Specialized agent tools for benefit insurance queries
* **Templates**: JSON templates for structured responses

For detailed documentation, see:
* [Core Tools Documentation](#core-tools-documentation)
* [Template Documentation](#template-documentation)

---

## Tool Description Module

The `tool_desc` module provides specialized tools for the Benefit Quote Agent. These tools handle specific aspects of benefit insurance queries, from intent classification to answer generation.

### Core Tools Overview

The core tools are located in `tool_desc/core/` and include:

| Tool | Purpose | Key Functions |
|------|---------|---------------|
| `vector_search.py` | Semantic search over benefit documents | Vector similarity search, reranking |
| `classifyintenttool.py` | Classify user intent | Intent detection, routing |
| `plandetecttool.py` | Detect insurance plan type | Plan identification from context |
| `copaycoinsurancetool.py` | Lookup copay/coinsurance amounts | Cost-sharing information retrieval |
| `definitiontool.py` | Define insurance terms | Term lookup and explanation |
| `exclusionchecktool.py` | Check coverage exclusions | Exclusion verification |
| `programmanagementtool.py` | Handle program management queries | Program-specific information |
| `generateanswertool.py` | Generate final answers | Answer synthesis and formatting |
| `chat_history.py` | Manage conversation history | Context tracking across turns |
| `fallbackagenttool.py` | Handle edge cases | Fallback responses |

### Detailed Tool Documentation

For comprehensive technical documentation on each tool, see:
* [Vector Search Tool Details](#vector-search-tool-details)
* [Intent Classification Tool Details](#intent-classification-tool-details)
* [Answer Generation Tool Details](#answer-generation-tool-details)

---

## Core Tools Documentation

### Vector Search Tool Details

**Location:** `tool_desc/core/vector_search.py`

**Purpose:** Performs semantic search over benefit documentation using Databricks Vector Search to retrieve relevant context for answering user queries.

#### Key Functions

##### `vector_search(query: str, index_name: str, num_results: int = 5) -> List[Dict]`

Performs vector similarity search against a specified index.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `query` | `str` | Yes | The user's natural language query |
| `index_name` | `str` | Yes | Fully qualified Unity Catalog index name (catalog.schema.index) |
| `num_results` | `int` | No | Number of results to return (default: 5) |

**Returns:**

| Type | Description |
|------|-------------|
| `List[Dict]` | List of search results with `content`, `score`, and `metadata` fields |

**Usage Example:**

```python
from tool_desc.core.vector_search import vector_search

# Search for relevant benefit information
query = "What is the copay for primary care visits?"
index_name = "dev_adb.nexusbenefitsquote_gold_mvp1.tbl_eoc_categories_index"

results = vector_search(
    query=query,
    index_name=index_name,
    num_results=5
)

for result in results:
    print(f"Score: {result['score']}")
    print(f"Content: {result['content']}")
    print(f"Metadata: {result['metadata']}")
```

**Implementation Notes:**

* Uses Databricks Vector Search client for efficient similarity search
* Supports reranking with `DatabricksReranker` for improved relevance
* Automatically handles authentication via Databricks workspace context
* Returns results sorted by relevance score (highest first)

**Error Handling:**

* Raises `ValueError` if index_name is not properly formatted
* Returns empty list if no results found
* Handles connection errors gracefully with retry logic

---

### Intent Classification Tool Details

**Location:** `tool_desc/core/classifyintenttool.py`

**Purpose:** Classifies user intent to route queries to appropriate specialized tools.

#### Key Functions

##### `classify_intent(query: str, chat_history: List[Dict] = None) -> str`

Classifies the user's intent from their query.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `query` | `str` | Yes | The user's natural language query |
| `chat_history` | `List[Dict]` | No | Previous conversation turns for context |

**Returns:**

| Type | Description |
|------|-------------|
| `str` | Intent category (e.g., "copay_inquiry", "coverage_check", "definition_request") |

**Supported Intent Categories:**

* `copay_inquiry`: Questions about copayments or coinsurance
* `coverage_check`: Questions about what is covered
* `exclusion_check`: Questions about what is not covered
* `definition_request`: Requests for term definitions
* `program_management`: Questions about care management programs
* `general_inquiry`: General benefit questions

**Usage Example:**

```python
from tool_desc.core.classifyintenttool import classify_intent

query = "How much do I pay for an emergency room visit?"
intent = classify_intent(query)

print(f"Detected intent: {intent}")  # Output: "copay_inquiry"

# Route to appropriate tool based on intent
if intent == "copay_inquiry":
    # Use copay/coinsurance tool
    pass
elif intent == "definition_request":
    # Use definition tool
    pass
```

**Implementation Notes:**

* Uses LLM-based classification for robust intent detection
* Considers chat history for context-aware classification
* Falls back to "general_inquiry" for ambiguous queries
* Optimized for benefit insurance domain

---

### Answer Generation Tool Details

**Location:** `tool_desc/core/generateanswertool.py`

**Purpose:** Generates final, formatted answers based on retrieved context and user query.

#### Key Functions

##### `generate_answer(query: str, context: List[Dict], plan_type: str = "generic") -> Dict`

Generates a comprehensive answer using retrieved context.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `query` | `str` | Yes | The user's original query |
| `context` | `List[Dict]` | Yes | Retrieved context from vector search |
| `plan_type` | `str` | No | Insurance plan type (generic, hmo, ppo) for template selection |

**Returns:**

| Type | Description |
|------|-------------|
| `Dict` | Answer object with `text`, `sources`, `confidence`, and `metadata` fields |

**Usage Example:**

```python
from tool_desc.core.generateanswertool import generate_answer
from tool_desc.core.vector_search import vector_search

# Get context from vector search
query = "What is the copay for specialist visits?"
context = vector_search(query, index_name="...", num_results=5)

# Generate answer
answer = generate_answer(
    query=query,
    context=context,
    plan_type="ppo"
)

print(f"Answer: {answer['text']}")
print(f"Confidence: {answer['confidence']}")
print(f"Sources: {answer['sources']}")
```

**Response Structure:**

```python
{
    "text": "For specialist visits under your PPO plan, the copay is $40 per visit...",
    "confidence": 0.92,
    "sources": [
        {
            "document": "EOC_Section_3.pdf",
            "page": 12,
            "section": "Outpatient Services"
        }
    ],
    "metadata": {
        "plan_type": "ppo",
        "effective_date": "20240101",
        "template_used": "ppo_template"
    }
}
```

**Implementation Notes:**

* Uses plan-specific templates from `tool_desc/templates/`
* Applies text processing utilities for consistent formatting
* Includes source citations for transparency
* Calculates confidence scores based on context relevance
* Handles special cases via `special_cases.py` module

---

### Chat History Management

**Location:** `tool_desc/core/chat_history.py`

**Purpose:** Manages conversation history for context-aware multi-turn interactions.

#### Key Functions

##### `add_message(session_id: str, role: str, content: str) -> None`

Adds a message to the conversation history.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `session_id` | `str` | Yes | Unique session identifier |
| `role` | `str` | Yes | Message role (user, assistant, system) |
| `content` | `str` | Yes | Message content |

##### `get_history(session_id: str, max_turns: int = 10) -> List[Dict]`

Retrieves conversation history for a session.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `session_id` | `str` | Yes | Unique session identifier |
| `max_turns` | `int` | No | Maximum number of turns to retrieve (default: 10) |

**Returns:**

| Type | Description |
|------|-------------|
| `List[Dict]` | List of message objects with `role` and `content` fields |

**Usage Example:**

```python
from tool_desc.core.chat_history import add_message, get_history

session_id = "s-456"

# Add user message
add_message(session_id, "user", "What is my copay for primary care?")

# Add assistant response
add_message(session_id, "assistant", "Your copay for primary care visits is $25.")

# Retrieve history
history = get_history(session_id, max_turns=5)

for msg in history:
    print(f"{msg['role']}: {msg['content']}")
```

---

## Template Documentation

### Response Templates

The `tool_desc/templates/` directory contains JSON templates for structured responses based on plan type.

#### Available Templates

* **`generic_template.json`**: Default template for all plan types
* **`hmo_template.json`**: HMO-specific response formatting
* **`ppo_template.json`**: PPO-specific response formatting

#### Template Structure

```json
{
  "plan_type": "ppo",
  "response_format": {
    "greeting": "Based on your PPO plan...",
    "answer_structure": {
      "copay_section": "Your copay is...",
      "network_info": "In-network vs out-of-network...",
      "additional_notes": "Please note..."
    },
    "disclaimer": "This information is based on your current plan..."
  }
}
```

---

## Evaluation and Metrics

### LLM Judge Evaluation

Use `6.1 llm_judge_mlflow_v1.py` to evaluate agent responses using an LLM-as-a-judge approach.

**Evaluation Criteria:**

* Accuracy: Is the answer factually correct?
* Completeness: Does it address all aspects of the question?
* Clarity: Is the answer easy to understand?
* Source Attribution: Are sources properly cited?

### Custom Metrics

The `tool_desc/core/custom_metrics.py` module provides:

* **NDCG (Normalized Discounted Cumulative Gain)**: Measures ranking quality
* **Retrieval Precision**: Measures relevance of retrieved documents
* **Answer Relevance**: Measures how well the answer addresses the query

---

## Configuration Files

### `model_config.json`

Model-specific configuration including:
* Model architecture parameters
* Inference settings
* Resource requirements

### `runtime_cfg.json`

Runtime configuration including:
* Environment (dev, staging, prod)
* Feature flags
* Logging settings

### `run_cfg.json`

Run-specific configuration for individual executions:
* Experiment tracking
* Custom parameters
* Override settings

---

## Best Practices

### Development Workflow

1. **Local Testing**: Test tools individually before integration
2. **Version Control**: Use MLflow for model versioning
3. **Evaluation**: Run LLM judge evaluation before deployment
4. **Monitoring**: Track metrics in production

### Code Organization

* Keep tools modular and single-purpose
* Use type hints for better code clarity
* Document all public functions
* Write unit tests for critical components

### Deployment

* Use Unity Catalog for model governance
* Enable Model Serving for production endpoints
* Set appropriate workload sizes based on traffic
* Configure auto-scaling and scale-to-zero as needed

---

## Troubleshooting

### Common Issues

**Issue: Vector search returns no results**
* Verify index name is fully qualified (catalog.schema.index)
* Check that index is synced and online
* Ensure query is not empty

**Issue: Model deployment fails**
* Verify all resources (indexes, endpoints, warehouses) exist
* Check Unity Catalog permissions
* Ensure pip requirements are compatible

**Issue: Low answer quality**
* Review retrieved context relevance
* Adjust vector search parameters (num_results, reranking)
* Fine-tune prompts in answer generation tool

---

## Contributing

When adding new tools or features:

1. Follow the existing code structure in `tool_desc/core/`
2. Add comprehensive docstrings with parameter descriptions
3. Include usage examples in documentation
4. Write unit tests
5. Update this README with links to new documentation


## Contact

For questions or support, please contact the Benefit Quote Agent team.

---

## Additional Resources

* [Databricks LangChain Documentation](https://docs.databricks.com/en/generative-ai/langchain.html)
* [MLflow Documentation](https://mlflow.org/docs/latest/index.html)
* [LangGraph Documentation](https://langchain-ai.github.io/langgraph/)
* [Databricks Vector Search](https://docs.databricks.com/en/generative-ai/vector-search.html)
