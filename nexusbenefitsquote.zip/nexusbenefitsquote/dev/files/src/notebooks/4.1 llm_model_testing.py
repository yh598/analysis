# Databricks notebook source
# MAGIC %pip install --upgrade \
# MAGIC   mlflow[databricks]>=3.1.3 \
# MAGIC   databricks-langchain \
# MAGIC   langchain>=0.3.0 \
# MAGIC   langgraph \
# MAGIC   databricks-vectorsearch>=0.40 \
# MAGIC   pyyaml \
# MAGIC   databricks-agents \
# MAGIC     psycopg[binary]\
# MAGIC     rapidfuzz\
# MAGIC       ftfy

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from tool_desc import *
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.types import RetryPolicy
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from typing import *
import os
from databricks.vector_search.client import VectorSearchClient
# Databricks LLM client
from databricks_langchain import ChatDatabricks
from databricks.vector_search.reranker import DatabricksReranker


# Pydantic v2
from pydantic import BaseModel, Field
import mlflow
import yaml


# COMMAND ----------

import sys, os
# repo_root/.. (adjust if needed)
parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
# print(parent_dir)

sys.path.insert(0, parent_dir)
from utilities.LLM_pipeline.benefit_agent_mlflow_utils_log import *

# COMMAND ----------

# local_test_agent.py
import os, json
CONFIGS_DIR = "/Workspace/Users/sgupta27@blueshieldca.com/nexusbenefitsquote/databricks/src/configs" 
             # 
RUN_CFG     = "./runtime_cfg.json"         

json.dump({"env": "dev"}, open(RUN_CFG, "w"))

class DummyCtx:
    def __init__(self, artifacts: dict):
        self.artifacts = artifacts

ctx = DummyCtx(artifacts={"configs": CONFIGS_DIR, "run_cfg": RUN_CFG})

agent = BenefitCostResponsesAgent()
agent.load_context(ctx)           

class DummyReq:
    def __init__(self, input, custom_inputs):
        self.input = input
        self.custom_inputs = custom_inputs

request = DummyReq(
    input=[
        {
            "role": "user",
            "content": [{"type": "input_text", "text": "Does my health insurance cover pre-existing conditions without any waiting period or limitations?"}],
        }
    ],
    custom_inputs={
        "user_id": "u-124442323",
        "username": "abc124432423",
        "session_id": "s-456122344423",
        "question_id": "q-22224",
        "facets_product_id": "M0042181",
        "effective_date": "20260101",
        
    },
)
#M0037414	Are fertility preservation services covered?

# 5) Run predict
resp = agent.predict(request)
print("OUTPUT:", resp)


# COMMAND ----------

