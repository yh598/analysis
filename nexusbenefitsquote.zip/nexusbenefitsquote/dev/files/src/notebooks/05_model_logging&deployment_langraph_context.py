# Databricks notebook source
# MAGIC %pip install --upgrade \
# MAGIC   mlflow[databricks]>=3.1.3 \
# MAGIC   databricks-langchain \
# MAGIC   langchain>=0.3.0 \
# MAGIC   langgraph \
# MAGIC   databricks-vectorsearch>=0.40 \
# MAGIC   pyyaml \
# MAGIC   databricks-agents

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from tool_desc import *

# COMMAND ----------

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from typing import *
import os
from databricks.vector_search.client import VectorSearchClient
# Databricks LLM client
from databricks_langchain import ChatDatabricks
from databricks.vector_search.reranker import DatabricksReranker


# Pydantic v2
from pydantic import BaseModel, Field
import mlflow
import yaml


# COMMAND ----------

dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()
dbutils.widgets.text("environment", "dev")
env: str = dbutils.widgets.get("environment").lower()


# COMMAND ----------



config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

# Extract variable from YAML configuration file
project_name = config['project_name']


# COMMAND ----------

schema_gold=config["schema_name_gold"]
spark.sql(f"create schema if not exists {env}_adb.{schema_gold}")

# COMMAND ----------

def start_mlflow_experiment(experiment_name):
   

    # Define the experiment path in the user's workspace
    experiment_base_path = f"/Workspace/Shared"
    experiment_path = f"{experiment_base_path}/{experiment_name}"



    # Set the experiment (creates if not exists) and return experiment metadata
    experiment = mlflow.set_experiment(experiment_path)
    return experiment

# Usage
experiment_tag = "Benefit_Quote_MVP1"
experiment=start_mlflow_experiment(experiment_tag)


# COMMAND ----------



# COMMAND ----------

import json
import mlflow

mlflow.set_registry_uri("databricks-uc")

input_example = {
    "input": [
        {
            "role": "user",
            "content": [
                {"type": "input_text", "text": "What is a formulary?"}
            ],
        }
    ],
    "custom_inputs": {
        "user_id": "u-123",
        "username": "Priyanka",
        "session_id": "s-456",
        "question_id": "q-789",
        "facets_product_id": "M0033807",
        "effective_date": "20240101"
    },
}
runtime_cfg = {"env": env}
cfg_path = "runtime_cfg.json"
with open(cfg_path, "w") as f:
    json.dump(runtime_cfg, f)
with mlflow.start_run(run_name="register-agent_langraph"):
    mlflow.pyfunc.log_model(
        artifact_path="benefit_agent_langraph",
        python_model="../utilities/LLM_pipeline/benefit_agent_mlflow_utils_context_log.py",
        code_paths=["tool_desc"],
        #code_paths=["../utilities"],
        artifacts={"configs": "../configs", "run_cfg": cfg_path},
        pip_requirements=[
            "mlflow>=3.1.3",
            "pyyaml",
            "databricks-langchain",
            "langchain>=0.3.0",
            "langgraph",
            "databricks-vectorsearch>=0.40",
        ],
        input_example=input_example,
        registered_model_name=f"{env}_adb.{schema_gold}.nexusbenefit_context_model",
    )

# COMMAND ----------

import mlflow.pyfunc
import pandas as pd
df = input_example
model = mlflow.pyfunc.load_model(f"models:/{env}_adb.{schema_gold}.nexusbenefit_context_model/1")
print( model.predict(df))


# COMMAND ----------


from databricks import agents



registered_model_name = f"{env}_adb.{schema_gold}.nexusbenefit_context_model"
print(registered_model_name)
#custom_endpoint_name = "agents-benefits_quote_gold-benefit_quote_MVP1"

deployment = agents.deploy( registered_model_name, 9, scale_to_zero=False)
agents.set_review_instructions(registered_model_name, "Thank you for testing Benefit insurance agent. Ask an appropriate question and use your domain expertise to evaluate and give feedback on the agent's responses.")

agents.set_review_instructions(
    registered_model_name,
    "Thank you for testing Benefit insurance agent. Ask an appropriate question and use your domain expertise to evaluate and give feedback on the agent's responses."
)

# COMMAND ----------

# from databricks import agents
# model_name = "benefit_model_content"

# registered_model_name = f"dev_adb.benefits_quote_gold.benefit_model_content"

# deployment = agents.deploy(registered_model_name, 16, scale_to_zero=True,)
# agents.set_review_instructions(registered_model_name, "Thank you for testing Benefit insurance agent. Ask an appropriate question and use your domain expertise to evaluate and give feedback on the agent's responses.")