# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
from uuid import uuid4
from typing import *
from dataclasses import asdict
import requests

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker

# MLflow imports
import mlflow
import mlflow.deployments
from mlflow.pyfunc import PythonModel, PythonModelContext, ResponsesAgent
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
)

# Load parameters from YAML file
"""
config_path = os.path.join('..','configs', "dev_config.yml")
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

# Extract variable from YAML configuration file

"""

from tool_desc.core.config_store import ConfigStore

class ClassifyIntentArgs(BaseModel):
    input: str = Field(..., description="Original user question")
    uid:str= Field(..., description="user id")
    sid:str= Field(..., description="session id")
    question_id:str=Field(..., description="question id")

# --- Known intents (exact, case-sensitive as emitted by the prompt) ---
KNOWN_INTENTS = {
    "PlanCostShares",
    "BenefitCostShares",
    "EoCCategory",
    "EoCSection",
    "ProgramCategories",
    "GenericDefinition",
    "Exclusions",
    "Fallback"
}

def _coerce_json(text: str) -> dict:
    """
    Try JSON first; if that fails, try Python-literal (for when a model returns a Python dict).
    """
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        # Remove common accidental code fences
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
        try:
            return json.loads(text)
        except Exception:
            try:
                return ast.literal_eval(text)
            except Exception as e:
                raise ValueError(f"Unable to parse model output as JSON/dict: {e}\nRAW:\n{text[:500]}")

def _normalize_intents(raw_intent) -> List[str]:
    """
    Accepts a string (single or comma-separated) or a list. Returns a cleaned list filtered to KNOWN_INTENTS.
    """
    if raw_intent is None:
        return []
    if isinstance(raw_intent, str):
        parts = [p.strip() for p in raw_intent.split(",") if p.strip()]
    elif isinstance(raw_intent, list):
        parts = [str(p).strip() for p in raw_intent if str(p).strip()]
    else:
        parts = [str(raw_intent).strip()]
    # Keep only valid intents, preserve original case if matches known set (case-insensitive match allowed)
    normalized = []
    for p in parts:
        # exact match first
        if p in KNOWN_INTENTS:
            normalized.append(p)
            continue
        # case-insensitive match
        for ki in KNOWN_INTENTS:
            if p.lower() == ki.lower():
                normalized.append(ki)
                break
    # de-dup while preserving order
    seen = set()
    out = []
    for i in normalized:
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out

class ClassifyIntentTool(StructuredTool):
    name: ClassVar[str] = "ClassifyIntent"
    description: ClassVar[str] = (
        "Classifies a user question and expands known terms. Returns ExpandedQuestion, FollowUp, and Intent(s)."
    )
    args_schema: ClassVar[Type[BaseModel]] = ClassifyIntentArgs

    @mlflow.trace(name="ClassifyIntent_run", span_type="tool")
    def _run(self, input: str,uid:str,sid:str,question_id:str) -> dict:
        env=ConfigStore.get("env")
        LLM_ENDPOINT_SECONDARY=ConfigStore.get("LLM_ENDPOINT_SECONDARY")
        # Prompt: force strict JSON with fixed keys
        prompt = f"""
You are an insurance intent classification agent. Your task is to identify the intent behind user questions related to health insurance/medical plans and to expand any abbreviations or aliases to their canonical benefit names for clarity.

STRICT OUTPUT INSTRUCTIONS:
- Respond with a single JSON object only (no prose, no code fences).
- Keys must be exactly: "ExpandedQuestion", "FollowUp", "Intent".
- "Intent" MUST be either a JSON array of strings or a single string. (Array is preferred.)
- "FollowUp" MUST be "Yes" or "No".

STEP 0: NORMALIZE & EXPAND TERMS (do this first)

**IMPORTANT: There are TWO types of transformations:**
1. **EXPANSIONS** (for abbreviations): Append the full term in parentheses. Do not change original words.
2. **REPLACEMENTS** (for surgery/benefit mappings): Replace the ENTIRE question with the specified text.

**TYPE 1: EXPANSIONS (append in parentheses)**
Expand known abbreviations at their first occurrence using parentheses (append only; do not change original words).
Case-insensitive. Expand each unique term only once.
Canonical map:
- PCP -> Primary Care Physician
- FDA -> Food and Drug Administration
- online consultation->telehealth consulation
**INFERTILITY/FERTILITY EXPANSION (use medical knowledge to distinguish):**
Use your medical knowledge to identify which type of fertility/infertility benefit applies:

A. **Infertility DIAGNOSIS** - Testing to identify the cause of infertility:
   - Examples: fertility testing, infertility diagnosis, HSG test, semen analysis, hormone testing for infertility, ovarian reserve testing, genetic testing for infertility causes
   - Expansion: Add "(Diagnosis and Treatment of the Cause of Infertility)"

B. **Infertility TREATMENT** - Assisted reproductive procedures and treatments:
   - Examples: IVF, in vitro fertilization, IUI, intrauterine insemination, fertility treatment, infertility treatment, assisted reproduction, egg retrieval, embryo transfer, ICSI
   - Expansion: Add "(Infertility - Assisted Reproductive Benefits)"

C. **Family Planning** - General contraception and family planning services:
   - Examples: birth control, contraceptives, family planning counseling, sterilization, vasectomy, tubal ligation
   - Expansion: Add "(Family Planning and Infertility Benefits)"
**Important:** Diagnosis and treatment are different benefits. Use your medical knowledge to determine which applies based on the question context.

- child  or son/daughter below 18 year or kid or infant-> Pediatric

**TYPE 2: REPLACEMENTS (replace entire question)**
If the question matches any of the following patterns, REPLACE the entire question with the specified text.

**SURGERY REPLACEMENT RULES (Guidance-Based - No Hardcoding):**

For any question about a surgery or surgical procedure, use medical knowledgeand think intelligently to determine the most appropriate setting if surgery can be done inpatient or outpatient orcan be done in  both inpatient and outpatient. Do not rely on a fixed list of surgery names. Analyze the characteristics of the surgery mentioned. Surgeries may be inpatient, outpatient, or both—use your judgment to identify the setting. If both are possible, provide information for both scenarios.

Rule 1: INPATIENT SURGERIES (require overnight hospital stay) 
Use your medical knowledge to classify as INPATIENT if the surgery meets ANY of these criteria:

- Opens the chest cavity or abdomen for major organ work
- Requires general anesthesia with extended recovery time (typically 4+ hours)
- Requires ICU or intensive post-operative monitoring
- Involves replacement of major joints (hip, knee, shoulder)
- Involves major spinal procedures requiring hospitalization
- Is high-risk with significant potential for complications
- Involves major organ systems (cardiovascular, pulmonary, gastrointestinal, hepatic, renal)
- Involves transplantation of organs or tissue
- Involves major cancer resection or removal requiring hospitalization
- Involves major obstetric procedures requiring overnight stay
- Is explicitly described as "inpatient surgery" or "requires overnight hospital stay"
- Typically requires 24+ hours of post-operative hospital care

**Medical Knowledge Guidance:** Consider the invasiveness, complexity, anesthesia requirements, recovery time, and standard medical practice for the procedure. If the procedure typically requires overnight hospitalization for monitoring and recovery, classify as INPATIENT.

→ Replace with:
"Provide the cost share for Hospital Services->Inpatient(nexusId 75) vs Physician and other Professional Services->Physician or surgeon services in an inpatient facility(nexusId 121)"

Rule 2: OUTPATIENT SURGERIES (same-day procedures) Classify as OUTPATIENT if the surgery:

    1.Uses minimally invasive techniques (laparoscopic, endoscopic, arthroscopic,cystoscopy)
    2.Involves all the possible invasive diagnostic procedures (e.g., bronchoscopy, colonoscopy, cystoscopy,biopsies, etc.)
    3.Requires only local anesthesia or light sedation
    4.Has a short recovery time (under 2 hours)
    5.Is low-risk, does not require ICU, and is performed in an ambulatory or outpatient facility
    6.Is described as "outpatient surgery" or "same-day surgery"
    7.Involves minor procedures (skin, ENT, eye, minor ortho, diagnostic endoscopy, biopsies, wound care, debridement, wound care services, etc.)
    8. If the question mentione about the woundcare services

→ Replace the question with:
"Provide the cost share for Ambulatory Surgery Centers->surgery vs Outpatient->Surgeries vs Physician and other Professional Services->Physician or surgeon services in an outpatient facility"

Special Case: Colonoscopy
If colonoscopy or screening colonoscopy is mentioned, always include Preventive health services->Screening colonoscopy (nexusId:648) as the first option.

→ For colonoscopy:
"Provide the cost share for Preventive health services->Screening colonoscopy (nexusId:648) vs Ambulatory Surgery Centers->surgery vs Outpatient->Surgeries vs Physician and other Professional Services->Physician or surgeon services in an outpatient facility"

Rule 3: AMBIGUOUS SURGERIES (could be inpatient OR outpatient)

**IMPORTANT: DO NOT classify as AMBIGUOUS if the surgery clearly meets Rule 1 (INPATIENT) criteria.**


**ONLY classify as AMBIGUOUS if:**
- The surgical approach is NOT specified in the question (could be open OR minimally invasive/laparoscopic) AND the procedure could reasonably be done either way
- The procedure can be performed in BOTH inpatient and outpatient settings depending on:
  * Patient's overall health status and comorbidities
  * Complexity of the specific case
  * Surgeon's preference or facility capabilities
  * Expected recovery time and monitoring needs
- Involves moderate-complexity procedures where setting depends on individual factors:
  * Certain orthopedic procedures (depending on extent) - NOT major joint replacements
  * Certain gynecological procedures (depending on approach) - NOT major abdominal surgeries
  * Certain urological procedures (depending on complexity) - NOT major organ work
  * Certain gastrointestinal procedures (depending on invasiveness) - NOT major bowel/organ surgeries
- The question does NOT explicitly state "inpatient" or "outpatient" setting
- The procedure is genuinely performed in both settings in standard medical practice

**Medical Knowledge Guidance:** Only classify as AMBIGUOUS if the procedure could reasonably be performed as same-day surgery in some cases AND require overnight stay in others. If the procedure ALWAYS or ALMOST ALWAYS requires overnight hospitalization, classify as INPATIENT (Rule 1), not AMBIGUOUS.

**When genuinely uncertain about moderate-complexity procedures, default to AMBIGUOUS** to give the patient complete information for both scenarios.

→ Replace the question as below:
"Provide the cost share for BOTH scenarios:
A) Inpatient surgery: Hospital Services->Inpatient(nexusId 75) vs Physician and other Professional Services->Physician or surgeon services in an inpatient facility(nexusId 121)
B) Outpatient surgery: Ambulatory Surgery Centers->surgery vs Outpatient->Surgeries vs Physician and other Professional Services->Physician or surgeon services in an outpatient facility"


**Rule 4: RECONSTRUCTIVE SURGERY (separate from inpatient surgeries)**
If the question mentions: reconstructive surgery, reconstructive procedure, reconstruction, plastic surgery, cosmetic surgery, cosmetic procedure, elective surgery, Breast reduction, Reduction mammaplasty, Rhinoplasty, Nose surgery, Septoplasty, Eyelid surgery, Blepharoplasty, Ptosis repair, Scar revision, Skin graft, Cleft palate repair, Jaw surgery, Orthognathic surgery, Gynecomastia surgery, Abdominoplasty, Tummy tuck, Body contouring

→ Replace with: "Provide the cost share for Ambulatory Surgery Centers->surgery vs Outpatient->Surgeries vs Physician and other Professional Services->Physician or surgeon services in an outpatient facility. Also check if this is covered under reconstructive surgery benefits when medically necessary or if it is excluded as cosmetic/elective surgery."

**OTHER REPLACEMENT RULES:**

**SPECIALIST/PHYSICIAN VISIT RULE:**
If the question is about visiting, consulting, or seeing a physician, doctor, or medical specialist or specilaist doctor such as internal medicine visit, internal medicine doctor, internist visit, internist appointment, General practitioners (GPs), Family practitioners, Internists, OB/GYNs, Pediatricians,or any other specialist (use your medical knowledge to identify physician/specialist visits - do not rely on a hardcoded list), including but not limited to: office visits, consultations, appointments with any type of physician or specialist, specialist coverage, or specialist referral coverage

→ Replace the question with: "Provide the cost share for Physician and other Professional Services->Office Visit/Consultation, Physician and other Professional Services->Second opinion specialist"

**GENETIC COUNSELING RULE (Family Planning Only):**
If the question mentions: genetic counseling for family planning, genetic testing for family planning, carrier screening for family planning, prenatal genetic counseling, genetic screening for pregnancy planning

→ Replace with: "Provide the cost share for Diagnosis and Treatment of the Cause of Infertility->Laboratory and Pathology services. Note: Genetic counseling and testing for family planning are diagnostic services under infertility benefits, not general family planning counseling."

**THERAPY RULE:**
If the user question contains the word "therapy" (case-insensitive) AND the word "therapy" appears as a standalone word (not preceded by any modifier, adjective, or descriptor word), then replace the standalone word "therapy" with "mental therapy" in the expanded question. If "therapy" is preceded by any word that describes or modifies it (e.g., "physical therapy", "speech therapy", "radiation therapy", "infusion therapy", "hormone therapy", etc.), do NOT add "mental therapy" - keep the original phrasing as-is.

**PREGNANCY RULE:**
If the question mentions: pregnancy or having a baby (do not add this expansion if question does not belong to this category)

→ Replace with: "Provide cost share for all the Pregnancy and Maternity Care benefits (prenatal, postnatal visits, Delivery (Hospital, Physician, Mid-wife non-RN, mid-wife RN, Anesthesia), newborn services-nursery charges (do not miss any), do not mention abortion service), Preventive health-prenatal screening), Ultrasound-(Outpatient Radiology center vs Outpatient department of a hospital) including oopm, deductible lines in all the benefits wherever applicable following the lines from templates. Do not skip bscMaxText if present."

**BENEFIT CATEGORY ROUTING (LAST PRIORITY - apply only if none of the above rules match):**
If the question does NOT match any of the above replacement rules (surgery, specialist, therapy, pregnancy), use your medical/insurance knowledge to map the user's question to the most relevant Evidence of Coverage (EOC) benefit category by adding it in parentheses.

**Available Benefit Categories:**

- Diagnostic X-ray, imaging, pathology, laboratory, and other testing services - covers ONLY **non-invasive** diagnostic procedures (e.g., MRI, X-ray, ultrasound, blood test, EEG, sleep study, CT scan, PET scan).
  **IMPORTANT:** This category does NOT include invasive diagnostic procedures. Invasive procedures (biopsies, endoscopies, bronchoscopies, cystoscopies, or any procedure involving insertion of instruments or removal of tissue) must be classified as OUTPATIENT surgeries under Rule 2.
- Emergency Benefits
- Family Planning and Infertility Benefits
- Fertility Preservation Services
- Hospital Services- Includes facility charges for inpatient stays, such as room and board and surgery, and outpatient facility fees for surgery or treatment at hospitals and ambulatory surgery centers,biofeedback therapy, infusion therapy, radio and chemotherapy
- Infertility - Assisted Reproductive Benefits
- Physician and other Professional Services-Covers office visits, specialist consultations, telehealth, and professional services for diagnosis, treatment, and office-based surgeries.
- Urgent Care services


**Routing Instructions:**
1. Identify the medical service/procedure/test in the question
2. Map it to the most relevant benefit categories from the list above
3. Add the benefit category name in parentheses after the service,do not add the description of the category
4. If the question matches multiple benefit categories, include all relevant categories.
5. If no category matches, keep the original question as-is

**Routing Examples:**
- "Is an MRI covered?" → "Is an MRI (Diagnostic X-ray, imaging, pathology, laboratory, and other testing services) covered?"
- "Do I need authorization for home health care?" → "Do I need authorization for home health care (Home Health Services)?"
- "What's my copay for emergency services?" → "What's my copay for emergency (Emergency Benefits)?"
-" what is my copay for catract surgery?"-> "what is my copay for catract surgery (Hospital Services,Physician and other Professional Services)


IMPORTANT: If question does not contain this terms , do not expand unnecesaarily. For e.g if question is about only diagnosting such as ultrasound, do not add expansions for pregnancy.
Examples:
"what is my cost share of PCP" -> "what is my cost share of Primary Care Physician"

If no terms match, ExpandedQuestion must equal the original input verbatim.

STEP 1: DETERMINE IF THIS IS A FOLLOW-UP
A follow-up depends on prior context, continues an earlier topic, or would be confusing alone.
Return "Yes" or "No".

STEP 2: CLASSIFY THE INTENT(S) (return one or more)
A single question may contain multiple intents.  
Return one or more intents separated by commas.  
Never invent new ones. Always return at least one.
Available intents:
1. PlanCostShares  
→ Plan-level cost details.  
Includes deductible (per person/family), out-of-pocket maximum, accumulator type, HSA eligibility, INN/OON deductible, or plan-level coinsurance.  
Keywords: deductible, OOP max, accumulator, embedded, aggregate, HSA, plan type.  
Examples:  
- "Is this plan HSA-eligible?"
2. BenefitCostShares  
→ Service-level cost sharing (specific copay or coinsurance).  
Includes ER copay, per-visit copay, coinsurance %, waived if admitted, etc.  
Keywords: copay, coinsurance, ER, per-visit, per-admission, OOP applies,cost.  
Examples:  
- "What is the ER copay?"  
- "How much does a specialist visit cost?"
-what does any specific service cost?"
- "Are non-FDA (Food and Drug Administration) approved drugs covered?"
3. EoCCategory  
→ Whether a category/benefit /medical equipment is covered or included at all. Any question that ask about coverage which is related to medical/benefit services.It does not incliude out of state coverage questions.
Keywords: cover, included, benefit name (maternity, infertility, DME, mental health, vision, preventive,telehealth). 
Examples:  
- "Does this plan cover infertility treatment?"  
- "Is preventive care included?"  
- "Is a car transport to an office visit covered?"
- "Are DME items covered?"
- "Is telehealth an option on this plan?"
- "How much does Liposuction cost?"
IMPORTANT:ItIt will only include questions specifically about benefit coverage and will not include generic questions or questions about coverage for travelling out-of-state services.
4. EoCSection  
→ Detailed rules, limits, or conditions under a covered benefit.  
Includes: prior authorization, step therapy, referral, visit/frequency limits, waiting periods, medical necessity, conditional coverage.  
Keywords: prior auth, pre-cert, referral, limit, step therapy, medically necessary, authorization required.  
Examples:  
- "Is prior authorization required for MRI?"  
- "Are PT visits limited to 30 per year?"
- "Explain podiatrist benefits in my plan."
5. ProgramCategories  
→ Add-on or wellness programs and vendor-based offerings.  
Includes: nurse line,out of state,out of californial, travelling coverage, case management, advocacy, BlueCard, EAP, disease management, diabetes program.  
Keywords: nurse line, concierge, case management, BlueCard, EAP, wellness program.  
Examples:  
- "Does this plan have a nurse hotline?"  
- "travelling out of state"
-"Am I covered out of sate?"
-"Am I covered while travelling?"
- "Is there a diabetes management program?"
-"Can I talk to a nurse?"
6. GenericDefinition  
→ If the question is about definitions of insurance or healthcare terms, but do NOT include any questions that start with or contain "How".  
Keywords: what is, define, explain, meaning of, my deductible, my out of pocket maximum.  
Examples:  
- "What is a deductible?"  
- "What is my out of pocket maximum?"  
- "What is the maximum I can pay out of pocket on my plan?"  
Do NOT include or classify any question that starts with or contains "how" under GenericDefinition. For example, do NOT classify "How does any specific process work"  as GenericDefinition.

7. Exclusions  
→ Items, services, or drugs that are NOT COVERED under the plan — permanently or conditionally.  
Includes cosmetic or elective procedures, experimental services, OTC drugs, vitamins, supplies, or limitations listed under Exclusions & Limitations.  
Keywords: excluded, not covered, exclusion list, exception, limitation, not payable, not eligible, experimental, cosmetic, over-the-counter.  
Examples:  
- "Are over-the-counter drugs excluded?"  
- "Is cosmetic surgery not covered?"  
- "Which services are under exclusions?"  
- "Are infertility treatments excluded?"  
- "Is acupuncture excluded?"
-------------------------------
EXCLUSIONS vs COVERAGE RULE
-------------------------------
If question asks:
- "Covered(not out of state/travelling)/included?" → EoCCategory  
- "Excluded/not covered/covered(out ofstate)/exception?" → Exclusions  
- Both coverage & exclusion → EoCCategory, Exclusions  
- Coverage + rule (prior auth, limit) → EoCCategory, EoCSection  
- Excluded with condition ("unless medically necessary") → Exclusions, EoCSection  
- If ambiguous, default to EoCCategory.
8. Fallback  
→ Use this ONLY when the user question is completely outside the domain of health insurance or benefits.  
For example:
- Greetings or conversational prompts (e.g., "hi", "hello", "how are you?")
- Weather, location, travel time, or any general-knowledge queries unrelated to insurance
- Personal or unrelated topics (e.g., food, movies, relationships, general health advice)
- Any question where the intent cannot reasonably map to PlanCostShares, BenefitCostShares, EoCCategory, EoCSection, ProgramCategories, GenericDefinition, or Exclusions.

Important:  
Do NOT classify a question as Fallback if it is even loosely about insurance, benefits, coverage, cost shares, limits, rules, or plan terminology.  
Fallback is strictly for out-of-scope, non-insurance questions only.



RETURN EXAMPLE (JSON):
{{
  "ExpandedQuestion": "what is my cost share of PCP (Primary Care Physician)",
  "FollowUp": "No",
  "Intent": ["BenefitCostShares"]
}}

Now classify this input:
{json.dumps(input)}
""".strip()

        #llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
        #raw = llm.invoke([HumanMessage(content=prompt)])
        crid = f"{uid}|{sid}|{question_id}"
        client = mlflow.deployments.get_deploy_client("databricks")
        response = client.predict(
                        endpoint=LLM_ENDPOINT_SECONDARY,
                        inputs={
                            "client_request_id": crid,
                            "messages": [
                                {"role": "user", "content": prompt}
                            ],
                            "temperature":0  # Set your desired temperature here
                        },
                    )
        result=response["choices"][0]["message"]["content"]
        print("result",result)
        

        # Parse robustly
        payload = _coerce_json(result)

        # Extract fields with safe defaults
        expanded = payload.get("ExpandedQuestion", input) or input
        followup = payload.get("FollowUp", "No")
        intent = _normalize_intents(payload.get("Intent"))

        # Safety defaults if model went off-spec
        if followup not in {"Yes", "No"}:
            followup = "No"
        if  "EoCSection" in intent:
            # If truly nothing recognized, default to EoCCategory per rule
            intent = ["EoCCategory"]

        result = {
            "expanded_question": expanded,
            "followup": followup,
            "intent": intent,
        }
        print("ClassifyIntentTool result ->", result)
        return result