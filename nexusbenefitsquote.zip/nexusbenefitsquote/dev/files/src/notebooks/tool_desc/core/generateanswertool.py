# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
import re
import ast
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct
from databricks.sdk import WorkspaceClient

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore
from tool_desc.core.referral_script import *
from tool_desc.core.special_cases import *
from tool_desc.core.chat_history import ChatHistoryManager
from tool_desc.core.limitText_and_bscMaxText_replacer import PlanTextReplacer

import json
from copy import deepcopy

 
from ftfy import fix_text
import unicodedata


 
def clean_encoding_artifacts(text: str) -> str:
    """
    Cleans encoding artifacts and normalizes Unicode text.
 
    Uses ftfy to fix common encoding issues (mojibake) and applies Unicode normalization (NFKC).
    NFKC (Normalization Form Compatibility Composition) converts characters to their canonical
    equivalents and replaces compatibility characters with standard forms, ensuring consistent
    text representation.
    """
    if not isinstance(text, str):
        return text
    text = fix_text(text)
    return unicodedata.normalize("NFKC", text)
def extract_oopm_lines(plan_data_str):
    """
    Extract OOP Maximum values for Participating and Non-Participating providers.
    Returns list of formatted OOPM lines.
    """

    # Load the plan JSON safely
    try:
        cost_shares = json.loads(plan_data_str)
    except Exception:
        # If the JSON contains escaped quotes, try fixing it
        fixed = plan_data_str.replace("'", '"')
        data = json.loads(fixed)

    #cost_shares = json.loads(data["plan_cost_share"])

    oopm_entry = None
    for entry in cost_shares:
        if entry.get("costShareType") == "OOP Maximum":
            oopm_entry = entry
            break

    if not oopm_entry:
        return []

    results = []

    for pcs in oopm_entry["providerCostShares"]:
        provider_type = pcs["providerCostShareType"]

        # Extract individual + family values
        individual = None
        family = None

        for cp in pcs["coveredParties"]:
            if cp["coveredPartyType"] == "Individual":
                individual = cp["amount"]
            elif cp["coveredPartyType"] == "Family":
                family = cp["amount"]

        if individual is None or family is None:
            continue

        # Build the final output line
        line = (
            f"The service applies to the plan's out-of-pocket maximum amount of "
            f"${individual:,},not to exceed ${family:,} per family. "
            f"When the plan's out-of-pocket maximum amount is satisfied, "
            f"Blue Shield will reimburse the provider 100% of the allowed amount."
        )

        results.append({
            "provider_type": provider_type,
            "individual": individual,
            "family": family,
            "line": line
        })

    return results

tier_prompt="""
Prescription Coverage Instructions (for LLM prompt):

When the member asks about prescription coverage, you MUST always answer using

ALL of the following tiers and service types:

 

Service types:

- Retail Pharmacy

- Mail Order Service

- Retail 90-Day

 

For EACH service type, you MUST include ALL of these tiers, in this order:

- Tier 1

- Tier 2

- Tier 3

- Tier 4


Use this exact template:

Retail Pharmacy (30-day supply):

- Tier 1: <fill in>

- Tier 2: <fill in>

- Tier 3: <fill in>

- Tier 4: <fill in>


Mail Order Service (90-day supply):

- Tier 1: <fill in>

- Tier 2: <fill in>

- Tier 3: <fill in>

- Tier 4: <fill in>

Retail 90-Day (at retail pharmacies):

- Tier 1: <fill in>

- Tier 2: <fill in>

- Tier 3: <fill in>

- Tier 4: <fill in>
You are NOT allowed to omit any tier or service type.
For each line, always provide the deductible line first (if applicable), then the cost share line, then the OOPM text (if applicable), in that order.
"""
# --- Subject to deductible (same regardless of template_key) ---
SUBJ_DED_TEMPLATES = {
    ("IN",  "Coinsurance"): "PPO_IN: Subject to Deductible & Coinsurance",
    ("OUT", "Coinsurance"): "PPO_Out: Subject to Deductible & Coinsurance",
    ("IN",  "Copay")      : "PPO_IN: Subject to Deductible & Copay",
    ("OUT", "Copay")      : "PPO_Out: Subject to Deductible & Copay",
    ("IN",  "No Charge")  : "PPO_IN: Subject to Deductible, No Patient Liability",
    ("OUT", "No Charge")  : "PPO_Out: Subject to Deductible, No Patient Liability",
}

# --- Not subject to deductible: choose ZERO vs NON-ZERO plan deductible variant ---
NOT_SUBJ_DED_TEMPLATES_NONZERO = {
    ("IN",  "Coinsurance"): "PPO_IN: Not Subject to Deductible;Plan deductible is not zero; Subject to  Coinsurance",
    ("OUT", "Coinsurance"): "PPO_Out: Not Subject to Deductible;Plan deductible is not zero; Subject to  Coinsurance;subjectToDeductible=='false'",
    ("IN",  "Copay")      : "PPO_IN: Not Subject to Deductible;Plan deductible is not zero; Subject to Copay",
    ("OUT", "Copay")      : "PPO_Out: Not Subject to Deductible;Plan deductible is not zero ;Subject to Copay",
    ("IN",  "No Charge")  : "PPO_IN: Not Subject to Deductible;Plan deductible is not zero;No Patient Liability",
    ("OUT", "No Charge")  : "PPO_Out: Not Subject to Deductible;Plan deductible is not zero ;No Patient Liability",
}

NOT_SUBJ_DED_TEMPLATES_ZERO = {
    ("IN",  "Coinsurance"): "PPO_IN: Not Subject to Deductible;Plan deductible is zero; Subject to  Coinsurance;subjectToDeductible=='false'",
    ("OUT", "Coinsurance"): "PPO_Out: Not Subject to Deductible;Plan deductible is zero; Subject to  Coinsurance",
    ("IN",  "Copay")      : "PPO_IN: Not Subject to Deductible;Plan deductible is zero; Subject to Copay",
    ("OUT", "Copay")      : "PPO_Out: Not Subject to Deductible;Plan deductible is zero ;Subject to Copay",
    ("IN",  "No Charge")  : "PPO_IN: Not Subject to Deductible;Plan deductible is zero;No Patient Liability",
    ("OUT", "No Charge")  : "PPO_Out: Not Subject to Deductible;Plan deductible is zero ;No Patient Liability",
}

NOT_COVERED_HINT = {
    "IN":  "PPO_IN: NAB or General Exclusion",
    "OUT": "PPO_Out: NAB or General Exclusion",
}
import json, ast

def safe_load_eoc(raw):
    """Return parsed dict/list or None if invalid."""
    if not raw:
        return None

    # If it's already a dict/list, just return it
    if isinstance(raw, (dict, list)):
        return raw

    # Now we know it's a str
    try:
        return json.loads(raw)
    except Exception:
        try:
            # handle Python-literal strings like "{'a': 1}"
            return ast.literal_eval(raw)
        except Exception:
            # last resort – log a sample and skip
            print("[WARN] Could not parse eoc_categories_all_fields, sample:", repr(raw[:300]))
            return None

def _tier(providerCostShareType: str) -> str:
    s = (providerCostShareType or "").strip().lower()
    if s.startswith("participating"): return "IN"
    if s.startswith("non-participating"): return "OUT"
    return "OUT" if "non" in s else "IN"

def _structure(structureType: str, costShareText: str) -> str:
    s = (structureType or "").strip()
    t = (costShareText or "").strip().lower()
    if "not covered" in t or s == "Not Covered": return "Not Covered"
    if "no charge"  in t or s == "No Charge":    return "No Charge"
    if "copay"      in t or s == "Copay":        return "Copay"
    return "Coinsurance" if s == "Coinsurance" else (s or "Coinsurance")

def _to_bool(v):
    if isinstance(v, bool): return v
    if isinstance(v, (int, float)): return bool(v)
    if isinstance(v, str): return v.strip().lower() in {"true","t","yes","y","1"}
    return False
def remove_out_of_network_sections_preserve_note(text: str) -> str:
    """
    Removes all 'Out-of-network Provider:' sections (with or without numbering and bold)
    and their content up to the next section header or end of string,
    but preserves any trailing notes or summaries.
    """
    # Identify the start of the note
    note_start = re.search(
        r"(Emergency Services are covered at the Participating Provider Cost Share.*)",
        text,
        flags=re.DOTALL
    )
    if note_start:
        main_text = text[:note_start.start()]
        note_text = text[note_start.start():]
    else:
        main_text = text
        note_text = ""
    # Remove Out-of-network sections (with optional leading numbering, whitespace, and bold)
    pattern = (
        r"\d+\.\s*\*\*Out-of-network Provider:\*\*.*?(?=(?:\d+\.\s*\*\*In-network Provider:\*\*|[A-Z]\.|$))"
    )
    cleaned_main = re.sub(pattern, '', main_text, flags=re.DOTALL)
    return cleaned_main + note_text
    
    #return re.sub(pattern, '', text, flags=re.DOTALL)

def remove_copayment_line(text: str) -> str:
    # Removes any substring starting with 'and applies to copayment' up to the next period (.)
    return re.sub(r'and applies to your copayment maximu[^.]*\.', '', text, flags=re.IGNORECASE)
def _plan_zero_nonzero_for_tier(template_key: str, tier: str) -> bool:
    """
    Returns True if plan deductible is NON-ZERO for this tier (IN/OUT),
    False if plan deductible is ZERO for this tier.
    Matches your 4 template_key semantics exactly.
    """
    k = (template_key or "").strip().lower()
    if k == "in_nonzero_deductible":
        return True if tier == "IN" else False
    if k == "out_nonzero_deductible":
        return True if tier == "OUT" else False
    if k == "non_deductible_zero":   # you said: both non-zero
        return True
    if k == "zero_deducitble":       # you kept this spelling: both zero
        return False
    # Fallback: treat as zero to be safe
    return False

def add_template_hints_from_template_key(items, plan_status: dict,oopm_line:dict):
    """
    items: list of rows; each row has 'eoc_categories_all_fields' JSON string (your sample)
    plan_status: output of get_plan_deductible_status(..., 'PPO')

    For each providerCostShare, adds:
      - template_hint (exact key from your template JSON)
      - plan_tier_has_deductible (bool per tier derived from template_key)
      - provider_type_normalized
    """
    template_key = plan_status.get("template_key", "")  # one of your 4 cases
    print("plan status",plan_status)
    out_rows = []
    for row in items:
        r = deepcopy(row)
        raw = r.get("eoc_categories_all_fields")
        try:
            parsed = json.loads(raw) if isinstance(raw, str) else (raw or {})
        except Exception:
            parsed = {}

        for subcat in (parsed.get("eocCategories_benefitSubCategories") or []):
            
            for benefit in (subcat.get("benefits") or []):
                
                for pcs in (benefit.get("providerCostShares") or []):
                  
                    tier  = _tier(pcs.get("providerCostShareType"))
                    struct= _structure(pcs.get("structureType"), pcs.get("costShareText"))
                    subj  = _to_bool(pcs.get("subjectToDeductible"))
                    oopm  = _to_bool(pcs.get("oopmApplies"))

                    pcs["provider_type_normalized"] = (
                        "Participating Provider" if tier == "IN" else "Non-Participating Provider"
                    )

                    # A) Not covered override
                    if struct == "Not Covered":
                        pcs["template_hint"] = NOT_COVERED_HINT[tier]
                        pcs["plan_tier_has_deductible"] = _plan_zero_nonzero_for_tier(template_key, tier)
                        continue

                    # B) Subject to deductible → fixed set
                    if subj:
                        pcs["template_hint"] = SUBJ_DED_TEMPLATES.get((tier, struct))
                        if tier=="IN":
                            if oopm:
                             
                                pcs["oopm_text"]=oopm_line["participating_provider"]
                            else:
                                pcs["oopm_text"]=""
                        elif tier=="OUT":
                            if oopm:
                                pcs["oopm_text"]=oopm_line["non-participating_provider"]
                            else:
                                pcs["oopm_text"]=""
                        pcs["plan_tier_has_deductible"] = _plan_zero_nonzero_for_tier(template_key, tier)
                        continue

                    # C) Not subject to deductible → choose ZERO vs NON-ZERO by template_key per tier
                    tier_has_nonzero = _plan_zero_nonzero_for_tier(template_key, tier)
                    if tier_has_nonzero:
                        pcs["template_hint"] = SUBJ_DED_TEMPLATES.get((tier, struct))
                        if oopm:
                            if tier=="IN":
                                pcs["oopm_text"]=oopm_line["participating_provider"]
                            elif tier=="OUT":
                                pcs["oopm_text"]=oopm_line["non-participating_provider"]
                        else:
                            pcs["oopm_text"]=""
                        pcs["template_hint"] = NOT_SUBJ_DED_TEMPLATES_NONZERO.get((tier, struct))
                    else:
                        pcs["template_hint"] = SUBJ_DED_TEMPLATES.get((tier, struct))
                        if oopm:
                            if tier=="IN":
                                pcs["oopm_text"]=oopm_line["participating_provider"]
                            elif tier=="OUT":
                                pcs["oopm_text"]=oopm_line["non-participating_provider"]
                        else:
                            pcs["oopm_text"]=""
                        pcs["template_hint"] = NOT_SUBJ_DED_TEMPLATES_ZERO.get((tier, struct))

                    

                    pcs["plan_tier_has_deductible"] = tier_has_nonzero

        r["eoc_categories_all_fields"] = parsed
  
        out_rows.append(r)
    print("#################################",out_rows)
    return out_rows

import json
import ast


def summarize_plan_cost_shares_plain_english(plan_cost_shares, plan_type="HMO"):
    """
    Summarize planCostShares JSON into clear, prompt-friendly English for LLM prompts.
    """
    def format_amount(amount):
        try:
            amount = float(amount)
            if amount == 0:
                return "$0"
            return f"${int(amount):,}" if amount == int(amount) else f"${amount:,.2f}"
        except Exception:
            return str(amount)
 
    lines = []
    plan_cost_shares = json.loads(plan_cost_shares) if isinstance(plan_cost_shares, str) else plan_cost_shares
 
    for cost_share in plan_cost_shares:
        cstype = cost_share.get("costShareType", "")
        structure = cost_share.get("structureType", "")
        section_header = f"**{cstype}**" + (f" ({structure})" if structure else "")
        lines.append(section_header)
 
        for pcs in cost_share.get("providerCostShares", []):
            provider_type = pcs.get("providerCostShareType", "")
            indiv = fam = None
            indiv_note = fam_note = ""
            for party in pcs.get("coveredParties", []):
                party_type = party.get("coveredPartyType", "")
                amount = format_amount(party.get("amount", "N/A"))
                accrues_oopm = party.get("accruesToOopm")
                accrues_med_oopm = party.get("accruesToMedicalOopm")
                accrual_note = ""
                if accrues_oopm is not None:
                    accrual_note = " (counts towards out-of-pocket maximum)" if accrues_oopm else " (does not count towards out-of-pocket maximum)"
                elif accrues_med_oopm is not None:
                    accrual_note = " (counts towards medical out-of-pocket maximum)" if accrues_med_oopm else " (does not count towards medical out-of-pocket maximum)"
                if "Individual" in party_type:
                    indiv = amount
                    indiv_note = accrual_note
                elif "Family" in party_type:
                    fam = amount
                    fam_note = accrual_note
 
            # Always show both individual and family, even if one is missing
            indiv_str = f"Individual: {indiv or 'N/A'}{indiv_note}"
            fam_str = f"Family: {fam or 'N/A'}{fam_note}"
            lines.append(f"- {provider_type}: {indiv_str}; {fam_str}")
 
        lines.append("")
 
    return "\n".join(lines)
def get_plan_deductible_status(plan_data_str: str, plan_type: str):
    """
    HMO:
      Returns: bool -> True if HMO Provider Individual/Family Facility deductible > 0 (either), else False.

    PPO:
      Returns: dict with detailed flags and a template_key you can use to route templates:
        {
          "participating":  {"individual": float, "family": float, "has_deductible": bool},
          "non_participating": {"individual": float, "family": float, "has_deductible": bool},
          "template_key": "<one of: in_nonzero_deductible | out_nonzero_deductible | non_deductible_zero | zero_deducitble>"
        }
    """
    # --- robust parse for JSON or python-literal string ---
    try:
        data = json.loads(plan_data_str)
    except Exception:
        try:
            data = ast.literal_eval(plan_data_str)
        except Exception:
            return False if plan_type.upper() == "HMO" else {
                "participating":  {"individual": 0.0, "family": 0.0, "has_deductible": False},
                "non_participating": {"individual": 0.0, "family": 0.0, "has_deductible": False},
                "template_key": "zero_deducitble",
            }

    # normalize to list
    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        return False if plan_type.upper() == "HMO" else {
            "participating":  {"individual": 0.0, "family": 0.0, "has_deductible": False},
            "non_participating": {"individual": 0.0, "family": 0.0, "has_deductible": False},
            "template_key": "zero_deducitble",
        }

    plan_type = (plan_type or "").upper()

    # ---------------- HMO (your original logic) ----------------
    if plan_type == "HMO":
        for item in data:
            if not isinstance(item, dict):
                continue
            if item.get("costShareType") != "Medical Deductible":
                continue

            for provider in item.get("providerCostShares", []) or []:
                if not isinstance(provider, dict):
                    continue
                if provider.get("providerCostShareType") != "HMO Provider":
                    continue

                indiv = 0.0
                fam   = 0.0
                for p in provider.get("coveredParties", []) or []:
                    cpt = (p or {}).get("coveredPartyType", "")
                    amt = (p or {}).get("amount", 0)
                    try:
                        amt = float(amt or 0)
                    except Exception:
                        amt = 0.0
                    if cpt == "Individual Facility":
                        indiv = amt
                    elif cpt == "Family Facility":
                        fam = amt

                return not (indiv == 0 and fam == 0)
        return False

    # ---------------- PPO logic (Participating vs Non-Participating) ----------------
    # find Medical Deductible block
    med_block = next(
        (item for item in data if isinstance(item, dict) and item.get("costShareType") == "Medical Deductible"),
        None
    )
    if not med_block:
        return {
            "participating":  {"individual": 0.0, "family": 0.0, "has_deductible": False},
            "non_participating": {"individual": 0.0, "family": 0.0, "has_deductible": False},
            "template_key": "zero_deducitble",
        }

    providers = med_block.get("providerCostShares", []) or []

    def extract_amounts(provider_type: str):
        indiv = 0.0
        fam   = 0.0
        for prov in providers:
            if not isinstance(prov, dict):
                continue
            if prov.get("providerCostShareType") != provider_type:
                continue
            for cp in prov.get("coveredParties", []) or []:
                cpt = (cp or {}).get("coveredPartyType", "")
                amt = (cp or {}).get("amount", 0)
                try:
                    amt = float(amt or 0)
                except Exception:
                    amt = 0.0
                # PPO data uses "Individual" / "Family"
                if cpt == "Individual":
                    indiv = amt
                elif cpt == "Family":
                    fam = amt
        return indiv, fam

    p_ind, p_fam   = extract_amounts("Participating Provider")
    np_ind, np_fam = extract_amounts("Non-Participating Provider")

    p_has  = (p_ind > 0 or p_fam > 0)
    np_has = (np_ind > 0 or np_fam > 0)

    # decide template key (using your exact names)
    if p_has and not np_has:
        template_key = "in_nonzero_deductible"
    elif not p_has and np_has:
        template_key = "out_nonzero_deductible"
    elif p_has and np_has:
        template_key = "non_deductible_zero"   # both non-zero
    else:
        template_key = "zero_deducitble"       # both zero (kept your spelling)

    return {
        "participating": {
            "individual": p_ind,
            "family": p_fam,
            "has_deductible": p_has
        },
        "non_participating": {
            "individual": np_ind,
            "family": np_fam,
            "has_deductible": np_has
        },
        "template_key": template_key
    }


def safe_json_loads(value):
    """Safely load nested/double-encoded JSON until we get a dict or list."""
    try:
        while isinstance(value, str) and value.strip().startswith(("{", "[")):
            value = json.loads(value)
        return value
    except Exception:
        return value


def check_bluecard_program(data):
    """
    Checks if 'BlueCard Program' is included (isIncluded=True)
    from mixed nested JSON / string input structures.
    """
    # Ensure we can iterate over dicts, even if input is a JSON string
    parsed_data = safe_json_loads(data)
    if not isinstance(parsed_data, list):
        print("Input is not a list after parsing.")
        return False

    for entry in parsed_data:
        # Ensure each entry is a dict
        entry = safe_json_loads(entry)
        if not isinstance(entry, dict):
            continue

        val = entry.get("combined_eoc_program_categories")
        val = safe_json_loads(val)
        if not isinstance(val, dict):
            continue

        programs = val.get("eoc_program_categories_programs", [])
        for p in programs:
            if p.get("name", "").strip().lower() == "bluecard program":
                return bool(p.get("isIncluded", False))
    return False


    
def extract_benefit_info_multi(data, keywords):
    #print("In the extarct benefits info multi")
    result = []
 
    benfits=data["benefits"]
    # print("data type is -->", type(benfits ))
    # print("data is -->",str(benfits))
 
    for item in benfits:
        benefit_id = item["benefit_id"]
        raw=item.get("eoc_categories_all_fields")
        eoc=safe_load_eoc(raw)
        
        #eoc = json.loads(item["eoc_categories_all_fields"])
        eoc_name = eoc["eocCategories_name"]
        subcats = []
        for subcat in eoc["eocCategories_benefitSubCategories"]:
            for benefit in subcat["benefits"]:
                name = benefit["name"]
                pcs = []
                for share in benefit["providerCostShares"]:
                    pcs_item = {"providerCostShareType": share["providerCostShareType"]}
                    for kw in keywords:
                        pcs_item[kw] = {k: v for k, v in share.items() if kw in k}
                    pcs.append(pcs_item)
                # Only keep this subcategory if at least one providerCostShare has any non-empty keyword dict
                if any(any(pcs_item[kw] for kw in keywords) for pcs_item in pcs):
                    subcats.append({
                        "name": name,
                        "providerCostShares": pcs
                    })
        # Only keep this benefit if it has at least one subcategory left
        if subcats:
            result.append({
                "benefit_id": benefit_id,
                "eocCategories_name": eoc_name,
                "eocCategories_benefitSubCategories": subcats
            })
 
    #print(json.dumps(result, indent=2))
    result=json.dumps(result)
   
 
    return result
 
 
def exclusive_check_prompt(prompt_key, additional_data, previous_prompt):
 
    prompts = {
        "max_limit_text": f"""
Second Instrcutions:
Instructions:
- If you find that both the 'limits' and 'bscMax' fields are empty for a provider type within a benefit name, Then you don't need to follow the second instrcutions just take the Original Prompt.
- Do not include raw JSON, code, or bullet points; use only plain text.
- Do not summarize the bscMax and Limit values , it should be properly matched and answer with reference to the benefitSubCategories.
 
Inputs:
- Original Prompt:
{previous_prompt}
 
- Raw bscMaxLimit_and_LimitDetails text:
{additional_data}
 
Return the improved answer by blending into orginal details, if other details are present at subcategory levels.
"""
    }
 
    #print("final-prompt is --->"+str(prompts))
    return prompts[prompt_key]

def safe_json_loads(value):
    """Safely load nested/double-encoded JSON until we get a dict or list."""
    try:
        while isinstance(value, str) and value.strip().startswith(("{", "[")):
            value = json.loads(value)
        return value
    except Exception:
        return value

def check_bluecard_program(data):
    """
    Checks if 'BlueCard Program' is included (isIncluded=True)
    from mixed nested JSON / string input structures.
    """
    # Ensure we can iterate over dicts, even if input is a JSON string
    parsed_data = safe_json_loads(data)
    if not isinstance(parsed_data, list):
        print("Input is not a list after parsing.")
        return False

    for entry in parsed_data:
        # Ensure each entry is a dict
        entry = safe_json_loads(entry)
        if not isinstance(entry, dict):
            continue

        val = entry.get("combined_eoc_program_categories")
        val = safe_json_loads(val)
        if not isinstance(val, dict):
            continue

        programs = val.get("eoc_program_categories_programs", [])
        for p in programs:
            if p.get("name", "").strip().lower() == "bluecard program":
                return bool(p.get("isIncluded", False))
    return False


def generate_ppo_prompt(question, plan_type, data, scripting_format):  # Use your stable HMO prompt here
    print("question",question)
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.Do not  combine the benefits/services/sections, provide each relevant section separately.Folow the 'template_hint' provided in cost share data for In-Network and Out-of-Network strictly while responding.

</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse  excluded but skilled home health covered;Callus Treatment excluded").

   c. Pure exclusion.
      If no benefit is found and an exclusion clearly matches, return exactly:
      “The [service] you are requesting is an exclusion under your current policy.This means that the patient would be responsible for 100% of the billed amount.”
      Note: Cryotherapy is excluded from the plan.

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         For e.g: ,"Private Duty Nursing is excluded but Home health services are covered"
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.
    If not excluded,** continue with the standard template-based generation**.

1. Answer only the specific user query. Do not include assumptions or external information.
2. Treat  "In-network Provider" and "Participating Provider" as  **In-network Provider. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.Use the Pharmacy deductible values for pharmacy related questions only (prescription coverage).Note:Medical equipments and opiod treatment are not related to pharmacy.
3. Use clear, simple language suitable for users with no technical background.
4.Analyze the question intelligently and answer it.For e.g 
        *If the cost share is $0 copay, mention this in response, Do not hallucinate other cost share.
        *For question on  Pediatric Dental Exam  , please not that Pediatric Dental Exam Coverage is not part of Preventive health Service. Do not get confused here.
        *Please review the question to determine if it asks about a specific service. If it does, provide details only for that service and do not include information about other services. FOr e.g if question is on diabetic testing supplies, do not add the pharmacy drug information in the response.
        *social skills training is completley excluded, not even included for mental health substance. 
        * For questions on infertility , list out all the benefits-subsections.
        *If question=="Do I need authorization for an MRI?"then add this line "The plan documents provided do not indicate whether prior authorization is required. You will need to research the most current Prior Auth Lists on the Medical Policy Department SharePoint to verify if the service requires prior authorization."
        *CRITICAL RULE FOR PRESCRIPTION/MEDICINE QUESTIONS: If the question asks about coverage for a specific medication or drug by name, OR contains keywords like "prescription", "medication", "drug", "medicine", "pharmacy", AND the specific medication is NOT explicitly listed in the benefit data, you MUST provide coverage details for ALL tiers (Tier 1, Tier 2, Tier 3, and Tier 4) across ALL service types (Retail Pharmacy 30-day, Retail 90-Day, and Mail Order Service 90-day). Strictly use Pharmacy deductible values in template. Do not miss deductible line, cost share, or oopm line for each tier and service type.
        * If the question ask about specialist and any referral needed frpm primary doctor, provide the cost share for generalist as well as specialist visit.
        * If the cost share include both copay and coinsurance, refer the template and add line for both copay and coinsurance. The 1st line should be deductinle line.
        * FOr therapy questions other than mental therapy, provide the cost share from Rehabilitative and Habilitative Service and skilled nursing facility based on the required therapy.
        *For any kind of transport such as inpatient facility transfer, for emergency, it includes both emergency and nonemergency transport.

5.Strict Prompt Guideline for Multiple Service Types/Settings:
    a)If the query involves multiple service types or settings (for example: standalone vs. hospital, outpatient radiology center vs. outpatient department of hospital, facility vs. physician, freestanding vs. hospital urgent care, outpatient radiology center vs. outpatient department of hospital, Freestanding Skilled Nursing Facility vs. Hospital Skilled Nursing Unit, Emergency Room Visit vs. Emergency Room Physician Services vs. Emergency Room Services Resulting in Admission,laboratory center vs. outpatient department of a hospital,Emergency transport vs non-emergency transport,Residents of Non-Designated Counties vs Residents of Designated Counties),you must Write a separate breakdown for Participating and Non-Participating providers for each type or setting.
    b)Do not merge, lump, combine, or collapse multiple coverage categories into a single benefit.
    c) If the service asked in question does not have direct benefits, provide the service name in the response.
    d)Never stop after the first matching benefit if additional variants remain in the same data block. List every possible section separately, as each section may have different values for deductible, out-of-pocket maximum (OOPM), limitText, or BSCMaxText.
This is a strict rule. Any response that merges, combines, or omits distinct coverage categories or fails to use the exact section titles from the data is invalid.
6.Tempate Hint Strict Rule:For each providerCostShareType in-network and out-network in each benefit/section, you MUST apply only the template indicated by that row’s 'template_hint'. Never reuse, merge, alter, override, or guess templates.template_hint = 100% authority.
7.Deductible Strict Rule:Do not keep the "[$X]" placeholder".It is cosidered invalid.Replace the value correctly provided in the plan cost share.
8. If the cost share is "Maximum" allowance for any providerCostShareType (in-network and out-of-network), do not add any coinsurance line in the response. Just mention the given maximum allowance.
9.Please provide the cost share line exactly as it appears in the context. For example, do not omit important terms such as "per visit".
10.IMPORTANT: Add "Additional information" only once at the end of the complete response. Do not repeat it for each network type (In-network/Out-of-network) or for each benefit section. Do not include in "Additional information" what is already mentioned in the In-network or Out-of-network provider sections (e.g., "covered at no charge for in-network" or "covered  when received from a Participating Provider/non-particiapting provider"), do NOT include it.
11.For each providerCostShareType,Add the oopm_text from the cost share data exact as given
    *Do not add any other line in cost share such as "and applies to your copayment maximum of $x, not to exceed $x per family.".This line is invalid.
12.For questions that ask whether a specific service is covered or for any question where the response could begin with "yes" or "no," such as can I, is it,does this , always start your response with a clear, natural English statement directly addressing the coverage status of that service.For e,g: For question Is a private home health care nurse covered?, start with "yes or no” statement and then conitunue as it is.   
13.Do not add the deductible,cost share or out of pocket maximum information as "Additional information:".
14.When the plan data does not contain information relevant to the user's question, or if the user's question is about administrative processes (such as obtaining referrals, prior authorizations, or approvals), navigation (such as how to find in-network providers or facilities), or provider search, rather than about specific benefit coverage, cost share, exclusions, or plan details, return the default response: "I’m here to help with topics related to health plan benefits. Could you please ask something related to these topics?"
15.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.
</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure, including only the subsection/subcategories/benefit that are relevant to the question::

A. [EOC Category name if present][nexusId]->Threshold:[score]->[benefitSubCategories Header if present,required and applicable to the question][nexusId]\n

  a. **[subsection/subcategories/benefits]**[nexusId]\n
    1. **In-network Provider:**  
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.]
    IMPORTANT:If service has  no cost share(copay/coinsurance) or oopmapplies is false , do not include OOPM line in your answer. "
  

    2. **Out-of-network Provider:**  
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional 
  
    IMPORTANT:1.If service has  no cost share(copay/coinsurance) or oopmapplies  is false , do not include OOPM line in your answer.
            2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

 b. **[subsection/subcategories/benefits]**[nexusId]\n
    1. **In-network Provider:**  
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.]
    IMPORTANT:If service has  no cost share(copay/coinsurance) or oopmapplies is false, do not include OOPM line in your answer.
            
    2. **Out-of-network Provider:**  
   [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.]
    IMPORTANT:1.If service has  no cost share(copay/coinsurance) or oopmapplies is false , do not include OOPM line in your answer.
            2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

  c..
  d.. 
  ...


IMPORTANT: 1.Analyze the question and include only those subsection/subcategories that are relevant ot the question
           2. At the end of each EOC Category such as A.,B, , add "Note" section that should include any additional information from the <content> section,Vendor detail such as important details, contact numbers,vendor contact number,network contact no, URLs, or other relevant information.Strictly,do not miss adding contact ni if present in benefit.Do not add the deductible,cost share or out of pocket maximum information in addtional details.Do not repeat the EOC category for each subsection,keep common heading .
           3. Do not add any referral line in the response.
           4.Strictly use the template provided by 'template_hint' in the cost share data.

           Only plain text / Markdown. No JSON, no placeholders.

</RESPONSE FORMAT>
IMPORTANT: 1. DO not merge or combine multiple coverage categories into one benefit. For e.g: If question is about ultrasound/MRI or Imaging, 
            provide all the sections including radiology center,outpatient department of hospital.
           2. Do not add any referral line in the response.
           3. Do not add the deductible,cost share or out of pocket maximum information in "Additional information"
          
"""



def generate_hmo_prompt(question, plan_type, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse excluded;skilled home health covered”).

   c. Pure exclusion.
      If no benefit is found and an exclusion clearly matches, return exactly:
      “[Service name]\nThe [service] you are requesting is an exclusion under your current policy.This means that the patient would be responsible for 100% of the billed amount.”
      Note: Cryotherapy is excluded from the plan.

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.

    If not excluded,** continue with the standard template-based generation**.
1. Answer only the specific user query. Do not include assumptions or external information.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.Use the Pharmacy deductible values for pharmacy related questions only (prescription coverage).Note:Medical equipments and opiod treatment are not related to pharmacy.
4. Use clear, simple language suitable for users with no technical background.
5.Analyze the question intelligently and answer it.For e.g 
         *For Prenatal screening and annual health checkups, both In and Out network are covered at "No Charge".
        *Please review the question to determine if it asks about a specific service. If it does, provide details only for that service and do not include information about other services. FOr e.g if question is on diabetic testing supplies, do not add the pharmacy drug information in the response.For allergy injection, provide the answer for allergy injections only.
        *social skills training is completley excluded, not even included for mental health substance. 
        *CRITICAL RULE FOR PRESCRIPTION/MEDICINE QUESTIONS: If the question asks about coverage for a specific medication or drug by name, OR contains keywords like "prescription", "medication", "drug", "medicine", "pharmacy", AND the specific medication is NOT explicitly listed in the benefit data, you MUST provide coverage details for ALL tiers (Tier 1, Tier 2, Tier 3, and Tier 4) across ALL service types (Retail Pharmacy 30-day, Retail 90-Day, and Mail Order Service 90-day). Strictly use Pharmacy deductible values in template. Do not miss deductible line, cost share, or oopm line for each tier and service type.
        * If the question ask about specialist and any referral needed frpm primary doctor, provide the cost share for generalist as well as specialist visit.
        *If question=="Do I need authorization for an MRI?"then only refer "The plan documents provided do not indicate whether prior authorization is required. You will need to research the most current Prior Auth Lists on the Medical Policy Department SharePoint to verify if the service requires prior authorization."
        *For any kind of transport for emergency, it includes both emergency and nonemergency transport.
        * If the cost share include both copay and coinsurance, refer the template and add line sfor both copay and coinsurance. The 1st line should be deductinle line.
        * FOr therapy questions otheer than mental therapy, provide the cost share from Rehabilitative and Habilitative Service and skilled nursing facility based on the required therapy.

6.Strict Prompt Guideline for Multiple Service Types/Settings:
     a)If the query involves multiple service types or settings (for example: standalone vs. hospital, outpatient radiology center vs. outpatient department of hospital, facility vs. physician, freestanding vs. hospital urgent care, outpatient radiology center vs. outpatient department of hospital, Freestanding Skilled Nursing Facility vs. Hospital Skilled Nursing Unit, Emergency Room Visit vs. Emergency Room Physician Services vs. Emergency Room Services Resulting in Admission,laboratory center vs. outpatient department of a hospital,Emergency transport vs non-emergency transport,Residents of Non-Designated Counties vs Residents of Designated Counties),you must Write a separate breakdown for Participating and Non-Participating providers for each type or setting.
    b)Do not merge, lump, combine, or collapse multiple coverage categories into a single benefit.
    c) If the service asked in question does not have direct benefits, provide the service name in the response.
    d)Never stop after the first matching benefit if additional variants remain in the same data block. List every possible section separately, as each section may have different values for deductible, out-of-pocket maximum (OOPM), limitText, or BSCMaxText.
This is a strict rule. Any response that merges, combines, or omits distinct coverage categories or fails to use the exact section titles from the data is invalid.
7.OOPM Rule: Check the **oopmApplies** flag for "In-network provide' for each service. If it is true, add the complete "oopm_text" in response including the line"When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.". If the oopmapplies is false for the specific service, do not add the "oopm_text" and keep it empty in response.This rule should not be violated.
8.Deductible  STRICT Rule:From the scripting, choose the correct template , check the subjectotDeductible flag carefully for the service and strictly fill the values accordingly.If subjecttoDeductible is False, do not select the template with deductible as True. Do not keep the "[$X]" placeholder" in your answer.
9.For questions that ask whether a specific service is covered or for any question where the response could begin with "yes" or "no," such as can I, is it,does this , always start your response with a clear, natural English statement directly addressing the coverage status of that service.For e,g: For question Is a private home health care nurse covered?, start with "yes or no” statement and then conitunue as it is.
10.Please provide the cost share line exactly as it appears in the context. For example, do not omit important terms such as "per visit".
11.When the plan data does not contain information relevant to the user's question, or if the user's question is about administrative processes (such as obtaining referrals, prior authorizations, or approvals), navigation (such as how to find in-network providers or facilities), or provider search rather than about specific benefit coverage, cost share, exclusions, or plan details, return the default response: "I’m here to help with topics related to health plan benefits. Could you please ask something related to these topics?"
12.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.
</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure, including only the subsection/subcategories/benefit that are relevant to the question::

A. [EOC Category name if present][nexusId]->Threshold:[score]->[benefitSubCategories Header if present,required and applicable to the question][nexusId]\n
 a. **[subsection/subcategories/benefits]**[nexusId]\n
    1. **In-network Provider:**  
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.If the benefits listed in the EOC category do not match the service mentioned in the question, use the service name from the question instead.]
    IMPORTANT:If service has  no cost share(copay/coinsurance) or oopmApplies is false for the benefit , do not include OOPM line in your answer.If the subjectToDeductible is false, and plan deductible is not zero,add the line"However, [service] is not subject to dedcuctible."\n

    2. **Out-of-network Provider:**  
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.]
    IMPORTANT:1.If service has  no cost share(copay/coinsurance) or oopmapplies  is false , do not include OOPM line in your answer.
            2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

 b. **[subsection/subcategories/benefits]**[nexusId]\n
    1. **In-network Provider:**  
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.If the benefits listed in the EOC category do not match the service mentioned in the question, use the service name from the question instead.]
    IMPORTANT:If service has  no cost share(copay/coinsurance) or oopmapplies is false, do not include OOPM line in your answer.If the subjectToDeductible is false, add the line"However, [service] is not subject to dedcuctible."\n
            
    2. **Out-of-network Provider:**  
   [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.]
    IMPORTANT:1.If service has  no cost share(copay/coinsurance) or oopmapplies is false , do not include OOPM line in your answer.
            2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

  c..
  d.. 

B....

IMPORTANT: 1.Analyze the question and include only those subsection/subcategories that are relevant ot the question
           2. At the end of each EOC Category such as A.,B, , add "Note" section that should include any additional information from the <content> section,Vendor detail such as important details, contact numbers,vendor contact number,network contact no, URLs, or other relevant information.Strictly,do not miss adding contact ni if present in benefit.Do not add the deductible,cost share or out of pocket maximum information in addtional details.Do not repeat the EOC category for each subsection,keep common heading .
           3. Do not add any referral line in the response.
        
          
Only plain text / Markdown. No JSON, no placeholders.


</RESPONSE FORMAT>
IMPORTANT: 1. DO not merge or combine multiple coverage categories into one benefit. For e.g: If question is about ultrasound/MRI or Imaging, 
            provide all the sections including radiology center,outpatient department of hospital.
            2.Do not add any referral line in the response.
          
"""





def generate_hmo_access_prompt(question, plan_type,plan_name, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse excluded;skilled home health covered”).

    c. Pure exclusion.
    If no benefit is found and an exclusion clearly matches, return ONLY this exact message and STOP:
    "The [service] you are requesting is an exclusion under your current policy. This means that the patient would be responsible for 100% of the billed amount."
    Do not provide any additional information, benefit details, or cost share. Do not continue with any other template or section.
    Note: Cryotherapy is excluded from the plan.
   

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.
      DO not add deductible line, in-network and out-network scripting in responses for exclusion.Simplay add the exclusion line only.

    If not excluded,** continue with the standard template-based generation**.
1. Answer only the specific user query. Do not include assumptions or external information.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.Use the Pharmacy deductible values for pharmacy related questions.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.Use the Pharmacy deductible values for pharmacy related questions only (prescription,medicine coverage).Note:Medical equipments and opiod treatment are not related to pharmacy.
4. Use clear, simple language suitable for users with no technical background.
5.Analyze the question intelligently and answer it.For e.g .
        *Pediatric dental coverage,Durable medical equipment and Contraceptive Implants are not falling under "Preventive health service", do not confuse.
        *Please review the question to determine if it asks about a specific service. If it does, provide details only for that service and do not include information about other services. FOr e.g if question is on diabetic testing supplies, do not add the pharmacy drug information in the response.
        *social skills training is completley excluded, not even included for mental health substance. 
        * Opioid treatment is not included for detoxification purposes but inpatient facility services for substance use disorder is included.
        *CRITICAL RULE FOR PRESCRIPTION/MEDICINE QUESTIONS: If the question asks about coverage for a specific medication or drug by name, OR contains keywords like "prescription", "medication", "drug", "medicine", "pharmacy", AND the specific medication is NOT explicitly listed in the benefit data, you MUST provide coverage details for ALL tiers (Tier 1, Tier 2, Tier 3, and Tier 4) across ALL service types (Retail Pharmacy 30-day, Retail 90-Day, and Mail Order Service 90-day). Strictly use Pharmacy deductible values in template. Do not miss deductible line, cost share, or oopm line for each tier and service type.
        * If the question ask about specialist and and also ask about referral needed from primary doctor then only, provide the cost share for generalist as well as specialist visit.
        *If question=="need authorization for an MRI?"then only refer "The plan documents provided do not indicate whether prior authorization is required. You will need to research the most current Prior Auth Lists on the Medical Policy Department SharePoint to verify if the service requires prior authorization."and provide rest of the benefits coverage.*For any kind of transport for emergency, it includes both emergency and nonemergency transport.
        * If the cost share include both copay and coinsurance, refer the template and add line sfor both copay and coinsurance. The 1st line should be deductinle line.
        * For therapy questions otheer than mental therapy, provide the cost share from Rehabilitative and Habilitative Service and skilled nursing facility based on the required therapy.

6.Strict Prompt Guideline for Multiple Service Types/Settings:
     a)If the query involves multiple service types or settings (for example: standalone vs. hospital, outpatient radiology center vs. outpatient department of hospital, facility vs. physician, freestanding vs. hospital urgent care, outpatient radiology center vs. outpatient department of hospital, Freestanding Skilled Nursing Facility vs. Hospital Skilled Nursing Unit, Emergency Room Visit vs. Emergency Room Physician Services vs. Emergency Room Services Resulting in Admission,laboratory center vs. outpatient department of a hospital,Emergency transport vs non-emergency transport,Residents of Non-Designated Counties vs Residents of Designated Counties),you must Write a separate breakdown for Participating and Non-Participating providers for each type or setting.
    b)Do not merge, lump, combine, or collapse multiple coverage categories into a single benefit.
    c) If the service asked in question does not have direct benefits, provide the service name in the response.
    d)Never stop after the first matching benefit if additional variants remain in the same data block. List every possible section separately, as each section may have different values for deductible, out-of-pocket maximum (OOPM), limitText, or BSCMaxText.
This is a strict rule. Any response that merges, combines, or omits distinct coverage categories or fails to use the exact section titles from the data is invalid.
7.OOPM Rule(STRICT RULE-should not be violated):Do not miss the OOPM line if oopm applies is True.Check the **oopmApplies** flag for "In-network provide' for each service. If it is true, add the complete "oopm_text" in response including the line"When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.". If the oopmApplies is false for the specific service, do not add the "oopm_text" in response.This rule should not be violoated in any case or any question.
8.Deductible Rule (STRICT RULE-should not be violated):From the scripting, check the subjectTodeductible flag carefully and choose the correct template for the service and strictly fill the values accordingly.For e.g: If subjectTodeductible is False and plan deductible is not zero,add the line "However,[service] is not subject to deductible".Do not keep the "[$X]" placeholder" in your answer.This rule should not be violated.
9. Please provide the cost share line exactly as it appears in the context. For example, do not omit important terms such as "per visit".
10.For questions that ask whether a specific service is covered or for any question where the response could begin with "yes" or "no," such as can I, is it,does this , always start your response with a clear, natural English statement directly addressing the coverage status of that service.For e,g: For question Is a private home health care nurse covered?, start with "yes or no” statement and then conitunue as it is.
11.STRICT RULE - Non-Coverage/Non-Benefit Questions:
If the question asks about anything OTHER than coverage or cost share of a specific insurance benefit service  respond ONLY with:
"The plan documents provided do not contain information to answer this question. Please contact your insurance company directly for assistance."
12.Whem the plan documents provided do not contain information to answer this question, or if the user's question is about administrative processes (such as obtaining referrals, prior authorizations, or approvals), navigation (such as how to find in-network providers or facilities), or provider search, rather than about specific benefit coverage, cost share, exclusions, or plan details, return the default response: "I’m here to help with topics related to health plan benefits. Could you please ask something related to these topics?"
13.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.

</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure, including only the subsection/subcategories/benefit that are relevant to the question::

A. [EOC Category name if present][nexusId]->Threshold:[score]->[benefitSubCategories Header if present,required and applicable to the question][nexusId]\n
 a. **[subsection/subcategories/benefits]**[nexusId]\n
    1. **In-network Provider:**  
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.If the benefits listed in the EOC category do not match the service mentioned in the question, use the service name from the question instead.]
    

    2. **Out-of-network Provider:**
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.]
    IMPORTANT:1.If service has  no cost share(copay/coinsurance) or oopmapplies  is false , do not include OOPM line in your answer.
            2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

 b. **[subsection/subcategories/benefits]**[nexusId]\n
    1. **In-network Provider:**  
    [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.If the benefits listed in the EOC category do not match the service mentioned in the question, use the service name from the question instead.]
  
            
    2. **Out-of-network Provider:**  
   [Output from the scripting format, filled with the relevant values for Deductibility, Copay/Benefit/Cost Share/Coinsurance, Out-of-Pocket Maximum (OOPM) and any additional information provided in the data.]
    IMPORTANT:1.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

  c..
  d.. 
  .
  .
  .

IMPORTANT: 1.Analyze the question and include only those subsection/subcategories that are relevant ot the question
           2. At the end of each EOC Category such as A.,B, , add "Note" section that should include any additional information from the <content> section,Vendor detail such as important details, contact numbers,vendor contact number,network contact no, URLs, or other relevant information.Strictly,do not miss adding contact ni if present in benefit.Do not add the deductible,cost share or out of pocket maximum information in addtional details.Do not repeat the EOC category for each subsection,keep common heading .
           3. Do not add any referral line in the response.
       
</RESPONSE FORMAT>
"""


class GenerateAnswerArgs(BaseModel):
    input: str=  Field(..., description="Original  question")
    question: str = Field(..., description="expanded user question")
    plan_meta: str = Field(..., description="Plan-wide metadata (JSON string)")
    plan_type: str = Field(..., description="plan_type")
    plan_name: str = Field(..., description="Plan name")
    followup: str = Field(..., description="Followup of the question")
    uid: str = Field(..., description="Unique user ID")
    sid: str = Field(..., description="Session ID")
    question_id: str = Field(..., description="Unique question ID")
    intent: Optional[list] = None
    exclusion: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Exclusions list (parsed)"
    )
    cost_share: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Benefits list (parsed)"
    )
    def_cost_share: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Definition cost share list (parsed)"
    )
    program_details: Optional[List[Dict[str, Any]]] = Field(default_factory=list, description="Program details list (parsed)"),

  
class GenerateAnswerTool(StructuredTool):
    name: ClassVar[str] = "GeneratePlanAnswer"
    description: ClassVar[str] = "Merge cost-share details, templates, exclusion and plan metadata into final Markdown."
    args_schema: ClassVar[Type[BaseModel]] = GenerateAnswerArgs

    @mlflow.trace(name="GenerateAnswer_run", span_type="tool")
    def _run(
        self,
        input:str,
        question: str,
        plan_meta: str,
        plan_type: str,
        plan_name: str,
        followup: str,
        uid:str,
        sid:str,
        question_id:str,
        intent: Optional[list] = None,
        exclusion: Optional[List[Dict[str, Any]]] = None,
        cost_share: Optional[List[Dict[str, Any]]] = None,
        def_cost_share: Optional[List[Dict[str, Any]]] = None,
        program_details:Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        data = {}
        
        # Safe defaults for optional args
        exclusion = exclusion or []
        env=ConfigStore.get("env")
        LLM_ENDPOINT_PRIMARY=ConfigStore.get("LLM_ENDPOINT_PRIMARY")
        LLM_ENDPOINT_SECONDARY=ConfigStore.get("LLM_ENDPOINT_SECONDARY")
        print("LLM_ENDPOINT_PRIMARY",LLM_ENDPOINT_PRIMARY)
        instance = ConfigStore.get("instance")
        print("instance",instance)
        w = WorkspaceClient()
        current_user_name = w.current_user.me().user_name
        user_name = current_user_name
        print("user_name",user_name)
        db_name = "databricks_postgres"
        print(db_name)
        host = w.database.get_database_instance(name=instance).read_write_dns
        print(host)
        sslmode = "require"
        cost_share = cost_share or []
        def_cost_share = def_cost_share or []
        
        chat_obj= ChatHistoryManager()
        replacer = PlanTextReplacer()        

        history_prompt = ''
        if followup == "Yes":
            history = chat_obj.fetch_chat_history(user_id=uid, session_id=sid)
            history_prompt = (
        "=== CONVERSATION HISTORY (Most recent messages) ===\n"
        + str(history) + "\n"
        "=== END OF HISTORY ===\n\n"
        
        "CRITICAL INSTRUCTIONS FOR FOLLOW-UP QUESTIONS:\n"
        "- You are now answering a follow-up question. The user may be clarifying, expanding, or probing deeper.\n"
        "- Do NOT assume your previous response was complete or fully accurate — always treat the current question as an opportunity to provide the best possible answer using fresh retrieval.\n"
        "- Prioritize the latest retrieved context over anything said in previous responses.\n"
        "- If the new retrieval contains additional, different, or more detailed information than what was said before, use it and update/correct the answer accordingly.\n"
        "- Be transparent and helpful: If this changes or adds to what was said earlier, acknowledge it naturally (e.g., 'To give you the most accurate info...', 'Additionally...', or 'Upon double-checking...').\n"
        "- Never repeat an incomplete answer just because it was given before — aim for completeness and accuracy now.\n\n"
        
        "Answer the user's current question using the latest retrieved context and this history."
    )

        # ----- Program Categories -----
        if  "ProgramCategories" in intent:
            print("program_details",program_details)
         
            #program_categories_json={"ProgramCategories": program_details}
            #print(type(program_details))
            #print(program_categories_json)

            if plan_type == "HMO":
            
                prompt = f"""
                You are a Health Plan Program Assistant.

                Use only the provided Program Categories data to answer the user question.

                User Question: {question}  
                data:{program_details}   

                Rules:
                1. Identify if the question matches a program (e.g., “talk to a nurse” → Nurse Advice Line, 24/7 Nurse Line, Nurse Hotline, etc.,).
                2. If a matching program exists, summarize :
                • Program name and purpose  
                • How to access (phone/app)  
                • Availability or hours  
                • Cost (if given)
                3. If marked as excluded or not covered, reply exactly:
                “This service is not covered under the plan.”
4. If no matching program exists, reply:
   “This information isn’t available in the provided program data. Please contact Member Services for help.”
5. Use only plain text or simple bullets, no JSON, no placeholders.

"""             
                prompt = prompt+"\n"+history_prompt
                crid = f"{uid}|{sid}|{question_id}"
                client = mlflow.deployments.get_deploy_client("databricks")
                response = client.predict(
                                endpoint=LLM_ENDPOINT_PRIMARY,
                                inputs={
                                    "client_request_id": crid,
                                    "messages": [
                                        {"role": "user", "content": prompt}
                                    ],
                                    "reasoning_effort":"low"  
                                },
                            )
                result=response["choices"][0]["message"]["content"]

                content = str(result)
                chat_obj.save_chat_history(question,content,question_id,user_id=uid,session_id=sid)
                result="The patient must receive services from either an in-network provider or a provider associated with their medical group to be eligible for benefits. A referral from the patient's primary care physician (PCP) is usually required when the patient wants to see a specialist or other provider."+"\n"+result

                return result
                

            elif plan_type == "PPO":
                if not cost_share or len(cost_share) == 0:
                    return "I’m here to help with topics related to health plan benefits. Could you please ask something related to these topics?"                
                # Expecting you have the helper defined elsewhere:
                # def check_bluecard_program(program_data_list): -> bool
                is_bluecard = check_bluecard_program(cost_share)
                if is_bluecard:
                    return (
                        "Under the BlueCard® Program, when you receive Out-of-Area Covered Health Care Services within "
                        "the geographic area served by a Host Blue, Blue Shield will remain responsible for the provisions "
                        "of this Agreement. However, the Host Blue is responsible for contracting with and generally handling "
                        "all interactions with its participating healthcare providers, including direct payment to the provider. "
                        "The BlueCard® Program enables you to obtain Out-of-Area Covered Health Care Services, as defined above, "
                        "from a health care provider participating with a Host Blue, where available. The participating health care "
                        "provider will automatically file a claim for the Out-of-Area Covered Health Care Services provided to you."
                    )
                else:
                    return (
                        "This Blue Shield plan provides limited coverage for health care services received outside of the Plan "
                        "Service Area. Out-of-Area Covered Health Care Services are restricted to Emergency Services, Urgent Services, "
                        "and Out-of-Area Follow-up Care. Any other services will not be covered when processed through an Inter-Plan "
                        "Arrangement unless prior authorized by Blue Shield."
                    )

        # ----- Concept/Definition questions -----
        elif "GenericDefinition" in intent:
            data = {
                "plan_data": plan_meta,
                #"benefits": def_cost_share or cost_share,
            }
 
            prompt = f"""
              <ROLE>
              You are a Health Insurance Agent. Explain key insurance terms using your knowldege about insurance terms.
            
              </ROLE>
 
              <INSTRUCTION>
              User question: {question}
              data:{data}

              </INSTRUCTION>
 
              <GUIDELINES>
              • Start with a short, plain-language definition.Do not give any false information about cost share. 
              • If question ask about deductible, provide the deductibles from the current plan, do not provide any cost share information.
              • If the user asks any question, your definition and explanation should be between 200 and 300 words. Describe in 100 - 200 words.
              </GUIDELINES>
 
              <RESPONSE FORMAT>
              Write one short paragraph combining the definition and explanation in natural language.
 
              If the question asks about CPT code (e.g., 99213), do not provide the deductibles, OOPM, or cost share. Simply provide definition and explanation for the code.
              For example: "The code '99213' refers to a specific billing code used to denote a particular type of office or outpatient visit for an established patient. This code is part of the Current Procedural Terminology (CPT) system, which is used by healthcare providers to report medical, surgical, and diagnostic procedures and services. In the context of the provided plan data, there is no direct mention of CPT code 99213. To understand how a visit billed under code 99213 would be covered, one would need to refer to the specific terms related to office visits or outpatient services within the plan, which are not explicitly detailed in the provided data."
              </RESPONSE FORMAT>
              """
            
            prompt = prompt+"\n"+history_prompt  
            crid = f"{uid}|{sid}|{question_id}"
            client = mlflow.deployments.get_deploy_client("databricks")
            response = client.predict(
                            endpoint=LLM_ENDPOINT_PRIMARY,
                            inputs={
                                "client_request_id": crid,
                                "messages": [
                                    {"role": "user", "content": prompt}
                                ],
                                "reasoning_effort":"low"  # Set your desired temperature here
                            },
                        )
            result=response["choices"][0]["message"]["content"]         

            content = str(result)
            chat_obj.save_chat_history(question,content,question_id,user_id=uid,session_id=sid)
            if "how" in question.lower():
                result="I’m here to help with topics related to health plan benefits. Could you please ask something related to these topics?"

            return result
        
        elif "BenefitCostShares" in intent or "EoCCategory" in intent or "Exclusions" in intent:
            #try:
            scripting_key = "HMO" if "HMO" in plan_type else "PPO"
            #print("planmeta",type(plan_meta))
            result=get_plan_deductible_status(plan_meta,plan_type)
            if "provide the cost share" in question.lower():
                question=input+question
            else:
                question=input
            #question=question+"\n List all possible relevant benefits."
            
            
            
            if plan_type=="HMO":                
                template_key="non_deductible_zero" if result else "zero_deductible" 
            elif plan_type=="PPO":               
                template_key = result["template_key"]
            
            try:
                from pathlib import Path
              

                BASE_DIR = Path(__file__).resolve().parent.parent
                #print(BASE_DIR)
                json_path = BASE_DIR / "templates" /f"{scripting_key.lower()}_template.json"
                #with open(f"{scripting_key.lower()}_template.json", "r") as f:
                with open(json_path, "r") as f:
                    #tool_config = json.load(f)
                
                    scripting_format = json.dumps(json.load(f), indent=4)
                #scripting_format=scripting_format.replace("The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.","The service applies to the plan's out-of-pocket maximum amount of $17,500, not to exceed $35,000 per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.")
                #print(type(scripting_format))
                scripting_format=json.loads(scripting_format)
             
                
                scripting_format=scripting_format[plan_type][template_key]
                #print(scripting_format)
                
                
                if plan_type=="PPO":        
                    oopm_lines = extract_oopm_lines(plan_meta)
                    
                    provider_lines = {
                        item["provider_type"].lower().replace(" ", "_"): item["line"]
                        for item in oopm_lines
                    }
                    #print(provider_lines['participating_provider'])
                  
                    
                    
                    cost_share=add_template_hints_from_template_key(cost_share,result,provider_lines)
                    
                  
                    #print("cost_share",cost_share)
                
               
                plan_meta=summarize_plan_cost_shares_plain_english(plan_meta)
                
                # Convert exclusion list to string before appending clarification
                exclusion_str = json.dumps(exclusion) if isinstance(exclusion, list) else str(exclusion)
                exclusion_str = exclusion_str + "\n\n**CRITICAL CLARIFICATION FOR PRESCRIPTION/MEDICATION QUESTIONS:**\n\nWhen a user asks about coverage for a specific medication or drug by name (e.g., 'What is the coverage for Acetaminophen?', 'Is Tylenol covered?'), you MUST check if there are pharmacy tier benefits (Tier 1, 2, 3, 4) in the plan data.\n\nIF pharmacy tier benefits exist:\n- DO NOT treat the medication as excluded, even if it appears in the OTC (over-the-counter) exclusion list\n- The OTC exclusion (#7) only applies when purchasing the medication over-the-counter WITHOUT a prescription\n- When prescribed by a physician and filled through pharmacy benefits, the medication IS covered under the appropriate tier\n- Provide coverage details for ALL tiers (Tier 1, Tier 2, Tier 3, Tier 4) across ALL service types (Retail Pharmacy 30-day, Retail 90-Day, Mail Order Service 90-day)\n\nIF no pharmacy tier benefits exist in the plan:\n- Then and only then should you treat OTC medications as excluded per exclusion #7\n\nThis rule takes precedence over the OTC exclusion for prescription/medication questions."
                #print("plan meta summary",plan_meta)
                data = {
                    "plan_data": plan_meta,
                    "benefits": cost_share,
                    "exclusion": exclusion_str,
                }
            except Exception as e:
                print(e)
                return (
                    "We are unable to find relevant benefit details in the current plan "
                    "data to answer this question accurately."
                )
           
            
          
            if plan_type == "HMO" and "access+" not in plan_name.lower():
                
                prompt = generate_hmo_prompt(
                    question, plan_type, data, scripting_format
                )
            elif plan_type == "HMO" and "access+" in plan_name.lower():              
                prompt = generate_hmo_access_prompt(
                    question, plan_type, plan_name, data, scripting_format
                )
            else:  # PPO
                
               
                prompt = generate_ppo_prompt(
                    question, plan_type, data, scripting_format
                )
            
            #print("prompt time",end-start)
            """
            if "infertility treatment" in question.lower() :
                #Keywords extarcts start here
                maxt_limit_text=""
                keywords = ["limit", "bscMax"]

                maxt_limit_text=extract_benefit_info_multi(data, keywords)
                
                if maxt_limit_text is not None and maxt_limit_text !='':
                    prompt_ex=exclusive_check_prompt("max_limit_text",maxt_limit_text, prompt)
                    prompt=prompt+prompt_ex
                #Keywords extarcts end  here
            """
          
           

      
            #if ("prescription" in question.lower() or "prescribed" in question.lower()) and "mail" not in question.lower() and "retail" not in question.lower():
             #   prompt=prompt+"\n"+tier_prompt
         
            question=input+question
                

            prompt = prompt+"\n"+history_prompt   
            crid = f"{uid}|{sid}|{question_id}"
            client = mlflow.deployments.get_deploy_client("databricks")
            response = client.predict(
                            endpoint=LLM_ENDPOINT_PRIMARY,
                            inputs={
                                "client_request_id": crid,
                                "messages": [
                                    {"role": "user", "content": prompt}
                                ],
                                "reasoning_effort":"low"  # Set your desired temperature here
                            },
                        )
            
            final_llm_response=response["choices"][0]["message"]["content"]
            final_llm_response=remove_copayment_line(final_llm_response)
            if plan_type!="PPO":
                
      
                referral_line = decide_referral(question, final_llm_response,plan_type,plan_name)
                
                #print("referral time",end-start)
            
                if referral_line:
                    #referral_line=decide_referral_with_llm(question, answer_text, client, LLM_ENDPOINT_PRIMARY, crid)
                    final_llm_response = f"{final_llm_response.rstrip()}\n\n{referral_line}"
            
            # ---- SPECIAL CASE APPEND ----
            special_note = get_special_case_text(
                answer_text=final_llm_response,
                question=question,
                client=client,
                LLM_ENDPOINT=LLM_ENDPOINT_SECONDARY,
                uid=uid,
                sid=sid,
                qid=question_id,
                plan_type=plan_type
            )
            
         

            if special_note:
                final_llm_response = f"{final_llm_response}\n\n{special_note}"
             
          
            
            if "$X" in final_llm_response or "[$X]" in final_llm_response or "The plan has a deductible per person, not to exceed per family." in final_llm_response:
                #print(final_llm_response)
                raise RuntimeError("Template hallucination — retrying LLM generation.")


            #print("final_llm_response",final_llm_response)
            #if "emergency" in question.lower() or "ambulance" in final_llm_response.lower() :
                #final_llm_response=remove_out_of_network_sections_preserve_note(final_llm_response)
            if "over the counter" in question.lower():
                final_llm_response="Over-the-counter medications are generally not covered under your current policy. According to the plan's exclusions, drugs that are available without a prescription (over-the-counter) are excluded, including drugs for which there is an over-the-counter drug that has the same active ingredient and dosage as the prescription drug. \nHowever, this exclusion does not apply to over-the-counter drugs with a United States Preventive Services Task Force (USPSTF) rating of A or B when prescribed by a physician or to over-the-counter contraceptive drugs and devices."
            
          
            final_llm_response =clean_encoding_artifacts(final_llm_response)
            

          
            BASE_DIR = Path(__file__).resolve().parent.parent
            json_path = BASE_DIR/ "templates" /"generic_template.json"
            with open(json_path, "r") as f:
              generic_template = json.load(f)
            generic_line = generic_template[plan_type]
            print("generic_line",generic_line)
            print("plan_type",plan_type)
            

            # Prepend HMO generic line unless emergency/not-covered
            if (
                "HMO" in plan_type
                and "emergency" not in question.lower()
                and "the service you are requesting is either not a benefit" not in final_llm_response.lower()
                and "exclusion under your current policy" not in final_llm_response.lower()
                and "not covered under your current policy" not in final_llm_response.lower()
                and "A." in final_llm_response
                and "I’m here to help with topics related to health plan benefits. Could you please ask something related to these topics?" not in final_llm_response
            ):
                final_answer = f"Plan: {plan_name}\n\n{generic_line}\n\n{final_llm_response}"
            else:
                final_answer = f"Plan: {plan_name}\n\n{final_llm_response}"

            #return json.dumps({"answer": final_answer})
            

            if plan_type=="PPO":
                try:
                    final_answer = replacer.replace_limit_text_section(final_answer)
                    final_answer = replacer.replace_bsc_max_text_section(final_answer)
                except Exception:
                    pass

            content = str(final_answer)
            chat_obj.save_chat_history(question,content,question_id,user_id=uid,session_id=sid)
            final_answer=final_answer.replace("Your pharmacy benefits vary by tier (e.g., Generic, Preferred Brand, Non-Preferred Brand, Specialty). [Display member cost share per tier and any pharmacy-specific out-of-pocket maximum or caps.]","")

            return final_answer
        

        # ----- Fallback if intent missing or unsupported -----
        return (
            "Sorry, I couldn't determine how to answer this with the provided intent. "
            "Please try rephrasing your question."
        )