import json
import uuid
import yaml
import psycopg,sys,os
from datetime import datetime
from tool_desc.core.config_store import ConfigStore
from databricks.sdk import WorkspaceClient

class ChatHistoryManager:
    def __init__(self):
        self.w = WorkspaceClient()
        self.instance = ConfigStore.get("instance")
        self.limit = ConfigStore.get("fetch_chat_history_limit")
        self.user_name = self.w.current_user.me().user_name
        self.db_name = "databricks_postgres"
        self.sslmode = "require"
    
    def _conn(self, autocommit=False):
        cred = self.w.database.generate_database_credential(
            request_id=str(uuid.uuid4()), instance_names=[self.instance]
        )
        host = self.w.database.get_database_instance(name=self.instance).read_write_dns
        return psycopg.connect(
            host=host,
            port=5432,
            dbname=self.db_name,
            user=self.user_name,
            password=cred.token,
            sslmode=self.sslmode,
            connect_timeout=10,
            autocommit=autocommit,
        )

    def insert_chat_history(self, session_id, user_id, question_id, insert_timestamp, qa_pairs):
        conn = self._conn()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO chat_history (session_id, user_id, question_id, insert_timestamp, qa_pairs)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (session_id, user_id, question_id, insert_timestamp, qa_pairs)
        )
        conn.commit()
        cur.close()
        conn.close()

    def save_chat_history(self, question, answer, question_id, session_id, user_id):
        qa_pairs = json.dumps({"question": question, "answer": answer})
        insert_timestamp = datetime.now()
        self.insert_chat_history(session_id, user_id, question_id, insert_timestamp, qa_pairs)

    def fetch_chat_history(self,user_id: str, session_id: str,) -> list:
        conn = self._conn()
        cursor = conn.cursor()
        cursor.execute(
            f"""
            SELECT qa_pairs FROM chat_history
            WHERE user_id = %s
            AND session_id = %s
            ORDER BY insert_timestamp DESC
            LIMIT {self.limit}
            """,
            (user_id, session_id)
        )
        chat_history = cursor.fetchall()
        cursor.close()
        conn.close()
        return chat_history