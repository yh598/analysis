import re
class PlanTextReplacer:
    def __init__(self):
        self.limit_keys = [
            r"Up to\s*\d+\s*days",
            r"Up to\s*\d+\s*visits",
            "per year",
            "per lifetime"
        ]

    def replace_limit_text_section(self, result):
        try:
            if re.search(r"This plan has a limit of", result):
                return result
            pattern = r'([^.]*(' + "|".join(self.limit_keys) + r')[^.]*\.)'
            def repl(match):
                return f'This plan has a limit of-{match.group(1)}'
            result = re.sub(pattern, repl, result)
            return result
        except Exception as e:
            print(f"Error in replace_limit_section: {e}")
            return result

    def replace_bsc_max_text_section(self, result):
        try:
            pattern = r"(Up to[^.]*\$\d+[^.]*\.)"
            def repl(match):
                return f'This plan has maximum payable of-{match.group(1)}'
            result = re.sub(pattern, repl, result)
            return result
        except Exception as e:
            print(f"Error in replace_bsc_max_section: {e}")
            return result