import re
from typing import Dict, List, Tuple
import re
from rouge_score import rouge_scorer


class BenefitTemplateComparator:
    # Matches: "a. Emergency transport - air"
    SUBSECTION_HEADER = re.compile(
        r"^\s*([a-z])\.\s*(.+?)\s*$",
        re.IGNORECASE | re.MULTILINE,
    )

    PROVIDER_BLOCK = re.compile(
        r"(In-network Provider:|Out-of-network Provider:)\s*"
        r"(.*?)"
        r"(?=(?:In-network Provider:|Out-of-network Provider:|^\s*[a-z]\.\s+|\Z))",
        re.DOTALL | re.IGNORECASE | re.MULTILINE,
    )

    OOPM_PREFIX = "the service applies"

    def __init__(self, ground_truth: str, expected_response: str):
        self.gt = self._extract_by_title(ground_truth)
        self.exp = self._extract_by_title(expected_response)

    # ---------- Helpers ----------

    @staticmethod
    def _norm(s: str) -> str:
        return re.sub(r"\s+", " ", s).strip()

    @staticmethod
    def _provider_key(label: str) -> str:
        return "In-network" if "in-network" in label.lower() else "Out-of-network"

    def _meaningful_lines(self, block: str) -> List[str]:
        lines = []
        for ln in block.splitlines():
            x = self._norm(ln)
            if x:
                lines.append(x)
        return lines

    # ---------- Core Extraction (order-independent) ----------

    def _extract_by_title(
        self, text: str
    ) -> Dict[Tuple[str, str], Dict[str, str]]:
        """
        Key: (subsection_title_lower, provider)
        Value: {deductible, cost_share, oopm}
        """
        out = {}

        headers = [
            (m.start(), m.end(), self._norm(m.group(2)).lower())
            for m in self.SUBSECTION_HEADER.finditer(text)
        ]

        for i, (_, header_end, title) in enumerate(headers):
            body_end = headers[i + 1][0] if i + 1 < len(headers) else len(text)
            subsection_body = text[header_end:body_end]

            for provider_label, provider_text in self.PROVIDER_BLOCK.findall(subsection_body):
                provider = self._provider_key(provider_label)
                lines = self._meaningful_lines(provider_text)

                deductible = lines[0] if len(lines) >= 1 else ""
                cost_share = lines[1] if len(lines) >= 2 else ""

                oopm = ""
                for ln in lines:
                    if ln.lower().startswith(self.OOPM_PREFIX):
                        oopm = ln
                        break

                out[(title, provider)] = {
                    "deductible": deductible,
                    "cost_share": cost_share,
                    "oopm": oopm,
                }

        return out

    # ---------- Public Checks ----------

    def deductible_check(self) -> Tuple[bool, List[str]]:
        """
        Returns:
          (passed, matching_titles)
        """
        failed = []
        matched = []

        common_keys = set(self.gt.keys()) & set(self.exp.keys())
        for (title, provider) in common_keys:
            if self.gt[(title, provider)]["deductible"].lower() == \
               self.exp[(title, provider)]["deductible"].lower():
                matched.append(title)
            else:
                failed.append(title)

        return "yes" if len(failed) == 0 else "no", sorted(set(matched))

    def cost_share_check(self) -> Tuple[bool, List[str]]:
        failed = []
        matched = []

        common_keys = set(self.gt.keys()) & set(self.exp.keys())
        for (title, provider) in common_keys:
            if self.gt[(title, provider)]["cost_share"].lower() == \
               self.exp[(title, provider)]["cost_share"].lower():
                matched.append(title)
            else:
                failed.append(title)

        return "yes" if len(failed) == 0 else "no", sorted(set(matched))

    def oopm_check(self) -> Tuple[bool, List[str]]:
        """
        Rules:
        - If GT has OOPM and Expected does NOT → fail
        - If both have OOPM → must match
        - If GT does NOT have OOPM → pass
        """
        failed = []
        matched = []

        common_keys = set(self.gt.keys()) & set(self.exp.keys())
        for (title, provider) in common_keys:
            gt_oopm = self.gt[(title, provider)]["oopm"]
            exp_oopm = self.exp[(title, provider)]["oopm"]

            if gt_oopm:
                if not exp_oopm or gt_oopm.lower() != exp_oopm.lower():
                    failed.append(title)
                else:
                    matched.append(title)
            else:
                matched.append(title)

        return "yes" if len(failed) == 0 else "no", sorted(set(matched))
    


class TemplateEvaluator:
    WORD_PATTERN = re.compile(r"\w+", re.UNICODE)

    WEIGHTS = {
        "phone": 10,
        "url": 10,
        "deductible": 30,
        "cost_share": 30,
        "oopm": 20,
    }

    @staticmethod
    def tokenize(text: str):
        if not isinstance(text, str):
            return []
        return TemplateEvaluator.WORD_PATTERN.findall(text.lower())

    @staticmethod
    def f1_overlap(pred: str, truth: str) -> float:
        pred_tokens = TemplateEvaluator.tokenize(pred)
        truth_tokens = TemplateEvaluator.tokenize(truth)

        if not pred_tokens or not truth_tokens:
            return 0.0

        pred_set = set(pred_tokens)
        truth_set = set(truth_tokens)

        common = len(pred_set & truth_set)
        if common == 0:
            return 0.0

        precision = common / len(pred_set)
        recall = common / len(truth_set)

        if precision + recall == 0:
            return 0.0
        return 2 * precision * recall / (precision + recall)

    @staticmethod
    def lcs_length(a, b):
        dp = [[0]*(len(b)+1) for _ in range(len(a)+1)]
        for i in range(1, len(a)+1):
            for j in range(1, len(b)+1):
                if a[i-1] == b[j-1]:
                    dp[i][j] = dp[i-1][j-1] + 1
                else:
                    dp[i][j] = max(dp[i-1][j], dp[i][j-1])
        return dp[-1][-1]

    @staticmethod
    def rouge_l(pred: str, ref: str) -> float:
        scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)
        if not pred or not ref:
            return 0.0
        score = scorer.score(ref, pred)
        return score["rougeL"].fmeasure

    @staticmethod
    def phone_number_match(response: str, expected_response: str):
        def extract_phone(text):
            digits = re.sub(r'\D', '', str(text))
            return digits if 7 <= len(digits) <= 15 else None
        phone1 = extract_phone(response)
        phone2 = extract_phone(expected_response)
        if phone2:
            return "yes" if phone1 and phone2 and phone1 == phone2 else "no"
        elif not phone1 and not phone2:
            return "yes"

    @staticmethod
    def url_match(response: str, expected_response: str):
        def extract_urls(text):
            return set(re.findall(r'https?://[^\s,;]+', str(text)))
        urls_pred = extract_urls(response)
        urls_gt = extract_urls(expected_response)
        if not urls_gt:
            return "yes" if not urls_pred else "no"
        if len(urls_pred & urls_gt) / len(urls_gt) == 1:
            return "yes"
        else:
            return "no"

    @staticmethod
    def derive_template_accuracy(
        phone_ok: bool,
        url_ok: bool,
        deductible_ok: bool,
        cost_share_ok: bool,
        oopm_ok: bool,
    ):
        checks = {
            "phone": phone_ok,
            "url": url_ok,
            "deductible": deductible_ok,
            "cost_share": cost_share_ok,
            "oopm": oopm_ok,
        }

        score = sum(
            TemplateEvaluator.WEIGHTS[k] for k, passed in checks.items() if passed
        )

        if score == 100:
            verdict = "Pass"
        elif score >= 80 and deductible_ok and cost_share_ok:
            verdict = "Needs Review"
        elif score >= 50:
            verdict = "Action Required"
        else:
            verdict = "Fail"

        return {
            "score": score,
            "verdict": verdict
        }

