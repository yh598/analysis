PPO_RAW_SPECIAL_CASES= [
    (
        "Emergency",
        "Emergency Services are covered at the Participating Provider Cost Share, even if when treatment is received from a Non-Participating Provider. If a patient is admitted to an Out of Network (OON) or Non-Participating hospital, the In Network benefits would apply until their condition stabilizes and they're able to be transferred to an In Network hospital."
    ),
	(
	    
        "Emergency Room",
        "Emergency Services are covered at the Participating Provider Cost Share, even if when treatment is received from a Non-Participating Provider. If a patient is admitted to an Out of Network (OON) or Non-Participating hospital, the In Network benefits would apply until their condition stabilizes and they're able to be transferred to an In Network hospital.In addition to the Emergency room bill, the patient can expect related professional costs like services provided from a pathologist or radiologist."
	
	),
    (
        "Accupuncture or Chiropractic or Therapeutic Massage",
        "Discounts for (service) treatments are available through the ChooseHealthy program provided by American Speciatly Health Group. (Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy website to locate a particpating provider and learn more about what's included in this program)."
    ),
    (
        "Annual Physical",
        "Your medical group or IPA may limit routine physical exams using a rolling 12-month schedule. Check with your PCP/IPA for exact timing."
    ),
    (
        "In Patient Facility / Hospital",
        "The facility must contact Medical Care Solutions (MCS) within 5 days of a scheduled admission or within 24 hours of an emergent admission at 1 (800) 541-6652 (say 'Authorizations'). In addition to the hospital bill, members may receive separate professional bills for surgery, anesthesia, radiology, pathology, or laboratory services."
    ),
		
    (
        "Out Patient Facility / Hospital",
        "Besides the facility bill, you may also see separate professional charges for anesthesia and diagnostic testing (radiology or laboratory)."
    ),

    (
        "Physical Therapy",
        "Blue Shield of California offers physical therapy (PT) programs.  (Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy to learn more)."
    ),
  

    (
        "Urgent Care",
        "In addition to the urgent care center bill, the patient can expect related fees for services like diagnostic testing (radiology or laboratory). "
    ),
    (
        "Hearing Aids",
        "A discount program is available from EPIC Hearing Healthcare.  (Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy/hearing-aid-discount learn more)."
    ),
    (
        "Fitness, gym and exercise",
        "Blue Shield of California offers gym membership discount programs and digital fitness programs. (Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy to learn more)."
    ),
    (
        "Pediatric Vision",
         "Benefits are available for pediatric vision services from ophthalmologists, optometrists, and opticians.A discount vision program is available to Blue Shield members. (Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy to learn more)."
    ),
	( 
	   "Pharmacy or Prescription drugs or medicines",
	   "Your pharmacy benefits vary by tier (e.g., Generic, Preferred Brand, Non-Preferred Brand, Specialty). (Display member cost share per tier and any pharmacy-specific out-of-pocket maximum or caps.)"
	),
     ( 
	   "surgery or Tubal Ligation",
	   "In addition to the surgeon's bill, the patient can expect related fees for services like anesthesia, and diagnostic testing (radiological, pathology, or laboratory). A surgical package includes the surgical procedure, pre-operative care medical visits on the same day of surgery and normal uncomplicated follow-up care."
	)
 
     
		
]
HMO_RAW_SPECIAL_CASES = [
    (
        "Emergency or Ambulance Service",
        "Emergency Services are covered at the Participating Provider Cost Share, even when treatment is received from a Non-Participating Provider. "
        "If a patient is admitted to an Out-of-Network (OON) or Non-Participating hospital, the in-network benefits apply until their condition "
        "stabilizes and they are able to be transferred to an in-network hospital."
    ),
    (
        "Emergency Room",
        "Emergency Services are covered at the Participating Provider Cost Share, even if when treatment is received from a Non-Participating Provider. If a patient is admitted to an Out of Network (OON) or Non-Participating hospital, the In Network benefits would apply until their condition stabilizes and they're able to be transferred to an In Network hospital.In addition to the emergency room bill, the patient can expect related professional costs such as services provided by a pathologist or radiologist."
    ),
    (
        "Accupuncture or Chiropractic or Therapeutic Massage",
        "Discounts for [service] treatments are available through the ChooseHealthy program provided by American Specialty Health Group. "
        "(Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy to locate a participating provider and learn more about what's included in this program)."
    ),
    (
        "Annual Physical",
        "Your medical group or IPA may limit routine physical exams using a rolling 12-month schedule. Check with your PCP/IPA for exact timing."
    ),
    (
        "In Patient Facility / Hospital",
        "The facility must contact Medical Care Solutions (MCS) within 5 days of a scheduled admission or within 24 hours of an emergent admission at 1 (800) 541-6652 (say 'Authorizations'). "
        "In addition to the hospital bill, members may receive separate professional bills for surgery, anesthesia, radiology, pathology, or laboratory services."
    ),
    (
        "Out Patient Facility / Hospital",
        "Besides the facility bill, you may also see separate professional charges for anesthesia and diagnostic testing (radiology or laboratory)."
    ),
    (
        "Physical Therapy",
        "Blue Shield of California offers physical therapy (PT) programs. (Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy to learn more)."
    ),
 
    (
        "Urgent Care",
        "If you need to visit an urgent care center and you are in your Medical Group Service Area, go to the urgent care center designated by your Medical Group or call your PCP. "
        "If you are outside of your Medical Group Service Area but within California and need urgent care, you may visit any urgent care center near you."
    ),
    (
        "Hearing Aids",
        "A discount program is available from EPIC Hearing Healthcare. (Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy/hearing-aid-discount to learn more)."
    ),
    (
        "Fitness, gym and exercise",
        "Blue Shield of California offers gym membership discount programs and digital fitness programs. "
        "(Refer to https://blueshieldca.com/en/home/be-well/live-healthy to learn more)."
    ),
    (
        "Pediatric Vision",
        "Benefits are available for pediatric vision services from ophthalmologists, optometrists, and opticians.A discount vision program is available to Blue Shield members. (Refer to https://www.blueshieldca.com/en/home/be-well/live-healthy to learn more)."
    ),
    (
        "Pharmacy or Prescription drugs or medicines",
        "Your pharmacy benefits vary by tier (e.g., Generic, Preferred Brand, Non-Preferred Brand, Specialty). "
        "[Display member cost share per tier and any pharmacy-specific out-of-pocket maximum or caps.]"
    ),
    ( 
	   "surgery or Tubal Ligation",
	   "In addition to the surgeon's bill, the patient can expect related fees for services like anesthesia, and diagnostic testing (radiological, pathology, or laboratory). A surgical package includes the surgical procedure, pre-operative care medical visits on the same day of surgery and normal uncomplicated follow-up care."
	)
]

import re
from typing import List, Dict

def _split_keywords(label: str) -> List[str]:
    # Split label into atomic keywords
    parts = re.split(r"\s+or\s+|/|,\s*|\s+and\s+", label, flags=re.IGNORECASE)
    return [p.strip() for p in parts if p.strip()]



def extract_benefit_headings(answer_text: str) -> List[str]:
    """
    Extract headings like:
      'A. Chiropractic Services' -> 'Chiropractic Services'
      'B. Physical Therapy'
    Returns a list of heading strings.
    """
    if not answer_text:
        return []

    headings: List[str] = []

    # Pattern 1: "A. Something"
    for m in re.finditer(r"^[A-Z]\.\s*(.+)$", answer_text, flags=re.MULTILINE):
        h = m.group(1).strip()
        if h:
            headings.append(h)

    # If none found, try text before 'In-network Provider'
    if not headings:
        m = re.search(
            r"^(.*?)\s*(?:In[- ]network Provider|In Network Provider)",
            answer_text,
            flags=re.IGNORECASE | re.MULTILINE | re.DOTALL,
        )
        if m:
            chunk = m.group(1).strip()
            if chunk:
                first_line = chunk.splitlines()[0].strip()
                if first_line:
                    headings.append(first_line)

    # Fallback: first non-empty line
    if not headings:
        for line in answer_text.splitlines():
            line = line.strip()
            if line:
                headings.append(line)
                break

    # De-dup
    seen = set()
    out = []
    for h in headings:
        if h not in seen:
            seen.add(h)
            out.append(h)
    return out


try:
    from rapidfuzz import fuzz
except ImportError:
    fuzz = None

def _best_special_case_match(
    headings: List[str],
    question: str,
    special_cases: List[Dict],
    fuzzy_threshold: int = 90,
) -> Dict:
    if not headings and not question:
        print("No headings or question provided. Returning empty dict.")
        return {}

    haystack = " ".join(headings + [question]).lower()

    best_case = {}
    best_score = 0
    print("in special cases")
    for sc in special_cases:
        for kw in sc["keywords"]:
            kw_lower = kw.lower()
           

            if fuzz:
                score = fuzz.partial_ratio(kw_lower, haystack)
                print(kw_lower,haystack)
                if score > best_score:
                    best_score = score
                    best_case = sc
                    print("best_score in special case", best_score)
                    print("fuzzy_threshold", fuzzy_threshold)
    print("best_score in final special case", best_score)
    if best_score >= fuzzy_threshold:
        print("Fuzzy match found:", best_case)
        return best_case
    print("No special case matched. Returning empty dict.")
    return {}

def llm_choose_special_case(
    answer: List[str],
    question: str,
    special_cases: List[Dict],
    client,
    LLM_ENDPOINT: str,
    uid: str,
    sid: str,
    qid: str,
) -> Dict:
    """
    Ask LLM: given headings + question + candidate labels,
    which ONE label (if any) applies? Returns special_case dict or {}.
    """
    print("in llm special case")
    labels_block = "\n".join(
        [f"- {sc['label']}: {', '.join(sc['keywords'])}" for sc in special_cases]
    )
    #headings_text = "; ".join(headings) if headings else "None"

    prompt = f"""
You are a classification and answer enhancement assistant.

Given:
- A member's question
- A list of special-case categories (each with a label and keywords)

Your tasks:
1. Analyze the question special-case categories and the answer.
2.From the answer, extract each subsection/subheader or benefit indexed as a'a. to z.' and their corresponding text.
3. For each benefit found in step2, determine if it matches any of the special-case categories based on the keywords.For e.g if outpatient facility is there in answer or beneft, add the special case text of label outpatient facility in response. similary, chirpractice will only be added if question is about chiropractic services.
2. Decide if exactly any of these labels clearly fits the question/benefit. If none clearly fits, return: NONE.
3. Consider the context and urgency described in the question. If the question describes a situation that is urgent, severe, or requires immediate medical attention (such as a broken bone, severe injury, or sudden illness), classify it as "Emergency" even if the word "emergency" is not explicitly mentioned.
4. If a label is selected, append the corresponding special-case text (provided below for each label) to the end of the main answer, separated by a blank line.
5. Do not add the label in response..Output exactly the matching special-case text and replace the [service] if present with service name from the question.Do not give any explaination.
6. If the  matching special-case text is already present in answer, do not add it again,only add if any line is miising otherwise return empty string.
7.Do not add label in the response.

Special-case categories (label: keywords):
{labels_block}

Special-case texts:
{chr(10).join([f"{sc['label']}: {sc['text']}" for sc in special_cases])}

Question:
{question}

Answer:
{answer}

Output:
Return the final answer as follows:
- If a special-case label is selected, return the only the special-case text for that label, separated by a blank line.
- If NONE, return the empty string.
"""

    crid = f"{uid}|{sid}|{qid}|special_case"
    resp = client.predict(
        endpoint=LLM_ENDPOINT,
        inputs={
            "client_request_id": crid,
            "messages": [{"role": "user", "content": prompt}],
            "temperature":0,
        },
    )
    
    label = resp["choices"][0]["message"]["content"].strip()
    print("response",label)

    if label:
        return label

    

    return {}

def get_special_case_text(
    answer_text: str,
    question: str,
    client,
    LLM_ENDPOINT: str,
    uid: str,
    sid: str,
    qid: str,
    plan_type:str
) -> str:
    """
    1) Extract benefit headings from answer
    2) Try keyword/fuzzy match
    3) If no match, use LLM to pick label
    4) Return special-case paragraph ('' if none)
    """
    #headings = extract_benefit_headings(answer_text)
    SPECIAL_CASES: List[Dict] = []
    RAW_SPECIAL_CASES= PPO_RAW_SPECIAL_CASES if plan_type=="PPO" else HMO_RAW_SPECIAL_CASES
    for label, text in RAW_SPECIAL_CASES:
        SPECIAL_CASES.append(
            {
                "label": label,
                "keywords": _split_keywords(label),
                "text": text,
            }
        )

    # 1) Deterministic / fuzzy
    sc=""
    if not sc:
        # 2) LLM fallback
        print("in llm fallback")
        sc = llm_choose_special_case(
            answer=answer_text,
            question=question,
            special_cases=SPECIAL_CASES,
            client=client,
            LLM_ENDPOINT=LLM_ENDPOINT,
            uid=uid,
            sid=sid,
            qid=qid,
        )

    if not sc:
        return ""

    text = sc

    # Optional: replace [service] in the text with the main heading, if present
    if "[service]" in text :
        # use first heading; you can make this smarter if needed
        main_heading = headings[0]
        # strip A./B. if still present
        main_heading_clean = re.sub(r"^[A-Z]\.\s*", "", main_heading).strip()
        text = text.replace("[service]", main_heading_clean)
    if text is None or text=="NONE":
        text=""
    

    return text



# --------------------------------
