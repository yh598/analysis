# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore


def extract_bsc_maxtext_block(text):
    text = json.dumps(text)
    # Find the position of "bscMaxInterval"
    if "bscMaxInterval".lower() not in text.lower():
        print("Keyword 'bscMaxInterval' not found in the text.")
        return None
    else:
        print('Keyword "bscMaxInterval" found in the text.')
        bsc_pos = text.find("bscMaxInterval")
        # Find the preceding "[{" before "bscMaxInterval"
        start = text.rfind('[{', 0, bsc_pos)
        if start == -1:
            print("Could not find the starting delimiter '[{' before 'bscMaxInterval'.")
            return None
        # Find the first "}]"" after "bscMaxInterval"
        end = text.find('}]', bsc_pos)
        if end == -1:
            print("Could not find the ending delimiter '}]' after 'bscMaxInterval'.")
            return None
        end += 2  # Include the "}]"
       
        return text[start:end]
    
def exclusive_check_prompt(prompt_key, additional_data, previous_response):
    prompts = {
        "max_text": f"""
You are a Health Insurance Agent. Your task is to enhance the provided answer by adding a concise, user-friendly summary of the 'providerCostShares' information.

Instructions:
- Do not repeat or restate details already present in the original answer.
- Do not add a new section or heading.
- Instead, add 1-2 sentences at the end of the original answer that clearly explain, in plain language, what the 'providerCostShares' mean for the user.But don't include the keywork 'providerCostShares', it just for you to get the context.
- Focus on the practical impact for the user (e.g., what they will pay, what is covered, any important limits).
- Do not include raw JSON, code, or bullet points; use only plain text.
- The summary should blend naturally with the original answer and help the user understand the main takeaway.

Inputs:
- Original Answer:
{previous_response}

- Raw providerCostShares text:
{additional_data}

Return the improved answer with the summary appended at the end, making sure it reads as a natural conclusion to the original answer.
"""
    }
    return prompts[prompt_key]

def safe_json_loads(value):
    """Safely load nested/double-encoded JSON until we get a dict or list."""
    try:
        while isinstance(value, str) and value.strip().startswith(("{", "[")):
            value = json.loads(value)
        return value
    except Exception:
        return value

def check_bluecard_program(data):
    """
    Checks if 'BlueCard Program' is included (isIncluded=True)
    from mixed nested JSON / string input structures.
    """
    # Ensure we can iterate over dicts, even if input is a JSON string
    parsed_data = safe_json_loads(data)
    if not isinstance(parsed_data, list):
        print("Input is not a list after parsing.")
        return False

    for entry in parsed_data:
        # Ensure each entry is a dict
        entry = safe_json_loads(entry)
        if not isinstance(entry, dict):
            continue

        val = entry.get("combined_eoc_program_categories")
        val = safe_json_loads(val)
        if not isinstance(val, dict):
            continue

        programs = val.get("eoc_program_categories_programs", [])
        for p in programs:
            if p.get("name", "").strip().lower() == "bluecard program":
                return bool(p.get("isIncluded", False))
    return False


def generate_ppo_prompt(question, plan_type, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse excluded;skilled home health covered”).

   c. Pure exclusion.
      If no benefit is found and an exclusion clearly matches, return exactly:
      “The [service] you are requesting is an exclusion under your current policy.”

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.

    If not excluded,** continue with the standard template-based generation**.
1. Always refer in network and out network separately from the template for the spcific service.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.
4. Use clear, simple language suitable for users with no technical background.
5. If the query involves multiple service types or settings e.g., (standalone vs. hospital),(outpatient radiology center vs outpatient department of hospital) or facility vs. physician, write a separate breakdown for Participating and Non-Participating providers.
6. For each service setting, provide a separate section.e.g., (freestanding vs. hospital urgent care),(outpatient radiology center vs outpatient department of hospital))
7.Analyze the question intelligently and answer it.For e.g (if the question asks Telehealth consultation, also looks for teladoc service as well.)
8.Do not collapse or omit variants that share the same broad category.  
  – If several distinct “flavors” of the benefit exist (e.g., standard vs. non-standard contact lenses, elective vs. medically-necessary lenses, fitting vs. supply, professional vs. facility, hospital vs. freestanding), treat each as its own **separate section** in the response.  
  – Use the exact wording from `benefit_header` or `description` to craft clear section titles, so the user can see every covered option.  
  – Letter the sections A., B., C.… in the order they appear in the data.  
  – **Never stop after the first matching benefit** if additional variants remain in the same data block.
9.Always follow the template while answering.
10.Deductible Rule:For each benefit, strictly **determine separately for In-network and Out-of-network** from the template(refer ppo_in and ppo_out separately).From the scripting, choose the correct template for the service and strictly fill the values accordingly.Do not keep the "[$X]" placeholder" in your answer.
11. If the service is not an exclusion in the plan,Try to frame the response in natural language as well by analyzing the question. For e.g:for question Do I need to have a Primary Care Physician?, answer could be yes/no followed by a short text. Notes or additional information should be at the end of the repsonse.
12.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.


</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure:

A. [Service Setting] (e.g., Hospital-Based Urgent Care)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) if any and any additional information]
IMPORTANT:1.If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.
          2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

B. [Service Setting] (e.g., Services Outside Your Physician’s Service Area)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.
          
2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT:1.If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.
          2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

At the very end, add the content from special cases and include only those entries from SpecialCases whose guardrails match the current query/context; if none match, omit this section.Do not print the title “Special Cases (if applicable)” — just append the matching special case text naturally at the end for coverage and exclusions as well.
Only plain text / Markdown. No JSON, no placeholders.
</RESPONSE FORMAT>
"""




def generate_hmo_prompt(question, plan_type, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse excluded;skilled home health covered”).

   c. Pure exclusion.
      If no benefit is found and an exclusion clearly matches, return exactly:
      “[Service name]\nThe [service] you are requesting is an exclusion under your current policy.This means that the patient would be responsible for 100% of the billed amount.”

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.

    If not excluded,** continue with the standard template-based generation**.
1. Answer only the specific user query. Do not include assumptions or external information.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.
4. Use clear, simple language suitable for users with no technical background.
5. If the query involves multiple service types or settings e.g., (standalone vs. hospital),(outpatient radiology center vs outpatient department of hospital) or facility vs. physician, write a separate breakdown for Participating and Non-Participating providers.
6. For each service setting, provide a separate section.e.g., (freestanding vs. hospital urgent care),(outpatient radiology center vs outpatient department of hospital),(Emergency Room Visit vs Emergency Room Physician Services vs Emergency Room Services Resulting in Admission))
7.Analyze the question intelligently and answer it.For e.g (if the question asks Telehealth consultation,provide the answer for both Teladoc and Teleconsultation service as well.),(for specialist visit, include trio-specialist visit as well)
8.Do not collapse or omit variants that share the same broad category.  
  – If several distinct “flavors” of the benefit exist (e.g., standard vs. non-standard contact lenses, elective vs. medically-necessary lenses, fitting vs. supply, professional vs. facility, hospital vs. freestanding), treat each as its own **separate section** in the response.  
  – Use the exact wording from **`benefit_header` or `description`** to craft clear section titles, so the user can see every covered option.  
  – Letter the sections A., B., C.… in the order they appear in the data.  
  – **Never stop after the first matching benefit** if additional variants remain in the same data block.
9.Always follow the template while answering.
10.Deductible Rule:If plan has deductible and a specific service is not subject to deductible,never say "The Plan does not have deductible" and do not add any out of pocket maximum line.From the scripting, choose the correct template for the service and strictly fill the values accordingly.Do not keep the "[$X]" placeholder" in your answer.
11.Referral rule:
   - append the line “The patient does not need a referral for this service.” strictly and only if the benefit/service clearly belongs to one of these categories:
       • Emergency Services
       • Urgent Services
       • Trio visits
       • OB/GYN services by an obstetrician, gynecologist, or family practice physician within the patient’s Medical Group
       • Office visits with the patient’s Primary Care Physician (PCP)
       • Outpatient Mental Health and Substance Use Disorder services.

   - Do NOT include this line for imaging (e.g., MRI, CT, X-ray), diagnostic tests,Pediatric vision, or specialist visits unless explicitly stated in plan data.
12. If the service is not an exclusion in the plan,Try to frame the response in natural language as well by analyzing the question. For e.g:for question Do I need to have a Primary Care Physician?, answer could be yes/no followed by a short text. Notes or additional information should be at the end of the repsonse.
13.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.


</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure:

A. [Service Setting] (e.g., Hospital-Based Urgent Care)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) if any and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

B. [Service Setting] (e.g., Services Outside Your Physician’s Service Area)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

At the very end, add the content from special cases and include only those entries from SpecialCases whose guardrails match the current query/context/response. for e.g (chiropractor maps to chiropractice); if none match, omit this section.Do not print the title “Special Cases (if applicable)” — just append the matching special case text naturally at the end for coverage and exclusions services as well.
Only plain text / Markdown. No JSON, no placeholders.
</RESPONSE FORMAT>
"""





def generate_hmo_access_prompt(question, plan_type,plan_name, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse excluded;skilled home health covered”).

   c. Pure exclusion.
      If no benefit is found and an exclusion clearly matches, return exactly:
      “The [service] you are requesting is an exclusion under your current policy.”

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.

    If not excluded,** continue with the standard template-based generation**.
1. Answer only the specific user query. Do not include assumptions or external information.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.
4. Use clear, simple language suitable for users with no technical background.
5. If the query involves multiple service types or settings e.g., (standalone vs. hospital),(outpatient radiology center vs outpatient department of hospital) or facility vs. physician, write a separate breakdown for Participating and Non-Participating providers.
6. For each service setting, provide a separate section.e.g., (freestanding vs. hospital urgent care),(outpatient radiology center vs outpatient department of hospital))
7.Analyze the question intelligently and answer it.For e.g (if the question asks Telehealth consultation, also looks for teladoc service as well.)
8.Do not collapse or omit variants that share the same broad category.  
  – If several distinct “flavors” of the benefit exist (e.g., standard vs. non-standard contact lenses, elective vs. medically-necessary lenses, fitting vs. supply, professional vs. facility, hospital vs. freestanding), treat each as its own **separate section** in the response.  
  – Use the exact wording from `benefit_header` or `description` to craft clear section titles, so the user can see every covered option.  
  – Letter the sections A., B., C.… in the order they appear in the data.  
  – **Never stop after the first matching benefit** if additional variants remain in the same data block.
9.Always follow the template while answering.
10.Deductible Rule:If plan has deductible and a specific service is not subject to deductible,never say "The Plan does not have deductible" and do not add any out of pocket maximum line.From the scripting, choose the correct template for the service and strictly fill the values accordingly.Do not keep the "[$X]" placeholder" in your answer.
11.Referral rule:
   - Strictly, append the line “The patient does not need a referral for this service.”if the benefit/service clearly belongs to one of these categories:
       • Emergency Services
       • Urgent Services
       • Trio visits
       • OB/GYN services by an obstetrician, gynecologist, or family practice physician within the patient’s Medical Group
       • Office visits with the patient’s Primary Care Physician (PCP)
       • Outpatient Mental Health and Substance Use Disorder services.

   - Do NOT include this line for imaging (e.g., MRI, CT, X-ray), diagnostic tests,Pediatric vision, or specialist visits unless explicitly stated in plan data.
12.If the service is not an exclusion in the plan,Try to frame the response in natural language as well by analyzing the question. For e.g:for question Do I need to have a Primary Care Physician?, answer could be yes/no followed by a short text. Notes or additional information should be at the end of the repsonse.
13.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.


</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure:

A. [Service Setting] (e.g., Hospital-Based Urgent Care)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) if any and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

B. [Service Setting] (e.g., Services Outside Your Physician’s Service Area)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

At the very end, add the content from special cases and include only those entries from SpecialCases whose guardrails match the current query/context; if none match, omit this section.Do not print the title “Special Cases (if applicable)” — just append the matching special case text naturally at the end for coverage and exclusions as well.
Only plain text / Markdown. No JSON, no placeholders.
</RESPONSE FORMAT>
"""


class GenerateAnswerArgs(BaseModel):
    question: str = Field(..., description="User question")
    plan_meta: str = Field(..., description="Plan-wide metadata (JSON string)")
    plan_type: str = Field(..., description="plan_type")
    plan_name: str = Field(..., description="Plan name")
    uid: str = Field(..., description="Unique user ID")
    sid: str = Field(..., description="Session ID")
    question_id: str = Field(..., description="Unique question ID")
    intent: Optional[list] = None
    exclusion: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Exclusions list (parsed)"
    )
    cost_share: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Benefits list (parsed)"
    )
    def_cost_share: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Definition cost share list (parsed)"
    )
    program_details: Optional[List[Dict[str, Any]]] = Field(default_factory=list, description="Program details list (parsed)"),

  
class GenerateAnswerTool(StructuredTool):
    name: ClassVar[str] = "GeneratePlanAnswer"
    description: ClassVar[str] = "Merge cost-share details, templates, exclusion and plan metadata into final Markdown."
    args_schema: ClassVar[Type[BaseModel]] = GenerateAnswerArgs

    @mlflow.trace(name="GenerateAnswer_run", span_type="tool")
    def _run(
        self,
        question: str,
        plan_meta: str,
        plan_type: str,
        plan_name: str,
        uid:str,
        sid:str,
        question_id:str,
        intent: Optional[list] = None,
        exclusion: Optional[List[Dict[str, Any]]] = None,
        cost_share: Optional[List[Dict[str, Any]]] = None,
        def_cost_share: Optional[List[Dict[str, Any]]] = None,
        program_details:Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        data = {}
        # Safe defaults for optional args
        exclusion = exclusion or []
        env=ConfigStore.get("env")
        LLM_ENDPOINT=ConfigStore.get("LLM_ENDPOINT")
        cost_share = cost_share or []
        def_cost_share = def_cost_share or []

        # ----- Program Categories -----
        if  "ProgramCategories" in intent:
         
            program_categories_json={"ProgramCategories": program_details}
            print(type(program_details))
            print(program_categories_json)

            if plan_type == "HMO":
                prompt = f"""
                You are a Health Plan Program Assistant.

                Use only the provided Program Categories data to answer the user question.

                User Question: {question}  
                data:{program_details}   

                Rules:
                1. Identify if the question matches a program (e.g., “talk to a nurse” → Nurse Advice Line, 24/7 Nurse Line, Nurse Hotline, etc.).
                2. If a matching program exists, summarize:
                • Program name and purpose  
                • How to access (phone/app)  
                • Availability or hours  
                • Cost (if given)
                3. If marked as excluded or not covered, reply exactly:
                “This service is not covered under the plan.”
4. If no matching program exists, reply:
   “This information isn’t available in the provided program data. Please contact Member Services for help.”
5. Use only plain text or simple bullets, no JSON, no placeholders.
"""
               

            elif plan_type == "PPO":
                # Expecting you have the helper defined elsewhere:
                # def check_bluecard_program(program_data_list): -> bool
                is_bluecard = check_bluecard_program(cost_share)
                if is_bluecard:
                    return (
                        "Under the BlueCard® Program, when you receive Out-of-Area Covered Health Care Services within "
                        "the geographic area served by a Host Blue, Blue Shield will remain responsible for the provisions "
                        "of this Agreement. However, the Host Blue is responsible for contracting with and generally handling "
                        "all interactions with its participating healthcare providers, including direct payment to the provider. "
                        "The BlueCard® Program enables you to obtain Out-of-Area Covered Health Care Services, as defined above, "
                        "from a health care provider participating with a Host Blue, where available. The participating health care "
                        "provider will automatically file a claim for the Out-of-Area Covered Health Care Services provided to you."
                    )
                else:
                    return (
                        "This Blue Shield plan provides limited coverage for health care services received outside of the Plan "
                        "Service Area. Out-of-Area Covered Health Care Services are restricted to Emergency Services, Urgent Services, "
                        "and Out-of-Area Follow-up Care. Any other services will not be covered when processed through an Inter-Plan "
                        "Arrangement unless prior authorized by Blue Shield."
                    )

        # ----- Concept/Definition questions -----
        elif "GenericDefinition" in intent:
            data = {
                "plan_data": plan_meta,
                "benefits": def_cost_share or cost_share,
            }

            prompt = f"""
              <ROLE>
              You are a Health Insurance Agent. Explain key insurance terms using only the attached plan and cost-share data.
              When users ask “What is deductible?” or similar, define the term clearly and describe how it appears in this plan.
              </ROLE>

              <INSTRUCTION>
              User question: {question}

              Use this information:
              data = {data}
              Rely only on the given plan details — no external definitions.
              </INSTRUCTION>

              <GUIDELINES>
              • Start with a short, plain-language definition.
              • Then in next line add how it applies in this plan (values, tiers, limits, etc.).

              </GUIDELINES>

              <RESPONSE FORMAT>
              Write one short paragraph combining the definition and plan-specific explanation in natural language.
              </RESPONSE FORMAT>
              """
            crid = f"{uid}|{sid}|{question_id}"
            client = mlflow.deployments.get_deploy_client("databricks")
            response = client.predict(
                            endpoint=LLM_ENDPOINT,
                            inputs={
                                "client_request_id": crid,
                                "messages": [
                                    {"role": "user", "content": prompt}
                                ],
                                "temperature": 0  # Set your desired temperature here
                            },
                        )
            result=response["choices"][0]["message"]["content"]
            return result
        elif "BenefitCostShares" in intent or "EoCCategory" in intent:
            #try:
            scripting_key = "HMO" if "HMO" in plan_type else "PPO"
            try:
                from pathlib import Path
                import json

                BASE_DIR = Path(__file__).resolve().parent.parent
                print(BASE_DIR)
                json_path = BASE_DIR / "templates" /f"{scripting_key.lower()}_template.json"
                #with open(f"{scripting_key.lower()}_template.json", "r") as f:
                with open(json_path, "r") as f:
                    #tool_config = json.load(f)
                
                    scripting_format = json.dumps(json.load(f), indent=4)
                #print(scripting_format)
                #template_json = json.loads(templates)
                #templates = template_json[scripting_key]
                #scripting_format = json.dumps(templates, indent=4)

                data = {
                    "plan_data": plan_meta,
                    "benefits": cost_share,
                    "exclusion": exclusion,
                }
            except Exception as e:
                print(e)
                return (
                    "We are unable to find relevant benefit details in the current plan "
                    "data to answer this question accurately."
                )

    
            
        
            if plan_type == "HMO" and "access+" not in plan_name.lower():
                prompt = generate_hmo_prompt(
                    question, plan_type, data, scripting_format
                )
            elif plan_type == "HMO" and "access+" in plan_name.lower():
                prompt = generate_hmo_access_prompt(
                    question, plan_type, plan_name, data, scripting_format
                )
            else:  # PPO
                prompt = generate_ppo_prompt(
                    question, plan_type, data, scripting_format
                )
            
            crid = f"{uid}|{sid}|{question_id}"
            client = mlflow.deployments.get_deploy_client("databricks")
            response = client.predict(
                            endpoint=LLM_ENDPOINT,
                            inputs={
                                "client_request_id": crid,
                                "messages": [
                                    {"role": "user", "content": prompt}
                                ],
                                "temperature": 0  # Set your desired temperature here
                            },
                        )
            final_llm_response=response["choices"][0]["message"]["content"]

            max_text=""
            maxt_text=extract_bsc_maxtext_block(data)
            if max_text is not None and max_text !='':
                prompt_ex=exclusive_check_prompt("max_text",max_text, final_llm_response)
                response= llm.invoke([HumanMessage(content=prompt_ex)])
            BASE_DIR = Path(__file__).resolve().parent.parent
            json_path = BASE_DIR / "templates" /f"{scripting_key.lower()}_template.json"
            with open(json_path, "r") as f:
              generic_template = json.load(f)
            generic_line = generic_template[plan_type]

            # Prepend HMO generic line unless emergency/not-covered
            if (
                plan_type == "HMO"
                and "emergency" not in final_llm_response.lower()
                and "the service you are requesting is either not a benefit" not in final_llm_response.lower()
                and "exclusion under your current policy" not in final_llm_response.lower()
                and "not covered under your current policy" not in final_llm_response.lower()
            ):
                final_answer = f"Plan: {plan_name}\n\n{generic_line}\n\n{final_llm_response}"
            else:
                final_answer = f"Plan: {plan_name}\n\n{final_llm_response}"

            #return json.dumps({"answer": final_answer})
            return json.dumps({"context":data,"answer": final_answer})
        

        # ----- Fallback if intent missing or unsupported -----
        return (
            "Sorry, I couldn't determine how to answer this with the provided intent. "
            "Please try rephrasing your question."
        )