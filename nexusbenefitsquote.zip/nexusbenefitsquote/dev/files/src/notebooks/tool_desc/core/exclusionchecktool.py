# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct

# Databricks sdk import
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementParameterListItem

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore
from tool_desc.core.vector_search import *

def get_warehouse_id_by_name(warehouse_name: str):
    client = WorkspaceClient()
    warehouses = client.warehouses.list()  # returns list of SQL warehouses

    for wh in warehouses:
        if wh.name == warehouse_name:
            return wh.id

    raise ValueError(f"Warehouse '{warehouse_name}' not found")

class ExclusionArgs(BaseModel):
 
    plan_nexus: int = Field(..., description="Current plan nexusId")

class ExclusionCheckTool(StructuredTool):
    name: ClassVar[str] = "exclusionchecktool"
    description: ClassVar[str] = (
        "Answer cost-share questions for the current plan. Returns a JSON list of benefit dicts."
    )
    args_schema: ClassVar[Type[BaseModel]] = ExclusionArgs

    @mlflow.trace(name="ExclusionCheck_run", span_type="tool")
    def _run(self,plan_nexus: int) -> str:
        env=ConfigStore.get("env")
        # EXCLUSION_INDEX=ConfigStore.get("EXCLUSION_INDEX")
        eoc_sections=ConfigStore.get("eoc_sections")
        warehouse_name=ConfigStore.get("warehouse")
        warehouse_id=get_warehouse_id_by_name(warehouse_name)
        client = WorkspaceClient()
        stmt = f"select * from {eoc_sections} where nexusId = {plan_nexus} and get_json_object(eoc_sections_combined, '$.eoc_sections_name') = 'Exclusions and Limitations'"

        result = client.statement_execution.execute_statement(
            warehouse_id=warehouse_id,
            statement=stmt,
            parameters=[
                StatementParameterListItem(name="plan_nexus", value=plan_nexus)
            ],
            wait_timeout="30s"
        )
        if result.result is None or result.result.data_array is None:
            return []
        else:
            data = result.result.data_array
            cols = [col.name for col in result.manifest.schema.columns]
            return json.dumps([
                {
                    "section_id": r[cols.index("section_id")],
                    "eoc_sections_combined": r[cols.index("eoc_sections_combined")]
                }
                for r in data
            ])