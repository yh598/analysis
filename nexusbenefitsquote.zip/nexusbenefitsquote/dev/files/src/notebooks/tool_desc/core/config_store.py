class ConfigStore:
    _cfg = {}

    @classmethod
    def set(cls, **kwargs):
        cls._cfg.update(kwargs)

    @classmethod
    def get(cls, key, default=None):
        return cls._cfg.get(key, default)

    @classmethod
    def all(cls):
        return dict(cls._cfg)  # copy
