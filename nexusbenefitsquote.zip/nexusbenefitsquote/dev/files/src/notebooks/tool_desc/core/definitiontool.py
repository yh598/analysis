# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore
from tool_desc.core.vector_search import *

class DefinitionArgs(BaseModel):
    input: str = Field(..., description="User question asking for a definition")
    plan_nexus: int = Field(..., description="Current plan nexusId")

class DefinitionTool(StructuredTool):
    name: ClassVar[str] = "DefinitionTool"
    description: ClassVar[str] = "Returns concise health-insurance definitions (deductible, copay, coinsurance, OOPM, BlueCard, etc.)"
    args_schema: ClassVar[Type[BaseModel]] = DefinitionArgs

    @mlflow.trace(name="DefinitionTool_run", span_type="tool")
    def _run(self, input: str, plan_nexus: int) -> str:
        env=ConfigStore.get("env")
        BENEFIT_INDEX=ConfigStore.get("BENEFIT_INDEX")
        hits = vs_search(
            q=input,
            nexus=plan_nexus,
            k=5,
            index_name=BENEFIT_INDEX,
            columns=[
                "benefit_id",
                "eoc_categories_all_fields",
                # add whatever columns you actually need
            ],
            filters={"nexusId": plan_nexus},
            #rerank_column="eoc_categories_summary"  
)

        cols=[
                "benefit_id",
                "eoc_categories_all_fields",
                # add whatever columns you actually need
            ]
        print("hits")
        if not hits:
            return "[]"
        result = hits.get("result", hits)
        cols   = result.get("column_names", cols)
        rows   = result.get("data_array", [])


        out = []
        for r in rows:
            rown={}
            row = {cols[i]: r[i] for i in range(len(cols))}  # keep everything
            rown["benefit_id"]   = row[cols[0]]      
            rown["eoc_categories_all_fields"] = row[cols[1]]      
            out.append(rown)

        #print("hits",out)
        # Ensure hits are dicts (normalize if your vs_search returns objects)
        def to_dict(h):
            if isinstance(h, dict):
                return h
            # fallback for objects with __dict__ or attributes
            try:
                return dict(h)
            except Exception:
                return {"value": str(h)}

        payload: List[Dict[str, Any]] = [to_dict(h) for h in out]
        print("payload",payload)
        return json.dumps(payload)  # <-- JSON list of dicts