# special_cases_referral.py

NO_REFERRAL_KEYWORDS = {
    "emergency_services": [
        "emergency room", "er visit", "emergency services", "er services","emergency transport","air ambulance"
    ],
    "urgent_services": [
        "urgent care", "urgent services"
    ],
    "trio_visit": [
        "trio visit", "trio network office visit"
    ],
    "obgyn": [
        "ob gyn", "ob/gyn", "gynecology visit", "obstetrician", "gynecologist"
    ],
  
    "mental_sud": [
        "outpatient mental health", "outpatient substance use disorder",
        "mental health office visit", "therapy visit", "behavioral health visit"
    ],
}

BLOCK_REFERRAL_KEYWORDS = {
    "imaging": [
        "mri", "ct scan", "ct", "x-ray", "xray", "imaging"
    ],
    "allergy": [
        "allergy testing", "allergy test", "immunotherapy"
    ],
    "diagnostic_tests": [
        "diagnostic test", "diagnostic services", "lab test", "laboratory test"
    ],
    "pediatric_vision": [
        "pediatric vision", "children's vision", "child vision exam"
    ],
}
from rapidfuzz import fuzz

def best_category(text: str, category_keywords: dict, threshold: int = 90):
    """
    Return (category_key, best_score) or (None, 0) if nothing passes threshold.
    """
    text = (text or "").lower()
    best_cat = None
    best_score = 0
    

    for cat, phrases in category_keywords.items():
        for phrase in phrases:
            score = fuzz.token_set_ratio(text, phrase.lower())
            if score > best_score:
                best_score = score
                best_cat = cat
    print("best score in referral",best_score)
    print("threshold", threshold)
    if best_score >= threshold:
        return best_cat, best_score
    return None, 0

import re
from typing import List

def extract_benefit_headings(answer_text: str) -> List[str]:
    """
    Extract all benefit headings from the LLM answer.
    Handles patterns like:
      - 'A. Chiropractic Services'
      - 'B. Physical Therapy'
    Falls back to a single heading using the older logic if needed.
    """
    if not answer_text:
        return []

    headings = []

    # Pattern 1: Lines starting with 'A. Something', 'B. Something', etc.
    for m in re.finditer(r"^[A-Z]\.\s*(.+)$", answer_text, flags=re.MULTILINE):
        heading = m.group(1).strip()
        if heading:
            headings.append(heading)

    if headings:
        return headings

    # Pattern 2 (fallback): first block before 'In-network Provider' / 'In Network Provider'
    m = re.search(
        r"^(.*?)\s*(?:In[- ]network Provider|In Network Provider)",
        answer_text,
        flags=re.IGNORECASE | re.MULTILINE | re.DOTALL,
    )
    if m:
        first_block = m.group(1).strip()
        # Take just the first non-empty line from that block
        for line in first_block.splitlines():
            if line.strip():
                return [line.strip()]

    # Final fallback: first non-empty line in the whole answer
    for line in answer_text.splitlines():
        if line.strip():
            return [line.strip()]

    return []

from typing import Optional
#from special_cases_referral import NO_REFERRAL_KEYWORDS, BLOCK_REFERRAL_KEYWORDS

REFERRAL_LINE = "The patient does not need a referral for this service."


def decide_referral(question: str, answer_text: str,plan_type :str, plan_name:str) -> str:
    """
    Decide whether to append the 'no referral needed' line,
    using ALL detected benefit headings.
    """
    
    REFERRAL_LINE = "The patient does not need a referral for this service."
    headings = extract_benefit_headings(answer_text)
    if not headings:
        return ""

    # Combine question + each heading for better signal
    blocked = False
    allowed = False

    for heading in headings:
        combined_text = f"{question}\n{heading}".lower()
        """
        # Check blocklist first (imaging, allergy, etc.)
        block_cat, _ = best_category(combined_text, BLOCK_REFERRAL_KEYWORDS, threshold=90)
        if block_cat:
            blocked = True
            # If ANY heading is a blocked type, safest is: do NOT add no-referral line at all
            break
        """
        allow_cat, _ = best_category(combined_text, NO_REFERRAL_KEYWORDS, threshold=90)
        if allow_cat:
            allowed = True

    if blocked:
        return ""

    if allowed:
        # Note: this adds a single global line for the whole answer;
        # if you ever want per-section lines, we’d need to restructure the answer.
        if "Primary Care Physician" in question and plan_type=="HMO" and "trio" in plan_name.lower():
            REFERRAL_LINE="The patient does not need referral for this service."
        elif "specialist Office visit" in answer_text.lower() and plan_type=="HMO" and "trio" in plan_name.lower():
            REFERRAL_LINE="The patient does not need referral for this service."
        elif "specialist Office visit" in answer_text.lower() and plan_type=="HMO" and "trio" not in plan_name.lower():
            REFERRAL_LINE="The patient need referral for this service."
    


        return REFERRAL_LINE

    return ""

    def decide_referral_with_llm(question: str, answer_text: str, llm_client, endpoint, crid: str):
        heading = extract_benefit_heading(answer_text)
        combined_text = f"{question}\n{heading}".lower()

        block_cat, _ = best_category(combined_text, BLOCK_REFERRAL_KEYWORDS, threshold=90)
        if block_cat:
            return ""

        allow_cat, _ = best_category(combined_text, NO_REFERRAL_KEYWORDS, threshold=90)
        if allow_cat:
            return REFERRAL_LINE

        # Fallback to a tiny LLM check (very constrained)
        tiny_prompt = f"""
    You are a referral rule checker.

    Service description: "{heading}"
    User question: "{question}"

    Rules:
    - Only the following categories are guaranteed NO REFERRAL REQUIRED:
    Emergency Services, Urgent Services, Trio visits,
    OB/GYN services, PCP office visits,
    Outpatient Mental Health and Substance Use Disorder (except imaging & allergy testing).
    - For Imaging, Allergy Testing/Immunotherapy, Diagnostic Tests, Pediatric Vision,
    do NOT say "no referral required".

    Answer only "NO_REFERRAL" or "UNKNOWN".
    """
        resp = llm_client.predict(
            endpoint=endpoint,
            inputs={
                "client_request_id": crid,
                "messages": [{"role": "user", "content": tiny_prompt}],
                "temperature": 0,
            },
        )
        label = resp["choices"][0]["message"]["content"].strip().upper()
        if label == "NO_REFERRAL":
            return REFERRAL_LINE
        return ""

