# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore
from tool_desc.core.vector_search import *

def safe_json_loads(value):
    """Safely load nested/double-encoded JSON until we get a dict or list."""
    try:
        while isinstance(value, str) and value.strip().startswith(("{", "[")):
            value = json.loads(value)
        return value
    except Exception:
        return value


def check_bluecard_program(data):
    """
    Checks if 'BlueCard Program' is included (isIncluded=True)
    from mixed nested JSON / string input structures.
    """
    # Ensure we can iterate over dicts, even if input is a JSON string
    parsed_data = safe_json_loads(data)
    if not isinstance(parsed_data, list):
        print("Input is not a list after parsing.")
        return False

    for entry in parsed_data:
        # Ensure each entry is a dict
        entry = safe_json_loads(entry)
        if not isinstance(entry, dict):
            continue

        val = entry.get("combined_eoc_program_categories")
        val = safe_json_loads(val)
        if not isinstance(val, dict):
            continue

        programs = val.get("eoc_program_categories_programs", [])
        for p in programs:
            if p.get("name", "").strip().lower() == "bluecard program":
                return bool(p.get("isIncluded", False))
    return False

#print("BlueCard Program included:", is_bluecard)

class ProgramArgs(BaseModel):
    input: str = Field(..., description="Original question string.")
    plan_nexus: int = Field(..., description="Current plan nexusId")
    plan_type: str = Field(..., description="Current plan type")

class ProgrammanagementTool(StructuredTool):
    name: ClassVar[str] = "Programmanagement"
    description: ClassVar[str] = (
        "Answer cost-share questions for the current plan. Returns a JSON list of benefit dicts."
    )
    args_schema: ClassVar[Type[BaseModel]] = ProgramArgs

    @mlflow.trace(name="Programmanagement_run", span_type="tool")
    def _run(self, input: str, plan_nexus: int,plan_type: str) -> str:
        env=ConfigStore.get("env")
        PROGRAM_INDEX=ConfigStore.get("PROGRAM_INDEX")
        hits = vs_search(
            q=input,
            nexus=plan_nexus,
            k=4,
            index_name=PROGRAM_INDEX,
            columns=[
                "program_id",
                "combined_eoc_program_categories",
                # add whatever columns you actually need
            ],
            filters={"nexusId": plan_nexus} 
)

        if not hits:
            return "[]"

        cols=["program_id","combined_eoc_program_categories"]
        result = hits.get("result", hits)
        cols   = result.get("column_names", cols)
        rows   = result.get("data_array", [])


        out = []
        for r in rows:
            rown={}
            row = {cols[i]: r[i] for i in range(len(cols))}  # keep everything
            rown["program_id"]   = row[cols[0]]      
            rown["combined_eoc_program_categories"] = row[cols[1]]      
            out.append(rown)

        #print("hits",out)
        # Ensure hits are dicts (normalize if your vs_search returns objects)
        def to_dict(h):
            if isinstance(h, dict):
                return h
            # fallback for objects with __dict__ or attributes
            try:
                return dict(h)
            except Exception:
                return {"value": str(h)}

        payload: List[Dict[str, Any]] = [to_dict(h) for h in out]
        #print("payload",payload)
        return payload
        