# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct


# Databricks sdk import
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementParameterListItem

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore
from tool_desc.core.vector_search import *


def get_warehouse_id_by_name(warehouse_name: str):
    client = WorkspaceClient()
    warehouses = client.warehouses.list()  # returns list of SQL warehouses

    for wh in warehouses:
        if wh.name == warehouse_name:
            return wh.id

    raise ValueError(f"Warehouse '{warehouse_name}' not found")

class PlanDetectArgs(BaseModel):
    facets_product_id: str = Field(..., description="facets_product_id")
    effective_date: str = Field(..., description="effective_date")

class PlanDetectTool(StructuredTool):
    name: ClassVar[str] = "PlanDetect"
    description: ClassVar[str] = (
        "Detect the health‑plan the user is asking about. "
        "Returns BOTH plan_nexus and its plan_cost_share JSON."
    )
    args_schema: ClassVar[Type[BaseModel]] = PlanDetectArgs

    #plan_summary_index_name="tbl_plan_summary_index"
    @mlflow.trace(name="PlanDetect_run", span_type="tool")
    def _run(self,facets_product_id:str,effective_date:str ) -> str:
        env=ConfigStore.get("env")
        #LLM_ENDPOINT=ConfigStore.get("LLM_ENDPOINT")
        plan_details=ConfigStore.get("plan_details")
        #VS_ENDPOINT=ConfigStore.get("VS_ENDPOINT")
        query = facets_product_id
        warehouse_name=ConfigStore.get("warehouse")
        warehouse_id=get_warehouse_id_by_name(warehouse_name)
        client = WorkspaceClient()
        # columns MUST include the JSON string/struct that holds cost‑share rows
        cols = ["nexusId", "planStructureType", "planCostShares","product_line_of_business","planName"]

        stmt = f"SELECT * FROM {plan_details} WHERE facets_product_id = :facets_product_id and effective_date = :effective_date"

  

        result =client.statement_execution.execute_statement(
            warehouse_id=warehouse_id,
            statement=stmt,
            wait_timeout="30s",
            parameters=[
                StatementParameterListItem(
                    name="facets_product_id",
                    value=str(facets_product_id),
                ),
                StatementParameterListItem(
                    name="effective_date",
                    value=str(effective_date),
                )
            ]
        )

        if result.result is None or result.result.data_array is None:
            return []
        print("result",result)
        data= result.result.data_array
        plan_type = data[0][-1]
        plan_cost_json = data[0][-2]
        plan_nexus=data[0][4]
        plan_name=data[0][12]

        
        if "HMO" in plan_type:
            plan_type="HMO"
        if plan_type:
            return json.dumps(
                {"plan_nexus": plan_nexus, "plan_cost_share": plan_cost_json,"plan_name":plan_name,"plan_type":plan_type},
                default=str
            )
        else:
             return json.dumps(
                {"plan_nexus": "", "plan_cost_share": "","plan_name":"","plan_type":""},
                default=str
            ) 
        
