# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
from uuid import uuid4
from typing import *
from dataclasses import asdict
import requests

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker

# MLflow imports
import mlflow
import mlflow.deployments
from mlflow.pyfunc import PythonModel, PythonModelContext, ResponsesAgent
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
)


# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore
#from tool_desc.core.vector_search import *

class FallbackArgs(BaseModel):
    question: str = Field(..., description="Original or expanded user question")


class FallbackAgentTool(StructuredTool):
    name: ClassVar[str] = "FallbackAgent"
    description: ClassVar[str] = (
        "Handles queries that are neither cost-share nor benefits. "
        "Simply replies that the question is outside scope, or asks for clarification."
    )
    args_schema: ClassVar[Type[BaseModel]] = FallbackArgs
    @mlflow.trace(name="FallbackAgent_run", span_type="tool")
    def _run(self, question: str) -> str:
        env=ConfigStore.get("env")
        LLM_ENDPOINT=ConfigStore.get("LLM_ENDPOINT_SECONDARY")
            
        prompt = f"""
You are Benny AI - an assistant designed exclusively to answer questions about health plan benefits, cost shares, coverage rules, exclusions, and related definitions.

The user has asked a question that is OUTSIDE your scope (procedural questions, administrative processes, greetings, personal concerns, or unrelated topics).

Your task: Provide ONLY a brief, appropriate response using the templates below. Do NOT attempt to answer the question. Do NOT provide explanations, steps, or processes.

**Response Templates:**

1. For greetings (hi, hello, hey):
"Hello! I'm here to help with topics related to health plan benefits. Could you please ask something related to these topics?"

2. For personal concerns (I'm sick, not feeling well, health complaints):
"I'm sorry to hear that. I'm here to help with topics related to health plan benefits. Could you please ask something related to these topics?"

3. For "about you" questions (who are you, what can you do):
"I'm Benny AI, your health plan benefits assistant. I'm here to help with topics related to health plan benefits. Could you please ask something related to these topics?"

4. For ALL other out-of-scope questions (procedural, administrative, how-to, processes):
"I'm here to help with topics related to health plan benefits. Could you please ask something related to these topics?"

**CRITICAL RULES:**
- Do NOT answer procedural questions (how to get referralsetc.)
- Do NOT provide steps, processes, or instructions
- Do NOT explain what the user should do
- ONLY use the templates above
- Keep response to 1-2 sentences maximum

User question: "{question}"

Your response (use template only):
"""


        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
        resp = llm.invoke([HumanMessage(content=prompt)])
        return resp.content.strip()
