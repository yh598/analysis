# Standard library imports
import sys
import os
import json
import re
import logging
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict
from pyspark.sql import SparkSession

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore
from tool_desc.core.vector_search import *

class CopayArgs(BaseModel):
    input: str = Field(..., description="Original question string.")
    plan_nexus: int = Field(..., description="Current plan nexusId")
    score_threshold: Optional[float] = Field(None, description="Minimum score to include in results")
class CopayCoinsuranceTool(StructuredTool):
    name: ClassVar[str] = "CopayCoinsurance"
    description: ClassVar[str] = (
        "Answer cost-share questions for the current plan. Returns a JSON list of benefit dicts."
    )
    args_schema: ClassVar[Type[BaseModel]] = CopayArgs

    @mlflow.trace(name="CopayCoinsurance_run", span_type="tool")
    def _run(self, input: str, plan_nexus: int,score_threshold: Optional[float]) -> str:
        env=ConfigStore.get("env")
        score_threshold=ConfigStore.get("score_threshold")        
        BENEFIT_INDEX=ConfigStore.get("BENEFIT_INDEX")
        n=6
        hits = vs_search(
            q=input,
            nexus=plan_nexus,
            k=n,
            index_name=BENEFIT_INDEX,
            columns=[
                "benefit_id",
                "eoc_categories_all_fields",
                # add whatever columns you actually need
            ],
            #rerank_column="eoc_categories_summary" ,
            filters={"nexusId": plan_nexus},
            score_threshold=score_threshold            
             
)
        cols=[
                "benefit_id",
                "eoc_categories_all_fields",
                "score"
                # add whatever columns you actually need
            ]
        if not hits:
            return "[]"
        result = hits.get("result", hits)
        cols   = result.get("column_names", cols)
        rows   = result.get("data_array", [])

        out = []
        for r in rows:
            rown={}
            row = {cols[i]: r[i] for i in range(len(cols))}  # keep everything
            rown["benefit_id"]   = row[cols[0]]      
            rown["eoc_categories_all_fields"] = row[cols[1]]
            rown["score"] = round(float(row[cols[2]]),3)     
            out.append(rown)

        #print("hits",out)
        # Ensure hits are dicts (normalize if your vs_search returns objects)
        def to_dict(h):
            if isinstance(h, dict):
                return h
            # fallback for objects with __dict__ or attributes
            try:
                return dict(h)
            except Exception:
                return {"value": str(h)}

        payload: List[Dict[str, Any]] = [to_dict(h) for h in out]
        return json.dumps(out)  # <-- JSON list of dicts