import sys
import os
import json
import yaml
import re
import logging
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict

from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore


VS_ENDPOINT=ConfigStore.get("VS_ENDPOINT")


def vs_search(
    q: str,
    nexus: int | None,
    k: int,
    index_name: str,
    columns: list[str] | None = None,
    score_threshold: float | None = None,
    filters: dict[str, Any] | None = None,
    rerank_column:str=None,
) -> list[dict[str, Any]]:
    vsc=VectorSearchClient()
    if columns is None:
        columns = ["benefit_id", "search_text"]

    # build filters safely
    if filters is not None:
        search_filters = filters
    elif nexus is not None:
        search_filters = {"nexusId": int(nexus)}
    else:
        search_filters = None      
                     

    idx = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=index_name)
   
    raw = idx.similarity_search(
        query_text=q,
        num_results=k,
        #query_type="hybrid",
        
        filters=search_filters,
        reranker=DatabricksReranker(
        columns_to_rerank=[rerank_column]
    ),
           
        columns=columns,
        score_threshold=score_threshold,
    )


    result = raw.get("result", raw)
    cols   = result.get("column_names", columns)
    rows   = result.get("data_array", [])


    out = []
    for r in rows:
      
        row = {cols[i]: r[i] for i in range(len(cols))}  # keep everything
        row["id"]   = row[cols[0]]      
        row["text"] = row[cols[1]]      
        out.append(row)
  
    return raw