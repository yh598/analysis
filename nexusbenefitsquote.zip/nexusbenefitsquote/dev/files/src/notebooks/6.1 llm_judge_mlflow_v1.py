# Databricks notebook source
# MAGIC %pip install --upgrade "mlflow[databricks]>=3.1"

# COMMAND ----------

# MAGIC %pip install --upgrade openpyxl rouge-score

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import mlflow
import pandas as pd
import numpy as np
import re
from mlflow.genai import make_judge
import json
from rouge_score import rouge_scorer
from tool_desc.core.custom_metrics import *
from tool_desc.core.ndcg_metrics import *



# COMMAND ----------



# COMMAND ----------

import os
print(os.getcwd())
from tool_desc import *

# COMMAND ----------

def start_mlflow_experiment(experiment_name):
    user_email = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
    experiment_base_path = f"/Workspace/Users/pmane01@blueshieldca.com/benefit_quote_mlflow_eval"
    experiment_path = f"{experiment_base_path}/{experiment_name}"

    # No need to create the directory manually; MLflow will handle it
    experiment = mlflow.set_experiment(experiment_path)
    return experiment

# Usage
experiment_tag = "Benefit_Agent_mlflow_make_Judge"
experiment = start_mlflow_experiment(experiment_tag)

# COMMAND ----------


EXCEL_PATH = "/Volumes/dev_adb/benefits_quote_bronze_mvp1/bsc/answer_context_12152025 (1).xlsx"


JUDGE_MODEL = "databricks:/databricks-claude-sonnet-4-5"  # or "openai:/gpt-4o-mini"



# COMMAND ----------

from mlflow.genai import evaluate
from mlflow.genai.scorers import Correctness


# COMMAND ----------

response_judge = make_judge(
    name="response_quality_judge",
    model=JUDGE_MODEL,
  
    instructions="""
    You evaluate *response quality only* (no context needed).

    Inputs:
    - {{ inputs }}        : user question
    - {{ expectations }}  : correct answer
    - {{ outputs }}       : model's response

    Definitions:
    - response_relevance = does the answer address the question?
    - response_completeness = how much of ground truth the answer covers.

    NO explanations, only JSON.

    Return EXACTLY this JSON:
    {
      "response_relevance": float(0-1)
    }
    """
    ,feedback_value_type=float
)

# COMMAND ----------

relevance_judge = make_judge(
    name="response_relevance",
    instructions="""
    Rate the relevance and completeness each separately of the response to the user input on a scale of 0.0 to 1.0.
    Input: {{ inputs }}
    Response: {{ outputs }}
    Output only the two float values in this order: response_relevance,response_completeness.
    """,
    feedback_value_type=float,
)

# COMMAND ----------

context_judge = make_judge(
    name="context_quality",
    instructions="""
Rate the retrieved context quality for answering the user question.

Inputs:
Question: {{ inputs }}
Retrieved Context: {{ expectations }}
Ground Truth Answer: {{ outputs }}

Evaluate ONLY the retrieved context. Do NOT evaluate the model response.

Scoring:
1. context_relevance (0.0–1.0):
   How directly the retrieved context is related to the question topic.
   If any part of the context clearly matches the question topic, score ≥ 0.4.

2. context_precision (0.0–1.0):
   How much of the retrieved context is useful.
   Extra or irrelevant text should reduce this score.

3. context_recall (0.0–1.0):
   Whether the retrieved context contains the key facts needed
   to produce the ground truth answer.
   Do NOT reduce this score due to extra or irrelevant text.

Be tolerant of paraphrasing and formatting differences.

Output ONLY three float values in this order:
context_relevance, context_precision, context_recall
""",
    feedback_value_type=float,
)


# COMMAND ----------

def extract_feedback_scores(feedback_obj):
    """
    Returns feedback scores as a list of floats
    """
    if not feedback_obj or not getattr(feedback_obj, "feedback", None):
        return []

    value = feedback_obj.feedback.value  # e.g. "0.9, 0.9"

    if isinstance(value, str):
        return [float(v.strip()) for v in value.split(",")]

    # fallback if already numeric
    if isinstance(value, (list, tuple)):
        return list(map(float, value))

    return []


# COMMAND ----------

def result_to_feedback(result_dict, prefix=None):
    feedbacks = []
    for k, v in result_dict.items():
        name = f"{prefix}_{k}" if prefix else k

        # Only log numeric values
        if isinstance(v, (int, float)):
            feedbacks.append(Feedback(name=name, value=float(v)))
    return feedbacks

# COMMAND ----------

from mlflow.genai.scorers import scorer
from mlflow.entities import Feedback

@scorer(name="benefit_multi_metric_scorer")
def benefit_multi_metric_scorer(*, inputs=None, outputs=None, expectations=None, trace=None):
 

    question = inputs.get("request", "") if inputs else ""
    ground_truth = expectations.get("expected_response", "") if expectations else ""
    outputs=outputs.get("response", "") if expectations else ""
    context = expectations.get("context", "") if expectations else ""


    fb_re = relevance_judge(
        inputs={"question": question},
        outputs=outputs,
        expectations={
            "ground_truth": ground_truth,
        },
    )
    print(fb_re)
    re_metric=extract_feedback_scores(fb_re)
    print(re_metric)
   
    fb_co = context_judge(
        inputs={"question": question},
        expectations={"retrieved_context": context},
        outputs=outputs
    ) 
    print(fb_co)
    co_metric=extract_feedback_scores(fb_co)
    print(co_metric)
  
   
    
    cmp = BenefitTemplateComparator(ground_truth, outputs)

    deductible_check, ded_titles = cmp.deductible_check()
    cost_share_check, cs_titles = cmp.cost_share_check()
    oopm_check, oopm_titles = cmp.oopm_check()
    print(deductible_check)

    evaluator = TemplateEvaluator()
    rouge_l_score= evaluator.rouge_l(outputs,ground_truth)
    f1_overlap_score=evaluator.f1_overlap(outputs,ground_truth)
    url_match_check=evaluator.url_match(outputs,ground_truth)
    phone_number_match_check=evaluator.phone_number_match(outputs,ground_truth)
   
    template_accuracy=evaluator.derive_template_accuracy(
        phone_number_match_check,url_match_check,deductible_check,cost_share_check,oopm_check)
    template_accuracy_score=template_accuracy.get("score")
    template_accuracy_verdict=template_accuracy.get("verdict")
    print(template_accuracy)
    metrics = NexusMetrics() 
    result = metrics.compute_metrics_for_query( response_text=outputs, ground_truth=ground_truth, context_items=context )
    print("result",result)
  
  
    return [
    Feedback(name="response_relevance", value=float(re_metric[0])),
    Feedback(name="response_completeness", value=float(re_metric[1])),

    Feedback(name="context_relevance", value=float(co_metric[0])),
    Feedback(name="context_precision", value=float(co_metric[1])),
    Feedback(name="context_recall", value=float(co_metric[2])),

    Feedback(name="deductible_check", value=deductible_check),
    Feedback(name="rouge_l_score", value=rouge_l_score),
    Feedback(name="f1_overlap_score", value=f1_overlap_score),
    Feedback(name="url_match_check", value=url_match_check),
    Feedback(name="phone_number_match_check", value=phone_number_match_check),
    Feedback(name="cost_share_check", value=cost_share_check),
    Feedback(name="oopm_check", value=oopm_check),
    Feedback(name="template_accuracy_score", value=template_accuracy_score),
    Feedback(name="template_accuracy_verdict", value=template_accuracy_verdict),
    *result_to_feedback(result)
]



# COMMAND ----------

records = []
import pandas as pd
df = pd.read_excel(EXCEL_PATH)
df=df.iloc[0:2]


required = ["question", "ground_truth", "assistant_answer", "retrieved_context"]
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError(f"Excel missing columns: {missing}")

for _, row in df.iterrows():
    records.append(
        {
            "inputs": {"request": str(row["question"])},
            "outputs": {"response":str(row["assistant_answer"])},
            "expectations": {
                "expected_response": str(row["ground_truth"]),
                "context": str(context),
            },
        }
    )

trace_eval = mlflow.genai.evaluate(
    data=records,
    scorers=[Correctness(),benefit_multi_metric_scorer],
)

# COMMAND ----------

pdf=trace_eval.result_df
pdf["assessments"].iloc[0]

# COMMAND ----------

df = pd.read_excel(EXCEL_PATH)
df = df.iloc[0:1,]
#display(df)

# COMMAND ----------

print(df["ground_truth"][0])

# COMMAND ----------

context="[{\"benefit_id\": \"28506_688\", \"eoc_categories_all_fields\": \"{\\\"eocCategories_nexusId\\\":688,\\\"eocCategories_name\\\":\\\"Fertility Preservation Services\\\",\\\"eocCategories_content\\\":\\\" Fertility preservation services Fertility preservation services are covered for Members undergoing treatment or receiving Covered Services that may directly or indirectly cause iatrogenic Infertility.Under these circumstances,standard fertility preservation services are a Covered Service and do not fall under the scope of Infertility Benefits described in the Family Planning and Infertility Benefits section.\\\",\\\"eocCategories_benefitSubCategories\\\":[{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":6108,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Iatrogenic Fertility - Ambulatory Surgery Center (ASC)\\\",\\\"nexusId\\\":1436,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":300,\\\"copayInterval\\\":\\\"per surgery\\\",\\\"costShareText\\\":\\\"$300 per surgery\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":74,\\\"nexusBenefitCategory\\\":\\\"Infertility Iatrogenic Benefits\\\",\\\"nexusBenefitName\\\":\\\"Iatrogenic Infertility ASC Services\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":true,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":6109,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Iatrogenic Fertility - Lab Outpatient\\\",\\\"nexusId\\\":1007,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":35,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$35 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":559,\\\"nexusBenefitCategory\\\":\\\"Professional Physician Services\\\",\\\"nexusBenefitName\\\":\\\"Iatrogenic Fertility Lab - Outpatient\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":6107,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Iatrogenic Fertility - Professional Inpatient\\\",\\\"nexusId\\\":1004,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Professional Physician Services\\\",\\\"nexusBenefitName\\\":\\\"Iatrogenic Infertility Professional - Inpatient\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":6110,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Iatrogenic Fertility - Professional Office\\\",\\\"nexusId\\\":1018,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":35,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$35 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":128,\\\"nexusBenefitCategory\\\":\\\"Infertility Iatrogenic Benefits\\\",\\\"nexusBenefitName\\\":\\\"Iatrogenic Fertility Professional - Office\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":6111,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Iatrogenic Fertility - Professional Outpatient\\\",\\\"nexusId\\\":1011,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":35,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$35 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":520,\\\"nexusBenefitCategory\\\":\\\"Infertility Iatrogenic Benefits\\\",\\\"nexusBenefitName\\\":\\\"Iatrogenic Fertility Professional - Outpatient\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Fertility Preservation Services\\\",\\\"nexusId\\\":1513}]}\"}, {\"benefit_id\": \"28506_766\", \"eoc_categories_all_fields\": \"{\\\"eocCategories_nexusId\\\":766,\\\"eocCategories_name\\\":\\\"Infertility - Assisted Reproductive Benefits\\\",\\\"eocCategories_content\\\":\\\" Introduction The Member is entitled to Benefits under this assisted reproductive technology Benefit.Covered Services for Infertility include all professional,Hospital,Ambulatory Surgery Center,ancillary services and injectable drugs when authorized by the Primary Care Physician to a Member for the inducement of fertilization as described herein.For the purposes of this Benefit,Infertility is:A licensed Physician's findings,based on a patient's medical,sexual,and reproductive history,age,physical findings,diagnostic testing,or any combination of those factors.This definition shall not prevent testing and diagnosis of Infertility before the 12-month or 6-month period to establish Infertility in paragraph (3); A person's inability to reproduce either as an individual or with their partner without medical intervention; or The failure to establish a pregnancy or to carry a pregnancy to live birth after regular,unprotected sexual intercourse.For purporses of this definition,\\\\\\\"regular,unprotected sexual intercourse\\\\\\\" means no more than 12 months of unprotected sexual intercourse for a person under 35 years of age or no more than 6 months of unprotected sexual intercourse for a person 35 years of age or older.Pregnancy resulting in miscarriage does not restart the 12-month or 6-month time period to qualify as having Infertility.Benefits Benefits are provided for a Member who meets the definition of Infertility for a medically appropriate diagnostic work-up and ART procedures.The Member is responsible for the Copayment or Coinsurance listed for all professional and Hospital services,Ambulatory Surgery Center and ancillary services used in connection with any procedure covered under this Benefit,and injectable drugs administered by the provider to induce fertilization.Self-administered Drugs prescribed to induce fertilization are covered at the applicable Drug tier Copayment or Coinsurance under the Prescription Drug Benefits section of the Evidence of Coverage.Procedures must be consistent with established medical practice for the treatment of Infertility and authorized by the Primary Care Physician.Benefits are only provided for services received from Participating Providers.These Covered Services are not subject to the Calendar Year Medical Deductible.Cost Share for these Covered Services applies towards the Out-of-Pocket Maximum.Exclusions No Benefits are provided for:ART and associated services related to intracytoplasmic sperm injection (ICSI); ART and associated services related to zygote intrafallopian transfer (ZIFT); ART and associated services related to in vitro fertilization (IVF); Services received from Non-Participating Providers; Services for or incident to sexual dysfunction and sexual inadequacies,except as provided for treatment of organically based conditions,for which Covered Services are provided only under the medical Benefits portion of the Evidence of Coverage (EOC); Services incident to or resulting from procedures for a surrogate mother.However,if the surrogate mother is enrolled in a Blue Shield of California health Plan,Covered Services for pregnancy and maternity care for the surrogate mother will be covered under that health Plan; Services for collection,purchase or storage of embryos,oocytes,ovarian tissue,or sperm from donors other than the Member entitled to Benefits under this assisted reproductive technology Benefit; Cryopreservation of embryos,oocytes,ovarian tissue,or sperm from donors other than the Member entitled to Benefits under this assisted reproductive technology Benefit; Home ovulation prediction testing kits or home pregnancy tests; Microsurgical epididymal sperm aspiration (MESA),percutaneous epididymal sperm aspiration (PESA),and testicular sperm aspiration (TESA) if the Member had a previous vasectomy; Reversal of surgical sterilization and associated services; Any services not specifically listed as a Covered Service,above; or Covered Services in excess of the lifetime Benefit maximums .\\\",\\\"eocCategories_benefitSubCategories\\\":[{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":5393,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Cryopreservation of embryos,oocytes,sperm,reproductive tissue (Retrieved from a Member)\\\",\\\"nexusId\\\":1275,\\\"providerCostShares\\\":[{\\\"coinsurancePct\\\":50,\\\"costShareText\\\":\\\"50% Coinsurance\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"limit\\\":\\\"1 procedure per year up to 1 year\\\",\\\"limitCombinedWith\\\":\\\"Cryo Storage\\\",\\\"limitInterval\\\":\\\"per year up to 1 year\\\",\\\"limitText\\\":\\\"1 per year up to 1 year.\\\",\\\"limitType\\\":\\\"procedure\\\",\\\"limitValue\\\":1,\\\"mappedBenefitId\\\":346,\\\"nexusBenefitCategory\\\":\\\"Infertility\\\",\\\"nexusBenefitName\\\":\\\"Cryopreservation Storage\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Coinsurance\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5388,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Gamete intrafallopian transfer (GIFT)\\\",\\\"nexusId\\\":556,\\\"providerCostShares\\\":[{\\\"coinsurancePct\\\":50,\\\"costShareText\\\":\\\"50% Coinsurance\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"limit\\\":\\\"1 procedures per lifetime\\\",\\\"limitCombinedWith\\\":\\\"GIFT\\\",\\\"limitInterval\\\":\\\"per lifetime\\\",\\\"limitText\\\":\\\"1 per lifetime.\\\",\\\"limitType\\\":\\\"procedures\\\",\\\"limitValue\\\":1,\\\"mappedBenefitId\\\":346,\\\"nexusBenefitCategory\\\":\\\"Infertility\\\",\\\"nexusBenefitName\\\":\\\"GIFT\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Coinsurance\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5390,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"In vitro fertilization (IVF)\\\",\\\"nexusId\\\":82,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"Not Covered\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":82,\\\"nexusBenefitCategory\\\":\\\"Infertility\\\",\\\"nexusBenefitName\\\":\\\"In Vitro Fertilization (IVF) - w/Limit\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Not Covered\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5389,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Intracytoplasmic sperm injection (ICSI)\\\",\\\"nexusId\\\":608,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"Not Covered\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":608,\\\"nexusBenefitCategory\\\":\\\"Infertility\\\",\\\"nexusBenefitName\\\":\\\"ICSI\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Not Covered\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5394,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Natural artificial inseminations without ovum [oocyte or ovarian tissue (egg)] stimulation\\\",\\\"nexusId\\\":1263,\\\"providerCostShares\\\":[{\\\"coinsurancePct\\\":50,\\\"costShareText\\\":\\\"50% Coinsurance\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"limit\\\":\\\"6 procedures per lifetime\\\",\\\"limitInterval\\\":\\\"per lifetime\\\",\\\"limitText\\\":\\\"6 per lifetime.\\\",\\\"limitType\\\":\\\"procedures\\\",\\\"limitValue\\\":6,\\\"mappedBenefitId\\\":346,\\\"nexusBenefitCategory\\\":\\\"Infertility\\\",\\\"nexusBenefitName\\\":\\\"Artificial Insemination Unassisted - Outpatient Facility\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Coinsurance\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5395,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Oocyte (egg) retrieval\\\",\\\"nexusId\\\":1594,\\\"providerCostShares\\\":[{\\\"coinsurancePct\\\":50,\\\"costShareText\\\":\\\"50% Coinsurance\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":346,\\\"nexusBenefitCategory\\\":\\\"Infertility\\\",\\\"nexusBenefitName\\\":\\\"Always ART Procedures - Oocyte Retrieval - Professional Inpatient\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Coinsurance\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5386,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Stimulated artificial inseminations with ovum (oocyte or ovarian tissue) stimulation\\\",\\\"nexusId\\\":495,\\\"providerCostShares\\\":[{\\\"coinsurancePct\\\":50,\\\"costShareText\\\":\\\"50% Coinsurance\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"limit\\\":\\\"3 procedures per lifetime\\\",\\\"limitCombinedWith\\\":\\\"AI Assisted\\\",\\\"limitInterval\\\":\\\"per lifetime\\\",\\\"limitText\\\":\\\"3 per lifetime.\\\",\\\"limitType\\\":\\\"procedures\\\",\\\"limitValue\\\":3,\\\"mappedBenefitId\\\":346,\\\"nexusBenefitCategory\\\":\\\"Infertility\\\",\\\"nexusBenefitName\\\":\\\"Artificial Insemination Assisted\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Coinsurance\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5391,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Zygote intrafallopian transfer (ZIFT)\\\",\\\"nexusId\\\":609,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"Not Covered\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":609,\\\"nexusBenefitCategory\\\":\\\"Infertility\\\",\\\"nexusBenefitName\\\":\\\"ZIFT\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Not Covered\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Infertility Services\\\",\\\"nexusId\\\":1291}]}\"}, {\"benefit_id\": \"28506_684\", \"eoc_categories_all_fields\": \"{\\\"eocCategories_nexusId\\\":684,\\\"eocCategories_name\\\":\\\"Family Planning and Infertility Benefits\\\",\\\"eocCategories_content\\\":\\\" Family planning and Infertility Benefits Family planning Benefits are available for family planning services without illness or injury.Benefits include:Counseling,consulting,and education; Office-administered contraceptives; Physician office visits for office-administered contraceptives; Clinical services related to the provision or use of contraceptives,including consultations,examinations,procedures,device insertion,ultrasound,anesthesia,patient education,referrals,and counseling; Follow-up services related to contraceptive Drugs,devices,products,and procedures,including but not limited to management of side effects,counseling for continued adherence,and device removal; Voluntary tubal ligation and other similar sterilization procedures; and Vasectomy services and procedures.Family planning services may also be covered under the Preventive Health Services Benefit and the Prescription Drug Benefit.Infertility Benefits Benefits are provided for the diagnosis and treatment of the cause of Infertility,including professional,Hospital,Ambulatory Surgery Center,and related services to diagnose and treat the cause of Infertility,with the exception of what is excluded in the Exclusions and limitations section.\\\",\\\"eocCategories_benefitSubCategories\\\":[{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":4364,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Counseling,consulting,and education\\\",\\\"nexusId\\\":170,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":170,\\\"nexusBenefitCategory\\\":\\\"Preventive Health Services (WPH)\\\",\\\"nexusBenefitName\\\":\\\"Counseling and Consulting For Contraception\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4346,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Diaphragm Fitting\\\",\\\"nexusId\\\":164,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":170,\\\"nexusBenefitCategory\\\":\\\"Preventive Health Services (WPH)\\\",\\\"nexusBenefitName\\\":\\\"Diaphragm Fitting Procedure\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4347,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Implanted Contraceptives\\\",\\\"nexusId\\\":169,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":170,\\\"nexusBenefitCategory\\\":\\\"Preventive Health Services (WPH)\\\",\\\"nexusBenefitName\\\":\\\"Implantable Contraceptives\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4348,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Injectable Contraceptives\\\",\\\"nexusId\\\":168,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":170,\\\"nexusBenefitCategory\\\":\\\"Preventive Health Services (WPH)\\\",\\\"nexusBenefitName\\\":\\\"Injectable Contraceptives\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4365,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Insertion and Removal of IUD\\\",\\\"nexusId\\\":165,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":170,\\\"nexusBenefitCategory\\\":\\\"Preventive Health Services (WPH)\\\",\\\"nexusBenefitName\\\":\\\"Insertion and Removal of IUD\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4366,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Intrauterine Device (IUD)\\\",\\\"nexusId\\\":166,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":170,\\\"nexusBenefitCategory\\\":\\\"Preventive Health Services (WPH)\\\",\\\"nexusBenefitName\\\":\\\"Intrauterine Device (IUD)\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Contraceptives\\\",\\\"nexusId\\\":1036},{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":4357,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Injections Inpatient\\\",\\\"nexusId\\\":1311,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Infertility Diagnosis & Treatment Benefits\\\",\\\"nexusBenefitName\\\":\\\"Diagnosis and Treatment of the Cause of infertility - Injections IP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4358,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Injections Outpatient\\\",\\\"nexusId\\\":1312,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":35,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$35 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":520,\\\"nexusBenefitCategory\\\":\\\"Infertility Diagnosis & Treatment Benefits\\\",\\\"nexusBenefitName\\\":\\\"Diagnosis and Treatment of the Cause of infertility - Injections OP\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4359,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Injections Office\\\",\\\"nexusId\\\":1313,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":35,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$35 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":520,\\\"nexusBenefitCategory\\\":\\\"Infertility Diagnosis & Treatment Benefits\\\",\\\"nexusBenefitName\\\":\\\"Diagnosis and Treatment of the Cause of infertility - Injections Office\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4360,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Lab and Pathology Outpatient\\\",\\\"nexusId\\\":1315,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":55,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$55 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":97,\\\"nexusBenefitCategory\\\":\\\"Infertility Diagnosis & Treatment Benefits\\\",\\\"nexusBenefitName\\\":\\\"Diagnosis and Treatment of the Cause of infertility - Lab & Pathology OP\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4361,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Outpatient Facility\\\",\\\"nexusId\\\":494,\\\"providerCostShares\\\":[{\\\"coinsurancePct\\\":20,\\\"costShareText\\\":\\\"20% Coinsurance\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":77,\\\"nexusBenefitCategory\\\":\\\"Infertility Diagnosis & Treatment Benefits\\\",\\\"nexusBenefitName\\\":\\\"Diagnosis and Treatment of the Cause of infertility - Outpatient Facility\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Coinsurance\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4362,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Visit Inpatient\\\",\\\"nexusId\\\":1255,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Infertility Diagnosis & Treatment Benefits\\\",\\\"nexusBenefitName\\\":\\\"Diagnosis and Treatment of the Cause of infertility - Visit IP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4363,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Visit Office\\\",\\\"nexusId\\\":1257,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":35,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$35 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":128,\\\"nexusBenefitCategory\\\":\\\"Infertility Diagnosis & Treatment Benefits\\\",\\\"nexusBenefitName\\\":\\\"Diagnosis and Treatment of the Cause of infertility - Visit Office\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Diagnosis and Treatment of the Cause of Infertility\\\",\\\"nexusId\\\":1038},{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":4349,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Tubal Ligation\\\",\\\"nexusId\\\":173,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":173,\\\"nexusBenefitCategory\\\":\\\"Preventive Health Services (WPH)\\\",\\\"nexusBenefitName\\\":\\\"Tubal Ligation\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4350,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Vasectomy\\\",\\\"nexusId\\\":60,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":60,\\\"nexusBenefitCategory\\\":\\\"Family Planning\\\",\\\"nexusBenefitName\\\":\\\"Vasectomy Professional\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Family Planning\\\",\\\"nexusId\\\":1037}]}\"}, {\"benefit_id\": \"28506_659\", \"eoc_categories_all_fields\": \"{\\\"eocCategories_nexusId\\\":659,\\\"eocCategories_name\\\":\\\"Diagnostic X-ray,imaging,pathology,laboratory,and other testing services\\\",\\\"eocCategories_content\\\":\\\" Diagnostic X-ray,imaging,pathology,laboratory,and other testing services Benefits are available for imaging,pathology,and laboratory services for preventive screening or to diagnose or treat illness or injury.Benefits include:Basic diagnostic imaging services,such as plain film X-rays,ultrasounds,and mammography; Advanced diagnostic radiological and nuclear imaging,including CT,PET,MRI,and MRA scans; COVID-19 diagnostic testing,screening testing,and related healthcare services.Medical Necessity requirements do not apply for COVID-19 screening testing; Reimbursement for over-the-counter at-home COVID-19 tests.The reimbursement is allowed for up to 8 tests per Member per month,subject to a maximum reimbursement of $12 per test.See the Claims for Emergency or Urgent Services section for information about how to submit a claim for repayment for this Benefit Biomarker testing for the purposes of diagnosis,treatment,appropriate management,or ongoing monitoring of your disease or condition to guide treatment decisions.Benefits must be prior authorized; Clinical pathology services; Laboratory services; Other areas of non-invasive diagnostic testing,including respiratory,neurological,vascular,cardiological,genetic,cardiovascular,and cerebrovascular; and Prenatal diagnosis of genetic disorders of the fetus in cases of high-risk pregnancy.Laboratory or imaging services performed as part of a preventive health screening are covered under the Preventive Health Services Benefit.For services provided by Participating Providers,Blue Shield will waive Cost Shares for COVID-19 diagnostic testing,screening testing,and related services.Blue Shield encourages Members to seek services from Participating Providers to avoid paying extra fees.Some Non-Participating Providers may charge extra fees that are not covered by Blue Shield.Any fees not covered by Blue Shield will be the Member\\u2019s responsibility.See the How to access care section for information about Participating and Non-Participating Providers.\\\",\\\"eocCategories_benefitSubCategories\\\":[{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":5488,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Outpatient Radiology center\\\",\\\"nexusId\\\":96,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":250,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$250 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":96,\\\"nexusBenefitCategory\\\":\\\"Professional Physician Services\\\",\\\"nexusBenefitName\\\":\\\"Advanced Imaging Services includes diagnostic radiological and nuclear imaging such as CT,PET scans and MRIs,MRAs (including Radiopharmaceutical supplies for the use of diagnostic or therapeutic imaging services) - Professional Outpatient\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":true,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5489,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Outpatient department of a hospital\\\",\\\"nexusId\\\":89,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":250,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$250 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":89,\\\"nexusBenefitCategory\\\":\\\"Hospital Benefits (Facility Services)\\\",\\\"nexusBenefitName\\\":\\\"Advanced Imaging Services Outpatient Facility includes diagnostic radiological and nuclear imaging such as CT,PET scans,and MRI's,MRA's (including Radiopharmaceutical supplies)\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":true,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Advanced Imaging Services\\\",\\\"nexusId\\\":1315},{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":5483,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Outpatient Radiology center\\\",\\\"nexusId\\\":97,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":55,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$55 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":97,\\\"nexusBenefitCategory\\\":\\\"Professional Physician Services\\\",\\\"nexusBenefitName\\\":\\\"Basic Imaging Services includes plain film X-rays,ultrasounds,and diagnostic mammography - Professional Office\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5484,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Outpatient department of a hospital\\\",\\\"nexusId\\\":93,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":55,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$55 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":93,\\\"nexusBenefitCategory\\\":\\\"Hospital Benefits (Facility Services)\\\",\\\"nexusBenefitName\\\":\\\"Outpatient Basic Imaging Services includes plain film X-rays,ultrasounds,and diagnostic mammography - Facility Outpatient\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Basic Imaging Services\\\",\\\"nexusId\\\":1313},{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":5481,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Laboratory Center\\\",\\\"nexusId\\\":559,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":35,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$35 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":559,\\\"nexusBenefitCategory\\\":\\\"Professional Physician Services\\\",\\\"nexusBenefitName\\\":\\\"Professional Clinical Lab and Pathology\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5482,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Outpatient department of a hospital\\\",\\\"nexusId\\\":91,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":35,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$35 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":91,\\\"nexusBenefitCategory\\\":\\\"Hospital Benefits (Facility Services)\\\",\\\"nexusBenefitName\\\":\\\"Outpatient Diagnostic Testing,Clinical Lab,Pathology\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Laboratory and Pathology Services\\\",\\\"nexusId\\\":1312},{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":5487,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Office Location\\\",\\\"nexusId\\\":97,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":55,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$55 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":97,\\\"nexusBenefitCategory\\\":\\\"Professional Physician Services\\\",\\\"nexusBenefitName\\\":\\\"Basic Imaging Services includes plain film X-rays,ultrasounds,and diagnostic mammography - Professional Office\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":5486,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Outpatient department of a hospital\\\",\\\"nexusId\\\":93,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":55,\\\"copayInterval\\\":\\\"per visit\\\",\\\"costShareText\\\":\\\"$55 per visit\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":93,\\\"nexusBenefitCategory\\\":\\\"Hospital Benefits (Facility Services)\\\",\\\"nexusBenefitName\\\":\\\"Outpatient Basic Imaging Services includes plain film X-rays,ultrasounds,and diagnostic mammography - Facility Outpatient\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Other Outpatient Non-Invasive Diagnostic Testing\\\",\\\"nexusId\\\":1314}]}\"}, {\"benefit_id\": \"28506_759\", \"eoc_categories_all_fields\": \"{\\\"eocCategories_nexusId\\\":759,\\\"eocCategories_name\\\":\\\"Transplant Services\\\",\\\"eocCategories_content\\\":\\\" Transplant services Benefits are available for tissue and kidney transplants and special transplants.Tissue and kidney transplants Benefits are available for facility and professional services provided in connection with human tissue and kidney transplants when you are the transplant recipient.Benefits include services incident to obtaining the human transplant material from a living donor or a tissue/organ transplant bank.Special transplants Benefits are available for special transplants only if:The procedure is performed at a special transplant facility contracting with Blue Shield,or if you access this Benefit outside of California,the procedure is performed at a transplant facility designated by Blue Shield; and You are the recipient of the transplant.Special transplants are:Human heart transplants; Human lung transplants; Human heart and lung transplants in combination; Human liver transplants; Human kidney and pancreas transplants in combination; Human bone marrow transplants,including autologous bone marrow transplantation (ABMT) or autologous peripheral stem cell transplantation used to support high-dose chemotherapy when such treatment is Medically Necessary and is not Experimental or Investigational; Pediatric human small bowel transplants; and Pediatric and adult human small bowel and liver transplants in combination.Donor services Transplant Benefits include coverage for donation-related services for a living donor,including a potential donor,or a transplant organ bank.Donor services must be directly related to a covered transplant for a Member of this plan.Donor services include:Donor evaluation; Harvesting of the organ,tissue,or bone marrow; and Treatment of medical complications for 90 days after the evaluation or harvest procedure.\\\",\\\"eocCategories_benefitSubCategories\\\":[{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":3982,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Facility services in a special transplant facility\\\",\\\"nexusId\\\":323,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":600,\\\"copayInterval\\\":\\\"per day\\\",\\\"costShareText\\\":\\\"$600 per day\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":75,\\\"memberMax\\\":\\\"$600 per day up to 5 days per admission\\\",\\\"memberMaxAmount\\\":600,\\\"memberMaxInterval\\\":\\\"per day up to 5 days per admission\\\",\\\"memberMaxText\\\":\\\"$600 per day up to 5 days per admission.\\\",\\\"nexusBenefitCategory\\\":\\\"Transplant Benefit\\\",\\\"nexusBenefitName\\\":\\\"Facility Services in a Special Transplant Facility\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":true,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":3984,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Hospital facility services\\\",\\\"nexusId\\\":76,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":600,\\\"copayInterval\\\":\\\"per day\\\",\\\"costShareText\\\":\\\"$600 per day\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":75,\\\"memberMax\\\":\\\"$600 per day up to 5 days per admission\\\",\\\"memberMaxAmount\\\":600,\\\"memberMaxInterval\\\":\\\"per day up to 5 days per admission\\\",\\\"memberMaxText\\\":\\\"$600 per day up to 5 days per admission.\\\",\\\"nexusBenefitCategory\\\":\\\"Hospital Benefits (Facility Services)\\\",\\\"nexusBenefitName\\\":\\\"Transplant\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":true,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":3983,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Professional physician services\\\",\\\"nexusId\\\":324,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Transplant Benefit\\\",\\\"nexusBenefitName\\\":\\\"Professional (Physician) Services\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Transplant services\\\",\\\"nexusId\\\":948}]}\"}, {\"benefit_id\": \"28506_675\", \"eoc_categories_all_fields\": \"{\\\"eocCategories_nexusId\\\":675,\\\"eocCategories_name\\\":\\\"Pregnancy and Maternity Care\\\",\\\"eocCategories_content\\\":\\\" Pregnancy and maternity care Benefits are available for maternity care services.Benefits include:Prenatal care; Postnatal care; Involuntary complications of pregnancy; Inpatient Hospital services including labor,delivery,and postpartum care; Elective newborn circumcision within 18 months of birth; and Abortion and abortion-related services,including preabortion and followup services.See the Diagnostic X-ray,imaging,pathology,and laboratory services and Preventive Health Services sections for information about coverage of genetic testing and diagnostic procedures related to pregnancy and maternity care.The Newborns\\u2019 and Mothers\\u2019 Health Protection Act requires health plans to provide a minimum Hospital stay for the mother and newborn child of 48 hours after a normal,vaginal delivery and 96 hours after a C-section.The attending Physician,in consultation with the mother,may determine that a shorter length of stay is adequate.If your Hospital stay is shorter than the minimum stay,you can receive a follow-up visit with a Health Care Provider whose scope of practice includes postpartum and newborn care.This follow-up visit may occur at home or as an outpatient,as necessary.This visit will include parent education,assistance and training in breast or bottle feeding,and any necessary physical assessments for the mother and child.Prior authorization is not required for this follow-up visit.\\\",\\\"eocCategories_benefitSubCategories\\\":[{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":4583,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Abortion services\\\",\\\"nexusId\\\":59,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":59,\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Incomplete - Missed Abortion (Non-Induced) Professional - All\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Abortion Services\\\",\\\"nexusId\\\":1070},{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":4590,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Circumcision\\\",\\\"nexusId\\\":135,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Routine Newborn Circumcision - IP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4591,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Nursery charges\\\",\\\"nexusId\\\":563,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Prenatal and Postnatal,including delivery Professional Services - IP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Newborn Services\\\",\\\"nexusId\\\":1072},{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":4585,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Anesthesia\\\",\\\"nexusId\\\":361,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Anesthesia - Prenatal and Postnatal,including delivery Professional Services - IP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4589,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Certified nurse midwife non-RN\\\",\\\"nexusId\\\":362,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"Not Covered\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":313,\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Licensed midwife - Non RN - IP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Not Covered\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4587,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Certified nurse midwife RN\\\",\\\"nexusId\\\":567,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Certified nurse midwife - RN - IP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4586,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Hospital Services\\\",\\\"nexusId\\\":132,\\\"providerCostShares\\\":[{\\\"copayAmt\\\":600,\\\"copayInterval\\\":\\\"per day\\\",\\\"costShareText\\\":\\\"$600 per day\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":75,\\\"memberMax\\\":\\\"$600 per day up to 5 days per admission\\\",\\\"memberMaxAmount\\\":600,\\\"memberMaxInterval\\\":\\\"per day up to 5 days per admission\\\",\\\"memberMaxText\\\":\\\"$600 per day up to 5 days per admission.\\\",\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Facility Services; Room and Board,Delivery Room,Specialty Care units,nursery care,Cesarean Section,and complications of Pregnancy\\\",\\\"oopmApplies\\\":true,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"Copay\\\",\\\"subjectToDeductible\\\":true,\\\"tieredBenefit\\\":false}]},{\\\"categoryBenefitId\\\":4588,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Physician Services\\\",\\\"nexusId\\\":563,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":121,\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Prenatal and Postnatal,including delivery Professional Services - IP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Delivery\\\",\\\"nexusId\\\":1071},{\\\"benefits\\\":[{\\\"categoryBenefitId\\\":4592,\\\"isCustomBenefit\\\":false,\\\"name\\\":\\\"Pre/Postnatal Visits\\\",\\\"nexusId\\\":139,\\\"providerCostShares\\\":[{\\\"costShareText\\\":\\\"No Charge\\\",\\\"customDeductibleName\\\":\\\"\\\",\\\"isCarvedOut\\\":false,\\\"mappedBenefitId\\\":139,\\\"nexusBenefitCategory\\\":\\\"Pregnancy Maternity\\\",\\\"nexusBenefitName\\\":\\\"Prenatal and Postnatal,including delivery Professional Services - OP\\\",\\\"oopmApplies\\\":false,\\\"providerCostShareType\\\":\\\"HMO Provider\\\",\\\"structureType\\\":\\\"No Charge\\\",\\\"subjectToDeductible\\\":false,\\\"tieredBenefit\\\":false}]}],\\\"name\\\":\\\"Pregnancy and Maternity\\\",\\\"nexusId\\\":1073}]}\"}]"

# COMMAND ----------

context=context

# COMMAND ----------

metrics = NexusMetrics() 
result = metrics.compute_metrics_for_query( response_text=df["assistant_answer"][0], ground_truth=df["ground_truth"][0], context_items=context)
print(result)
