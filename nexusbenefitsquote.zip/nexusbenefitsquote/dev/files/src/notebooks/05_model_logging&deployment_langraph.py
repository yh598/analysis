# Databricks notebook source
# MAGIC %pip install --upgrade \
# MAGIC   mlflow[databricks]>=3.1.3 \
# MAGIC   databricks-langchain \
# MAGIC   langchain>=0.3.0 \
# MAGIC   langgraph \
# MAGIC   databricks-vectorsearch>=0.40 \
# MAGIC   pyyaml \
# MAGIC     psycopg[binary]\
# MAGIC   databricks-agents \
# MAGIC   rapidfuzz\
# MAGIC   ftfy
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from databricks.sdk import WorkspaceClient



# COMMAND ----------

from tool_desc import *

# COMMAND ----------

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from typing import *
import os
from databricks.vector_search.client import VectorSearchClient
# Databricks LLM client
from databricks_langchain import ChatDatabricks
from databricks.vector_search.reranker import DatabricksReranker


# Pydantic v2
from pydantic import BaseModel, Field
import mlflow
import yaml


# COMMAND ----------

dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()
dbutils.widgets.text("environment", "dev")
env: str = dbutils.widgets.get("environment").lower()


# COMMAND ----------



config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

# Extract variable from YAML configuration file
project_name = config['project_name']
warehouse_name=config["warehouse"]
print(warehouse_name)


# COMMAND ----------

def get_warehouse_id_by_name(warehouse_name: str):
    client = WorkspaceClient()
    warehouses = client.warehouses.list()  # returns list of SQL warehouses

    for wh in warehouses:
        if wh.name == warehouse_name:
            return wh.id

    raise ValueError(f"Warehouse '{warehouse_name}' not found")

warehouse_id=get_warehouse_id_by_name(warehouse_name)

# COMMAND ----------

schema_gold=config["schema_name_gold"]
schema_silver=config["schema_name_silver"]

spark.sql(f"create schema if not exists {env}_adb.{schema_gold}")

# COMMAND ----------

LLM_ENDPOINT_PRIMARY=config["LLM_ENDPOINT_PRIMARY"]
LLM_ENDPOINT_SECONDARY=config["LLM_ENDPOINT_SECONDARY"]

# COMMAND ----------

def start_mlflow_experiment(experiment_name):
   

    # Define the experiment path in the user's workspace
    experiment_base_path = f"/Workspace/Shared"
    experiment_path = f"{experiment_base_path}/{experiment_name}"



    # Set the experiment (creates if not exists) and return experiment metadata
    experiment = mlflow.set_experiment(experiment_path)
    return experiment

# Usage
experiment_tag = "Benefit_Quote_MVP1"
experiment=start_mlflow_experiment(experiment_tag)


# COMMAND ----------


import json
import mlflow
from mlflow.models.resources import DatabricksVectorSearchIndex,DatabricksServingEndpoint,DatabricksSQLWarehouse,DatabricksTable
mlflow.set_registry_uri("databricks-uc")

input_example = {
    "input": [
        {
            "role": "user",
            "content": [
                {"type": "input_text", "text": "what is the cost share for emergency room?"}
            ],
        }
    ],
    "custom_inputs": {
        "user_id": "u-123",
        "username": "Priyanka",
        "session_id": "s-456",
        "question_id": "q-789",
        "facets_product_id": "MG011320",
        "effective_date": "20240101"
    },
}
runtime_cfg = {"env": env}
VS_ENDPOINT="benefit_quote_test"
cfg_path = "runtime_cfg.json"
with open(cfg_path, "w") as f:
    json.dump(runtime_cfg, f)
with mlflow.start_run(run_name="register-agent_langraph"):

    mlflow.pyfunc.log_model(
        artifact_path="benefit_agent_langraph",
        python_model="../utilities/LLM_pipeline/benefit_agent_mlflow_utils_log.py",
        code_paths=["tool_desc"],
        #code_paths=["../utilities"],
        artifacts={"configs": "../configs", "run_cfg": cfg_path},
        pip_requirements=[
            "mlflow>=3.1.3",
            "pyyaml",
            "databricks-langchain",
            "langchain>=0.3.0",
            "langgraph",
            "databricks-vectorsearch>=0.40",
            "rapidfuzz",
            "ftfy",
            "psycopg[binary]"
        ],
        resources=[
            # Use the FULL UC name: <catalog>.<schema>.<index_name>
            DatabricksVectorSearchIndex(
                #endpoint_name=VS_ENDPOINT,
                index_name=f"{env}_adb.nexusbenefitsquote_gold_mvp1.tbl_eoc_categories_index"
            ),
            
            DatabricksVectorSearchIndex(
                #endpoint_name=VS_ENDPOINT,
                index_name=f"{env}_adb.nexusbenefitsquote_silver_mvp1.tbl_eoc_program_categories_index"
            ),
            DatabricksServingEndpoint(
                endpoint_name=f"{LLM_ENDPOINT_PRIMARY}"
            ),
            DatabricksServingEndpoint(
                endpoint_name=f"{LLM_ENDPOINT_SECONDARY}"
            ),
            DatabricksSQLWarehouse(
                warehouse_id=warehouse_id
            ),
            DatabricksTable(table_name=f"{env}_adb.{schema_silver}.tbl_plan_details"),
            DatabricksTable(table_name=f"{env}_adb.{schema_silver}.tbl_eoc_sections")
        ],
       

        input_example=input_example,
        # registered_model_name=f"{env}_adb.{schema_gold}.mvp1-gpt5-backup",
        registered_model_name=f"{env}_adb.{schema_gold}.mvp1-gpt5-backup",
    )

# COMMAND ----------

from mlflow import MlflowClient

# model_name = f"{env}_adb.nexusbenefitsquote_gold_mvp1.mvp1-gpt5-backup"
model_name = f"{env}_adb.nexusbenefitsquote_gold_mvp1.mvp1-gpt5-backup"
client = MlflowClient()

# returns ModelVersion objects in newest-first order
latest = client.search_model_versions(
    filter_string=f"name='{model_name}'",
    max_results=1
)[0]
latest_version = int(latest.version)
print(latest_version)



# COMMAND ----------

print(type(latest_version))

# COMMAND ----------

# MAGIC %skip
# MAGIC import mlflow.pyfunc
# MAGIC import pandas as pd
# MAGIC input_example = {
# MAGIC     "input": [
# MAGIC         {
# MAGIC             "role": "user",
# MAGIC             "content": [
# MAGIC                 {"type": "input_text", "text": "Am I covered out of state?"}
# MAGIC             ],
# MAGIC         }
# MAGIC     ],
# MAGIC     "custom_inputs": {
# MAGIC         "user_id": "u-123",
# MAGIC         "username": "Priyanka",
# MAGIC         "session_id": "s-456",
# MAGIC         "question_id": "q-789",
# MAGIC         "facets_product_id": "MG011320",
# MAGIC         "effective_date": "20240101"
# MAGIC     },
# MAGIC }
# MAGIC df = input_example
# MAGIC model = mlflow.pyfunc.load_model(f"models:/{env}_adb.{schema_gold}.mvp1/{latest_version}")
# MAGIC print( model.predict(df))
# MAGIC

# COMMAND ----------

from databricks import agents


# registered_model_name = f"{env}_adb.{schema_gold}.mvp1-gpt5-backup"
registered_model_name = f"{env}_adb.{schema_gold}.mvp1-gpt5-backup"
print(registered_model_name)
#custom_endpoint_name = "agents-benefits_quote_gold-benefit_quote_MVP1"

deployment = agents.deploy( registered_model_name, latest_version,workload_size="Medium",scale_to_zero=False)
agents.set_review_instructions(registered_model_name, "Thank you for testing Benefit insurance agent. Ask an appropriate question and use your domain expertise to evaluate and give feedback on the agent's responses.")

agents.set_review_instructions(
    registered_model_name,
    "Thank you for testing Benefit insurance agent. Ask an appropriate question and use your domain expertise to evaluate and give feedback on the agent's responses."
)

# COMMAND ----------

# from databricks import agents
# model_name = "benefit_model_content"

# registered_model_name = f"dev_adb.benefits_quote_gold.benefit_model_content"

# deployment = agents.deploy(registered_model_name, 16, scale_to_zero=True,)
# agents.set_review_instructions(registered_model_name, "Thank you for testing Benefit insurance agent. Ask an appropriate question and use your domain expertise to evaluate and give feedback on the agent's responses.")