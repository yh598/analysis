import os
import json
import random
import glob
import logging
import gevent
from datetime import datetime, timedelta
from typing import List, Dict, Any
from locust import FastHttpUser, task
from threading import Lock
import time

VECTOR_SEARCH_INDEX_PATH= os.environ.get("VECTOR_SEARCH_INDEX_PATH")

COLUMNS_TO_RETURN = os.environ.get("COLUMNS_TO_RETURN", "benefit_id,eocCategories_content")
COLUMNS_TO_RETURN = [
        col.strip()
        for col in COLUMNS_TO_RETURN.split(",")
        if col.strip()
    ]
# Retrieve Databricks token from environment or fail if not set
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
assert DATABRICKS_TOKEN, "DATABRICKS_TOKEN environment variable must be set"

class VectorSearchLoadTestUser(FastHttpUser):
    search_queries: List[Dict[str, Any]] = []
    data_loading: bool = False
    _lock = Lock()

    @classmethod
    def _load_queries_streaming(cls):
        """Load queries file by file, appending as we go."""
        cls.data_loading = True

        input_file = os.environ.get("INPUT_FILE")
        if input_file and os.path.exists(input_file):
            logging.info(f"Loading single file {input_file}")
            with open(input_file, "r") as f:
                data = json.load(f)
                with cls._lock:
                    cls.search_queries.extend(data if isinstance(data, list) else [data])
            cls.data_loading = False
            return

        input_folder = os.environ.get("INPUT_FOLDER", ".")
        input_pattern = os.environ.get("INPUT_FILE_PATTERN", "vector_search_input*.json")
        search_path = os.path.join(input_folder, input_pattern)
        input_files = glob.glob(search_path) or glob.glob("vector_search_input*.json") or glob.glob("*.json")

        for file_path in input_files:
            try:
                with open(file_path, "r") as f:
                    data = json.load(f)
                    with cls._lock:
                        cls.search_queries.extend(data if isinstance(data, list) else [data])
                logging.info(f"Loaded queries from {file_path}, total so far: {len(cls.search_queries)}")
                gevent.sleep(0)  # yield control so workers can use loaded queries
            except Exception as e:
                logging.warning(f"Could not load {file_path}: {e}")

        cls.data_loading = False
        logging.info(f"Finished loading all queries: {len(cls.search_queries)}")

    @classmethod
    def start_background_loader(cls):
        if not cls.data_loading and not cls.search_queries:
            gevent.spawn(cls._load_queries_streaming)

    def on_start(self):
        """Initialize env vars and kick off background loader."""
        self.index_query_path = os.environ.get("VECTOR_SEARCH_INDEX_PATH")
        assert self.index_query_path and self.index_query_path.startswith("/"), \
            "VECTOR_SEARCH_INDEX_PATH must be set to a relative path starting with '/'"
        self.start_background_loader()

    def get_next_query(self) -> Dict[str, Any]:
        """Return a query if available, else dummy fallback."""
        with self._lock:
            if self.search_queries:
                query = random.choice(self.search_queries)
                # Ensure query_vector is a list, not a string
                if isinstance(query.get("query_vector"), str):
                    import ast
                    try:
                        query["query_vector"] = ast.literal_eval(query["query_vector"])
                    except Exception:
                        query["query_vector"] = [0.0] * 1024
                return query
        # fallback: use correct vector dimension and columns
        return {
            "query_vector": [0.0] * 1024,
            "num_results": 3,
            "columns": COLUMNS_TO_RETURN
        }

    def vector_dimension(self, vector, dim=1024):
        # If vector is a string, try to parse it as a list
        if isinstance(vector, str):
            import ast
            try:
                vector = ast.literal_eval(vector)
            except Exception:
                raise ValueError("query_vector is a string and could not be parsed as a list.")
        if not isinstance(vector, list):
            raise ValueError("query_vector must be a list of floats.")
        return (vector + [0.0] * dim)[:dim]

    @task
    def query_vector_search_ann(self):
        headers = {
            "Authorization": f"Bearer {DATABRICKS_TOKEN}",
            "Content-Type": "application/json"
        }
        search_input = self.get_next_query()

        ann_payload = {
            "num_results": search_input.get("num_results", 10),
            "query_vector": self.vector_dimension(search_input["query_vector"]),
            "columns": search_input.get("columns", COLUMNS_TO_RETURN)
        }
        if "filters" in search_input:
            ann_payload["filters"] = search_input["filters"]
        if "score_threshold" in search_input:
            ann_payload["score_threshold"] = search_input["score_threshold"]

        with self.client.post(
            self.index_query_path,
            headers=headers,
            json=ann_payload,
            catch_response=True,
            name="vector_search_query",
        ) as response:
            if response.status_code == 200:
                response.success()
            elif response.status_code in [429, 499]:
                retry_after = response.headers.get("Retry-After") or response.headers.get("retry-after") or "3"
                time.sleep(float(retry_after))
                response.failure(
                    f"Query failed: {response.status_code} {response.headers} {response.text}"
                )
            else:
                response.failure(
                    f"Query failed: {response.status_code} {response.headers} {response.text}"
                )