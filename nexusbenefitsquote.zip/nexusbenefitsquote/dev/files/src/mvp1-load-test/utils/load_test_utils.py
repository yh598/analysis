import os
import json
from locust import FastHttpUser, task, constant_throughput, events
from locust.env import Environment
import psutil
import gevent
import requests
from datetime import datetime, timedelta
from typing import Tuple
import time
import logging

class LoadTestUser(FastHttpUser):

    CUSTOM_AGENT_INVOCATION = ""
    EMBEDDING_INVOCATION = ""
    GPT_INVOCATION = ""

    def on_start(self):
        if "agent" in self.host:
            input_json_file = "agent.json"
            CUSTOM_AGENT_INVOCATION = os.environ.get("CUSTOM_AGENT_INVOCATION")

        elif "bge" in self.host:
            input_json_file = "embedding.json"
            EMBEDDING_INVOCATION = os.environ.get("EMBEDDING_INVOCATION")

        elif "gpt" in self.host:
            input_json_file = "gpt5.json"
            GPT_INVOCATION = os.environ.get("GPT_INVOCATION")
        else:
            raise ValueError(f"Unknown host for input selection: {self.host}")

        with open(f"./../input_json/{input_json_file}", "r") as json_features:
            self.invocation_input = json.load(json_features)
        self.oauth = os.environ["DATABRICKS_TOKEN"]

    @task
    def query_single_model(self):
        headers = {"Authorization": f"Bearer {self.oauth}"}
        url= self.host
        print(f"Sending request to {url}")
        response= self.client.post("", headers=headers, json=self.invocation_input)
        print(f"Received response {response.text}")