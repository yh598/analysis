# Nexus Benefits Load Testing Framework

## Project Overview

This project implements a comprehensive load testing framework for the Nexus Benefits application using Locust. It tests multiple endpoints including the Agent API, Embedding service, GPT model, and Vector Search index to ensure system reliability and performance under various load conditions.

---

## Table of Contents

1. [Project Structure](#project-structure)
2. [Installation & Setup](#installation--setup)
3. [Core Components](#core-components)
4. [Utility Modules](#utility-modules)
5. [Helper Modules](#helper-modules)
6. [Usage Guide](#usage-guide)
7. [Configuration](#configuration)
8. [Output Reports](#output-reports)
9. [Monitoring & Metrics](#monitoring--metrics)

---

## Project Structure

```
mvp1-load-test/
├── agent_load_test_report/          # Agent endpoint test results
│   ├── agent_load_test_exceptions.csv
│   ├── agent_load_test_failures.csv
│   ├── agent_load_test_stats.csv
│   └── agent_load_test_stats_history.csv
├── embedding_load_test_report/      # Embedding service test results
│   ├── embedding_load_test_exceptions.csv
│   ├── embedding_load_test_failures.csv
│   ├── embedding_load_test_stats.csv
│   └── embedding_load_test_stats_history.csv
├── gpt_load_test_report/            # GPT model test results
│   ├── gpt_load_test_exceptions.csv
│   ├── gpt_load_test_failures.csv
│   ├── gpt_load_test_stats.csv
│   └── gpt_load_test_stats_history.csv
├── vector_search_load_test_report/  # Vector search test results
│   ├── vectorsearch_exceptions.csv
│   ├── vectorsearch_failures.csv
│   ├── vectorsearch_stats.csv
│   └── vectorsearch_stats_history.csv
├── input_json/                      # Test input configurations
│   ├── agent.json
│   ├── embedding.json
│   ├── gpt5.json
│   ├── vector_search_input.json
│   └── vector_search_input_batch_0.json
├── main/                            # Main orchestration scripts
│   └── main_load_test.py
└── utils/                           # Utility modules
    ├── load_test_utils.py           # Generic load testing utilities
    └── vs_load_test.py              # Vector search specific utilities
```

---

## Installation & Setup

### Prerequisites

* Python 3.8+
* Databricks workspace access
* Locust 2.0+
* Valid Databricks authentication token

### Installation

```bash
# Install core dependencies
pip install locust psutil gevent requests pandas

# Set environment variables
export DATABRICKS_TOKEN="your_databricks_token"
export VECTOR_SEARCH_INDEX_PATH="/path/to/vector/search/index"
```

### Environment Configuration

```python
# Required environment variables
DATABRICKS_TOKEN = "dapi..."
VECTOR_SEARCH_INDEX_PATH = "/api/2.0/vector-search/indexes/..."
CUSTOM_AGENT_INVOCATION = "agent_endpoint_url"
EMBEDDING_INVOCATION = "embedding_endpoint_url"
GPT_INVOCATION = "gpt_endpoint_url"

# Optional configuration
INPUT_FILE = "path/to/single/input.json"
INPUT_FOLDER = "./input_json"
INPUT_FILE_PATTERN = "vector_search_input*.json"
COLUMNS_TO_RETURN = "benefit_id,eocCategories_content"
```

---

## Core Components

### 1. Main Load Test Orchestrator

**Location:** `main/main_load_test.py`

The main orchestration notebook that coordinates load testing across all endpoints.

#### Key Features:

* **Multi-endpoint testing**: Simultaneously tests Agent, Embedding, GPT, and Vector Search endpoints
* **Configurable load patterns**: Supports various user spawn rates and test durations
* **Automated reporting**: Generates CSV reports and writes to Delta tables
* **CPU monitoring**: Tracks CPU usage during agent endpoint tests

#### Configuration Parameters:

```python
# Test configuration
environment = "dev"  # or "prod"
schema = f"{environment}_adb.nexusbenefitsquote_gold_mvp1"

# Endpoint names
agent_endpoint_name = "nexus-benefits-agent-endpoint"
embedding_endpoint_name = "bge-large-en-v1-5-endpoint"
gpt_endpoint_name = "accenture-azure-gpt-4o-endpoint"
ENDPOINT_NAME = "vector-search-endpoint"

# Output paths
csv_output_prefix_agent = "./agent_load_test_report/agent_load_test"
csv_output_prefix_embedding = "./embedding_load_test_report/embedding_load_test"
csv_output_prefix_gpt = "./gpt_load_test_report/gpt_load_test"
csv_output_prefix_vector_search = "./vector_search_load_test_report/vectorsearch"
```

---

### 2. Load Test Execution Flow

#### Step 1: Initialize Test Environment

```python
# Set up environment
dbutils.widgets.text("environment", "dev")
env = dbutils.widgets.get("environment").lower()

# Configure endpoints
agent_endpoint_name = "nexus-benefits-agent-endpoint"
embedding_endpoint_name = "bge-large-en-v1-5-endpoint"
```

#### Step 2: Run Load Tests

```python
# Execute Locust tests for each endpoint
# Tests run in parallel using subprocess
import subprocess

# Agent endpoint test
subprocess.run([
    "locust",
    "-f", "utils/load_test_utils.py",
    "--host", agent_endpoint_url,
    "--users", "10",
    "--spawn-rate", "2",
    "--run-time", "60s",
    "--csv", csv_output_prefix_agent
])
```

#### Step 3: Collect and Process Results

```python
# Read CSV outputs
stats_df = pd.read_csv(f"{csv_output_prefix_agent}_stats.csv")
failures_df = pd.read_csv(f"{csv_output_prefix_agent}_failures.csv")
exceptions_df = pd.read_csv(f"{csv_output_prefix_agent}_exceptions.csv")

# Add metadata
stats_df["start_time"] = datetime.now()
stats_df["endpoint_details"] = agent_endpoint_name
```

#### Step 4: Write to Delta Tables

```python
# Write to Delta Lake
spark_df = spark.createDataFrame(stats_df)
spark_df.write.format("delta").mode("append").saveAsTable(
    f"{schema}.tbl_mvp1_load_test_stats"
)
```

---

## Utility Modules

### 1. Generic Load Test Utilities

**File:** `utils/load_test_utils.py`  
**Purpose:** Reusable load testing utilities for Agent, Embedding, and GPT endpoints

#### Class: `LoadTestUser`

```python
class LoadTestUser(FastHttpUser):
    """
    Generic load test user for Databricks model serving endpoints.
    Automatically selects input JSON based on endpoint type.
    """
    
    def on_start(self):
        """
        Initialize test user with appropriate input configuration.
        Detects endpoint type from host URL and loads corresponding JSON.
        """
```

**Key Features:**

* **Automatic input selection**: Detects endpoint type from host URL
* **OAuth authentication**: Uses Databricks token for authorization
* **Flexible configuration**: Supports multiple endpoint types

**Endpoint Detection Logic:**

```python
if "agent" in self.host:
    input_json_file = "agent.json"
    CUSTOM_AGENT_INVOCATION = os.environ.get("CUSTOM_AGENT_INVOCATION")

elif "bge" in self.host:
    input_json_file = "embedding.json"
    EMBEDDING_INVOCATION = os.environ.get("EMBEDDING_INVOCATION")

elif "gpt" in self.host:
    input_json_file = "gpt5.json"
    GPT_INVOCATION = os.environ.get("GPT_INVOCATION")
```

#### Method: `query_single_model`

```python
@task
def query_single_model(self):
    """
    Execute a single request to the model serving endpoint.
    
    Process:
    1. Prepare OAuth headers
    2. Send POST request with invocation input
    3. Log response
    
    Used by: Locust to generate load
    """
    headers = {"Authorization": f"Bearer {self.oauth}"}
    response = self.client.post("", headers=headers, json=self.invocation_input)
```

**Usage Example:**

```bash
# Run load test for agent endpoint
locust -f utils/load_test_utils.py \
    --host https://your-workspace.databricks.com/serving-endpoints/agent \
    --users 50 \
    --spawn-rate 5 \
    --run-time 5m \
    --csv agent_load_test
```

---

### 2. Vector Search Load Test Utilities

**File:** `utils/vs_load_test.py`  
**Purpose:** Specialized utilities for vector search index load testing

#### Class: `VectorSearchLoadTestUser`

```python
class VectorSearchLoadTestUser(FastHttpUser):
    """
    Load test user for Databricks Vector Search indexes.
    Supports streaming query loading and ANN search operations.
    """
    
    search_queries: List[Dict[str, Any]] = []
    data_loading: bool = False
    _lock = Lock()
```

**Key Features:**

* **Streaming query loading**: Loads queries incrementally to avoid memory issues
* **Thread-safe operations**: Uses locks for concurrent access
* **Flexible input sources**: Supports single file or folder with pattern matching
* **Automatic vector dimension handling**: Ensures correct vector dimensions (1024)

---

#### Method: `_load_queries_streaming`

```python
@classmethod
def _load_queries_streaming(cls):
    """
    Load queries file by file, appending as we go.
    
    Process:
    1. Check for single INPUT_FILE first
    2. If not found, scan INPUT_FOLDER with INPUT_FILE_PATTERN
    3. Load each file and append to search_queries
    4. Yield control between files (gevent.sleep)
    
    Why streaming: Large query sets can exceed memory limits.
    Loading incrementally allows tests to start before all data is loaded.
    """
```

**Input File Priority:**

1. `INPUT_FILE` environment variable (single file)
2. `INPUT_FOLDER` + `INPUT_FILE_PATTERN` (multiple files)
3. Fallback: `vector_search_input*.json` in current directory

**Example:**

```python
# Single file mode
export INPUT_FILE="./input_json/vector_search_input.json"

# Multi-file mode
export INPUT_FOLDER="./input_json"
export INPUT_FILE_PATTERN="vector_search_input_batch_*.json"
```

---

#### Method: `get_next_query`

```python
def get_next_query(self) -> Dict[str, Any]:
    """
    Return a query if available, else dummy fallback.
    
    Thread-safe query selection:
    - Acquires lock
    - Randomly selects from loaded queries
    - Ensures query_vector is a list (not string)
    - Returns fallback if no queries loaded yet
    
    Fallback query:
    {
        "query_vector": [0.0] * 1024,
        "num_results": 3,
        "columns": ["benefit_id", "eocCategories_content"]
    }
    """
```

**Query Format:**

```json
{
    "query_vector": [0.1, 0.2, ..., 0.0],  // 1024 dimensions
    "num_results": 10,
    "columns": ["benefit_id", "eocCategories_content"],
    "filters": {
        "facets_product_id": "MG011320",
        "effective_date": "20240101"
    },
    "score_threshold": 0.5
}
```

---

#### Method: `vector_dimension`

```python
def vector_dimension(self, vector, dim=1024):
    """
    Ensure vector has exactly 1024 dimensions.
    
    Handles:
    - String vectors: Parses using ast.literal_eval()
    - Short vectors: Pads with zeros
    - Long vectors: Truncates to 1024
    
    Why needed: Vector search index expects fixed dimensions.
    Mismatched dimensions cause API errors.
    """
```

**Example:**

```python
# Input: 512-dimensional vector
vector = [0.1] * 512

# Output: 1024-dimensional vector
padded = self.vector_dimension(vector)
# [0.1, 0.1, ..., 0.1, 0.0, 0.0, ..., 0.0]
#  <--- 512 --->  <--- 512 zeros --->
```

---

#### Method: `query_vector_search_ann`

```python
@task
def query_vector_search_ann(self):
    """
    Execute ANN (Approximate Nearest Neighbor) search query.
    
    Process:
    1. Get next query from queue
    2. Prepare ANN payload with vector, num_results, columns
    3. Add optional filters and score_threshold
    4. Send POST request to vector search index
    5. Handle rate limiting (429, 499) with retry
    
    Rate Limiting:
    - Status 429/499: Extract Retry-After header
    - Sleep for specified duration
    - Mark as failure (Locust will retry)
    """
```

**Payload Structure:**

```python
ann_payload = {
    "num_results": 10,
    "query_vector": [0.1, 0.2, ..., 0.0],  # 1024 dims
    "columns": ["benefit_id", "eocCategories_content"],
    "filters": {"facets_product_id": "MG011320"},  # optional
    "score_threshold": 0.5  # optional
}
```

**Error Handling:**

```python
if response.status_code == 200:
    response.success()
elif response.status_code in [429, 499]:
    retry_after = response.headers.get("Retry-After", "3")
    time.sleep(float(retry_after))
    response.failure(f"Rate limited: {response.status_code}")
else:
    response.failure(f"Query failed: {response.status_code}")
```

**Usage Example:**

```bash
# Run vector search load test
export DATABRICKS_TOKEN="dapi..."
export VECTOR_SEARCH_INDEX_PATH="/api/2.0/vector-search/indexes/catalog.schema.index/query"
export INPUT_FOLDER="./input_json"
export COLUMNS_TO_RETURN="benefit_id,eocCategories_content"

locust -f utils/vs_load_test.py \
    --host https://your-workspace.databricks.com \
    --users 100 \
    --spawn-rate 10 \
    --run-time 10m \
    --csv vectorsearch_load_test
```

---

## Helper Modules

### Input JSON Configurations

**Location:** `input_json/`

#### 1. Agent Input (`agent.json`)

```json
{
  "input": [
    {
      "role": "user",
      "content": [
        {
          "type": "input_text",
          "text": "what is the cost share for emergency room?"
        }
      ]
    }
  ],
  "custom_inputs": {
    "user_id": "databricks-load-test",
    "username": "databricks-load-test",
    "session_id": "s-897",
    "question_id": "q-981",
    "facets_product_id": "MG011320",
    "effective_date": "20240101"
  }
}
```

**Purpose:** Test agent endpoint with realistic user queries

---

#### 2. Embedding Input (`embedding.json`)

```json
{
  "inputs": [
    "What is the copay for emergency room visits?",
    "Does this plan cover mental health services?",
    "What is the out-of-pocket maximum?"
  ]
}
```

**Purpose:** Test embedding model with various text inputs

---

#### 3. GPT Input (`gpt5.json`)

```json
{
  "messages": [
    {
      "role": "user",
      "content": "Given the user query: what is copay for my PCP visit?\n\nUse the following information to formulate your answer:\n- Insurance plan data: {...}"
    }
  ],
  "reasoning_effort": "minimal"
}
```

**Purpose:** Test GPT model with complex prompts including plan data

---

#### 4. Vector Search Input (`vector_search_input.json`)

```json
[
  {
    "query_vector": [0.1, 0.2, ..., 0.0],
    "num_results": 3,
    "columns": ["benefit_id", "eocCategories_content"],
    "filters": {
      "facets_product_id": "MG011320",
      "effective_date": "20240101"
    }
  }
]
```

**Purpose:** Test vector search with pre-computed embeddings

---

## Usage Guide

### Running a Complete Load Test

#### Step 1: Configure Environment

```python
# In Databricks notebook
dbutils.widgets.text("environment", "dev")
environment = dbutils.widgets.get("environment").lower()

# Set endpoint names
agent_endpoint_name = "nexus-benefits-agent-endpoint"
embedding_endpoint_name = "bge-large-en-v1-5-endpoint"
gpt_endpoint_name = "accenture-azure-gpt-4o-endpoint"
ENDPOINT_NAME = "vector-search-endpoint"
```

#### Step 2: Run Individual Endpoint Tests

**Agent Endpoint:**

```bash
locust -f utils/load_test_utils.py \
    --host https://workspace.databricks.com/serving-endpoints/agent \
    --users 50 \
    --spawn-rate 5 \
    --run-time 5m \
    --csv ./agent_load_test_report/agent_load_test \
    --headless
```

**Embedding Endpoint:**

```bash
locust -f utils/load_test_utils.py \
    --host https://workspace.databricks.com/serving-endpoints/embedding \
    --users 100 \
    --spawn-rate 10 \
    --run-time 5m \
    --csv ./embedding_load_test_report/embedding_load_test \
    --headless
```

**GPT Endpoint:**

```bash
locust -f utils/load_test_utils.py \
    --host https://workspace.databricks.com/serving-endpoints/gpt \
    --users 30 \
    --spawn-rate 3 \
    --run-time 5m \
    --csv ./gpt_load_test_report/gpt_load_test \
    --headless
```

**Vector Search:**

```bash
export VECTOR_SEARCH_INDEX_PATH="/api/2.0/vector-search/indexes/catalog.schema.index/query"
export INPUT_FOLDER="./input_json"

locust -f utils/vs_load_test.py \
    --host https://workspace.databricks.com \
    --users 100 \
    --spawn-rate 10 \
    --run-time 10m \
    --csv ./vector_search_load_test_report/vectorsearch \
    --headless
```

#### Step 3: Process Results

The main notebook automatically processes CSV outputs and writes to Delta tables:

```python
# Stats table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {schema}.tbl_mvp1_load_test_stats (
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    type STRING,
    name STRING,
    request_count STRING,
    failure_count STRING,
    median_response_time STRING,
    average_response_ms STRING,
    min_response_time STRING,
    max_response_time STRING,
    average_content_size STRING,
    requests STRING,
    failures STRING,
    cpu STRING,
    file_name STRING,
    endpoint_details STRING
) USING DELTA
""")
```

#### Step 4: Analyze Results

```python
# Query aggregated stats
stats_df = spark.sql(f"""
    SELECT 
        endpoint_details,
        AVG(CAST(average_response_ms AS DOUBLE)) as avg_response_time,
        SUM(CAST(request_count AS INT)) as total_requests,
        SUM(CAST(failure_count AS INT)) as total_failures,
        MAX(CAST(max_response_time AS DOUBLE)) as max_response_time
    FROM {schema}.tbl_mvp1_load_test_stats
    WHERE start_time >= current_date()
    GROUP BY endpoint_details
""")
display(stats_df)
```

---

## Configuration

### Environment Variables

```python
# Authentication
DATABRICKS_TOKEN = "dapi..."

# Vector Search
VECTOR_SEARCH_INDEX_PATH = "/api/2.0/vector-search/indexes/..."
COLUMNS_TO_RETURN = "benefit_id,eocCategories_content"

# Input Configuration
INPUT_FILE = "path/to/single/input.json"  # Optional
INPUT_FOLDER = "./input_json"
INPUT_FILE_PATTERN = "vector_search_input*.json"

# Endpoint URLs
CUSTOM_AGENT_INVOCATION = "https://workspace.databricks.com/serving-endpoints/agent"
EMBEDDING_INVOCATION = "https://workspace.databricks.com/serving-endpoints/embedding"
GPT_INVOCATION = "https://workspace.databricks.com/serving-endpoints/gpt"
```

### Locust Configuration

```python
# Load test parameters
--users 100              # Total number of concurrent users
--spawn-rate 10          # Users spawned per second
--run-time 10m           # Test duration
--csv output_prefix      # CSV output file prefix
--headless               # Run without web UI
```

### Delta Table Schema

```python
# Environment-specific schema
environment = "dev"  # or "prod"
schema = f"{environment}_adb.nexusbenefitsquote_gold_mvp1"

# Tables created:
# 1. tbl_mvp1_load_test_stats
# 2. tbl_mvp1_load_test_stats_history
# 3. tbl_mvp1_load_test_error_exception
```

---

## Output Reports

### 1. Stats CSV (`*_stats.csv`)

**Columns:**

* `Type`: Request type (e.g., "POST")
* `Name`: Endpoint name
* `Request Count`: Total requests
* `Failure Count`: Failed requests
* `Median Response Time`: 50th percentile (ms)
* `Average Response Time`: Mean response time (ms)
* `Min Response Time`: Fastest response (ms)
* `Max Response Time`: Slowest response (ms)
* `Average Content Size`: Mean response size (bytes)
* `Requests/s`: Throughput
* `Failures/s`: Failure rate

**Example:**

```csv
Type,Name,Request Count,Failure Count,Median Response Time,Average Response Time,Min Response Time,Max Response Time,Average Content Size,Requests/s,Failures/s
POST,vector_search_query,1000,5,250,275,120,1500,2048,16.67,0.08
```

---

### 2. Stats History CSV (`*_stats_history.csv`)

**Columns:**

* `Timestamp`: Time of measurement
* `User Count`: Active users at timestamp
* `Name`: Endpoint name
* `Requests/s`: Throughput at timestamp
* `Failures/s`: Failure rate at timestamp
* `Total Request Count`: Cumulative requests
* `Total Failure Count`: Cumulative failures
* `Total Median Response Time`: Cumulative median (ms)
* `Total Average Response Time`: Cumulative average (ms)
* `Total Min Response Time`: Cumulative min (ms)
* `Total Max Response Time`: Cumulative max (ms)
* `Total Average Content Size`: Cumulative avg size (bytes)

**Purpose:** Track performance over time during test execution

---

### 3. Failures CSV (`*_failures.csv`)

**Columns:**

* `Method`: HTTP method
* `Name`: Endpoint name
* `Error`: Error message
* `Occurrences`: Number of times error occurred

**Example:**

```csv
Method,Name,Error,Occurrences
POST,vector_search_query,"Query failed: 429 Rate limit exceeded",15
POST,agent_endpoint,"Query failed: 500 Internal Server Error",2
```

---

### 4. Exceptions CSV (`*_exceptions.csv`)

**Columns:**

* `Count`: Number of exceptions
* `Message`: Exception message
* `Traceback`: Full stack trace
* `Nodes`: Worker nodes where exception occurred

**Purpose:** Debug unexpected errors and crashes

---

### 5. Delta Tables

#### `tbl_mvp1_load_test_stats`

Aggregated statistics for all endpoints:

```sql
SELECT 
    endpoint_details,
    start_time,
    end_time,
    request_count,
    failure_count,
    average_response_ms,
    cpu
FROM dev_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_load_test_stats
WHERE start_time >= current_date()
ORDER BY start_time DESC
```

#### `tbl_mvp1_load_test_stats_history`

Time-series performance data:

```sql
SELECT 
    timestamp,
    endpoint_details,
    user_count,
    requests,
    failures,
    total_average_response_time_ms
FROM dev_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_load_test_stats_history
WHERE start_time >= current_date()
ORDER BY timestamp
```

#### `tbl_mvp1_load_test_error_exception`

Error and exception logs:

```sql
SELECT 
    start_time,
    endpoint_details,
    type,
    COUNT(*) as error_count
FROM dev_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_load_test_error_exception
WHERE start_time >= current_date()
GROUP BY start_time, endpoint_details, type
```

---

## Monitoring & Metrics

### Key Performance Indicators (KPIs)

#### 1. Response Time Metrics

* **Median Response Time**: 50th percentile (target: < 500ms)
* **95th Percentile**: 95% of requests (target: < 1000ms)
* **99th Percentile**: 99% of requests (target: < 2000ms)
* **Max Response Time**: Worst-case latency

**Interpretation:**

* Median < 500ms: Good performance
* Median 500-1000ms: Acceptable
* Median > 1000ms: Performance issues

---

#### 2. Throughput Metrics

* **Requests/s**: Total throughput
* **Successful Requests/s**: Successful throughput
* **Failures/s**: Error rate

**Targets:**

* Agent: 10-20 req/s
* Embedding: 50-100 req/s
* GPT: 5-10 req/s
* Vector Search: 100-200 req/s

---

#### 3. Error Metrics

* **Failure Count**: Total failed requests
* **Failure Rate**: Failures / Total Requests
* **Error Types**: Distribution of error codes

**Targets:**

* Failure Rate < 1%: Excellent
* Failure Rate 1-5%: Acceptable
* Failure Rate > 5%: Critical

---

#### 4. Resource Metrics

* **CPU Usage**: Tracked for agent endpoint
* **Memory Usage**: Monitored via psutil
* **Network I/O**: Inferred from content size

**CPU Monitoring:**

```python
import psutil

# Track CPU during agent tests
CPU = psutil.cpu_percent(interval=1)
df["CPU"] = CPU if "agent" in endpoint_name else None
```

---

### Performance Analysis Queries

#### Average Response Time by Endpoint

```sql
SELECT 
    endpoint_details,
    AVG(CAST(average_response_ms AS DOUBLE)) as avg_response_time,
    PERCENTILE_APPROX(CAST(average_response_ms AS DOUBLE), 0.95) as p95_response_time,
    PERCENTILE_APPROX(CAST(average_response_ms AS DOUBLE), 0.99) as p99_response_time
FROM dev_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_load_test_stats
WHERE start_time >= current_date()
GROUP BY endpoint_details
```

#### Failure Rate by Endpoint

```sql
SELECT 
    endpoint_details,
    SUM(CAST(request_count AS INT)) as total_requests,
    SUM(CAST(failure_count AS INT)) as total_failures,
    ROUND(SUM(CAST(failure_count AS INT)) * 100.0 / SUM(CAST(request_count AS INT)), 2) as failure_rate_pct
FROM dev_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_load_test_stats
WHERE start_time >= current_date()
GROUP BY endpoint_details
```

#### Performance Over Time

```sql
SELECT 
    DATE_TRUNC('hour', timestamp) as hour,
    endpoint_details,
    AVG(CAST(total_average_response_time_ms AS DOUBLE)) as avg_response_time,
    AVG(CAST(requests AS DOUBLE)) as avg_throughput
FROM dev_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_load_test_stats_history
WHERE start_time >= current_date() - INTERVAL 7 DAYS
GROUP BY DATE_TRUNC('hour', timestamp), endpoint_details
ORDER BY hour DESC
```

---

## Troubleshooting

### Common Issues

#### 1. Authentication Errors

**Error:** `401 Unauthorized`

**Solution:**

```bash
# Verify token is set
echo $DATABRICKS_TOKEN

# Regenerate token if expired
# In Databricks: Settings > User Settings > Access Tokens
export DATABRICKS_TOKEN="dapi_new_token"
```

---

#### 2. Vector Dimension Mismatch

**Error:** `Vector dimension mismatch: expected 1024, got 512`

**Solution:**

```python
# Ensure vector_dimension method is called
query_vector = self.vector_dimension(raw_vector, dim=1024)

# Check input JSON
# Vectors should be 1024-dimensional or will be padded
```

---

#### 3. Rate Limiting

**Error:** `429 Too Many Requests`

**Solution:**

```python
# Reduce spawn rate
--spawn-rate 5  # Instead of 10

# Add retry logic (already implemented in vs_load_test.py)
if response.status_code in [429, 499]:
    retry_after = response.headers.get("Retry-After", "3")
    time.sleep(float(retry_after))
```

---

#### 4. Input File Not Found

**Error:** `FileNotFoundError: vector_search_input.json`

**Solution:**

```bash
# Check file exists
ls -la ./input_json/

# Set INPUT_FILE explicitly
export INPUT_FILE="./input_json/vector_search_input.json"

# Or use pattern matching
export INPUT_FOLDER="./input_json"
export INPUT_FILE_PATTERN="vector_search_input*.json"
```

---

#### 5. Delta Table Write Failures

**Error:** `AnalysisException: Table not found`

**Solution:**

```python
# Ensure schema exists
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema}")

# Verify permissions
spark.sql(f"SHOW GRANTS ON SCHEMA {schema}")

# Check table creation
spark.sql(f"DESCRIBE TABLE {schema}.tbl_mvp1_load_test_stats")
```

---

## Best Practices

### 1. Load Test Design

* **Start small**: Begin with 10 users, gradually increase
* **Monitor resources**: Track CPU, memory, network during tests
* **Test incrementally**: Test each endpoint individually before combined tests
* **Use realistic data**: Input JSONs should match production patterns

### 2. Performance Targets

* **Agent endpoint**: 10-20 req/s, < 1s response time
* **Embedding endpoint**: 50-100 req/s, < 500ms response time
* **GPT endpoint**: 5-10 req/s, < 2s response time
* **Vector search**: 100-200 req/s, < 300ms response time

### 3. Error Handling

* **Retry transient errors**: 429, 499, 503
* **Log all failures**: Write to exceptions CSV
* **Alert on thresholds**: Failure rate > 5%

### 4. Data Management

* **Archive old reports**: Move CSVs to archive folder after processing
* **Partition Delta tables**: By date for efficient queries
* **Monitor table growth**: Set retention policies

---

## Appendix

### Locust Command Reference

```bash
# Basic load test
locust -f script.py --host URL --users 100 --spawn-rate 10 --run-time 5m

# Headless mode (no web UI)
locust -f script.py --host URL --users 100 --spawn-rate 10 --run-time 5m --headless

# With CSV output
locust -f script.py --host URL --users 100 --spawn-rate 10 --run-time 5m --csv output_prefix

# Distributed mode (master)
locust -f script.py --master --expect-workers 4

# Distributed mode (worker)
locust -f script.py --worker --master-host localhost
```

### Environment Variable Reference

```bash
# Required
export DATABRICKS_TOKEN="dapi..."

# Vector Search
export VECTOR_SEARCH_INDEX_PATH="/api/2.0/vector-search/indexes/..."
export COLUMNS_TO_RETURN="benefit_id,eocCategories_content"

# Input Configuration
export INPUT_FILE="./input_json/vector_search_input.json"
export INPUT_FOLDER="./input_json"
export INPUT_FILE_PATTERN="vector_search_input*.json"

# Endpoint URLs
export CUSTOM_AGENT_INVOCATION="https://..."
export EMBEDDING_INVOCATION="https://..."
export GPT_INVOCATION="https://..."
```

---

## References

* [Locust Documentation](https://docs.locust.io/)
* [Databricks Model Serving](https://docs.databricks.com/machine-learning/model-serving/index.html)
* [Databricks Vector Search](https://docs.databricks.com/vector-search/index.html)
* [Delta Lake Documentation](https://docs.delta.io/)

---

**Last Updated:** January 2026  
**Maintained By:** MVP1 Nexus Benefits Team
**Contact:** pmane01@blueshieldca.com
