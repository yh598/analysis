# Databricks notebook source
# MAGIC %pip install gevent==24.11.1
# MAGIC %pip install locust==2.32.6
# MAGIC %pip install databricks-sdk==0.50.0
# MAGIC %pip install databricks-vectorsearch
# MAGIC %pip install --upgrade "locust" "urllib3>=2.0.0"
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import os
import pandas as pd
import requests
import matplotlib.pyplot as plt
import subprocess
import shlex
import time
import json
import random
from contextlib import contextmanager
from datetime import datetime
import shutil
import pathlib
from math import ceil
from databricks.sdk import WorkspaceClient

# COMMAND ----------

# MAGIC %md
# MAGIC Variables for Endpoints

# COMMAND ----------

dbutils.widgets.text("environment", "dev")
environment = dbutils.widgets.get("environment")

dbutils.widgets.text("agent_endpoint_name", "agents_dev_adb-nexusbenefitsquote_gold_mvp1-mvp1", "Agent Endpoint Name")
agent_endpoint_name = dbutils.widgets.get("agent_endpoint_name")

dbutils.widgets.text("embedding_endpoint_name", "databricks-bge-large-en", "Embedding Endpoint Name")
embedding_endpoint_name = dbutils.widgets.get("embedding_endpoint_name")

dbutils.widgets.text("gpt_endpoint_name", "accenture-azure-gpt-4o-2024-08-06-sp", "GPT Endpoint Name")
gpt_endpoint_name = dbutils.widgets.get("gpt_endpoint_name")

dbutils.widgets.text("all_endpoint", "", "Comma Separated Endpoint Names")
all_endpoint = dbutils.widgets.get("all_endpoint")

dbutils.widgets.text("locust_run_time", "1m", "How Long Test Should run(in mins.)")
locust_run_time = dbutils.widgets.get("locust_run_time")

dbutils.widgets.text("users", "5", "Number of Users")
users = int(dbutils.widgets.get("users"))

dbutils.widgets.text("spawn_rate", "1", "User Spawn Rate")
spawn_rate = int(dbutils.widgets.get("spawn_rate"))

dbutils.widgets.text("CPU", "LARGE", "CPU")
CPU = dbutils.widgets.get("CPU")


# COMMAND ----------

# MAGIC %md
# MAGIC Variable For Vector Search

# COMMAND ----------

# Vector Search Index configuration
dbutils.widgets.text("ENDPOINT_NAME", "benefits_quote_test", "Vector Search Endpoint Name")
ENDPOINT_NAME = dbutils.widgets.get("ENDPOINT_NAME")

dbutils.widgets.text("INDEX_NAME", "dev_adb.nexusbenefitsquote_silver_mvp1.tbl_eoc_content_test_index", "Vector Search Index Name")
INDEX_NAME = dbutils.widgets.get("INDEX_NAME")

dbutils.widgets.text("TEST_TABLE", "dev_adb.nexusbenefitsquote_silver_mvp1.tbl_eoc_content_test", "Vector Search Test Table")
TEST_TABLE = dbutils.widgets.get("TEST_TABLE")

dbutils.widgets.text("EMBEDDING_COLUMN", "eoc_categories_all_fields", "VS Embedding Column")
EMBEDDING_COLUMN = dbutils.widgets.get("EMBEDDING_COLUMN")

dbutils.widgets.text(
    "COLUMNS_TO_RETURN",
    "benefit_id,eocCategories_content",
    "Columns to Return"
)
COLUMNS_TO_RETURN = [
    col.strip()
    for col in dbutils.widgets.get("COLUMNS_TO_RETURN").split(",")
    if col.strip()
]

print(COLUMNS_TO_RETURN)

NUMBER_OF_RESULTS=100

# Save these Locust variables as strings
import os

output_dir = "./../vector_search_load_test_report"
os.makedirs(output_dir, exist_ok=True)
csv_output_prefix_vector_search = os.path.join(output_dir, "vectorsearch")


# NUMBER_OF_TEST_QUERIES
NUM_TEST_EMBEDDINGS = 10

# Configuration for input files
INPUTS_PER_FILE = 10
INPUT_FOLDER = str(pathlib.Path().resolve().parent / "input_json")
print(f"INPUT_FOLDER: {INPUT_FOLDER}")
INPUT_FILE_PATTERN = "vector_search_input_batch_*.json"  # Pattern for input files

# COMMAND ----------

# Endpoint configuration
all_endpoint = dbutils.widgets.get("all_endpoint")
agent_endpoint_name = dbutils.widgets.get("agent_endpoint_name")
embedding_endpoint_name = dbutils.widgets.get("embedding_endpoint_name")
gpt_endpoint_name = dbutils.widgets.get("gpt_endpoint_name")

if all_endpoint and all_endpoint.lower() != "all":
    endpoint_names = [name.strip() for name in all_endpoint.split(",") if name.strip()]
elif all_endpoint and all_endpoint.lower() == "all":
    endpoint_names = [name for name in [agent_endpoint_name, embedding_endpoint_name, gpt_endpoint_name] if name]
else:
    endpoint_names = [name for name in [agent_endpoint_name] if name]

csv_output_prefix_agent = "./../agent_load_test_report/agent_load_test"
csv_output_prefix_embedding = "./../embedding_load_test_report/embedding_load_test"
csv_output_prefix_gpt = "./../gpt_load_test_report/gpt_load_test"
print(endpoint_names)

# COMMAND ----------

workspace_url = f"https://{spark.conf.get('spark.databricks.workspaceUrl')}"

c = WorkspaceClient()
endpoint_urls = []
invocation_urls = []

custom_agent_invocation = None
embedding_invocation = None
gpt_invocation = None

for name in endpoint_names:
    details = c.serving_endpoints.get(name=name)
    url = details.endpoint_url if details.endpoint_url is not None else f"{workspace_url}/serving-endpoints/{name}"
    endpoint_urls.append(url)
    invocation_url = f"{url}/invocations"
    invocation_urls.append(invocation_url)
    if "agent" in name:
        custom_agent_invocation = invocation_url
    elif "bge" in name:
        embedding_invocation = invocation_url
    elif "gpt" in name:
        gpt_invocation = invocation_url

print(custom_agent_invocation)
print(embedding_invocation)
print(gpt_invocation)

# COMMAND ----------

# MAGIC %md
# MAGIC Vector Search Initialization

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient

DATABRICKS_TOKEN = "dapibb845be09e87e1de619e69c0214475dd-2"

vsc_dp = VectorSearchClient(
  workspace_url=workspace_url,
  personal_access_token=DATABRICKS_TOKEN
)

index = vsc_dp.get_index(endpoint_name=ENDPOINT_NAME, index_name=INDEX_NAME)
index_url = index.index_url
print(index_url)

c = WorkspaceClient()
print(c.get_workspace_id())

print(f"workspace url: {workspace_url}")
print(f"index name: {INDEX_NAME}")
print(f"index_url: {index_url}")
index_host, index_query_path = index_url[8:].split('/',1)
index_host = "https://" + index_host
index_query_path =  "/" + index_query_path + "/query"
print(f"index_host: {index_host}")
print(f"index_query_path: {index_query_path}")

# COMMAND ----------

# MAGIC %md
# MAGIC Creating Vector Search Dimension

# COMMAND ----------

# Random embeddings from the test table
print(f"Sampling {NUM_TEST_EMBEDDINGS} random embeddings from {TEST_TABLE}...")

# Get total count for efficient random sampling
total_count = spark.table(TEST_TABLE).count()
print(f"Total records in test table: {total_count}")


sample_fraction = min(1.0, (NUM_TEST_EMBEDDINGS * 2) / total_count)  
sampled_df = spark.table(TEST_TABLE).select(EMBEDDING_COLUMN).sample(False, sample_fraction).limit(NUM_TEST_EMBEDDINGS)
embeddings_list = sampled_df.collect()

# Convert to list of vectors
test_embeddings = [row[EMBEDDING_COLUMN] for row in embeddings_list if row[EMBEDDING_COLUMN] is not None]
print(f"Successfully sampled {len(test_embeddings)} embeddings")

# Validate embedding dimensions
if test_embeddings:
    embedding_dim = len(test_embeddings[0])
    print(f"Embedding dimension: {embedding_dim}")

# COMMAND ----------

# Create input folder if it doesn't exist
os.makedirs(INPUT_FOLDER, exist_ok=True)

# Create multiple input JSON files with arrays of queries
input_configs = []
file_count = 0

# Split test embeddings into batches
for batch_start in range(0, len(test_embeddings), INPUTS_PER_FILE):
    batch_end = min(batch_start + INPUTS_PER_FILE, len(test_embeddings))
    batch_embeddings = test_embeddings[batch_start:batch_end]
    
    # Create array of queries for this batch
    queries = []
    for embedding in batch_embeddings:
        query = {
            "query_vector": embedding,
            "num_results": NUMBER_OF_RESULTS,
            "columns": COLUMNS_TO_RETURN
        }
        queries.append(query)
    
    # Write batch to file
    file_name = f"{INPUT_FOLDER}/vector_search_input_batch_{file_count}.json"
    with open(file_name, "w") as f:
        json.dump(queries, f)
    
    input_configs.append(file_name)
    file_count += 1
    
    print(f"Created {file_name} with {len(queries)} queries")

# Also create a single default input file
if test_embeddings:
    default_queries = []
    for embedding in test_embeddings[:INPUTS_PER_FILE]:
        default_queries.append({
            "query_vector": embedding,
            "num_results": 10
        })
    
    with open(f"{INPUT_FOLDER}/vector_search_input.json", "w") as f:
        json.dump(default_queries, f)

print(f"\nTotal: Created {file_count} batch files with {len(test_embeddings)} queries")
print(f"Files stored in: {INPUT_FOLDER}/")

# COMMAND ----------

os.environ["DATABRICKS_WORKSPACE_URL"] = workspace_url
os.environ["INVOCATION_URL"] = ','.join(invocation_urls)
os.environ["DATABRICKS_ENDPOINT_NAME"] = ','.join(endpoint_names)
os.environ["DATABRICKS_TOKEN"] = "dapibb845be09e87e1de619e69c0214475dd-2"
if custom_agent_invocation is not None  and custom_agent_invocation !='':
    os.environ["CUSTOM_AGENT_INVOCATION"]= custom_agent_invocation
if embedding_invocation is not None  and embedding_invocation !='':    
    os.environ["EMBEDDING_INVOCATION"]= embedding_invocation
if gpt_invocation is not None  and gpt_invocation !='':   
    os.environ["GPT_INVOCATION"]= gpt_invocation
os.environ["VECTOR_SEARCH_INDEX_NAME"] = INDEX_NAME
os.environ["VECTOR_SEARCH_INDEX_PATH"] = index_query_path
os.environ["ENDPOINT_NAME"] = ENDPOINT_NAME
os.environ["INPUT_FOLDER"] = INPUT_FOLDER  
os.environ["INPUT_FILE_PATTERN"] = INPUT_FILE_PATTERN  
os.environ["VECTOR_SEARCH_INDEX_QUERY_PATH"] = index_query_path
os.environ["COLUMNS_TO_RETURN"] = ",".join(COLUMNS_TO_RETURN)

# COMMAND ----------

def check_for_CPU_overload(line : str) -> None:
  """Watches for CPU overload messages in the locust output and raises an exception if found."""
  if "CPU" in line:
      raise Exception("CPU Overloaded, restart this notebook with a single node cluster with more available cores.")


# COMMAND ----------

# Ensure input.json exists before running locust
def run_locust_test(host : str, users : int, spawn_rate : int, run_time : str, csv_output_prefix : str, verbose : bool = False):
  """Spawns a locust process with the specified parameters."""
  locust_util = "./../utils/load_test_utils.py"
  locust_command = f"""locust --host={host} --users={users} --spawn-rate={spawn_rate} --run-time={run_time} --headless --locustfile={locust_util} --csv={csv_output_prefix}"""

  process = subprocess.Popen(shlex.split(locust_command), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
  # While the process is running, watch for CPU overload
  while True:
      line = process.stdout.readline()
      if not line and process.poll() is not None:
          break
      if line:
        check_for_CPU_overload(line)
        if verbose:
          print(line.strip())

# COMMAND ----------

for host, csv_prefix in [
    (custom_agent_invocation, csv_output_prefix_agent),
    (embedding_invocation, csv_output_prefix_embedding),
    (gpt_invocation, csv_output_prefix_gpt)
]:
    if host:
        print(f"Running locust test for: {host}")
        run_locust_test(
            host=host,
            users=users, 
            spawn_rate=spawn_rate, 
            run_time=locust_run_time,
            csv_output_prefix=csv_prefix,
            verbose=True
        )
    else:
        print(f"Skipping locust test for missing invocation_url with prefix: {csv_prefix}")


# COMMAND ----------

# MAGIC %md
# MAGIC Vector Search

# COMMAND ----------

import subprocess
import shlex

locust_command = f"locust -f ./../utils/vs_load_test.py --host={index_host} --headless -u {users} -r {spawn_rate} --run-time {locust_run_time} --csv={csv_output_prefix_vector_search}"
subprocess.run(shlex.split(locust_command))

# COMMAND ----------

# MAGIC %md
# MAGIC Stats Table

# COMMAND ----------

import pandas as pd
from datetime import datetime
import re

schema = f"{environment}_adb.nexusbenefitsquote_gold_mvp1"

def final_column(col):
    return re.sub(r'[ ,;{}()\n\t=]', '_', col).strip('_').lower()
    
required_stats_columns = [
    "start_time", "end_time", "type", "name", "request_count", "failure_count",
    "median_response_time", "average_response_time", "min_response_time",
    "max_response_time", "average_content_size", "requests/s", "failures/s", "CPU"
]

# Read stats CSVs and add start_time, end_time, file_name, endpoint_details
stats_csv_path_agent = f"{csv_output_prefix_agent}_stats.csv"
stats_csv_path_embedding = f"{csv_output_prefix_embedding}_stats.csv"
stats_csv_path_gpt = f"{csv_output_prefix_gpt}_stats.csv"
stats_csv_path_vector_search = f"{csv_output_prefix_vector_search}_stats.csv"
stats_csv_paths = [
    (stats_csv_path_agent, agent_endpoint_name),
    (stats_csv_path_embedding, embedding_endpoint_name),
    (stats_csv_path_gpt, gpt_endpoint_name),
    (stats_csv_path_vector_search, ENDPOINT_NAME)
]

now = datetime.now().strftime("%m-%d-%Y:%H:%M")
all_stats = []
for csv_path, endpoint_details in stats_csv_paths:
    try:
        df = pd.read_csv(csv_path, skip_blank_lines=True)
        df["start_time"] = now
        df["end_time"] = datetime.now().strftime("%m-%d-%Y:%H:%M")
        df["file_name"] = csv_path
        df["endpoint_details"] = endpoint_details
        # Only update CPU if endpoint_details contains 'agent'
        df["CPU"] = df["endpoint_details"].apply(lambda x: CPU if isinstance(x, str) and "agent" in x.lower() else None)
        df.columns = [final_column(str(col)) for col in df.columns]
        all_stats.append(df)
    except Exception:
        continue

final_required_cols = [final_column(col) for col in required_stats_columns] + ["file_name", "endpoint_details"]

if all_stats:
    stats_df = pd.concat(all_stats, ignore_index=True)
else:
    stats_df = pd.DataFrame(columns=final_required_cols)

# Ensure all required columns exist
for col in final_required_cols:
    if col not in stats_df.columns:
        stats_df[col] = None
stats_df = stats_df[final_required_cols]

# Rename columns as requested, avoiding invalid characters
rename_map = {
    "average_response_time": "average_response_ms",
    "requests/s": "requests",
    "failures/s": "failures"
}
stats_df = stats_df.rename(columns=rename_map)
#display(stats_df)

# Write stats to Delta table (append) only if DataFrame is not empty
if not stats_df.empty:
    from pyspark.sql import functions as F
    spark_stats_df = spark.createDataFrame(stats_df.astype(str))
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema}")
    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {schema}.tbl_mvp1_load_test_stats (
        start_time TIMESTAMP,
        end_time TIMESTAMP,
        type STRING,
        name STRING,
        request_count STRING,
        failure_count STRING,
        median_response_time STRING,
        average_response_ms STRING,
        min_response_time STRING,
        max_response_time STRING,
        average_content_size STRING,
        requests STRING,
        failures STRING,
        cpu STRING,
        file_name STRING,
        endpoint_details STRING
    ) USING DELTA
    """)
    # Use try_to_timestamp to tolerate invalid input and return NULL
    spark_stats_df = spark_stats_df.withColumn(
        "start_time", F.expr("try_to_timestamp(start_time, 'MM-dd-yyyy:HH:mm')")
    ).withColumn(
        "end_time", F.expr("try_to_timestamp(end_time, 'MM-dd-yyyy:HH:mm')")
    )
    #display(spark_stats_df)
    spark_stats_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{schema}.tbl_mvp1_load_test_stats")

# COMMAND ----------

import pandas as pd
from datetime import datetime
import re

schema = f"{environment}_adb.nexusbenefitsquote_gold_mvp1"
stats_history_table = f"{schema}.tbl_mvp1_load_test_stats_history"

def final_column(col):
    return re.sub(r'[ ,;{}()\n\t=]', '_', col).strip('_').lower()
    
required_stats_columns = [
    "timestamp", "user_count", "name", "requests/s", "failures/s",
    "total_request_count", "total_failure_count", "total_median_response_time",
    "total_average_response_time_ms", "total_min_response_time", "total_max_response_time",
    "total_average_content_size",
    "start_time", "end_time", "file_name", "endpoint_details"
]

# Read stats CSVs and add start_time, end_time, file_name, endpoint_details
stats_csv_path_agent = f"{csv_output_prefix_agent}_stats_history.csv"
stats_csv_path_embedding = f"{csv_output_prefix_embedding}_stats_history.csv"
stats_csv_path_gpt = f"{csv_output_prefix_gpt}_stats_history.csv"
stats_csv_path_vector_search = f"{csv_output_prefix_vector_search}_stats_history.csv"
stats_csv_paths = [
    (stats_csv_path_agent, agent_endpoint_name),
    (stats_csv_path_embedding, embedding_endpoint_name),
    (stats_csv_path_gpt, gpt_endpoint_name),
    (stats_csv_path_vector_search, ENDPOINT_NAME)
]

now = datetime.now().strftime("%m-%d-%Y:%H:%M")
all_stats = []
for csv_path, endpoint_details in stats_csv_paths:
    try:
        df = pd.read_csv(csv_path, skip_blank_lines=True)
        df["start_time"] = now
        df["end_time"] = datetime.now().strftime("%m-%d-%Y:%H:%M")
        df["file_name"] = csv_path
        df["endpoint_details"] = endpoint_details
        
        df.columns = [final_column(str(col)) for col in df.columns]
        # Rename the columns as requested
        rename_map = {
            "total_average_response_time": "total_average_response_time_ms",
            
        }
        df = df.rename(columns=rename_map)
        all_stats.append(df)
    except Exception:
        continue

final_required_cols = [final_column(col) for col in required_stats_columns]

if all_stats:
    stats_df = pd.concat(all_stats, ignore_index=True)
else:
    stats_df = pd.DataFrame(columns=final_required_cols)

# Ensure all required columns exist
for col in final_required_cols:
    if col not in stats_df.columns:
        stats_df[col] = None
stats_df = stats_df[final_required_cols]
rename = {
    "requests/s": "requests",
    "failures/s": "failures"
}
stats_df = stats_df.rename(columns=rename)
#display(stats_df)

if not stats_df.empty:
    from pyspark.sql import functions as F
    spark_stats_df = spark.createDataFrame(stats_df.astype(str)[['timestamp', 'user_count', 'name', 'requests', 'failures', 'total_request_count', 'total_failure_count', 'total_median_response_time', 'total_average_response_time_ms', 'total_min_response_time', 'total_max_response_time', 'total_average_content_size', 'start_time', 'end_time', 'file_name', 'endpoint_details']])
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {schema}")
    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {stats_history_table} (
        timestamp STRING,
        user_count STRING,
        name STRING,
        requests STRING,
        failures STRING,
        total_request_count STRING,
        total_failure_count STRING,
        total_median_response_time STRING,
        total_average_response_time_ms STRING,
        total_min_response_time STRING,
        total_max_response_time STRING,
        total_average_content_size STRING,
        start_time TIMESTAMP,
        end_time TIMESTAMP,
        file_name STRING,
        endpoint_details STRING
    ) USING DELTA
    """)
    spark_stats_df = spark_stats_df.withColumn(
        "start_time", F.expr("try_to_timestamp(start_time, 'MM-dd-yyyy:HH:mm')")
    ).withColumn(
        "end_time", F.expr("try_to_timestamp(end_time, 'MM-dd-yyyy:HH:mm')")
    )
    spark_stats_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(stats_history_table)

# COMMAND ----------

from datetime import datetime
import os
import pandas as pd
import re

def final_column(col):
    return re.sub(r'[ ,;{}()\n\t=]', '_', col).strip('_').lower()

now = datetime.now().strftime("%m-%d-%Y:%H:%M")

csv_paths = []
if agent_endpoint_name:
    csv_paths.extend([
        (f"{csv_output_prefix_agent}_exceptions.csv", "exception", agent_endpoint_name),
        (f"{csv_output_prefix_agent}_failures.csv", "failures", agent_endpoint_name)
    ])
if embedding_endpoint_name:
    csv_paths.extend([
        (f"{csv_output_prefix_embedding}_exceptions.csv", "exception", embedding_endpoint_name),
        (f"{csv_output_prefix_embedding}_failures.csv", "failures", embedding_endpoint_name)
    ])
if gpt_endpoint_name:
    csv_paths.extend([
        (f"{csv_output_prefix_gpt}_exceptions.csv", "exception", gpt_endpoint_name),
        (f"{csv_output_prefix_gpt}_failures.csv", "failures", gpt_endpoint_name)
    ])
if ENDPOINT_NAME:
    csv_paths.extend([
        (f"{csv_output_prefix_vector_search}_exceptions.csv", "exception", ENDPOINT_NAME),
        (f"{csv_output_prefix_vector_search}_failures.csv", "failures", ENDPOINT_NAME)
    ])

def read_and_tag(csv_path, tag, endpoint_details):
    try:
        if not os.path.exists(csv_path):
            return pd.DataFrame()
        df = pd.read_csv(csv_path, skip_blank_lines=True)
        if df.empty:
            return pd.DataFrame()
        df["start_time"] = now
        df["end_time"] = datetime.now().strftime("%m-%d-%Y:%H:%M")
        df["file_name"] = csv_path
        df["endpoint_details"] = endpoint_details
        df["type"] = tag
        df.columns = [final_column(str(col)) for col in df.columns]
        return df
    except Exception:
        return pd.DataFrame()

error_exception_dfs = [read_and_tag(path, tag, endpoint) for path, tag, endpoint in csv_paths]

non_empty_dfs = [df for df in error_exception_dfs if not df.empty]
#display(non_empty_dfs)
if non_empty_dfs:
    error_exception_df = pd.concat(non_empty_dfs, ignore_index=True)
    # Ensure all columns are lower case before writing
    error_exception_df.columns = [col.lower() for col in error_exception_df.columns]
    from pyspark.sql import functions as F
    spark_error_exception_df = spark.createDataFrame(error_exception_df.astype(str))
    # Convert start_time and end_time to timestamp
    if "start_time" in spark_error_exception_df.columns and "end_time" in spark_error_exception_df.columns:
        spark_error_exception_df = spark_error_exception_df.withColumn(
            "start_time", F.expr("try_to_timestamp(start_time, 'MM-dd-yyyy:HH:mm')")
        ).withColumn(
            "end_time", F.expr("try_to_timestamp(end_time, 'MM-dd-yyyy:HH:mm')")
        )
    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {schema}.tbl_mvp1_load_test_error_exception (
        {', '.join([f'`{col}` STRING' if col not in ['start_time', 'end_time'] else f'`{col}` TIMESTAMP' for col in error_exception_df.columns])}
    ) USING DELTA
    """)
    spark_error_exception_df.write.format("delta").mode("append").saveAsTable(f"{schema}.tbl_mvp1_load_test_error_exception")
    #display(spark_error_exception_df)
else:
    print("No error or exception data found.")