from databricks.sdk.runtime import *

from pyspark.sql.functions import col, udf, concat, lit
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("silverprocessor") \
    .getOrCreate()

def process_bronze_to_silver(model_name_to_id_mapping, bronze_table: str, silver_table_name: str, catalog: str, schema: str) -> None:
    """
    Process the bronze table and append new records to the silver table.

    Args:
        bronze_table (str): The name of the bronze table.
        silver_table_name (str): The name of the silver table.
        catalog (str): The catalog where the tables are located.
        schema (str): The schema where the silver table is located.

    Returns:
        None
    """
    print(f"Processing bronze table: {bronze_table} to silver table: {silver_table_name}")
    def get_model_id_func(model_name: str) -> str:
        return model_name_to_id_mapping.get(model_name, None)
    get_model_id = udf(get_model_id_func, StringType())
    
    bronze_table_full_name = f"{bronze_table}"
    # If silver table does not exist, create it using bronze table schema
    silver_table_full_name = f"{catalog}.{schema}.{silver_table_name}"
    table_exists = spark.catalog.tableExists(silver_table_full_name)
    if not table_exists:
        spark.sql(f"CREATE TABLE {silver_table_full_name} USING DELTA AS SELECT * FROM {bronze_table_full_name} WHERE 1=0")
    

    try:
        df_bronze = spark.table(bronze_table_full_name)
    except AnalysisException:
        print(f"Table {bronze_table_full_name} not found.")
        return
    if silver_table_name != "inference_custom":
        df_bronze_with_model_id = df_bronze.withColumn("model_ID", get_model_id(col("model")))
    else:
        df_bronze_with_model_id = df_bronze.withColumn("model_ID", df_bronze["model"])

    try:
        df_silver = spark.table(silver_table_full_name)
    except AnalysisException:
        df_silver = spark.createDataFrame([], df_bronze.schema)

    df_new_records = df_bronze_with_model_id.join(
        df_silver.select("databricks_request_id"),
        on="databricks_request_id",
        how="left_anti",
    )
   
    if df_new_records.count() > 0:
        df_new_records = df_new_records.drop('temperature')
        df_new_records.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(silver_table_full_name)
        print(f"Appended {df_new_records.count()} new records to {silver_table_full_name}")
    else:
        print(f"No new records to append to {silver_table_full_name}")