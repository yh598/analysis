import sys

# Add the parent directory of 'monitoring' to sys.path
sys.path.append('../../../.')
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, when

from typing import List
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()
# Create a text widget for sku_name
from pyspark.dbutils import DBUtils
dbutils = DBUtils(spark)
dbutils.widgets.text("sku_name", "PREMIUM_SERVERLESS_REAL_TIME_INFERENCE_US_CENTRAL")
sku_name = dbutils.widgets.get("sku_name")

class BillingUtils:
    @staticmethod
    def clean_billing_df(billing_df: DataFrame) -> DataFrame:
        return billing_df.drop("cloud", "custom_tags", "usage_unit", "usage_metadata", 
                               "usage_start_time", "usage_end_time", "record_id")

    @staticmethod
    def filter_billing_data(billing_df: DataFrame, workspace_id: str, start_date: str) -> DataFrame:
        return billing_df.filter(
            (col("workspace_id") == workspace_id) &
            (col("sku_name") == sku_name) &
            (col("usage_date") > start_date)
        )

    @staticmethod
    def calculate_cost(df: DataFrame) -> DataFrame:
        return df.withColumn(
            "cost_dollar",
            col("usage_quantity").cast("double") * col("pricing_default").cast("double")
        )


class BillingTransformations:
    @staticmethod
    def cleanse_and_join(
        billing_df: DataFrame,
        prices_df: DataFrame,
        selected_columns: List[str]
    ) -> DataFrame:
        """
        Joins the billing and prices DataFrames on 'sku_name' and selects specified columns.

        Args:
            billing_df (DataFrame): The billing DataFrame.
            prices_df (DataFrame): The prices DataFrame.
            selected_columns (List[str]): The list of columns to select after the join.

        Returns:
            DataFrame: The joined and filtered DataFrame.
        """
        billing_df_alias = billing_df.alias("billing")
        prices_df_alias = prices_df.alias("prices")

        # Perform the join
        joined_df = billing_df_alias.join(
            prices_df_alias,
            on="sku_name",
            how="left"
        )

        # Select necessary columns
        return joined_df.select(*selected_columns)
    
    @staticmethod
    def apply_cost_conversion(df: DataFrame) -> DataFrame:
        return df.withColumn(
            "pricing_conversion", 
            when(col("pricing_default").isNotNull(), col("pricing_default")).otherwise(0)
    )
