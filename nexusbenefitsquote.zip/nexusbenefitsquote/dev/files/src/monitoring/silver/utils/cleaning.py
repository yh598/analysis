import re
from typing import Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, concat_ws, lit
from pyspark.sql.types import ArrayType, StringType, StructType


def clean_text(text: Optional[str]) -> Optional[str]:
    """Clean the input text by removing non-ASCII characters."""
    return re.sub(r"[^\x00-\x7F]+", "", text) if text else text

def remove_nulls(df: DataFrame) -> DataFrame:
    """Remove rows with any null values from the DataFrame."""
    return df.dropna()

def standardize_columns(df: DataFrame, target_schema: StructType) -> DataFrame:
    """Standardize the schema of the DataFrame to match the target schema."""
    target_field_names = [field.name.lower() for field in target_schema.fields]

    # Normalize column names
    df = df.toDF(*[c.lower() for c in df.columns])

    # Add missing columns and cast existing ones to match the target schema
    for field in target_schema.fields:
        field_name = field.name.lower()
        field_type = field.dataType
        if field_name not in df.columns:
            df = df.withColumn(field_name, lit(None).cast(field_type))
        elif df.schema[field_name].dataType != field_type:
            df = df.withColumn(field_name, col(field_name).cast(field_type))

    # Remove extra columns not in target schema
    df_columns_set = set(df.columns)
    target_columns_set = set(target_field_names)
    df = df.select(*[c for c in df.columns if c in target_columns_set])

    # Handle ArrayType columns by converting to a string
    for field in df.schema.fields:
        if isinstance(field.dataType, ArrayType):
            df = df.withColumn(field.name, concat_ws(",", col(field.name)))

    return df


def is_dataframe_empty(df: DataFrame) -> bool:
    """Check if a DataFrame is empty."""
    return df.rdd.isEmpty()


def validate_schema(df: DataFrame, target_schema: StructType) -> bool:
    """Validate that the DataFrame schema matches the target schema."""
    df_fields = set((field.name, field.dataType) for field in df.schema.fields)
    target_fields = set((field.name, field.dataType) for field in target_schema.fields)

    missing_in_df = target_fields - df_fields
    return not missing_in_df
