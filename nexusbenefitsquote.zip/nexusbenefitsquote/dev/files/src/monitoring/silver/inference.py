# Databricks notebook source
# MAGIC %pip install pyyaml

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
root_path = "/Workspace" + "/".join(notebook_path.split("/")[:-4])

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import logging
import yaml
from pyspark.sql.functions import udf, col
from pyspark.sql.types import StringType
from pyspark.sql.utils import AnalysisException
import os
import sys
import requests

# COMMAND ----------


from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


# COMMAND ----------

dirs = os.path.abspath(os.path.join(os.getcwd(), "..", ".."))
sys.path.append(dirs)

from monitoring.silver.utils.process_inference import process_bronze_to_silver

# COMMAND ----------

# Set up environment and layer variables
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("layer", "silver")

environment = dbutils.widgets.get("environment").lower()
layer = dbutils.widgets.get("layer").lower()

# COMMAND ----------

# Define catalog and schema using environment and layer variables

catalog = f"{environment}_adb"
dbutils.widgets.text("schema", "nexusbenefitsquote_silver_mvp1")
schema = dbutils.widgets.get("schema").lower()

# Ensure schema exists
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")

# Set the catalog and schema
spark.sql(f"USE CATALOG {catalog}")
# spark.sql(f"USE {schema}")


current_catalog = spark.sql("SELECT current_catalog()").collect()[0][0]
current_schema = spark.sql("SELECT current_schema()").collect()[0][0]

# List tables using SQL instead of spark.catalog.listTables()
tables_in_silver_layer = spark.sql(
    f"SHOW TABLES IN {catalog}.{schema}"
)
#display(tables_in_silver_layer)

# COMMAND ----------

def load_config(config_path: str) -> dict:
    """
    Load configurations from a YAML file.

    Args:
        config_path (str): Path to the YAML configuration file.

    Returns:
        dict: Configuration dictionary.
    """
    with open(config_path, "r") as file:
        config = yaml.safe_load(file)
    return config


# COMMAND ----------

# Load the YAML configuration
config_path = "silver-gold.yaml"
config = load_config(config_path)

# Extract specific configurations
table_list_key = f"tables_{environment}"
print("table_list_key:", table_list_key)
table_list = config.get(table_list_key, [])
print("table_list:", table_list)
bronze_to_silver_mapping = config.get(f"bronze_to_silver_mapping_{environment}", {})
model_name_to_id_mapping = config.get(f"model_name_to_id_mapping_{environment}", {})
print("bronze_to_silver_mapping:", bronze_to_silver_mapping)

# COMMAND ----------

def get_silver_mappings(silver_table_name: str, catalog: str, schema: str):
    """
    Retrieve data from the silver table.

    Args:
        silver_table_name (str): The name of the silver table.
        catalog (str): The catalog where the table is located.
        schema (str): The schema where the table is located.

    Returns:
        DataFrame: The silver table DataFrame.
    """
    silver_table_full_name = f"{catalog}.{schema}.{silver_table_name}"
    try:
        df_silver = spark.table(silver_table_full_name)
        print(f"Successfully retrieved data from {silver_table_full_name}")
        return df_silver
    except AnalysisException:
        print(f"Table {silver_table_full_name} not found.")
        return spark.createDataFrame([], schema=spark.table(silver_table_full_name).schema)

# COMMAND ----------

bronze_table = table_list[0]
silver_table_name = bronze_to_silver_mapping.get(bronze_table)
print(silver_table_name)
if silver_table_name is None:
    # Attempt to find the correct mapping by matching values (case-insensitive)
    for k, v in bronze_to_silver_mapping.items():
        if k.lower() == bronze_table.lower():
            silver_table_name = v
            #print(silver_table_name)
            break
print(f"bronze_table: {bronze_table}")
print(f"bronze_to_silver_mapping: {bronze_to_silver_mapping}")
print(f"silver_table_name: {silver_table_name}")

# COMMAND ----------

# Loop through tables to process bronze to silver
for bronze_table in table_list:
    silver_table_name = bronze_to_silver_mapping.get(bronze_table)
    if silver_table_name:
        logging.info("Processing bronze table: {} -> silver table: {}".format(bronze_table, silver_table_name))
        process_bronze_to_silver(
            model_name_to_id_mapping,
            bronze_table,
            silver_table_name,
            catalog=catalog,
            schema=schema,
        )

# COMMAND ----------

from pyspark.sql.functions import split, expr

df_t = (
    spark.read.table(f"{environment}_adb.nexusbenefitsquote_silver_mvp1.tbl_chat_completions")
    .withColumn("split_values", split("client_request_id", "\\|"))
    .withColumn("user_id", expr("get(split_values, 0)"))
    .withColumn("session_id", expr("get(split_values, 1)"))
    .withColumn("question_id", expr("get(split_values, 2)"))
    .drop("split_values")
)

# COMMAND ----------

from pyspark.sql.functions import col, regexp_extract

pattern = r"<INSTRUCTION>\s*Given the user query:\s*(.*?)\s*Use the following information to formulate your answer:"
df_completions = df_t.withColumn(
    "question",
    regexp_extract(col("request_prompt"), pattern, 1)
)

context_pattern = (
    r"Use the following information to formulate your answer:(.*?)Your response must rely \*\*only\*\* on the provided data and follow the formatting and guidelines below\.\s*</INSTRUCTION>"
)

df_completions = df_completions.withColumn(
    "generated_context",
    regexp_extract(col("request_prompt"), context_pattern, 1)
)

df_completions = df_completions.withColumn(
    "answer",
    col("completion_text")
)

table_name = f"{environment}_adb.nexusbenefitsquote_silver_mvp1.tbl_chat_completions_response"
tables = spark.sql(f"SHOW TABLES IN {environment}_adb.nexusbenefitsquote_silver_mvp1").filter(col("tableName") == "tbl_chat_completions_response")

if tables.count() > 0:
    df_completions.write.mode("append").saveAsTable(table_name)
else:
    df_completions.write.mode("overwrite").saveAsTable(table_name)

# COMMAND ----------

from pyspark.sql.functions import col, get_json_object, substring

df_custom = (
    spark.read.table(f"{environment}_adb.nexusbenefitsquote_bronze_mvp1.tbl_custom_model")
    .filter(get_json_object(col("response"), "$.object") == "response")
    .withColumn("question", get_json_object(col("request"), "$.input[0].content[0].text"))
    .withColumn("answer", get_json_object(col("response"), "$.output[0].content[0].text"))
    .withColumn("custom_user_id", get_json_object(col("request"), "$.custom_inputs.user_id"))
    .withColumn("custom_session_id", get_json_object(col("request"), "$.custom_inputs.session_id"))
    .withColumn("custom_question_id", get_json_object(col("request"), "$.custom_inputs.question_id"))
    .withColumn(
        "productid",
        substring(get_json_object(col("request"), "$.custom_inputs.facets_product_id"), 1, 8)
    )
    .withColumn("effective_date", get_json_object(col("request"), "$.custom_inputs.effective_date"))
    .withColumn("custom_response_id", get_json_object(col("response"), "$.output[0].id"))
    .drop("user_id", "question_id", "session_id")
)
table_name = f"{environment}_adb.nexusbenefitsquote_silver_mvp1.tbl_custom_model_response"
tables = spark.sql(f"SHOW TABLES IN {environment}_adb.nexusbenefitsquote_silver_mvp1").filter(col("tableName") == "tbl_custom_model_response")

if tables.count() > 0:
    df_custom.write.mode("append").saveAsTable(table_name)
else:
    df_custom.write.mode("overwrite").saveAsTable(table_name)