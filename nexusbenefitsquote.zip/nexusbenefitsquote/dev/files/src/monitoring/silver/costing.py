# Databricks notebook source
dbutils.library.restartPython()

# COMMAND ----------

import sys
import os

dirs = os.path.abspath(os.path.join(os.getcwd(), "..", ".."))
sys.path.append(dirs)
print(dirs)

# COMMAND ----------

from pyspark.sql.functions import col, sum
from pyspark.sql import DataFrame


from monitoring.silver.schemas.billing_schema import get_silver_serving_costs_schema
from monitoring.silver.utils.costing_transformations import (
    BillingUtils,
    BillingTransformations,
)
from monitoring.utils.utils import (
    write_to_delta_with_schema_merge,
    is_dataframe_empty,
)
from monitoring.utils.dataframe_transformations import flatten_dataframe



# COMMAND ----------


from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


# COMMAND ----------

from databricks.sdk import WorkspaceClient
import re

w = WorkspaceClient()
DATABRICKS_HOST = w.config.host

# Extract the number after 'adb-' and before the first '.'
match = re.search(r'adb-(\d+)\.', DATABRICKS_HOST)
workspace_id = match.group(1) if match else None

print(f"Workspace Host: {DATABRICKS_HOST}")
print(f"Workspace ID: {workspace_id}")

# COMMAND ----------

dbutils.widgets.text("environment", "qa")
environment = dbutils.widgets.get("environment").lower()


catalog = f"{environment}_adb"

dbutils.widgets.text("schema", "nexusbenefitsquote_silver_mvp1")
schema = dbutils.widgets.get("schema").lower()

spark.sql(f"USE CATALOG {catalog}")


current_catalog = spark.sql("SELECT current_catalog()").collect()[0][0]
print(f"Current Catalog: {current_catalog}")

current_schema = spark.sql("SELECT current_schema()").collect()[0][0]
print(f"Current Schema: {current_schema}")

# COMMAND ----------

selected_columns = [
    "billing.sku_name",
    "billing.account_id",
    "billing.workspace_id",
    "billing.record_id",
    "billing.usage_start_time",
    "billing.usage_end_time",
    "billing.usage_date",
    "billing.usage_unit",
    "billing.usage_quantity",
    "billing.usage_metadata_endpoint_name",
    "billing.usage_metadata_endpoint_id",
    "billing.usage_metadata_app_name",
    "billing.usage_metadata_app_id",
    "billing.usage_type",
    "prices.pricing_default",
    "prices.pricing_promotional_default",
    "prices.pricing_effective_list_default",
]

# COMMAND ----------

billing_utils = BillingUtils()

# COMMAND ----------

from pyspark.sql.functions import col

# Ensure the silver schema exists in the current catalog
current_catalog = spark.sql("SELECT current_catalog()").collect()[0][0]
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {current_catalog}.nexusbenefitsquote_silver_mvp1")

billing_df_bronze_filtered = spark.read.table(f"{environment}_adb.nexusbenefitsquote_bronze_mvp1.usage").dropDuplicates(["record_id"])

# Apply all filters and union the results
billing_df_bronze = (
    billing_df_bronze_filtered.filter(
        (col("billing_origin_product") == "APPS") &
        (col("usage_metadata_app_name") == "nexus-benefits-app")
    )
    .unionByName(
        billing_df_bronze_filtered.filter(
            (col("billing_origin_product") == "MODEL_SERVING") &
            (col("usage_metadata_endpoint_name") == "agents_dev_adb-nexusbenefitsquote_gold_mvp1-mvp1")
        )
    )
    .unionByName(
        billing_df_bronze_filtered.filter(
            (col("billing_origin_product") == "AI_GATEWAY") &
            (col("usage_metadata_endpoint_name").like("%accenture-azure-gpt-4o-2024-08-06-sp%"))
        )
    )
    .unionByName(
        billing_df_bronze_filtered.filter(
            (col("billing_origin_product") == "VECTOR_SEARCH") &
            (col("usage_metadata_endpoint_name") == "benefits_quote_mvp1_vs_endpoint")
        )
    )
)

prices_df_bronze = spark.read.table(f"{environment}_adb.nexusbenefitsquote_bronze_mvp1.list_prices").dropDuplicates(["sku_name"])

billing_df_prices = BillingTransformations.cleanse_and_join(
    billing_df_bronze,
    prices_df_bronze,
    selected_columns
).dropDuplicates()


model_serving_costs = BillingUtils.calculate_cost(billing_df_prices)
model_serving_costs = BillingTransformations.apply_cost_conversion(model_serving_costs).dropDuplicates()

silver_table = f"{current_catalog}.nexusbenefitsquote_silver_mvp1.tbl_model_servings_costs"

if spark.catalog.tableExists(silver_table):
    silver_serving_df = spark.table(silver_table)
else:
    silver_serving_df = spark.createDataFrame([], model_serving_costs.schema)

# Only join if 'usage_date' exists in both DataFrames
if "usage_date" in model_serving_costs.columns and "usage_date" in silver_serving_df.columns:
    silver_append_serving_df = model_serving_costs.alias("new").join(
        silver_serving_df.alias("existing"),
        on="usage_date",
        how="left_anti"
    )
else:
    silver_append_serving_df = model_serving_costs

columns_to_drop = [
    'category', 'record_type', 'ingestion_date', 'product_features', 'jobs_tier',
    'sql_tier', 'dlt_tier', 'is_serverless', 'is_photon', 'serving_type', 'usage_type'
]
cols_to_drop = [col_name for col_name in columns_to_drop if col_name in silver_append_serving_df.columns]
if cols_to_drop:
    silver_append_serving_df = silver_append_serving_df.drop(*cols_to_drop)

silver_append_serving_df_1 = silver_append_serving_df.withColumn(
    "usage_quantity", col("usage_quantity").cast("double")
)

def is_dataframe_empty(df):
    return len(df.head(1)) == 0

if spark.catalog.tableExists(silver_table):
    if not is_dataframe_empty(silver_append_serving_df_1):
        silver_append_serving_df_1.write.format("delta") \
            .mode("append") \
            .saveAsTable(silver_table)
        display("Appended new data to nexusbenefitsquote_silver_mvp1.tbl_model_servings_costs")
    else:
        display("No new data to append to nexusbenefitsquote_silver_mvp1.tbl_model_servings_costs")
else:
    if not is_dataframe_empty(silver_append_serving_df_1):
        silver_append_serving_df_1.write.format("delta") \
            .mode("append") \
            .saveAsTable(silver_table)
        display("Created nexusbenefitsquote_silver_mvp1.tbl_model_servings_costs and inserted data")
    else:
        display("No data to nexusbenefitsquote_silver_mvp1.tbl_model_servings_costs")