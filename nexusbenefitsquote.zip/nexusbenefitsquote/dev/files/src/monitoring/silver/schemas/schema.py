# silver_schema.py

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, TimestampType, DateType

silver_schema = StructType([
    StructField("client_request_id", StringType(), True),
    StructField("databricks_request_id", StringType(), True),
    StructField("request_date", StringType(), True),  # Adjust to DateType() if necessary
    StructField("request_time", TimestampType(), True),
    StructField("status_code", IntegerType(), True),
    StructField("execution_duration_ms", LongType(), True),
    StructField("message_content", StringType(), True),
    StructField("finish_reason", StringType(), True),
    StructField("choice_index", IntegerType(), True),
    StructField("response_content", StringType(), True),
    StructField("response_role", StringType(), True),
    StructField("model", StringType(), True),
    StructField("served_entity_id", StringType(), True),
    StructField("logging_error_codes", StringType(), True),  # After concatenation
    StructField("requester", StringType(), True),
    StructField("categories", StringType(), True)
])


# Define schemas for each task
completions_schema = StructType([
    StructField("client_request_id", StringType(), True),
    StructField("databricks_request_id", StringType(), True),
    StructField("request_date", StringType(), True),  # Adjust to DateType() if necessary
    StructField("request_time", TimestampType(), True),
    StructField("status_code", IntegerType(), True),
    StructField("execution_duration_ms", LongType(), True),
    StructField("message_content", StringType(), True),
    StructField("finish_reason", StringType(), True),
    StructField("choice_index", IntegerType(), True),
    StructField("response_content", StringType(), True),
    StructField("model", StringType(), True),
    StructField("served_entity_id", StringType(), True),
    StructField("logging_error_codes", StringType(), True),
    StructField("requester", StringType(), True),
])

chat_schema = StructType([
    StructField("databricks_request_id", StringType(), True),
    StructField("request_time", TimestampType(), True),
    StructField("request_date", StringType(), True),  # Adjust to DateType() if necessary
    StructField("status_code", IntegerType(), True),
    StructField("execution_duration_ms", LongType(), True),
    StructField("message_content", StringType(), True),
    StructField("finish_reason", StringType(), True),
    StructField("choice_index", IntegerType(), True),
    StructField("response_content", StringType(), True),
    StructField("response_role", StringType(), True),
    StructField("model", StringType(), True),
    StructField("served_entity_id", StringType(), True),
    StructField("logging_error_codes", StringType(), True),
    StructField("requester", StringType(), True)
])
