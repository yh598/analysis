import sys

sys.path.append('/Workspace/Shared/Benefit_Quote_MVP1')

from pyspark.sql.types import StructType, StructField, StringType, FloatType, DateType


def get_silver_serving_costs_schema() -> StructType:
    """
    Defines the schema for the silver.model_serving_costs table.
    
    Returns:
        StructType: The schema for the silver serving costs table.
    """
    return StructType([
        StructField("usage_date", DateType(), True),
        StructField("workspace_id", StringType(), True),
        StructField("sku_name", StringType(), True),
        StructField("usage_quantity", FloatType(), True),
        StructField("cost_dollar", FloatType(), True),
        StructField("pricing_conversion", FloatType(), True)
    ])

def get_silver_cluster_costs_schema() -> StructType:
    """
    Defines the schema for the silver.cluster_costs table.
    
    Returns:
        StructType: The schema for the silver cluster costs table.
    """
    return StructType([
        StructField("usage_date", DateType(), True),
        StructField("workspace_id", StringType(), True),
        StructField("cluster_id", StringType(), True),
        StructField("cost_dollars", FloatType(), True),
        StructField("pricing_conversion", FloatType(), True)
    ])