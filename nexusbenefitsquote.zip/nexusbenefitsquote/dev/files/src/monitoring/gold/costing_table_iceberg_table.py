# Databricks notebook source
#sg added
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


# COMMAND ----------

# Parameters for catalog, schema, and table names using widgets
# dbutils.widgets.text("catalog", "dev_adb", "Catalog")
dbutils.widgets.text("schema", "nexusbenefitsquote_gold_mvp1", "Schema")
dbutils.widgets.text("source_tbl", "tbl_inference_token_costs", "Source Table")
dbutils.widgets.text("target_tbl", "tbl_costs_iceberg", "Target Iceberg Table")

dbutils.widgets.text("environment", "qa")
environment = dbutils.widgets.get("environment")

# catalog = dbutils.widgets.get("catalog")
catalog = f"{environment}_adb"
schema = dbutils.widgets.get("schema")
source_tbl = dbutils.widgets.get("source_tbl")
target_tbl = dbutils.widgets.get("target_tbl")

# Fully‑qualified names
src_fqn = f"{catalog}.{schema}.{source_tbl}"
tgt_fqn = f"{catalog}.{schema}.{target_tbl}"

# Create Iceberg table (if not exists) with selected columns
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {tgt_fqn}
USING ICEBERG
AS SELECT requester, date, total_cost FROM {src_fqn}
""")

# Verify the new table contents
display(spark.table(tgt_fqn))

# COMMAND ----------

