# batch_processing.py

import logging
from pyspark.sql import DataFrame
from core.monitoring.gold.transformations.metrics_management import MetricsManager

logger = logging.getLogger(__name__)

def process_batch(
    batch_df: DataFrame, metrics_manager: MetricsManager, target_table: str
) -> None:
    """
    Apply metrics to the batch DataFrame and write the results to the specified target table.

    Parameters
    ----------
    batch_df : DataFrame
        The Spark DataFrame batch to process.
    metrics_manager : MetricsManager
        An instance of the MetricsManager class.
    target_table : str
        The name of the target table to write the processed data.

    Returns
    -------
    None
    """
    try:
        df_with_metrics = metrics_manager.apply_metrics(batch_df, text_column="text")

        # Write the processed DataFrame to the target table in append mode
        df_with_metrics.write.mode("append").saveAsTable(target_table)

        # Count the number of records processed
        record_count: int = df_with_metrics.count()
        logger.info(
            f"Processed and appended batch with {record_count} records to '{target_table}'."
        )
    except Exception as e:
        logger.error(f"Failed to process and append batch to '{target_table}': {e}")

def process_data_in_batches(
    df: DataFrame,
    metrics_manager: MetricsManager,
    target_table: str,
    num_partitions: int = 10,
) -> None:
    """
    Process data in batches by partitioning the DataFrame and writing to the target table.

    Parameters
    ----------
    df : DataFrame
        The Spark DataFrame to process.
    metrics_manager : MetricsManager
        An instance of the MetricsManager class.
    target_table : str
        The name of the target table to write the processed data.
    num_partitions : int, default 10
        The number of partitions (batches) to create.

    Returns
    -------
    None
    """
    try:
        # Repartition the DataFrame to the desired number of batches
        partitioned_df = df.repartition(num_partitions)
        logger.info(f"Repartitioned DataFrame into {num_partitions} partitions.")

        # Collect the partitioned DataFrame as a list of DataFrames
        batches = partitioned_df.randomSplit([1.0] * num_partitions, seed=42)

        # Process each batch individually
        for idx, batch in enumerate(batches, start=1):
            logger.info(f"Processing batch {idx}/{num_partitions}.")
            process_batch(batch, metrics_manager, target_table)
        
        logger.info(
            f"Processed data in {num_partitions} batches and wrote to '{target_table}'."
        )
    except Exception as e:
        logger.error(
            f"Failed to process data in batches for table '{target_table}': {e}"
        )