from typing import Optional

def calculate_token_cost(model_name: str, token_type: str, token_count: int, model_config_map) -> float:
    """
    Calculates the cost of tokens for a specified OpenAI model based on input or output tokens.

    Args:
        model_name (str): The model name for which to calculate the token cost.
        token_type (str): Specifies either 'input_tokens' or 'output_tokens'.
        token_count (int): The number of tokens for which to calculate the cost.
        

    Returns:
        float: The calculated cost for the token count in USD.
    """
    openai_usage_config: Optional[dict] = model_config_map.get(model_name)
    if not openai_usage_config:
        raise ValueError(f"Model configuration not found for model: {model_name}")

    pricing: dict = openai_usage_config["pricing"]
    cost_per_1k_tokens: Optional[float] = None

    if token_type == "input_tokens":
        cost_per_1k_tokens = pricing.get("input_token_per_1k")
    elif token_type == "output_tokens":
        if "output_token_per_1m" in pricing:
            cost_per_1k_tokens = pricing["output_token_per_1m"] / 1000
        else:
            cost_per_1k_tokens = pricing.get("output_token_per_1k")
    
    if cost_per_1k_tokens is None:
        raise ValueError(f"Pricing information not found for {token_type} in model {model_name}")

    # Calculate the total cost in USD
    total_cost_usd: float = (token_count / 1000) * cost_per_1k_tokens

    return total_cost_usd