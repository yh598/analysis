# Databricks notebook source
dbutils.library.restartPython()

# COMMAND ----------


from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


# COMMAND ----------

from databricks.sdk import WorkspaceClient
import re

w = WorkspaceClient()
DATABRICKS_HOST = w.config.host

# Extract the number after 'adb-' and before the first '.'
match = re.search(r'adb-(\d+)\.', DATABRICKS_HOST)
workspace_id = match.group(1) if match else None

print(f"Workspace Host: {DATABRICKS_HOST}")
print(f"Workspace ID: {workspace_id}")

# COMMAND ----------

dbutils.widgets.text("environment", "qa")
environment = dbutils.widgets.get("environment").lower()

# dbutils.widgets.text("catalog", "dev_adb")
dbutils.widgets.text("schema", "nexusbenefitsquote_silver_mvp1")

# catalog: str = dbutils.widgets.get("catalog")
catalog = f"{environment}_adb"
schema: str = dbutils.widgets.get("schema")


spark.sql(f"USE CATALOG {catalog}")


# COMMAND ----------

import sys
from typing import List, Optional

import json

from pyspark.sql import DataFrame
from pyspark.sql.functions import col
from pyspark.sql.functions import col, sum, lit
from pyspark.sql.functions import *
from delta.tables import DeltaTable
from pyspark.sql.types import *
import os
import sys
dirs = os.path.abspath(os.path.join(os.getcwd(), "..", ".."))
sys.path.append(dirs)
# Import custom modules
from monitoring.silver.utils.costing_transformations import BillingUtils, BillingTransformations
from monitoring.gold.utils.costing import calculate_token_cost
from monitoring.utils.utils import is_dataframe_empty, write_to_delta_with_schema_merge


# COMMAND ----------

# Read silver data
try:
  silver_df = spark.table("nexusbenefitsquote_silver_mvp1.tbl_model_serving_costs")
  silver_endpoints_df = spark.table(f"{catalog}.nexusbenefitsquote_silver_mvp1.tbl_chat_completions_response")
except Exception as e:
  print(e)

# COMMAND ----------

_# Load model configurations from JSON
model_config_path = 'openai_cost_config.json'

with open(model_config_path, 'r') as file:
    model_configs = json.load(file)["openai_model_config"]

# Create a mapping from model names to configurations
model_config_map = {config["model"]: config for config in model_configs}


# COMMAND ----------

from pyspark.sql.functions import col, when, regexp_replace, lit, udf, trim
from pyspark.sql.types import FloatType

try:

    # Filter out rows with null or empty model
    filtered_df = silver_endpoints_df.filter(
        (col('model').isNotNull()) & (trim(col('model')) != "")
    )

    # Define UDF as before
    calculate_token_cost_udf = udf(
        lambda model_name, token_type, token_count: calculate_token_cost(
            model_name, token_type, token_count, model_config_map
        ),
        FloatType()
    )

    # Calculate costs
    df = filtered_df.withColumn(
        'input_cost',
        calculate_token_cost_udf(
            col('model'),
            lit('input_tokens'),
            col('prompt_tokens')
        )
    )

    df = df.withColumn(
        'output_cost',
        calculate_token_cost_udf(
            col('model'),
            lit('output_tokens'),
            col('completion_tokens')
        )
    )

    df = df.withColumn('total_cost', col('input_cost') + col('output_cost'))
    df.select('databricks_request_id', 'model', 'input_cost', 'output_cost', 'total_cost')
    df = df.dropDuplicates(["databricks_request_id"])
    #display(df)
    model_costs_df = df.groupBy('date','model').agg(
            sum('input_cost').alias('total_input_cost'),
            sum('output_cost').alias('total_output_cost'),
            sum('total_cost').alias('total_cost')
        )
    print("Aggregated Costs per Model:")
    #display(model_costs_df)

except Exception as e:
    print(e)

# COMMAND ----------

"""
# Aggregate total cost per endpoint per day
endpoint_costs_df = silver_df.groupBy(
    'usage_metadata_endpoint_id',
    'usage_metadata_endpoint_name',
    'usage_date'
).agg(
    sum('cost_dollar').alias('total_cost')
)

endpoint_costs_df = endpoint_costs_df.orderBy('usage_metadata_endpoint_id', 'usage_date')
"""

# COMMAND ----------

from delta.tables import DeltaTable
try:
    gold_table_name = 'nexusbenefitsquote_gold_mvp1.tbl_inference_token_costs'

    # Check if the gold table exists using Spark catalog API
    table_exists = spark.catalog.tableExists(gold_table_name)

    if table_exists:
        # Load the existing Delta table
        delta_table = DeltaTable.forName(spark, gold_table_name)

        # Define the merge condition based on unique identifiers
        merge_condition = "target.databricks_request_id = source.databricks_request_id"

        # Perform the merge
        delta_table.alias("target").merge(
            source=df.alias("source"),
            condition=merge_condition
        ).whenMatchedUpdateAll() \
        .whenNotMatchedInsertAll() \
        .execute()

        print("Merge completed into existing gold table.")
    else:
        # Write the DataFrame as a new Delta table
        df.write.format('delta').mode('append').saveAsTable(gold_table_name)
        print("Gold table created and data written.")
except Exception as e:
    print(e)

# COMMAND ----------

source_table = f"{environment}_adb.nexusbenefitsquote_silver_mvp1.tbl_custom_model_response"
target_table = f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_custom_model_response"

df = spark.table(source_table)
df.write.format("delta").mode("overwrite").saveAsTable(target_table)

# COMMAND ----------

from pyspark.sql.functions import regexp_extract, col, concat_ws
from pyspark.sql.functions import split, col, element_at, trim, try_element_at, lit
df_token_costs = spark.table(f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_inference_token_costs")
df_feedback = spark.table(f"{environment}_adb.gold.tbl_benefitsquote_feedback")

df_feedback_renamed = df_feedback.withColumnRenamed("session_id", "feedback_session_id") \
                                 .withColumnRenamed("user_id", "feedback_user_id")

df_joined_feedback = df_token_costs.join(
    df_feedback_renamed,
    on="question_id",
    how="left"
)
#df_joined_feedback.select("request").printSchema()
start_point = "Insurance plan data:"
end_point = "Your response must rely"

df_joined_feedback = df_joined_feedback.withColumn(
    "split_by_start",
    split(col("request"), start_point, 2)
).withColumn(
    "after_start",
    try_element_at(col("split_by_start"), lit(2))
).withColumn(
    "split_by_end",
    split(col("after_start"), end_point, 2)
).withColumn(
    "answer_used_context",
    trim(try_element_at(col("split_by_end"), lit(1)))
).drop("split_by_start", "after_start", "split_by_end")

#display(df_joined_feedback)##


# COMMAND ----------

import re
from pyspark.sql.functions import udf
from pyspark.sql.types import ArrayType, StringType

def extract_all_benefit_ids(request):
    if request is None:
        return []
    return re.findall(r"'benefit_id':\s*'([^']*)'", request)

extract_all_benefit_ids_udf = udf(extract_all_benefit_ids, ArrayType(StringType()))

df_benefit_ids = df_joined_feedback.withColumn(
    "benefit_id",
    extract_all_benefit_ids_udf(col("request"))
)
df_benefit_id_row=df_benefit_ids
#display(df_benefit_id_row)

# COMMAND ----------

from pyspark.sql.functions import sum, col, first, countDistinct

df_custom_model = spark.table(
    f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_custom_model_response"
).withColumnRenamed("request_date", "custom_model_date") \
 .withColumnRenamed("question", "custom_question") \
 .withColumnRenamed("answer", "custom_answer") \
 .withColumnRenamed("custom_response_id", "custom_response_id") \
 .withColumnRenamed("custom_session_id", "custom_session_id") \
 .withColumnRenamed("execution_duration_ms","custom_execution_duration_ms")
df_custom_model=df_custom_model.dropDuplicates(["custom_user_id","custom_session_id","custom_session_id"])
df_feedback_token_cost = df_benefit_id_row
df_feedback_token_cost=df_feedback_token_cost.dropDuplicates(["user_id","session_id","question_id"])


df_joined = df_custom_model.join(
    df_feedback_token_cost,
    (col("custom_user_id") == col("user_id")) &
    (col("custom_question_id") == col("question_id")) &
    (col("custom_session_id") == col("session_id")),
    how="left"
)

df_joined.createOrReplaceTempView("joined_table")

spark.conf.set("spark.sql.shuffle.partitions", 400)

final_df = spark.sql("""
    SELECT
        custom_user_id AS custom_user_id,
        custom_model_date AS request_date,
        productid AS plan_id,
        effective_date AS effective_date,
        custom_user_id AS user_id,
        custom_question AS question,
        custom_answer AS answer,
        feedback_type AS feedback_type,
        additional_comments AS additional_comments,
        total_tokens AS total_token,
        total_cost AS total_cost,
        execution_duration_ms,
        answer_used_context,
        benefit_id,
        reason_code,
        question_id
    FROM joined_table
    """)
#final_df.count()
#display(final_df)

# COMMAND ----------

from pyspark.sql.functions import round as spark_round

bronze_master_df = spark.table(f"{environment}_adb.nexusbenefitsquote_bronze_mvp1.master_table").alias("bm").drop("plan_id")

final_df_with_plan_type = final_df.join(
    bronze_master_df,
    (final_df.plan_id == bronze_master_df.facets_product_id) &
    (final_df.effective_date == bronze_master_df.product_effective_date),
    how="left"
).select(
    *[col for col in final_df.columns if col != "total_cost"],
    spark_round("total_cost", 4).alias("total_cost"),
    bronze_master_df["plan_type"], bronze_master_df["product_description"]
)

#display(final_df_with_plan_type)

# COMMAND ----------

from delta.tables import DeltaTable

target_table = f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_mat_etl_monitoring"

if spark.catalog.tableExists(target_table):
    delta_table = DeltaTable.forName(spark, target_table)
    
    merge_condition = (
        "target.user_id = source.user_id AND "
        "target.request_date = source.request_date AND "
        "target.plan_id = source.plan_id AND "
        "target.effective_date = source.effective_date AND "
        "target.question = source.question AND "
        "target.answer = source.answer"
    )
    delta_table.alias("target").merge(
        source=final_df_with_plan_type.alias("source"),
        condition=merge_condition
    ).whenNotMatchedInsertAll().execute()
else:
    final_df_with_plan_type.write.format("delta").mode("overwrite").saveAsTable(target_table)

# COMMAND ----------

final_df.createOrReplaceTempView("final_df")
agg_df_final = spark.sql("""
    SELECT
        user_id,
        request_date,
        COUNT(DISTINCT plan_id) AS num_plans,
        COUNT( question) AS num_questions,
        SUM(total_token) AS total_token,
        SUM(total_cost) AS total_cost,
        COUNT(*) AS total_rows
    FROM final_df
    GROUP BY user_id, request_date
    ORDER BY user_id, request_date
""")

#display(agg_df_final)

# COMMAND ----------

from delta.tables import DeltaTable

target_table = f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_mat_etl_monitoring_dashboard"

if spark.catalog.tableExists(target_table):
    delta_table = DeltaTable.forName(spark, target_table)
    merge_condition = (
        "target.user_id = source.user_id AND "
        "target.request_date = source.request_date"
    )
    delta_table.alias("target").merge(
        source=agg_df_final.alias("source"),
        condition=merge_condition
    ).whenMatchedUpdateAll() \
     .whenNotMatchedInsertAll() \
     .execute()
else:
    agg_df_final.write.format("delta").mode("overwrite").saveAsTable(target_table)