# Databricks notebook source
dbutils.library.restartPython()

# COMMAND ----------


from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)

# COMMAND ----------

from databricks.sdk import WorkspaceClient
import re

w = WorkspaceClient()
DATABRICKS_HOST = w.config.host

# Extract the number after 'adb-' and before the first '.'
match = re.search(r'adb-(\d+)\.', DATABRICKS_HOST)
workspace_id = match.group(1) if match else None

print(f"Workspace Host: {DATABRICKS_HOST}")
print(f"Workspace ID: {workspace_id}")

# COMMAND ----------

dbutils.widgets.text("environment", "qa")
environment = dbutils.widgets.get("environment").lower()

catalog = f"{environment}_adb"
dbutils.widgets.text("schema", "nexusbenefitsquote_silver_mvp1")
schema = dbutils.widgets.get("schema").lower()

# Set the catalog and schema
spark.sql(f"USE CATALOG {catalog}")



# COMMAND ----------

import sys
from typing import List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import col
from pyspark.sql.functions import col, sum

import os
import sys
dirs = os.path.abspath(os.path.join(os.getcwd(), "..", ".."))
sys.path.append(dirs)
# Import custom modules
from monitoring.silver.utils.costing_transformations import BillingUtils, BillingTransformations
from monitoring.gold.utils.costing import calculate_token_cost
from monitoring.utils.utils import is_dataframe_empty, write_to_delta_with_schema_merge


# COMMAND ----------

billing_utils = BillingUtils()

# COMMAND ----------

# Read silver data
silver_df = spark.table("nexusbenefitsquote_silver_mvp1.tbl_model_servings_costs")


# COMMAND ----------

# Aggregate total cost per endpoint per day
endpoint_costs_df = silver_df.groupBy(
    'usage_metadata_endpoint_id',
    'usage_metadata_endpoint_name',
    'usage_metadata_app_id',
    'usage_metadata_app_name',
    'usage_date'
).agg(
    sum('cost_dollar').alias('total_cost')
)

endpoint_costs_df = endpoint_costs_df.orderBy(
    'usage_metadata_endpoint_name',
    'usage_metadata_app_name',
    'usage_date'
)

# COMMAND ----------

gold_endpoint_costs_df = spark.createDataFrame([], endpoint_costs_df.schema)
gold_table_exists = False
new_records_df = endpoint_costs_df.alias('new').join(
    gold_endpoint_costs_df.alias('existing'),
    on=['usage_metadata_endpoint_id', 'usage_metadata_endpoint_name', 'usage_date'],
    how='left_anti'
)

# COMMAND ----------

# Ensure the gold schema exists in the current catalog
current_catalog = spark.sql("SELECT current_catalog()").collect()[0][0]
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {current_catalog}.nexusbenefitsquote_gold_mvp1")

gold_table_name = f"{current_catalog}.nexusbenefitsquote_gold_mvp1.tbl_endpoint_apps_costs"

if new_records_df.head(1):
    if gold_table_exists:
        new_records_df.write.format('delta').mode('append').saveAsTable(gold_table_name)
        print("New records appended to the existing gold table.")
    else:
        new_records_df.write.format('delta').mode('overwrite').saveAsTable(gold_table_name)
        print("Gold table created and new records written.")
else:
    print("No new records to write to the gold table.")

updated_gold_df = spark.table(gold_table_name)