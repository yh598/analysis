from pyspark.sql import DataFrame
from pyspark.sql.functions import col

class SilverToGoldTransformations:
    @staticmethod
    def transform_serving_costs(
        serving_df: DataFrame,
        endpoint_df: DataFrame
    ) -> DataFrame:
        """
        Transforms the serving costs data by joining with endpoint logs.

        Args:
            serving_df (DataFrame): The serving costs DataFrame from silver.
            endpoint_df (DataFrame): The endpoint logs DataFrame from gold.

        Returns:
            DataFrame: The transformed DataFrame ready for gold layer.
        """
        endpoint_df_dedup = endpoint_df.select(
            "date", "model_name", "model_version"
        ).dropDuplicates(["date"])

        joined_df = serving_df.join(
            endpoint_df_dedup,
            serving_df["usage_date"] == endpoint_df_dedup["date"],
            how="left"
        )

        result_df = joined_df.select(
            serving_df["*"],
            endpoint_df_dedup["model_version"],
            endpoint_df_dedup["model_name"]
        )

        return result_df
