# MVP1 Nexus Benefits Quote - Monitoring System

## Overview

The **Monitoring System** is a comprehensive data processing pipeline built on Databricks that implements a medallion architecture (Bronze → Silver → Gold) for tracking, analyzing, and optimizing AI/ML model usage, costs, and performance metrics. This system processes inference logs, billing data, and usage metrics to provide actionable insights for the MVP1 Nexus Benefits Quote application.

---

## Table of Contents

* [Project Structure](#project-structure)
* [Architecture](#architecture)
* [Installation & Setup](#installation--setup)
* [Module Documentation](#module-documentation)
  * [Bronze Layer](#bronze-layer)
  * [Silver Layer](#silver-layer)
  * [Gold Layer](#gold-layer)
  * [Utilities](#utilities)
  * [Schemas](#schemas)
* [Key Features](#key-features)
* [Usage Examples](#usage-examples)
* [Contributing](#contributing)

---

## Project Structure

```
monitoring/
├── bronze/                          # Raw data ingestion layer
│   ├── costing_logs.ipynb          # 📓 Notebook: Bronze costing data ingestion
│   ├── inference_logs.ipynb        # 📓 Notebook: Bronze inference log ingestion
│   ├── raw_bronze.yaml             # ⚙️ DLT pipeline configuration for raw to bronze
│   ├── costing/                     # Cost-related data processing
│   │   ├── costing_workflow.py     # Main costing workflow orchestration
│   │   └── calculate_token_cost.py # Token cost calculation utilities
│   ├── inference/                   # Inference log processing
│   │   ├── process_inference.py    # Main inference processing logic
│   │   └── processing_strategies.py # Strategy pattern for different model types
│   ├── schemas/                     # Bronze layer schema definitions
│   │   ├── billing.py              # Billing data schemas
│   │   ├── requests.py             # Request/response schemas
│   │   └── schema.py               # General bronze schemas
│   └── utils/                       # Bronze layer utilities
│       ├── data_filtering.py       # Data filtering strategies
│       └── delta_processing.py     # Delta table operations
├── silver/                          # Cleansed and transformed data layer
│   ├── costing.ipynb               # 📓 Notebook: Silver costing transformations
│   ├── inference.ipynb             # 📓 Notebook: Silver inference transformations
│   ├── silver-gold.yaml            # ⚙️ DLT pipeline configuration for silver to gold
│   ├── schemas/                     # Silver layer schema definitions
│   │   ├── billing_schema.py       # Silver billing schemas
│   │   └── schema.py               # General silver schemas
│   └── utils/                       # Silver layer utilities
│       ├── costing_transformations.py # Cost calculation transformations
│       ├── process_inference.py    # Inference data transformations
│       └── cleaning.py             # Data cleaning utilities
├── gold/                            # Business-ready aggregated data layer
│   ├── costing_table_iceberg_table.ipynb # 📓 Notebook: Gold costing Iceberg tables
│   ├── costing_token_count.ipynb   # 📓 Notebook: Token count aggregations
│   ├── openai_cost_config.json     # 💰 OpenAI model pricing configuration
│   ├── requirements.txt            # 📦 Python dependencies
│   ├── schema.py                    # Gold layer schemas
│   ├── transformations/             # Gold layer transformations
│   │   └── costing_transformations.py # Final cost aggregations
│   └── utils/                       # Gold layer utilities
│       ├── costing.py              # Cost calculation functions
│       └── optimisation.py         # Batch processing optimization
├── utils/                           # Shared utilities across all layers
│   ├── dataframe_transformations.py # DataFrame flattening utilities
│   └── utils.py                     # General utility functions
└── Readme.md                        # This file
```

---

## Architecture

### Medallion Architecture

The monitoring system follows the **Medallion Architecture** pattern:

1. **Bronze Layer (Raw)**: Ingests raw data from various sources with minimal transformation
2. **Silver Layer (Cleansed)**: Applies data quality rules, deduplication, and standardization
3. **Gold Layer (Curated)**: Creates business-ready aggregations and metrics

### Data Flow

```
Raw Sources → Bronze Tables → Silver Tables → Gold Tables → Analytics/Dashboards
     ↓              ↓              ↓              ↓
  Inference    Deduplication  Transformations  Aggregations
   Billing     Validation     Enrichment       Metrics
   Logs        Filtering      Joins            KPIs
```

---

## Installation & Setup

### Prerequisites

* Databricks Runtime 13.3 LTS or higher
* Unity Catalog enabled workspace
* Python 3.10+
* Required libraries: `pyspark`, `tiktoken`

### Environment Setup

```python
# Set catalog and schema
catalog = "dev_adb"
schema = "nexusbenefitsquote_bronze_mvp1"

# Configure Spark session
spark.sql(f"USE CATALOG {catalog}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
```

### Installation

```bash
# Install required Python packages
pip install tiktoken
```

---

## Module Documentation

### Bronze Layer

The Bronze layer handles raw data ingestion from multiple sources including inference logs, billing data, and system metrics.

#### 📁 **bronze/costing/**

##### `costing_workflow.py`

**Purpose**: Orchestrates the end-to-end costing data workflow from raw billing data to bronze tables.

**Key Classes**:

* **`DataWriter`**: Handles common data processing and writing operations
  * `process_and_write()`: Processes and writes data with optional filtering
  
* **`CostingWorkflow`**: Manages costing-specific transformations
  * `filter_billing_data_for_bronze()`: Filters billing data for AI Gateway, Model Serving, Vector Search, and Apps
  * `write_costing_data_to_bronze()`: Writes filtered costing data to bronze tables

* **`DataPipeline`**: Generic data processing pipeline for various workflows

**Usage Example**:

```python
from monitoring.bronze.costing.costing_workflow import CostingWorkflow, DataWriter
from monitoring.bronze.utils.delta_processing import DeltaTableManager

# Initialize components
delta_manager = DeltaTableManager(spark)
data_writer = DataWriter(delta_manager)
costing_workflow = CostingWorkflow(data_writer, workspace_id="your_workspace_id")

# Process billing data
costing_workflow.write_costing_data_to_bronze(
    table_name="system.billing.usage",
    schema=billing_schema,
    unique_id_col="record_id"
)
```

##### `calculate_token_cost.py`

**Purpose**: Calculates token costs for OpenAI models based on usage.

**Key Functions**:

* `get_model_config(model_name: str) -> dict`: Retrieves model configuration from JSON
* `count_tokens(prompt: str, model_name: str) -> int`: Tokenizes input using tiktoken
* `calculate_token_cost(model_name: str, token_type: str, token_count: int) -> float`: Calculates cost based on token count

**Usage Example**:

```python
from monitoring.bronze.costing.calculate_token_cost import calculate_token_cost, count_tokens

# Count tokens in a prompt
token_count = count_tokens("What is the benefit coverage?", "gpt-4")

# Calculate cost
input_cost = calculate_token_cost("gpt-4", "input_tokens", token_count)
output_cost = calculate_token_cost("gpt-4", "output_tokens", 150)
```

---

#### 📁 **bronze/inference/**

##### `process_inference.py`

**Purpose**: Processes raw inference logs and writes deduplicated data to bronze tables.

**Key Classes**:

* **`BronzeTableProcessor`**: Main processor for raw-to-bronze transformation
  * `process_raw_to_bronze()`: Applies processing strategy, filters duplicates, and writes to Delta

**Usage Example**:

```python
from monitoring.bronze.inference.process_inference import BronzeTableProcessor
from monitoring.bronze.inference.processing_strategies import ChatProcessingStrategy
from monitoring.bronze.utils.delta_processing import DeltaTableWriter

# Initialize processor
delta_writer = DeltaTableWriter(spark, "bronze.inference_logs")
processor = BronzeTableProcessor(spark, delta_writer)

# Process inference logs
processor.process_raw_to_bronze(
    raw_table_name="raw.inference_logs",
    processing_strategy=ChatProcessingStrategy(),
    bronze_table_name="bronze.inference_logs",
    id_column="databricks_request_id"
)
```

##### `processing_strategies.py`

**Purpose**: Implements strategy pattern for processing different model types.

**Key Classes**:

* **`BaseProcessingStrategy`**: Abstract base class for processing strategies
  * `_extract_request_time()`: Extracts and converts request timestamps

* **`ChatProcessingStrategy`**: Processes OpenAI chat completion logs
  * Parses request/response JSON
  * Extracts prompts, completions, and token counts
  * Handles multiple message formats

* **`CustomModelProcessingStrategy`**: Processes custom model inference logs
  * Extracts custom metadata (user_id, session_id, question_id)
  * Handles custom request/response formats

**Usage Example**:

```python
from monitoring.bronze.inference.processing_strategies import ChatProcessingStrategy

# Apply chat processing strategy
strategy = ChatProcessingStrategy()
processed_df = strategy.process(raw_inference_df)
```

---

#### 📁 **bronze/utils/**

##### `delta_processing.py`

**Purpose**: Provides utilities for Delta table operations including creation, writing, and schema management.

**Key Classes**:

* **`DeltaTableWriter`**: Handles Delta table writing with schema evolution
  * `table_exists()`: Checks if table exists
  * `create_table_with_schema()`: Creates table with specified schema
  * `write_data()`: Writes data with automatic schema merging

* **`DeltaTableManager`**: Manages Delta table lifecycle
  * `create_delta_table()`: Creates partitioned Delta tables
  * `write_new_data_to_bronze()`: Writes only new records (deduplication)

**Key Functions**:

* `is_dataframe_empty(df) -> bool`: Checks if DataFrame is empty
* `write_to_delta_with_schema_merge(df, table_name, mode)`: Writes with schema evolution

**Usage Example**:

```python
from monitoring.bronze.utils.delta_processing import DeltaTableManager

# Initialize manager
delta_manager = DeltaTableManager(spark)

# Create table with schema
delta_manager.create_delta_table(
    table_name="bronze.inference_logs",
    schema=inference_schema,
    partition_columns=["request_date"]
)

# Write new data only
delta_manager.write_new_data_to_bronze(
    df_flattened=processed_df,
    bronze_table_name="bronze.inference_logs",
    unique_id_col="databricks_request_id",
    schema=inference_schema
)
```

##### `data_filtering.py`

**Purpose**: Implements filtering strategies using the Strategy pattern.

**Key Classes**:

* **`DataFilteringStrategy`**: Abstract base class for filtering strategies
  * `apply(df: DataFrame) -> DataFrame`: Applies filtering logic

* **`StatusCodeFilter`**: Filters records by HTTP status code
  * Default: Filters out 400 status codes

**Usage Example**:

```python
from monitoring.bronze.utils.data_filtering import StatusCodeFilter

# Filter out error responses
filter_strategy = StatusCodeFilter(status_code=400)
filtered_df = filter_strategy.apply(raw_df)
```

---

#### 📁 **bronze/schemas/**

##### `billing.py`

**Purpose**: Defines schemas for system billing and pricing data.

**Key Functions**:

* `get_system_billing_schema() -> StructType`: Returns billing usage schema
  * Fields: workspace_id, usage_date, billing_origin_product, cost, usage_quantity, etc.

* `get_system_prices_schema() -> StructType`: Returns pricing schema
  * Fields: account_id, sku_name, pricing (amount, currency, unit)

##### `schema.py`

**Purpose**: Defines schemas for inference request/response data.

**Key Functions**:

* `get_request_schema() -> StructType`: Chat completion request schema
* `get_chat_response_schema() -> StructType`: Chat completion response schema
* Includes nested structures for messages, choices, and usage metrics

##### `requests.py`

**Purpose**: Additional request-specific schema definitions for various model types.

---

### Silver Layer

The Silver layer cleanses, validates, and enriches bronze data for analytical consumption.

#### 📁 **silver/utils/**

##### `costing_transformations.py`

**Purpose**: Transforms billing data for cost analysis and reporting.

**Key Classes**:

* **`BillingUtils`**: Utility methods for billing data operations
  * `clean_billing_df()`: Removes unnecessary columns
  * `filter_billing_data()`: Filters by workspace, SKU, and date
  * `calculate_cost()`: Computes cost from usage and pricing

* **`BillingTransformations`**: Advanced billing transformations
  * `cleanse_and_join()`: Joins billing and pricing data
  * `apply_cost_conversion()`: Applies pricing conversions

**Usage Example**:

```python
from monitoring.silver.utils.costing_transformations import BillingUtils, BillingTransformations

# Clean and filter billing data
cleaned_df = BillingUtils.clean_billing_df(billing_df)
filtered_df = BillingUtils.filter_billing_data(
    cleaned_df, 
    workspace_id="123456", 
    start_date="2025-01-01"
)

# Calculate costs
cost_df = BillingUtils.calculate_cost(filtered_df)
```

##### `process_inference.py`

**Purpose**: Transforms bronze inference data for silver layer consumption.

---

#### 📁 **silver/schemas/**

##### `billing_schema.py`

**Purpose**: Defines silver layer schemas for cost and billing tables.

**Key Functions**:

* `get_silver_serving_costs_schema() -> StructType`: Model serving costs schema
  * Fields: usage_date, workspace_id, sku_name, usage_quantity, cost_dollar, pricing_conversion

* `get_silver_cluster_costs_schema() -> StructType`: Cluster costs schema
  * Fields: usage_date, workspace_id, cluster_id, cost_dollars, pricing_conversion

---

### Gold Layer

The Gold layer provides business-ready, aggregated metrics and KPIs.

#### 📁 **gold/utils/**

##### `costing.py`

**Purpose**: Final cost calculation functions for gold layer metrics.

**Key Functions**:

* `calculate_token_cost(model_name, token_type, token_count, model_config_map) -> float`
  * Calculates token costs in USD
  * Supports input/output token pricing
  * Handles per-1K and per-1M pricing models

**Usage Example**:

```python
from monitoring.gold.utils.costing import calculate_token_cost

# Load model config
model_config_map = {...}  # From openai_cost_config.json

# Calculate costs
input_cost = calculate_token_cost("gpt-4", "input_tokens", 1000, model_config_map)
output_cost = calculate_token_cost("gpt-4", "output_tokens", 500, model_config_map)
total_cost = input_cost + output_cost
```

##### `optimisation.py`

**Purpose**: Batch processing optimization for large-scale data processing.

**Key Functions**:

* `process_batch(batch_df, metrics_manager, target_table)`: Processes a single batch
* `process_data_in_batches(df, metrics_manager, target_table, num_partitions)`: Partitions and processes data in parallel

**Usage Example**:

```python
from monitoring.gold.utils.optimisation import process_data_in_batches

# Process large dataset in batches
process_data_in_batches(
    df=large_inference_df,
    metrics_manager=metrics_manager,
    target_table="gold.qa_metrics",
    num_partitions=10
)
```

---

#### 📁 **gold/transformations/**

##### `costing_transformations.py`

**Purpose**: Final cost aggregations and transformations for business reporting.

---

#### 📁 **gold/schema.py**

**Purpose**: Defines gold layer schemas for analytics and reporting.

**Key Schema**:

* `gold_qa_metrics_schema`: Comprehensive QA metrics schema
  * Fields: databricks_request_id, client_request_id, request_date, request_time, status_code, execution_duration_ms, message_role, message_content, finish_reason, response_content, model_ID, prompt_tokens, completion_tokens, total_tokens, etc.

---

### Utilities

#### 📁 **utils/**

##### `dataframe_transformations.py`

**Purpose**: Generic DataFrame transformation utilities used across all layers.

**Key Functions**:

* `flatten_dataframe(df: DataFrame) -> DataFrame`
  * Recursively flattens nested StructType, ArrayType, and MapType columns
  * Handles complex nested structures
  * Preserves data integrity during flattening

**Usage Example**:

```python
from monitoring.utils.dataframe_transformations import flatten_dataframe

# Flatten nested JSON structure
nested_df = spark.read.json("path/to/nested/json")
flat_df = flatten_dataframe(nested_df)
```

**Technical Details**:

* Handles StructType: Flattens nested structures with dot notation
* Handles ArrayType: Explodes arrays of structs
* Handles MapType: Converts maps to key-value columns
* Iterative approach ensures complete flattening

---

## Key Features

### 1. **Multi-Model Support**

* OpenAI Chat Completions (GPT-3.5, GPT-4)
* Custom Databricks Models
* Extensible strategy pattern for new model types

### 2. **Cost Tracking**

* Token-level cost calculation
* Multi-product billing (AI Gateway, Model Serving, Vector Search, Apps)
* Real-time cost monitoring
* Historical cost analysis

### 3. **Data Quality**

* Automatic deduplication
* Schema evolution support
* Data validation and filtering
* Error handling and logging

### 4. **Performance Optimization**

* Delta Lake for ACID transactions
* Partitioned tables for query performance
* Batch processing for large datasets
* Broadcast joins for small dimension tables

### 5. **Observability**

* Request/response logging
* Execution duration tracking
* Status code monitoring
* Token usage metrics

---

## Usage Examples

### End-to-End Workflow

```python
# 1. Bronze Layer: Ingest raw data
from monitoring.bronze.inference.process_inference import BronzeTableProcessor
from monitoring.bronze.inference.processing_strategies import ChatProcessingStrategy
from monitoring.bronze.utils.delta_processing import DeltaTableWriter

delta_writer = DeltaTableWriter(spark, "bronze.inference_logs")
processor = BronzeTableProcessor(spark, delta_writer)
processor.process_raw_to_bronze(
    raw_table_name="raw.inference_logs",
    processing_strategy=ChatProcessingStrategy(),
    bronze_table_name="bronze.inference_logs"
)

# 2. Silver Layer: Transform and enrich
from monitoring.silver.utils.costing_transformations import BillingUtils

billing_df = spark.table("bronze.billing_usage")
cleaned_df = BillingUtils.clean_billing_df(billing_df)
cost_df = BillingUtils.calculate_cost(cleaned_df)
cost_df.write.mode("overwrite").saveAsTable("silver.model_serving_costs")

# 3. Gold Layer: Aggregate metrics
from monitoring.gold.utils.costing import calculate_token_cost

# Calculate total costs by model
gold_df = spark.sql("""
    SELECT 
        model,
        DATE(request_date) as date,
        SUM(prompt_tokens) as total_input_tokens,
        SUM(completion_tokens) as total_output_tokens,
        COUNT(*) as request_count
    FROM silver.inference_logs
    GROUP BY model, DATE(request_date)
""")

# Apply cost calculations
# ... (use calculate_token_cost UDF)

gold_df.write.mode("overwrite").saveAsTable("gold.daily_model_costs")
```

### Monitoring Dashboard Query

```sql
-- Daily cost summary by product
SELECT 
    usage_date,
    billing_origin_product,
    SUM(cost_dollar) as total_cost,
    SUM(usage_quantity) as total_usage
FROM silver.model_serving_costs
WHERE usage_date >= CURRENT_DATE - INTERVAL 30 DAYS
GROUP BY usage_date, billing_origin_product
ORDER BY usage_date DESC, total_cost DESC
```

---



### Testing

```python
# Example unit test structure
import pytest
from monitoring.bronze.inference.processing_strategies import ChatProcessingStrategy

def test_chat_processing_strategy():
    strategy = ChatProcessingStrategy()
    # ... test implementation
```

---

## Support & Contact

For questions, issues, or contributions, please contact the MVP1 Nexus Benefits Quote development team.

**Project Maintainer**: asinha01@blueshieldca.com

---

## License

Internal use only - Blue Shield of California

---

**Last Updated**: January 2025  
**Version**: 1.0.0