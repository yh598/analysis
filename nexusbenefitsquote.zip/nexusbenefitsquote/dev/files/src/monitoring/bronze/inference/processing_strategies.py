import os
import sys
from typing import Optional

from pyspark.sql.functions import (
    from_json, col, explode, regexp_extract, expr, lit
)
from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    array,
    coalesce,
    col,
    concat_ws,
    explode,
    expr,
    from_json,
    lit,
    size,
    to_date,
    to_timestamp,
    when,
)
from pyspark.sql.types import *
from pyspark.sql.functions import *

sys.path.append('../../../.')

from monitoring.bronze.schemas.schema import *

def get_completions_request_schema() -> StructType:
    return StructType([
    StructField("prompt", StringType(), True),        
    StructField("max_tokens", IntegerType(), True),    
    StructField("temperature", FloatType(), True)     
])

class BaseProcessingStrategy:
    """Base class for processing strategies."""

    def _extract_request_time(self, df: DataFrame) -> DataFrame:
        """
        Extracts and converts the request time from the DataFrame.

        Parameters
        ----------
        df : DataFrame
            Input DataFrame containing request data.

        Returns
        -------
        DataFrame
            DataFrame with the 'request_time' column converted to timestamp.

        Raises
        ------
        ValueError
            If no timestamp column is found in the DataFrame.
        """
        if "request_time" in df.columns:
            return df.withColumn("request_time", to_timestamp(col("request_time")))
        elif "timestamp_ms" in df.columns:
            return df.withColumn(
                "request_time", (col("timestamp_ms") / 1000).cast("timestamp")
            )
        else:
            raise ValueError("No timestamp column found in DataFrame")

class ChatProcessingStrategy(BaseProcessingStrategy):
    def process(self, df: DataFrame) -> DataFrame:
        df = self._extract_request_time(df)
        request_schema = get_request_schema()
        response_schema = get_chat_response_schema()

        bronze_df = (
            df.withColumn("parsed_request", from_json(col("request"), request_schema))
            .withColumn("parsed_response", from_json(col("response"), response_schema))
            .withColumn("choice", explode(col("parsed_response.choices")))
            .withColumn(
                "model",
                coalesce(col("parsed_request.model"), col("parsed_response.model")),
            )
            .withColumn(
                "request_prompt",
                when(
                    col("parsed_request.prompt").isNotNull(),
                    col("parsed_request.prompt"),
                )
                .when(
                    col("parsed_request.messages").isNotNull(),
                    concat_ws(
                        " ",
                        expr("transform(parsed_request.messages, x -> x.content)"),
                    ),
                )
                .otherwise(lit(None)),
            )
            .withColumn("completion_text", col("choice.message.content"))
            .withColumn("input_token_count", col("parsed_response.usage.prompt_tokens").cast(IntegerType()))
            .withColumn("output_token_count", col("parsed_response.usage.completion_tokens").cast(IntegerType()))
            .withColumn("finish_reason", col("choice.finish_reason"))
            .withColumn("max_tokens", col("parsed_request.max_tokens").cast(IntegerType()))
            .withColumn("temperature", col("parsed_request.temperature").cast(DoubleType()))
            # 
            .withColumn("prompt_tokens", col("input_token_count"))
            .withColumn("completion_tokens", col("output_token_count"))
            .withColumn("total_tokens", (col("prompt_tokens") + col("completion_tokens")))
        )

        # 
        expected_columns = {
            "request_date": DateType(),
            "date": DateType(),
            "databricks_request_id": StringType(),
            "client_request_id": StringType(),
            "request_time": TimestampType(),
            "status_code": IntegerType(),
            "sampling_fraction": DoubleType(),
            "execution_duration_ms": LongType(),
            "request": StringType(),
            "response": StringType(),
            "served_entity_id": StringType(),
            "logging_error_codes": ArrayType(StringType()),
            "requester": StringType(),
            "model": StringType(),
            "request_prompt": StringType(),
            "max_tokens": IntegerType(),
            "temperature": DoubleType(),
            "completion_text": StringType(),
            "input_token_count": IntegerType(),
            "output_token_count": IntegerType(),
            "prompt_tokens": IntegerType(),
            "completion_tokens": IntegerType(),
            "total_tokens": IntegerType(),
            "finish_reason": StringType()
        }
        for col_name, col_type in expected_columns.items():
            if col_name not in bronze_df.columns:
                bronze_df = bronze_df.withColumn(col_name, lit(None).cast(col_type))

        # Set date and request_date columns
        bronze_df = bronze_df.withColumn(
            "date", to_date(col("request_time"))
        ).withColumn(
            "request_date", to_date(col("request_time"))
        )

        # Select columns in the required order
        select_expr = [
            "request_date",
            "date",
            "databricks_request_id",
            "client_request_id",
            "request_time",
            "status_code",
            "sampling_fraction",
            "execution_duration_ms",
            "request",
            "response",
            "served_entity_id",
            "logging_error_codes",
            "requester",
            "model",
            "request_prompt",
            "max_tokens",
            "temperature",
            "completion_text",
            "input_token_count",
            "output_token_count",
            "prompt_tokens",
            "completion_tokens",
            "total_tokens",
            "finish_reason"
        ]
        bronze_df = bronze_df.select(*select_expr)
        return bronze_df

class CustomModelProcessingStrategy(BaseProcessingStrategy):
    """Processing strategy for the custom chat model."""

    def process(self, df):
        df = self._extract_request_time(df)

        bronze_df = (
            df
            .withColumn("parsed_request", from_json(col("request"), "STRUCT<messages:ARRAY<STRUCT<content:STRING>>>"))
            .withColumn("parsed_response", from_json(col("response"), "STRUCT<output:ARRAY<STRUCT<content:ARRAY<STRUCT<text:STRING>>>>>"))
            .withColumn(
                "request_prompt", 
                expr("concat_ws(' ', transform(parsed_request.messages, x -> x.content))")
            )
            .withColumn(
                "custom_inputs", 
                lit(None).cast("struct<user_id:string,username:string,session_id:string,question_id:string,productid_effectivedate_product:string>")
            )
            .withColumn("choice", explode(col("parsed_response.output")))
            .withColumn("completion_text", expr("choice.content[0].text"))
            .withColumn(
                "custom_outputs", 
                lit(None).cast("struct<session_id:string,username:string,user_id:string,question_id:string,productid_effectivedate_product:string>")
            )
            .withColumn("user_id", regexp_extract(col("client_request_id"), r"u-([^\|]+)", 1))
            .withColumn("session_id", regexp_extract(col("client_request_id"), r"s-([^\|]+)", 1))
            .withColumn("question_id", regexp_extract(col("client_request_id"), r"q-([^\|]+)", 1))
        )

        select_expr = [
            "databricks_request_id",
            "request_date",
            "client_request_id",
            "user_id",
            "session_id",
            "question_id",
            "request_time",
            "status_code",
            "sampling_fraction",
            "execution_duration_ms",
            "request",
            "response",
            "served_entity_id",
            "requester",
            "parsed_request",
            "parsed_response",
            "request_prompt",
            "custom_inputs",
            "custom_outputs",
            "choice",
            "completion_text"
        ]

        bronze_df = bronze_df.select(*select_expr)
        return bronze_df