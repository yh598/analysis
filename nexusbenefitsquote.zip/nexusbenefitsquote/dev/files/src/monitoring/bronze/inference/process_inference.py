import sys

sys.path.append('../../../.')

from monitoring.bronze.inference.processing_strategies import (
    BaseProcessingStrategy,
    ChatProcessingStrategy,
    CustomModelProcessingStrategy,
)
from monitoring.bronze.utils.data_filtering import DataFilteringStrategy
from monitoring.bronze.utils.delta_processing import DeltaTableWriter

from typing import Optional, Protocol
from pyspark.sql import DataFrame
from pyspark.sql.functions import broadcast
from pyspark.sql.utils import AnalysisException
from pyspark.sql import functions as F

from pyspark.sql import SparkSession


spark = SparkSession.builder \
    .appName("bronzeprocessor") \
    .getOrCreate()

class ProcessingStrategy(Protocol):
    """Protocol for processing strategies."""

    def process(self, df: DataFrame) -> DataFrame:
        ...

class BronzeTableProcessor:
    """Processes raw data, filters out duplicates, and writes to the bronze Delta table."""

    def __init__(
        self,
        spark: SparkSession,
        delta_writer: DeltaTableWriter,
        filtering_strategy: Optional[DataFilteringStrategy] = None,
    ) -> None:
        self.spark = spark
        self.delta_writer = delta_writer
        self.filtering_strategy = filtering_strategy

    def process_raw_to_bronze(
        self,
        raw_table_name: str,
        processing_strategy: ProcessingStrategy,
        bronze_table_name:str,
        id_column: str = "databricks_request_id",
    ) -> None:
        # Step 1: Check if raw table exists
        try:
            raw_df = self.spark.read.format("delta").table(raw_table_name)
            print(f"Successfully read raw table {raw_table_name} with {raw_df.count()} records.")
        except AnalysisException:
            print(f"Skipping {raw_table_name}: Table not found.")
            return

        # Step 2: Apply any filtering strategy
        if self.filtering_strategy:
            print("Applying filtering strategy to raw data.")
            raw_df = self.filtering_strategy.apply(raw_df)
            print(f"Data count after filtering: {raw_df.count()}")

        # Step 3: Transform the raw data
        print("Applying processing strategy to transform the raw data.")
        transformed_df = processing_strategy.process(raw_df)
        print(f"Data count after transformation: {transformed_df.count()}")

        try:
            bronze_df=spark.sql(f"select * from {bronze_table_name}")
            bronze_count=bronze_df.count()
        except Exception as e:
            print(e)
            bronze_count=0
        if bronze_count>0:
            print("Retrieving existing IDs from bronze table to avoid duplicates.")
            existing_ids_df = bronze_df.select(id_column)
            new_data_df = transformed_df.join(broadcast(existing_ids_df), on=id_column, how="left_anti")
            print(f"New records identified after deduplication: {new_data_df.count()}")
        else:
            new_data_df=transformed_df
        #this is for custom model process where model_id is received directly in response
        if "model_id" in new_data_df.columns:
            new_data_df = new_data_df.withColumnRenamed("model_id", "model")
        

        # Step 5: Write the new data to the bronze table if any
        self.delta_writer.write_data(new_data_df)