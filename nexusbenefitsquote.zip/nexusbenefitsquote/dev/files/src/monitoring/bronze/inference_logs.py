# Databricks notebook source
# MAGIC %pip install pyyaml

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
root_path = "/Workspace" + "/".join(notebook_path.split("/")[:-4])

# COMMAND ----------

dbutils.library.restartPython()
#

# COMMAND ----------

import sys
import os


from typing import Any
import yaml  # For reading the YAML configuration
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder \
    .appName("BronzeTableProcessor") \
    .getOrCreate()

# COMMAND ----------

#sg added
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


# COMMAND ----------

dirs = os.path.abspath(os.path.join(os.getcwd(), "..", ".."))
sys.path.append(dirs)
#print(dirs)

# COMMAND ----------

from monitoring.bronze.inference.processing_strategies import (
    ChatProcessingStrategy,
    CustomModelProcessingStrategy
)
from monitoring.bronze.utils.data_filtering import StatusCodeFilter
from monitoring.bronze.utils.delta_processing import DeltaTableWriter
from monitoring.bronze.inference.process_inference import BronzeTableProcessor

# COMMAND ----------

# Get the environment, catalog, and schema from Databricks widgets
dbutils.widgets.text("environment", "dev")

environment: str = dbutils.widgets.get("environment").lower()

catalog = f"{environment}_adb"

# Set Spark configuration
spark.sql(f"USE CATALOG {catalog}")


# COMMAND ----------


spark.sql(f"create schema if not exists {catalog}.nexusbenefitsquote_bronze_mvp1")
spark.sql(f"create schema if not exists {catalog}.nexusbenefitsquote_silver_mvp1")
spark.sql(f"create schema if not exists {catalog}.nexusbenefitsquote_gold_mvp1")

# COMMAND ----------

def load_config(config_path: str) -> dict:
    with open(config_path, "r") as file:
        config = yaml.safe_load(file)
    return config

environment = dbutils.widgets.get("environment")
filtering_strategy = StatusCodeFilter(status_code=400)

def process_tables(config_path: str):
    config = load_config(config_path)
    
    key = f"tables_{environment}"
    
    if key not in config:
        raise KeyError(
            f"Key '{key}' not found in config. Available keys: {list(config.keys())}"
        )

    processing_strategies = {
        "ChatProcessingStrategy": ChatProcessingStrategy
    }

    for table in config[key]:
        if "raw_table" not in table:
            continue

        raw_table_name = table['raw_table']
        bronze_table_name = table['bronze_table']
        strategy_name = table['processing_strategy']
        
        print(f"Starting processing for Raw Table: {raw_table_name} -> Bronze Table: {bronze_table_name} using {strategy_name}")
        
        # Initialize DeltaTableWriter for the current bronze table
        delta_writer = DeltaTableWriter(spark, bronze_table_name)
        
        processing_strategy_cls = processing_strategies.get(strategy_name)
        if processing_strategy_cls:
            processing_strategy = processing_strategy_cls()
        else:
            print(f"Unknown processing strategy: {strategy_name}")
            continue
        
        processor = BronzeTableProcessor(spark, delta_writer, filtering_strategy)
        
        print(f"Processing {raw_table_name} to {bronze_table_name} with {strategy_name}")
        try:
            processor.process_raw_to_bronze(raw_table_name, processing_strategy, bronze_table_name)
            print(f"Successfully processed {raw_table_name} to {bronze_table_name}")
        except Exception as e:
            print(f"Failed processing {raw_table_name} to {bronze_table_name} with error: {e}")


# COMMAND ----------

# Check if the bronze table exists, if not create it
config_path = "raw_bronze.yaml"
config = load_config(config_path)
table_entry = next(
    (t for t in config[f"tables_{environment}"] if t.get("bronze_table") == f"{catalog}.nexusbenefitsquote_bronze_mvp1.tbl_gpt_response"),
    None
)
if table_entry:
    raw_table_name = table_entry["raw_table"]
    bronze_table_full_name = table_entry["bronze_table"]
    if not spark.catalog.tableExists(bronze_table_full_name):
        df = spark.table(raw_table_name).limit(0)
        df.write.format("delta").mode("overwrite").saveAsTable(bronze_table_full_name)

# COMMAND ----------

config_path = "raw_bronze.yaml"  
process_tables(config_path)

# COMMAND ----------

# code for custom model definition
def load_config(config_path: str) -> dict:
    with open(config_path, "r") as file:
        config = yaml.safe_load(file)
    return config


filtering_strategy = StatusCodeFilter(status_code=400)

def process_tables_custom_model(config_path: str):
    config = load_config(config_path)
    processing_strategies = {
        "CustomModelProcessingStrategy": CustomModelProcessingStrategy
    }

    # Only process entries with 'custom_model_table'
    for table in config[f"tables_{environment}"]:
        if "custom_model_table" not in table:
            continue

        raw_table_name = table['custom_model_table']
        bronze_table_name = table['custom_bronze_table']
        strategy_name = table['custom_processing_strategy']

        print(f"Starting processing for Raw Table: {raw_table_name} -> Bronze Table: {bronze_table_name} using {strategy_name}")

        delta_writer = DeltaTableWriter(spark, bronze_table_name)
        processing_strategy_cls = processing_strategies.get(strategy_name)
        if processing_strategy_cls:
            processing_strategy = processing_strategy_cls()
        else:
            print(f"Unknown processing strategy: {strategy_name}")
            continue

        processor = BronzeTableProcessor(spark, delta_writer, filtering_strategy)
        print(f"Processing {raw_table_name} to {bronze_table_name} with {strategy_name}")
        try:
            processor.process_raw_to_bronze(raw_table_name, processing_strategy, bronze_table_name)
            print(f"Successfully processed {raw_table_name} to {bronze_table_name}")
        except Exception as e:
            print(f"Failed processing {raw_table_name} to {bronze_table_name} with error: {e}")


# COMMAND ----------

# Check if the bronze table exists, if not create it
config_path = "raw_bronze.yaml"
config = load_config(config_path)
table_entry = next(
    (t for t in config[f"tables_{environment}"] if t.get("custom_bronze_table") == f"{catalog}.nexusbenefitsquote_bronze_mvp1.tbl_custom_model"),
    None
)
if table_entry:
    raw_table_name = table_entry["custom_model_table"]
    bronze_table_full_name = table_entry["custom_bronze_table"]
    if not spark.catalog.tableExists(bronze_table_full_name):
        df = spark.table(raw_table_name).limit(0)
        df.write.format("delta").mode("overwrite").saveAsTable(bronze_table_full_name)

# COMMAND ----------

config_path = "raw_bronze.yaml"  
process_tables_custom_model(config_path)