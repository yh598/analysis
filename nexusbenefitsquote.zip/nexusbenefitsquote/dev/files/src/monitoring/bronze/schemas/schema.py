# schema_module.py

from pyspark.sql.types import (
    ArrayType,
    BooleanType,
    DoubleType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    FloatType
)

def get_completion_response_schema() -> StructType:
    return StructType([
        StructField("id", StringType(), True),
        StructField("object", StringType(), True),
        StructField("created", IntegerType(), True),
        StructField("model", StringType(), True),
        StructField("choices", ArrayType(
            StructType([
                StructField("text", StringType(), True),
                StructField("index", IntegerType(), True),
                StructField("logprobs", StructType([
                    StructField("tokens", ArrayType(StringType()), True),
                    StructField("token_logprobs", ArrayType(DoubleType()), True),
                ]), True),
                StructField("finish_reason", StringType(), True),
            ]),
        ), True),
        StructField("usage", StructType([
            StructField("prompt_tokens", IntegerType(), True),
            StructField("completion_tokens", IntegerType(), True),
            StructField("total_tokens", IntegerType(), True),
        ]), True),
        # Make 'predictions' optional
        StructField("predictions", ArrayType(
            StructType([
                StructField("response", StringType(), True),
                StructField("input_token_count", IntegerType(), True),
                StructField("output_token_count", IntegerType(), True),
                StructField("latency", DoubleType(), True),
                StructField("safe", BooleanType(), True),
            ]),
        ), True),
    ])
    
def get_completions_request_schema() -> StructType:
    return StructType([
    StructField("prompt", StringType(), True),        
    StructField("max_tokens", IntegerType(), True),    
    StructField("temperature", FloatType(), True)     
])
    
def get_request_schema() -> StructType:
    return StructType([
        StructField("prompt", StringType(), True),
        StructField("temperature", DoubleType(), True),
        StructField("max_tokens", IntegerType(), True),
        StructField("model", StringType(), True),
        StructField("dataframe_split", StructType([
            StructField("columns", ArrayType(StringType()), True),
            StructField("index", ArrayType(LongType()), True),
            StructField("data", ArrayType(ArrayType(StringType())), True),
        ]), True),
        StructField("query_context", StringType(), True),
        # Include 'messages' field if applicable
        StructField("messages", ArrayType(
            StructType([
                StructField("role", StringType(), True),
                StructField("content", StringType(), True),
            ]),
        ), True),
    ])

def get_chat_response_schema() -> StructType:
    return StructType([
        StructField("id", StringType(), True),
        StructField("object", StringType(), True),
        StructField("created", IntegerType(), True),
        StructField("model", StringType(), True),  # Include 'model' field
        StructField("choices", ArrayType(
            StructType([
                StructField("index", IntegerType(), True),
                StructField("message", StructType([
                    StructField("role", StringType(), True),
                    StructField("content", StringType(), True),
                ]), True),
                StructField("finish_reason", StringType(), True),
            ]),
        ), True),
        StructField("usage", StructType([
            StructField("prompt_tokens", IntegerType(), True),
            StructField("completion_tokens", IntegerType(), True),
            StructField("total_tokens", IntegerType(), True),
        ]), True),
    ])

    
def get_completions_request_schema() -> StructType:
    return StructType([
    StructField("prompt", StringType(), True),        
    StructField("max_tokens", IntegerType(), True),    
    StructField("temperature", FloatType(), True)     
])
    
def get_custom_request_schema() -> StructType:
    """Returns the schema for custom model request data, including both dataframe_split and fallback fields."""
    return StructType([
        StructField("dataframe_split", StructType([
            StructField("columns", ArrayType(StringType()), True),
            StructField("data", ArrayType(ArrayType(StringType())), True),
        ]), True),
        # Fallback fields
        StructField("model", StringType(), True),
        StructField("prompt", StringType(), True),
        StructField("temperature", DoubleType(), True),
        StructField("max_tokens", IntegerType(), True),
        # Add other necessary fields if they exist
    ])

def get_embedding_request_schema() -> StructType:
    return  StructType([
    StructField("input", StringType(), True) 
    ])

def get_embedding_response_schema() -> StructType:
     return StructType([
    StructField("object", StringType()),
    StructField("data", ArrayType(
        StructType([
            StructField("object", StringType()),
            StructField("index", IntegerType()),
            StructField("embedding", ArrayType(FloatType()))  # List of floats for embedding
        ])
    )),
    StructField("model", StringType()),
    StructField("usage", StructType([
        StructField("prompt_tokens", IntegerType()),
        StructField("total_tokens", IntegerType())
    ]))
])

def get_custom_response_schema() -> StructType:
    return StructType([
        StructField("predictions", ArrayType(
            StructType([
                StructField("response", StringType(), True),
                StructField("input_token_count", IntegerType(), True),
                StructField("output_token_count", IntegerType(), True),
                StructField("latency", DoubleType(), True),
                StructField("safe", BooleanType(), True),
                StructField("categories", StringType(), True), 
                StructField("output_categories", StringType(), True),  
            ]),
        ), True),
        StructField("databricks_output", StructType([
            StructField("trace", StringType(), True),
            StructField("databricks_request_id", StringType(), True),
        ]), True),
    ])


def get_request_metadata_schema() -> StructType:
    """Returns the schema for request metadata."""
    return StructType([
        StructField("model_name", StringType(), True),
        StructField("endpoint_name", StringType(), True),
        StructField("model_version", StringType(), True),
    ])
  