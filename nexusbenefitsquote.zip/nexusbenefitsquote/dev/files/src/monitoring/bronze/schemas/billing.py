from pyspark.sql.types import (
    DateType,
    DecimalType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

def get_system_billing_schema():
    schema = StructType(
        [
            StructField("workspace_id", StringType(), nullable=True),
            StructField("usage_date", DateType(), nullable=True),
            StructField("billing_origin_product", StringType(), nullable=True),
            StructField("cost", DecimalType(38, 18), nullable=True),
            StructField("usage_quantity", DecimalType(38, 18), nullable=True),
            StructField("account_id", StringType(), nullable=True),
            StructField("record_id", StringType(), nullable=True),
            StructField("sku_name", StringType(), nullable=True),
            StructField("cloud", StringType(), nullable=True),
            StructField("usage_start_time", TimestampType(), nullable=True),
            StructField("usage_end_time", TimestampType(), nullable=True),
            StructField("usage_unit", StringType(), nullable=True),
            StructField("record_type", StringType(), nullable=True),
        ]
    )
    return schema

def get_system_prices_schema():
    schema = StructType(
        [
            StructField("account_id", StringType(), nullable=True),
            StructField("price_start_time", TimestampType(), nullable=True),
            StructField("price_end_time", TimestampType(), nullable=True),
            StructField("sku_name", StringType(), nullable=True),
            StructField("cloud", StringType(), nullable=True),
            StructField("currency_code", StringType(), nullable=True),
            StructField("usage_unit", StringType(), nullable=True),
            # Updated pricing structure with populated fields
            StructField(
                "pricing",
                StructType(
                    [
                        StructField("amount", DecimalType(38, 18), nullable=True),
                        StructField("currency", StringType(), nullable=True),
                        StructField("unit", StringType(), nullable=True),
                    ]
                ),
                nullable=True,
            ),
        ]
    )
    return schema
