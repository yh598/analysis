# schema_module.py

from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    ArrayType,
    IntegerType,
    LongType,
    DoubleType,
)


def get_request_schema() -> StructType:
    """Returns the schema for request data."""
    return StructType([
        StructField("model", StringType(), True),
        StructField("prompt", StringType(), True),
        StructField("messages", ArrayType(
            StructType([
                StructField("role", StringType(), True),
                StructField("content", StringType(), True),
            ])
        ), True),
        StructField("max_tokens", IntegerType(), True),
        StructField("temperature", DoubleType(), True)
    ])


def get_custom_request_schema() -> StructType:
    """Returns the schema for custom model request data."""
    return StructType([
        StructField("dataframe_split", StructType([
            StructField("columns", ArrayType(StringType()), True),
            StructField("data", ArrayType(ArrayType(StringType())), True),
        ]), True),
    ])