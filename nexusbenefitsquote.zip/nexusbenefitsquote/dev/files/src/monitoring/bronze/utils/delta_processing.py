# delta_table_manager.py

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType
from pyspark.sql.functions import broadcast
from pyspark.errors import AnalysisException
import pyspark.sql.functions as F
from typing import Optional, List, Callable

def is_dataframe_empty(df: DataFrame) -> bool:
    """
    Check if a DataFrame is empty.

    Parameters
    ----------
    df : DataFrame
        The DataFrame to check.

    Returns
    -------
    bool
        True if the DataFrame is empty, False otherwise.
    """
    return len(df.head(1)) == 0
    

def write_to_delta_with_schema_merge(df: DataFrame, table_name: str, mode: str):
    """
    Write DataFrame to Delta with schema merging.

    Parameters
    ----------
    df : DataFrame
        The DataFrame to write.
    table_name : str
        The name of the Delta table.
    mode : str
        The mode for writing (e.g., 'append', 'overwrite').
    """
    df.write.format("delta").option("mergeSchema", "true").mode(mode).saveAsTable(table_name)

class DeltaTableWriter:
    """
    Handles Delta table interactions, including reading, writing, and deduplication.

    Attributes
    ----------
    spark : SparkSession
        The Spark session.
    table_name : str
        The name of the Delta table.
    mode : str, optional
        The mode for writing (default is "append").
    """
    def __init__(self, spark: SparkSession, table_name: str, mode: str = "append") -> None:
        """
        Initialize the DeltaTableWriter.

        Parameters
        ----------
        spark : SparkSession
            The Spark session.
        table_name : str
            The name of the Delta table.
        mode : str, optional
            The mode for writing (default is "append").
        """
        self.spark = spark
        self.table_name = table_name
        self.mode = mode

    def table_exists(self) -> bool:
        """
        Check if the Delta table exists.

        Returns
        -------
        bool
            True if the table exists, False otherwise.
        """
        try:
            self.spark.read.table(self.table_name)
            return True
        except AnalysisException:
            return False

    def create_table_with_schema(self, schema: StructType) -> None:
        """
        Create the table with the provided schema if it does not already exist.

        Parameters
        ----------
        schema : StructType
            The schema for the table.
        """
        if not self.table_exists():
            empty_df = self.spark.createDataFrame([], schema)
            empty_df.write.format("delta").mode("overwrite").saveAsTable(self.table_name)

    def write_data(self, df: DataFrame) -> None:
        """
        Write data to the Delta table, creating it if necessary and merging schemas.

        Parameters
        ----------
        df : DataFrame
            The DataFrame to write.
        """
        if not self.table_exists():
            self.create_table_with_schema(df.schema)
        if not is_dataframe_empty(df):
            df.write.format("delta").option("mergeSchema", "true").mode(self.mode).saveAsTable(self.table_name)

class DeltaTableManager:
    """
    Manager for Delta table operations, including creating and writing to Delta tables.

    Attributes
    ----------
    spark : SparkSession
        The Spark session.
    """
    def __init__(self, spark_session: SparkSession):
        """
        Initialize the DeltaTableManager.

        Parameters
        ----------
        spark_session : SparkSession
            The Spark session.
        """
        self.spark = spark_session
    
    def table_exists(self, table_name: str) -> bool:
        """
        Check if the Delta table exists.

        Parameters
        ----------
        table_name : str
            The name of the Delta table.

        Returns
        -------
        bool
            True if the table exists, False otherwise.
        """
        return self.spark.catalog.tableExists(table_name)
    
    def create_delta_table(self, table_name: str, schema: StructType, partition_columns: Optional[List] = None):
        """
        Create a Delta table with the provided schema and optional partition columns.

        Parameters
        ----------
        table_name : str
            The name of the Delta table.
        schema : StructType
            The schema for the table.
        partition_columns : list, optional
            List of columns to partition by (default is None).
        """
        if not self.table_exists(table_name):
            empty_df = self.spark.createDataFrame([], schema)
            write_options = {"mergeSchema": "true"}
            if partition_columns:
                write_options["partitionBy"] = partition_columns
            empty_df.write.format("delta").options(**write_options).mode("overwrite").saveAsTable(table_name)

    def write_new_data_to_bronze(
            self, df_flattened: DataFrame, bronze_table_name: str, unique_id_col: str, schema: StructType,
            filter_function: Optional[Callable[[DataFrame], DataFrame]] = None
        ) -> None:
        """
        Write new data to the bronze Delta table, creating it if necessary and merging schemas.

        Parameters
        ----------
        df_flattened : DataFrame
            The flattened DataFrame to write.
        bronze_table_name : str
            The name of the bronze Delta table.
        unique_id_col : str
            The unique identifier column.
        schema : StructType
            The schema for the table.
        filter_function : callable, optional
            A function to filter the DataFrame (default is None).
        """
        df_filtered = filter_function(df_flattened) if filter_function else df_flattened
        if not self.table_exists(bronze_table_name):
            self.create_delta_table(bronze_table_name, schema)
        
        bronze_append_df = df_filtered.alias("new").join(
            self.spark.table(bronze_table_name).alias("existing"), on=unique_id_col, how="left_anti"
        )
        if not is_dataframe_empty(bronze_append_df):
            write_to_delta_with_schema_merge(bronze_append_df, bronze_table_name, mode="append")