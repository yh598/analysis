from abc import ABC, abstractmethod
from pyspark.sql import DataFrame

class DataFilteringStrategy(ABC):
    """Abstract base class for data filtering strategies."""

    @abstractmethod
    def apply(self, df: DataFrame) -> DataFrame:
        """Apply the filtering strategy to a DataFrame."""
        pass

class StatusCodeFilter(DataFilteringStrategy):
    """
    Filter out records with a specific status code.

    Parameters
    ----------
    status_code : int
        The status code to filter out (e.g., 400).
    """

    def __init__(self, status_code: int = 400) -> None:
        self.status_code: int = status_code

    def apply(self, df: DataFrame) -> DataFrame:
        """
        Filter out records where 'status_code' equals the specified value.

        Parameters
        ----------
        df : DataFrame
            The Spark DataFrame to filter.

        Returns
        -------
        DataFrame
            The filtered Spark DataFrame.
        """
        if "status_code" in df.columns:
            filtered_df: DataFrame = df.filter(df["status_code"] != self.status_code)
        else:
            filtered_df = df
        return filtered_df