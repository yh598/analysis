# Databricks notebook source
dbutils.library.restartPython()

# COMMAND ----------

import sys
import os

dirs = os.path.abspath(os.path.join(os.getcwd(), "..", ".."))
sys.path.append(dirs)
#print(dirs)


# COMMAND ----------

from typing import Callable, Optional

from pyspark.sql import DataFrame
from pyspark.sql.types import StructType

from monitoring.bronze.costing.costing_workflow import CostingWorkflow, DataPipeline, DataWriter
from monitoring.bronze.schemas.billing import get_system_billing_schema, get_system_prices_schema
from monitoring.utils.dataframe_transformations import flatten_dataframe
from monitoring.bronze.utils.delta_processing import DeltaTableManager

# COMMAND ----------

#sg added
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


# COMMAND ----------

# Get the environment, catalog, and schema from Databricks widgets
dbutils.widgets.text("environment", "dev")


environment: str = dbutils.widgets.get("environment").lower()

catalog = f"{environment}_adb"


dbutils.widgets.text("billing_usage_table", "system.billing.usage")
billing_usage_table = dbutils.widgets.get("billing_usage_table")

dbutils.widgets.text("billing_list_prices", "system.billing.list_prices")
billing_list_prices = dbutils.widgets.get("billing_list_prices")

# Set Spark configuration
spark.sql(f"USE CATALOG {catalog}")


# COMMAND ----------


schemas = [
    "nexusbenefitsquote_bronze_mvp1",
    "nexusbenefitsquote_silver_mvp1",
    "nexusbenefitsquote_gold_mvp1",
    
]

for schema in schemas:
    spark.sql(
        f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}"
    )

# COMMAND ----------

from databricks.sdk import WorkspaceClient
import re

w = WorkspaceClient()
DATABRICKS_HOST = w.config.host

# Extract the number after 'adb-' and before the first '.'
match = re.search(r'adb-(\d+)\.', DATABRICKS_HOST)
workspace_id = match.group(1) if match else None

print(f"Workspace Host: {DATABRICKS_HOST}")
print(f"Workspace ID: {workspace_id}")

# COMMAND ----------

# Instantiate DeltaTableManager and DataWriter

delta_table_manager = DeltaTableManager(spark)
data_writer = DataWriter(delta_table_manager)  

# Instantiate DataPipeline and CostingWorkflow with the shared DataWriter
data_pipeline = DataPipeline(data_writer)
costing_workflow = CostingWorkflow(data_writer, workspace_id)

# Define schemas
billing_schema = get_system_billing_schema()
prices_schema = get_system_prices_schema()

# COMMAND ----------

# spark.sql(
#     f"CREATE SCHEMA IF NOT EXISTS {catalog}.bronze"
# )

costing_workflow.write_costing_data_to_bronze(
    table_name=billing_usage_table,
    schema=billing_schema,
    unique_id_col="record_id",
)

# COMMAND ----------

# Process and write pricing data using the generic DataPipeline
data_pipeline.process_and_write_data(
    table_name=billing_list_prices,
    schema=prices_schema,
    unique_id_col="sku_name"
)