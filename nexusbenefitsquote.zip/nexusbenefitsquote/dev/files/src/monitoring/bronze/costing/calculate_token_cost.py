import tiktoken

import requests

def get_model_config(model_name: str):
    """
    Searches for and returns the configuration for a specified model from JSON data.

    Args:
        model_name (str): The name of the model to search for.

    Returns:
        dict or None: The configuration dictionary for the specified model if found, otherwise None.
    """
    config_path = "openai_cost_config.json"
    with open(config_path, 'r') as file:
        json_string = json.load(file)

    # Check if "openai_model_config" key exists in the JSON data
    if "openai_model_config" in json_string:
        for model_config in json_string["openai_model_config"]:
            if model_config.get("model") == model_name:
                return model_config
    return None

def count_tokens(prompt: str, model_name: str) -> int:
    """
    Tokenizes the input prompt using tiktoken and returns the token count.

    Args:
        prompt (str): The prompt string to tokenize.
        model_name (str): The model for which to tokenize the prompt.

    Returns:
        int: The number of tokens in the prompt.
    """
    encoding = tiktoken.encoding_for_model(model_name)
    tokens = encoding.encode(prompt)
    return len(tokens)

def calculate_token_cost(model_name: str, token_type: str, token_count: int) -> float:
    """
    Calculates the cost of tokens for a specified OpenAI model based on input or output tokens.

    Args:
        model_name (str): The model name for which to calculate the token cost.
        token_type (str): Specifies either 'input_tokens' or 'output_tokens'.
        token_count (int): The number of tokens for which to calculate the cost.

    Returns:
        float: The calculated cost for the token count.
    """
    openai_usage_config = get_model_config(model_name)
    if not openai_usage_config:
        raise ValueError("Model configuration not found for model:", model_name)

    # Determine the pricing based on token_type
    pricing = openai_usage_config["pricing"]
    cost_per_1k_tokens = None

    if token_type == "input_tokens":
        cost_per_1k_tokens = pricing.get("input_token_per_1k")
    elif token_type == "output_tokens":
        if "output_token_per_1m" in pricing:
            # Convert 1M rate to 1K rate if only 1M pricing is available
            cost_per_1k_tokens = pricing["output_token_per_1m"] / 1000
        else:
            cost_per_1k_tokens = pricing.get("output_token_per_1k")
    
    if cost_per_1k_tokens is None:
        raise ValueError(f"Pricing information not found for {token_type} in model {model_name}")

    # Calculate the total cost based on the token count
    total_cost = (token_count / 1000) * cost_per_1k_tokens

    return total_cost
