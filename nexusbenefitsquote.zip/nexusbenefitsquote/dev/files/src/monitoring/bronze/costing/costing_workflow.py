from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()
try:
    dbutils
except NameError:
    from pyspark.dbutils import DBUtils
    dbutils = DBUtils(spark)

dbutils.widgets.text("usage_date", "2025-01-01")


# costing_workflow.py
import sys

sys.path.append('../../../.')
from monitoring.bronze.utils.delta_processing import DeltaTableManager, is_dataframe_empty
from monitoring.utils.dataframe_transformations import flatten_dataframe
from pyspark.sql import DataFrame
from pyspark.sql.types import StructType
import pyspark.sql.functions as F
from typing import Callable, Optional

# Parameterize filter values using widgets
usage_date = dbutils.widgets.get("usage_date")  

def validate_dataframe(df: DataFrame) -> bool:
    """Returns True if the DataFrame is valid (non-empty with a valid schema)."""
    return df is not None and df.schema is not None and len(df.columns) > 0 and df.limit(1).count() > 0

class DataWriter:
    """Utility class to handle common data processing and writing steps."""

    def __init__(self, delta_manager: DeltaTableManager):
        self.delta_manager = delta_manager

    def process_and_write(
        self,
        table_name: str,
        schema: StructType,
        unique_id_col: str,
        filter_function: Optional[Callable[[DataFrame], DataFrame]] = None
    ):
        df_raw = self.delta_manager.spark.table(table_name)
        df_flattened = flatten_dataframe(df_raw)
        df_to_write = filter_function(df_flattened) if filter_function else df_flattened
        bronze_table_name = f"nexusbenefitsquote_bronze_mvp1.{table_name.split('.')[-1]}"
        if validate_dataframe(df_to_write):
            print(f"Writing data for {table_name} to {bronze_table_name}")
            self.delta_manager.write_new_data_to_bronze(
                df_flattened=df_to_write,
                bronze_table_name=bronze_table_name,
                unique_id_col=unique_id_col,
                schema=schema,
                filter_function=filter_function
            )
        else:
            print(f"Skipping {table_name}. DataFrame is empty or has an invalid schema.")

class CostingWorkflow:
    """Handles costing-specific transformations and writing for the bronze layer."""
    
    def __init__(self, data_writer: DataWriter, workspace_id: str):
        self.data_writer = data_writer
        self.workspace_id = workspace_id

    def filter_billing_data_for_bronze(self, billing_df: DataFrame) -> DataFrame:
        """Filters billing data for the bronze layer based on costing requirements."""
        ai_gateway_df = billing_df.filter(
            (F.col("workspace_id") == self.workspace_id)
            & (F.col("usage_date") > usage_date)
            & (F.col("billing_origin_product") == "AI_GATEWAY")
            
        )
        custom_model_df = billing_df.filter(
            (F.col("workspace_id") == self.workspace_id)
            & (F.col("usage_date") > usage_date)
            & (F.col("billing_origin_product") == "MODEL_SERVING")
            
        )
        vector_search_df = billing_df.filter(
            (F.col("workspace_id") == self.workspace_id)
            & (F.col("billing_origin_product") == "VECTOR_SEARCH")
            & (F.col("usage_date") > usage_date))
        
        app_df = billing_df.filter(
            (F.col("workspace_id") == self.workspace_id)
            & (F.col("billing_origin_product") == "APPS")
            & (F.col("usage_date") > usage_date))
        


        result_df = ai_gateway_df.unionByName(app_df).unionByName(custom_model_df).unionByName(vector_search_df)
        return result_df

    def write_costing_data_to_bronze(self, table_name: str, schema: StructType, unique_id_col: str) -> None:
        self.data_writer.process_and_write(
            table_name=table_name,
            schema=schema,
            unique_id_col=unique_id_col,
            filter_function=self.filter_billing_data_for_bronze
        )

class DataPipeline:
    """Generic data processing pipeline for various data workflows."""

    def __init__(self, data_writer: DataWriter):
        self.data_writer = data_writer

    def process_and_write_data(
        self,
        table_name: str,
        schema: StructType,
        unique_id_col: str,
        filter_function: Optional[Callable[[DataFrame], DataFrame]] = None
    ):
        self.data_writer.process_and_write(
            table_name=table_name,
            schema=schema,
            unique_id_col=unique_id_col,
            filter_function=filter_function
        )