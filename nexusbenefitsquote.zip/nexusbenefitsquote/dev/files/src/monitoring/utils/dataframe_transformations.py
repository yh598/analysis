from pyspark.sql import DataFrame, Column
from pyspark.sql.functions import col, explode
from pyspark.sql.types import StructType, ArrayType, MapType
from typing import List, Tuple


def flatten_dataframe(df: DataFrame) -> DataFrame:
    """
    Recursively flattens a DataFrame with nested StructType, ArrayType, and MapType columns.

    Args:
        df (DataFrame): The DataFrame to flatten.

    Returns:
        DataFrame: The flattened DataFrame.
    """
    def _flatten(df: DataFrame) -> DataFrame:
        flat_cols: List[Column] = []
        nested_cols: List[Tuple[str, StructType]] = []

        for field in df.schema.fields:
            col_name = field.name
            data_type = field.dataType

            if isinstance(data_type, StructType):
                nested_cols.append((col_name, data_type))
            elif isinstance(data_type, ArrayType) and isinstance(data_type.elementType, StructType):
                # Handle arrays of structs
                df = df.withColumn(col_name, explode(col(col_name)))
                nested_cols.append((col_name, data_type.elementType))
            elif isinstance(data_type, MapType):
                # Correctly handle MapType columns using explode and aliasing both key and value
                df = df.selectExpr(
                    "*",
                    f"explode({col_name}) as ({col_name}_key, {col_name}_value)",
                )
                df = df.drop(col_name)
            else:
                flat_cols.append(col(col_name))

        for (col_name, data_type) in nested_cols:
            child_cols = [
                col(f"{col_name}.{field.name}").alias(f"{col_name}_{field.name}")
                for field in data_type.fields
            ]
            df = df.select("*", *child_cols).drop(col_name)

        return df

    previous_schema: str = ""
    while True:
        df = _flatten(df)
        current_schema = df.schema.simpleString()
        if previous_schema == current_schema:
            break
        previous_schema = current_schema

    return df