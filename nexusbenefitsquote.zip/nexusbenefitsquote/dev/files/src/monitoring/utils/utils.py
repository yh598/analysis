from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType
from pyspark.sql.functions import col, lit
from pyspark.sql.utils import AnalysisException
from typing import List, Optional, Dict
import requests

spark = SparkSession.builder.getOrCreate()

def table_exists(table_name: str) -> bool:
    """
    Check if a table exists in the Spark catalog.

    Parameters
    ----------
    table_name : str
        The name of the table to check.

    Returns
    -------
    bool
        True if the table exists, False otherwise.
    """
    try:
        spark.catalog.getTable(table_name)
        return True
    except AnalysisException:
        return False

def create_delta_table(
    table_name: str,
    schema: StructType,
    partition_columns: Optional[List[str]] = None
) -> None:
    """
    Create a Delta table with the specified schema and optional partitioning.

    Parameters
    ----------
    table_name : str
        The name of the Delta table to create.
    schema : StructType
        The schema of the Delta table.
    partition_columns : Optional[List[str]], optional
        List of column names to partition the Delta table by.
    """
    if table_exists(table_name):
        return

    empty_df = spark.createDataFrame([], schema)
    write_options = {}
    if partition_columns:
        write_options["partitionBy"] = partition_columns

    empty_df.write.format("delta").options(**write_options).saveAsTable(table_name)

def is_dataframe_empty(df: DataFrame) -> bool:
    """
    Check if a DataFrame is empty.

    Parameters
    ----------
    df : DataFrame
        The Spark DataFrame to check.

    Returns
    -------
    bool
        True if the DataFrame is empty, False otherwise.
    """
    return df.limit(1).count() == 0

def validate_dataframe_schema(
    df: DataFrame,
    target_schema: StructType
) -> DataFrame:
    """
    Validate and conform the DataFrame to the target schema.

    Parameters
    ----------
    df : DataFrame
        The input Spark DataFrame.
    target_schema : StructType
        The target schema to conform to.

    Returns
    -------
    DataFrame
        The validated and conformed DataFrame.
    """
    for field in target_schema.fields:
        if field.name in df.columns:
            df = df.withColumn(field.name, col(field.name).cast(field.dataType))
        else:
            df = df.withColumn(field.name, lit(None).cast(field.dataType))
    
    return df

def write_to_delta_with_schema_merge(
    df: DataFrame, 
    table_name: str,
    mode: str = "append", 
    schema: Optional[StructType] = None,
    partition_columns: Optional[List[str]] = None
) -> None:
    """
    Write a DataFrame to a Delta table with schema merge enabled, optionally validating against a schema.

    Parameters
    ----------
    df : DataFrame
        The Spark DataFrame to write to the Delta table.
    table_name : str
        The name of the target Delta table.
    mode : str, default "append"
        The write mode, e.g., "append", "overwrite". Default is "append".
    schema : Optional[StructType], optional
        The schema to validate against before writing. If provided, the DataFrame will be cast to this schema.
    partition_columns : Optional[List[str]], optional
        List of column names to partition the Delta table by. If the table doesn't exist, it will be created with these partitions.
    """
    if schema:
        df = validate_dataframe_schema(df, schema)

    if not table_exists(table_name):
        create_delta_table(table_name, schema, partition_columns)

    write_options = {
        "mergeSchema": "true"
    }

    if partition_columns:
        write_options["partitionBy"] = partition_columns

    df.write.format("delta").mode(mode).options(**write_options).saveAsTable(table_name)


def fetch_endpoints_list(databricks_url: str, headers: Dict[str, str]) -> List[str]:
    """
    Fetch the list of serving endpoints.

    Parameters
    ----------
    databricks_url : str
        The base URL for the Databricks instance.
    headers : Dict[str, str]
        Authentication headers.

    Returns
    -------
    List[str]
        List of endpoint names.
    """
    endpoints_url = f"{databricks_url}/api/2.0/serving-endpoints"
    response = requests.get(endpoints_url, headers=headers)
    if response.status_code == 200:
        endpoints_data = response.json()
        return [endpoint['name'] for endpoint in endpoints_data['endpoints']]
    else:
        print(f"Failed to list endpoints. Status code: {response.status_code}")
        print(response.text)
        return []