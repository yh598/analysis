# Databricks notebook source
import sys
import os
import json
import yaml
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct
from pyspark.sql.functions import when

# COMMAND ----------

# repo_root/.. (adjust if needed)
parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
# print(parent_dir)

sys.path.insert(0, parent_dir)

from utilities.delta_table_utils import DeltaTableClient
from utilities.data_pipeline.ingestion import *
from utilities.data_pipeline.transformation import *

# COMMAND ----------

# MAGIC %run ../configs/create_schema_and_directory

# COMMAND ----------

dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()

dbutils.widgets.text("environment", "dev")
env: str = dbutils.widgets.get("environment").lower()

# COMMAND ----------

# Load parameters from YAML file
config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

# Extract variable from YAML configuration file
project_name = config['project_name']

# print("Project name loaded from config: " + project_name)

# COMMAND ----------

catalog = config['catalog_name']

bronze_schema = config['schema_name_bronze']
silver_schema = config['schema_name_silver']

bronze_table: str = "tbl_nexus_plans_mvp1"
master_table: str = "master_table"

bronze_table_path = f"{env}_adb.{bronze_schema}.{bronze_table}"
#csv_path=f"/Volumes/{env}_adb/{schema_name_bronze}/input_file"
master_table_path=f"{env}_adb.{bronze_schema}.{master_table}"

table_name_plan_details = "tbl_plan_details"
table_name_eocCategories = "tbl_eoc_categories"
table_name_eocSections = "tbl_eoc_sections"
table_name_programCategories = "tbl_eoc_program_categories"

# COMMAND ----------

# DBTITLE 1,vali...
bronze_table_df = spark.read.table(bronze_table_path).alias("b") \
    .join(
        spark.read.table(master_table_path).alias("m"),
        (col("b.facets_product_id") == col("m.facets_product_id")) &
        (col("b.effective_date") == col("m.product_effective_date")),
        "inner"
    ) \
    .where(
        (col("m.bronze_ready_flag") == "Y") &
        (
            col("m.dbr_silver_layer_ready").isNull() |
            (col("m.dbr_silver_layer_ready") == "") |
            (col("m.dbr_silver_layer_ready") == "N")
        )
    ) \
    .select("b.*")

display(bronze_table_df)

# COMMAND ----------

plan_details_df = process_plan_details(bronze_table_df)
eoc_categories_df = process_eoc_categories(bronze_table_df)
eoc_program_categories_df = process_eoc_program_categories(bronze_table_df)
eoc_sections_df = process_eoc_sections(bronze_table_df)

# COMMAND ----------

# DBTITLE 1,selecting columns in sequential order for plan details
cols = [
    'facets_product_id',
    'effective_date',
    'product_line_of_business',
    'file_name',
    'nexusId',
    'lastPublished',
    'publishedBy',
    'facetsProductDescription',
    'facetsPlanId',
    'planType',
    'marketType',
    'commercialMarketStatus',
    'planName',
    'planANumber',
    'sourceSystemCode',
    'account',
    'accountType',
    'planStructureType',
    'planStructureTypeCode',
    'productConfigurationType',
    'productClassification',
    'fundingMethodType',
    'accumulatorPeriodCode',
    'opportunityType',
    'exchangeStatus',
    'medicalNetwork',
    'pharmacyNetwork',
    'regulatoryAgency',
    'drugFormulary',
    'medicarePartDStatus',
    'customProviderNetworks',
    'customerServicePhone',
    'drugFormularyId',
    'planCostShares',
    'mapped_medical_network'
]
plan_details_df =plan_details_df.select(cols)

# COMMAND ----------

if None not in [plan_details_df, eoc_categories_df, eoc_program_categories_df, eoc_sections_df]:
    plan_details_df.write.option("mergeSchema", "true").format("delta").mode("append").saveAsTable(
        f"{env}_adb.{silver_schema}.{table_name_plan_details}"
    )
    # Update insert_time and update_time column in master table for inserted records

    inserted_ids = plan_details_df.select("facets_product_id", "effective_date").distinct()

    inserted_ids.createOrReplaceTempView("inserted_ids_temp")
    spark.sql(f"""
        UPDATE {master_table_path} AS m
        SET insert_time = current_timestamp() , update_time = current_timestamp()
        WHERE EXISTS (
            SELECT 1
            FROM inserted_ids_temp AS t
            WHERE m.facets_product_id = t.facets_product_id
              AND m.product_effective_date = t.effective_date
        )
    """)

    eoc_categories_df.write.option("mergeSchema", "true").format("delta").mode("append").saveAsTable(
        f"{env}_adb.{silver_schema}.{table_name_eocCategories}"
    )
    eoc_program_categories_df.write.option("mergeSchema", "true").format("delta").mode("append").saveAsTable(
        f"{env}_adb.{silver_schema}.{table_name_programCategories}"
    )
    eoc_sections_df.write.option("mergeSchema", "true").format("delta").mode("append").saveAsTable(
        f"{env}_adb.{silver_schema}.{table_name_eocSections}"
    )
    
    update_plan_fields(plan_details_df, master_table_path,spark)
else:
    print(f"Skipping row facets_product_id={bronze_table_df['facets_product_id']} effective_date={bronze_table_df['effective_date']} due to error in processing.")