# Databricks notebook source
# MAGIC %md
# MAGIC ### The below end to end code will sync data from  delta lakehouse (master table) to lakebase postgres db

# COMMAND ----------

# MAGIC %pip install pyyaml

# COMMAND ----------

# MAGIC %pip install psycopg[binary]

# COMMAND ----------

# MAGIC %pip install --upgrade databricks-sdk

# COMMAND ----------

dbutils.library.restartPython()


# COMMAND ----------

from databricks.sdk import WorkspaceClient
import psycopg
from psycopg.rows import tuple_row
import uuid
from pyspark.sql.functions import current_date, when, col
import sys
import os
import io
import json
import yaml
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct
from pyspark.sql.functions import when
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)

# COMMAND ----------

# repo_root/.. (adjust if needed)
parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
# print(parent_dir)

sys.path.insert(0, parent_dir)

from utilities.delta_table_utils import DeltaTableClient
from utilities.data_pipeline.ingestion import *

# COMMAND ----------

# MAGIC %run ../configs/create_schema_and_directory

# COMMAND ----------

dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()

dbutils.widgets.text("config_file_lakebase", "lakebase_sync.yml")
config_file_lakebase: str = dbutils.widgets.get("config_file_lakebase").lower()

# COMMAND ----------

dbutils.widgets.text("environment", "dev")
env = dbutils.widgets.get("environment")

# COMMAND ----------

# Load parameters from YAML file
config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

config_path_lakebase = os.path.join('..','configs', config_file_lakebase)
print(config_path_lakebase)

with open(config_path_lakebase, 'r') as file:
    config_lakebase = yaml.safe_load(file)

# Extract variable from YAML configuration file
project_name = config['project_name']

# print("Project name loaded from config: " + project_name)

# COMMAND ----------

import pyspark.sql.functions as F

# Create a PySpark DataFrame with a single row and select the current user
df = spark.range(1).select(F.session_user().alias("current_user"))

# Convert the current user to a string
current_user_name = df.select("current_user").collect()[0]["current_user"]

# Print the current user name as a string
print(current_user_name)

# COMMAND ----------

w = WorkspaceClient()

catalog = config['catalog_name']
bronze_schema = config['schema_name_bronze']
gold_schema = config['schema_name_gold']
instance = config_lakebase[f'instance_{env}']
user_name = current_user_name
db_name = "databricks_postgres"
remove_old_chat_days = config_lakebase[f'remove_old_chat_days_{env}']
# host = config_lakebase[f'host_{env}']
host = w.database.get_database_instance(name=instance).read_write_dns
sslmode = config_lakebase['sslmode']
schema = config_lakebase['delta_lake_schema']

master_table: str = "master_table"
target_delta_table: str = "tbl_benefitsquote_feedback"

master_table_path = f"{catalog}.{bronze_schema}.{master_table}"
target_table_path = f"{catalog}.{schema}.{target_delta_table}"

agent_api_logs_delta_table: str = "tbl_agent_api_logs"
agent_api_logs_delta_table_path = f"{catalog}.{gold_schema}.{agent_api_logs_delta_table}"

# COMMAND ----------

# DBTITLE 1,connection setup to postgres db
def _conn(autocommit=False):
    inst = w.database.get_database_instance(name=instance)
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()), instance_names=[instance]
    )
    return psycopg.connect(
        host=host,
        port=5432,
        dbname=db_name,
        user=user_name,
        password=cred.token,
        sslmode=sslmode,
        connect_timeout=10,
        autocommit=autocommit,
    )


# COMMAND ----------

master_df = spark.read.table(master_table_path)

# COMMAND ----------

# display(master_df)

# COMMAND ----------

# DBTITLE 1,Insert data into table
master_df_pd = master_df.toPandas()

# Prepare a CSV buffer for bulk insert
buffer = io.StringIO()
master_df_pd.to_csv(buffer, index=False, header=False)
buffer.seek(0)

# Get column names for insert
columns = ','.join(master_df_pd.columns)
placeholders = ','.join(['%s'] * len(master_df_pd.columns))

insert_sql = f"""
    INSERT INTO master_table ({columns})
    VALUES ({placeholders})
    ON CONFLICT (facets_product_id, product_effective_date) DO UPDATE
    SET
        facets_product_id = EXCLUDED.facets_product_id,
        product_effective_date = EXCLUDED.product_effective_date,
        product_type = EXCLUDED.product_type,
        plan_type = EXCLUDED.plan_type,
        product_description = EXCLUDED.product_description,
        plan_id = EXCLUDED.plan_id,
        requested_time = EXCLUDED.requested_time,
        requester_id = EXCLUDED.requester_id,
        dbr_silver_layer_ready = EXCLUDED.dbr_silver_layer_ready,
        update_time = EXCLUDED.update_time,
        insert_time = EXCLUDED.insert_time,
        vector_db_ready = EXCLUDED.vector_db_ready,
        ready_for_agent = EXCLUDED.ready_for_agent,
        comments = EXCLUDED.comments,
        data_issue = EXCLUDED.data_issue,
        bronze_ready_flag = EXCLUDED.bronze_ready_flag
"""

with _conn() as conn:
    with conn.cursor() as cur:
        for row in master_df_pd.itertuples(index=False, name=None):
            cur.execute(insert_sql, row)
    conn.commit()

# COMMAND ----------

# MAGIC %md
# MAGIC ### The below end to end code will sync data from lakebase postgres db(feedback table) to delta lakehouse

# COMMAND ----------

query = f"""
CREATE TABLE IF NOT EXISTS {catalog}.{schema}.{target_delta_table}(
    response_id STRING,
    question_id STRING,
    user_id STRING,
    user_name STRING,
    feedback_type STRING,
    reason_code STRING,
    additional_comments STRING,
    session_id STRING,
    feedback_response_id STRING,
    insert_timestamp timestamp
) using delta
"""
spark.sql(query)

# COMMAND ----------

with _conn() as conn:
    with conn.cursor(row_factory=tuple_row) as cur:
        cur.execute("SELECT * FROM tbl_benefitsquote_feedback")
        rows = cur.fetchall()
        columns = [desc[0] for desc in cur.description]

import pandas as pd
df = pd.DataFrame(rows, columns=columns)

# COMMAND ----------

# display(df[df["feedback_response_id"] == "fb978dad"])

# COMMAND ----------

columns = [
    "response_id",
    "question_id",
    "user_id",
    "user_name",
    "feedback_type",
    "reason_code",
    "additional_comments",
    "session_id",
    "feedback_response_id",
    "insert_timestamp"
]

columns_str = ", ".join(columns)
values_str = ", ".join([f"source.{col}" for col in columns])

# COMMAND ----------

spark_df = spark.createDataFrame(df)
spark_df.createOrReplaceTempView("df")


spark.sql(
    f"""
    MERGE INTO {catalog}.{schema}.{target_delta_table} AS target
    USING df AS source
    ON target.response_id = source.response_id
       AND target.question_id = source.question_id
    WHEN NOT MATCHED THEN
      INSERT ({columns_str})
      VALUES ({values_str})
    """
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###The below end to end code will sync data from lakebase postgres db(agent api logs table) to delta lakehouse

# COMMAND ----------

# DBTITLE 1,creating delta table for agent api logs
query = f"""
CREATE TABLE IF NOT EXISTS {catalog}.{gold_schema}.{agent_api_logs_delta_table}(
question_id STRING,
response_status STRING,
insert_ts TIMESTAMP,
response_time_sec BIGINT
) using delta
"""
spark.sql(query)

# COMMAND ----------

# DBTITLE 1,fetching data from agent api logs lakebase table
with _conn() as conn:
    with conn.cursor(row_factory=tuple_row) as cur:
        cur.execute("SELECT * FROM tbl_agent_api_logs")
        rows = cur.fetchall()
        columns = [desc[0] for desc in cur.description]

import pandas as pd
agent_api_logs_df = pd.DataFrame(rows, columns=columns)
display(agent_api_logs_df)

# COMMAND ----------

agent_api_logs_columns = [
    "question_id",
    "response_status",
    "insert_ts",
    "response_time_sec"
]

agent_api_logs_columns_str = ", ".join(agent_api_logs_columns)
agent_api_logs_values_str = ", ".join([f"source.{col}" for col in agent_api_logs_columns])

# COMMAND ----------

#This will insert rows from the source only if their question_id does not exist in the target table.

spark_df = spark.createDataFrame(agent_api_logs_df)
spark_df.createOrReplaceTempView("agent_api_logs_source_df")

spark.sql(
    f"""
    MERGE INTO {catalog}.{gold_schema}.{agent_api_logs_delta_table} AS target
    USING agent_api_logs_source_df AS source
    ON target.question_id = source.question_id
    WHEN NOT MATCHED THEN
      INSERT ({agent_api_logs_columns_str})
      VALUES ({agent_api_logs_values_str})
    """
)

# COMMAND ----------

# DBTITLE 1,call- remove chat history procedures
with _conn() as conn:
    with conn.cursor() as cur:
        cur.execute(f" CALL remove_old_chat_records({remove_old_chat_days})")
    conn.commit()