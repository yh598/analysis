# Databricks notebook source
# MAGIC %pip install pyyaml

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import sys
import os
import json
import yaml
import re
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct
from pyspark.sql.functions import when
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
from pyspark.sql.functions import regexp_replace, expr, trim

# COMMAND ----------

# repo_root/.. (adjust if needed)
parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
# print(parent_dir)

sys.path.insert(0, parent_dir)

from utilities.delta_table_utils import DeltaTableClient
from utilities.data_pipeline.ingestion import *
from utilities.data_pipeline.transformation import *

# COMMAND ----------

# MAGIC %run ../configs/create_schema_and_directory

# COMMAND ----------

dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()

dbutils.widgets.text("environment", "dev")
env: str = dbutils.widgets.get("environment").lower()

# COMMAND ----------

# Load parameters from YAML file
config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

# COMMAND ----------

bronze_schema = config['schema_name_bronze']
schema_name_silver = config['schema_name_silver']
schema_name_gold = config['schema_name_gold']

master_table: str = "master_table"
master_table_path=f"{env}_adb.{bronze_schema}.{master_table}"

# COMMAND ----------

# DBTITLE 1,data loading from silver layer
df = spark.read.table(f"{env}_adb.{schema_name_silver}.tbl_eoc_categories").alias("b") \
    .join(
        spark.read.table(master_table_path).alias("m"),
        (col("b.facets_product_id") == col("m.facets_product_id")) &
        (col("b.effective_date") == col("m.product_effective_date")),
        "inner"
    ) \
    .where(
        (col("m.bronze_ready_flag") == "Y") &
        (
            col("m.dbr_silver_layer_ready").isNull() |
            (col("m.dbr_silver_layer_ready") == "") |
            (col("m.dbr_silver_layer_ready") == "N")
        )
    ) \
    .select("b.*")

# display(df)

# COMMAND ----------

# df = spark.table(f"{env}_adb.{schema_name_silver}.tbl_eoc_categories")

# Clean eoc_categories_all_fields column as per requirements
cleaned_col = "eoc_categories_all_fields"

# Remove all HTML tags
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r"<.*?>", " "))
# Remove any space after a dot
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r"\.\s+", "."))
# Remove any space after a comma
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r",\s+", ","))
# Remove space after :
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r":\s+", ":"))
# Replace two or more spaces with one space
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r" {2,}", " "))
# Remove spaces at the start of a line (including after newlines)
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r"(?m)^\s+", ""))
# Remove spaces at the end of a line (including before newlines)
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r"(?m)\s+$", ""))
# Remove space between new line (e.g., "\n   text" -> "\ntext")
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r"\n\s+", "\n"))
# Remove consecutive duplicate lines
df = df.withColumn(cleaned_col, expr(f"regexp_replace({cleaned_col}, '(?m)^(.+)(\\n\\1)+$', '\\1')"))

# display(df)

# COMMAND ----------

# DBTITLE 1,function for eoc categories summary
def create_eoc_summary(json_str):
    try:
        data = json.loads(json_str)
        name = data.get("eocCategories_name", "")
        content = data.get("eocCategories_content", "")
        subcats = data.get("eocCategories_benefitSubCategories", [])
        if not subcats:
            return ""
        
        subcat_names = []
        benefit_names = []
        service_concepts = set()
        
        for subcat in subcats:
            subcat_name = subcat.get("name", "")
            if subcat_name:
                subcat_names.append(subcat_name)
            for benefit in subcat.get("benefits", []):
                name_benefit = benefit.get("name")
                if name_benefit:
                    benefit_names.append(name_benefit)
                for pcs in benefit.get("providerCostShares", []):
                    nbn = pcs.get("nexusBenefitName")
                    if nbn:
                        service_concepts.add(nbn)
        
        # Remove duplicates while preserving order
        benefit_names = list(dict.fromkeys(benefit_names))
        subcat_names = list(dict.fromkeys(subcat_names))
        benefits_str = ", ".join(benefit_names)
        subcat_names_str = ", ".join(subcat_names)
        service_concepts_str = ", ".join(service_concepts)
        
        summary = f'This category includes the subcategories {subcat_names_str}. '
        summary += f'Covered benefits under this category include {benefits_str}.'
        if service_concepts_str:
            summary += f' These benefits correspond to service concepts such as {service_concepts_str}.'
        output = f'{name}-"content":{content}{summary}'
        # Remove space after :
        output = re.sub(r':\s+', ':', output)
        # Remove any space after a dot
        output = re.sub(r'\.\s+', '.', output)
        # Remove any space after a dash
        output = re.sub(r'-\s+', '-', output)
        return output.strip()
    except Exception as e:
        return f"Error: {e}"
    
create_eoc_summary_udf = udf(create_eoc_summary, StringType())

# COMMAND ----------

# DBTITLE 1,calling function
final_df = df.withColumn("eoc_categories_summary", create_eoc_summary_udf("eoc_categories_all_fields"))
gold_layer_eoc_categories_df = final_df.select("facets_product_id","effective_date","nexusId","benefit_id","eoc_categories_all_fields","eoc_categories_summary")
# display(gold_layer_eoc_categories_df)

# COMMAND ----------

# DBTITLE 1,writing the df into the target delta table
gold_layer_eoc_categories_df.write.mode("append").option("mergeSchema", "true").saveAsTable(f"{env}_adb.{schema_name_gold}.tbl_eoc_categories")

# Updating the status flag to Y in master table for vector and silver layer ready columns
update_ready_flags_master_table(gold_layer_eoc_categories_df, master_table_path,spark)