# Databricks notebook source
# MAGIC %pip install databricks-vectorsearch
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import sys
import os
import json
import yaml
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct
from databricks.vector_search.client import VectorSearchClient

# COMMAND ----------

# repo_root/.. (adjust if needed)
parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
# print(parent_dir)



sys.path.insert(0, parent_dir)

from utilities.delta_table_utils import DeltaTableClient
from utilities.data_pipeline.ingestion import *

# COMMAND ----------

# MAGIC %run ../configs/create_schema_and_directory

# COMMAND ----------

dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()

print(str(config_file))

dbutils.widgets.text("environment", "dev")
env: str = dbutils.widgets.get("environment").lower()

# COMMAND ----------

# Load parameters from YAML file
config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

# Extract variable from YAML configuration file
project_name = config['project_name']

print("Project name loaded from config: " + project_name)

# COMMAND ----------

catalog = config['catalog_name']

bronze_schema = config['schema_name_bronze']
silver_schema = config['schema_name_silver']
gold_schema = config['schema_name_gold']
bronze_table: str = "tbl_nexus_plans_mvp1"
master_table: str = "master_table"
bronze_table_path = f"{env}_adb.{bronze_schema}.{bronze_table}"
master_table_path = f"{env}_adb.{bronze_schema}.{master_table}"
vector_search_endpoint_name = config['VS_ENDPOINT']
embedding_endpoint_name = "databricks-bge-large-en"
# List of tables and their corresponding id and text fields
tables_config = [
    {
        "table_name": f"{env}_adb.{silver_schema}.tbl_eoc_program_categories",
        "id_field": "program_id",
        "text_field": "combined_eoc_program_categories"
    },
    {
        "table_name": f"{env}_adb.{gold_schema}.tbl_eoc_categories",
        "id_field": "benefit_id",
        "text_field": "eoc_categories_summary"
    }    
]

#Enable CDF for tables
tables_for_cdf = [
    f"{env}_adb.{silver_schema}.tbl_eoc_program_categories",
    f"{env}_adb.{gold_schema}.tbl_eoc_categories"
]

# COMMAND ----------

for table in tables_for_cdf:
    spark.sql(f"""
    ALTER TABLE {table}
    SET TBLPROPERTIES (delta.enableChangeDataFeed = true)
    """)

# COMMAND ----------

def get_table_vector_index_name(table_name):
    return f"{table_name}_index"

def create_vector_search_client():
    from databricks.vector_search.client import VectorSearchClient
    return VectorSearchClient(disable_notice=True)

def create_and_wait_for_endpoint(vsc, endpoint_name):
    from datetime import timedelta
    import time
    try:
        vsc.create_endpoint(name=endpoint_name, endpoint_type="STANDARD")
        time.sleep(5)
        vsc.wait_for_endpoint(name=endpoint_name, timeout=timedelta(minutes=60), verbose=True)
        print(f"Endpoint named {endpoint_name} is ready.")
    except Exception as e:
        if "already exists" in str(e):
            print(f"Endpoint named {endpoint_name} already exists.")
            print(f"Endpoint path: /api/2.0/vector-search/endpoints/{endpoint_name}")
        else:
            raise e

def create_or_get_index(vsc, endpoint_name, index_name, table_name, primary_key, embedding_source_column, embedding_model_endpoint_name):
    try:
        return vsc.create_delta_sync_index_and_wait(
            endpoint_name=endpoint_name,
            index_name=index_name,
            source_table_name=table_name,
            primary_key=primary_key,
            embedding_source_column=embedding_source_column,
            embedding_model_endpoint_name=embedding_model_endpoint_name,
            pipeline_type="TRIGGERED",
            verbose=True
        )
    except Exception as e:
        if "already exists" in str(e):
            print(f"Index named {index_name} already exists.")
            index = vsc.get_index(endpoint_name, index_name)
            index.sync()
            return index
        else:
            raise e

vsc = create_vector_search_client()
create_and_wait_for_endpoint(vsc, vector_search_endpoint_name)

table_indexes = []
for table_cfg in tables_config:
    index_name = get_table_vector_index_name(table_cfg["table_name"])
    idx = create_or_get_index(
        vsc,
        vector_search_endpoint_name,
        index_name,
        table_cfg["table_name"],
        table_cfg["id_field"],
        table_cfg["text_field"],
        "databricks-bge-large-en"
    )
    table_indexes.append(idx)