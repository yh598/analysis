# Databricks notebook source
# MAGIC %pip install pyyaml

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import sys
import os
import json
import yaml
import os
import requests
import json
import datetime as dt

from pyspark.sql.functions import current_timestamp,lit
from pyspark.sql import functions as F
from pyspark.errors import PySparkException

# COMMAND ----------

# repo_root/.. (adjust if needed)
parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
# print(parent_dir)

sys.path.insert(0, parent_dir)

from utilities.delta_table_utils import DeltaTableClient
from utilities.data_pipeline.ingestion import *

# COMMAND ----------

# MAGIC %run ../configs/create_schema_and_directory

# COMMAND ----------

# DBTITLE 1,DbUtils
dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()

dbutils.widgets.text("environment", "dev")
env: str = dbutils.widgets.get("environment").lower()

# COMMAND ----------

# DBTITLE 1,Config Load

# Load parameters from YAML file
config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

# Extract variable from YAML configuration file
project_name = config['project_name']


# COMMAND ----------

create_schema(config_file,"bronze")
create_schema(config_file,"silver")
create_schema(config_file,"gold")
create_volume(config_file,"bronze")

# COMMAND ----------

# DBTITLE 1,config and tables specific values
api_product_sync = config['api_product_sync']

bronze_table: str = "tbl_nexus_plans_mvp1"
catalog=config['catalog_name']
volume=config['volume_name']

schema_name_bronze = config['schema_name_bronze']
schema_name_silver = config['schema_name_silver']
schema_name_gold = config['schema_name_gold']

csv_path=f"/Volumes/{env}_adb/{schema_name_bronze}/input_file"
master_table_path=f"{env}_adb.{schema_name_bronze}.master_table"

bronze_table_path = f"{env}_adb.{schema_name_bronze}.{bronze_table}"
target_table = f"{env}_adb.{schema_name_bronze}.update_delete_plans_log"

# COMMAND ----------

# DBTITLE 1,Hitting product sync api
if spark.catalog.tableExists(master_table_path):
    dbutils.widgets.text("date_input", "")
    input_dt = dbutils.widgets.get("date_input")

    if not input_dt:
        today = dt.datetime.now().date()
        input_dt = [
            (today - dt.timedelta(days=1)).strftime("%Y-%m-%d"),
            today.strftime("%Y-%m-%d")
        ]

    else:
        # Ensure input_dt is a list
        input_dt = [d.strip() for d in input_dt.split(",")]

    print(input_dt)

    df_api = None
    all_data = []

    url = f"{api_product_sync}"

    for dt_val in input_dt:
        headers = {'If-Modified-Since': f'{dt_val}T00:00:00Z'}
        print(headers)
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            if data:
                all_data.extend(data)
        except Exception as e:
            print(f"API call failed : {e}")

    if all_data:
        df_api = (
            spark.createDataFrame(all_data)
            .withColumnRenamed("effectiveDate", "product_effective_date")
            .withColumnRenamed("facetsProductId", "facets_product_id")
        )
        if df_api.isEmpty():
            print("API returned no data. DataFrame is empty.")
            df_api = None

else:
    print(f"Master table does not exist. Skipping API sync.")

# COMMAND ----------

# DBTITLE 1,creating master table in delta lakehouse
spark.sql(
    f"""
    CREATE TABLE IF NOT EXISTS {master_table_path} (
      facets_product_id         STRING,
      plan_id                   STRING,
      product_effective_date    STRING,
      product_type              STRING,
      plan_type                 STRING,
      product_description       STRING,
      requested_time            TIMESTAMP,
      requester_id              STRING,
      dbr_silver_layer_ready    STRING,
      update_time               TIMESTAMP,
      insert_time               TIMESTAMP,
      vector_db_ready           STRING,
      ready_for_agent           STRING,
      comments                  STRING,
      data_issue                STRING
    )
    USING DELTA
    TBLPROPERTIES ('delta.columnMapping.mode' = 'name')
    """
)

# COMMAND ----------

from pyspark.sql.functions import col

df_master = spark.table(f'{env}_adb.{schema_name_bronze}.master_table')

if df_api is not None and df_api.count() > 0:
    try:
        if spark.catalog.tableExists(f'{env}_adb.{schema_name_bronze}.master_table'):

            print("Master Table exist")
            # 'df' is the DataFrame from the API response
            comparison_keys = ["facets_product_id", "product_effective_date"]

            # Records in df that are missing in master_table
            new_plans = df_api.join(
                df_master,
                on=comparison_keys,
                how="left_anti"
            )


            # Records in df that are available in master_table and api lastPublished > update_time
            plans_in_master = df_api.join(
                df_master,
                on=comparison_keys,
                how="inner"
            ).where(col("lastPublished") > col("update_time"))


    except Exception as e:
        print(f"Master Table does not exist:{e}")

    # Load CSV keys
    df_csv_keys = read_csv_keys_as_df(spark, csv_path)
    df_master_keys = df_master.select("facets_product_id", "product_effective_date").distinct()
    df_csv_keys = df_csv_keys.join(df_master_keys, on=["facets_product_id", "product_effective_date"], how="left_anti")

    # common columns between new_plans and plans_in_master
    common_cols = list(set(new_plans.columns).intersection(plans_in_master.columns))
    df_joined = new_plans.join(plans_in_master.select(common_cols), on=common_cols, how="outer")

    # Join CSV keys with the combined plan identifiers
    df_api_csv_combined = df_csv_keys.join(
        df_joined,
        on=["facets_product_id", "product_effective_date"],
        how="outer"
    )


else:
    df_csv_keys = read_csv_keys_as_df(spark, csv_path)
    df_master_keys = df_master.select("facets_product_id", "product_effective_date").distinct()
    df_api_csv_combined = df_csv_keys.join(df_master_keys, on=["facets_product_id", "product_effective_date"], how="left_anti")
    

# COMMAND ----------

# DBTITLE 1,update/delete existing records in master
table_path = [
    f"{env}_adb.{schema_name_silver}.tbl_plan_details",
    f"{env}_adb.{schema_name_silver}.tbl_eoc_sections",
    f"{env}_adb.{schema_name_silver}.tbl_eoc_program_categories",
    f"{env}_adb.{schema_name_silver}.tbl_eoc_categories",
    f"{env}_adb.{schema_name_gold}.tbl_eoc_categories"
]

try:
    plans_in_master_exists = 'plans_in_master' in locals() and plans_in_master is not None and plans_in_master.count() > 0
    if plans_in_master_exists:
        if spark.catalog.tableExists(table_path[0]):
            print("Table exist in silver layer")

            plans_in_master.createOrReplaceTempView("plans_in_master_keys")

            # First update master table
            spark.sql(f"""
                UPDATE {master_table_path}
                SET dbr_silver_layer_ready = 'N',
                    vector_db_ready = 'N'
                WHERE EXISTS (
                    SELECT 1
                    FROM plans_in_master_keys pmk
                    WHERE {master_table_path}.facets_product_id = pmk.facets_product_id
                    AND {master_table_path}.product_effective_date = pmk.product_effective_date
                )
            """)

            # Then delete from silver tables
            for table in table_path:
                spark.sql(f"""
                    DELETE FROM {table}
                    WHERE EXISTS (
                        SELECT 1
                        FROM plans_in_master_keys pmk
                        WHERE {table}.facets_product_id = pmk.facets_product_id
                        AND {table}.effective_date = pmk.product_effective_date
                    )
                """)
except Exception as e:
    print(f"Error during silver layer update/delete: {e}")

# COMMAND ----------


client = DeltaTableClient(
    spark,
    identifier=master_table_path,  
    is_path=False,
    partition_by=[""],                
)

# COMMAND ----------

# DBTITLE 1,api hit
output_dir = f"/Volumes/{env}_adb/{schema_name_bronze}/plan_data_mvp1"
REQUESTER_ID="Kiran.Vengala@blueshieldca.com"
df_new_rows = fetch_and_build_rows_df(spark, df_api_csv_combined, output_dir,config["api_url"],REQUESTER_ID)

# COMMAND ----------

df_new_rows.display()

# COMMAND ----------

# DBTITLE 1,new rows
# Load the master table as a DataFrame
df_table = spark.table(master_table_path).where("dbr_silver_layer_ready='N' AND vector_db_ready='N'")
# display(df_table)

df_not_in_table = df_new_rows.join(df_table, on=["facets_product_id", "product_effective_date"], how="left_anti")
# display(df_not_in_table)

# Union the two DataFrames
df_final = df_table.unionByName(df_not_in_table, allowMissingColumns=True)
# display(df_final)

# COMMAND ----------

# DBTITLE 1,write old plans that will be update
try:
    if spark.catalog.tableExists(bronze_table_path):
        # Example: df_table has 'facets_product_id', 'product_effective_date'
        # bronze_df has 'bronze_product_id', 'bronze_effective_date'
        key_df = (
            df_table
            .select(
                col("facets_product_id").alias("facets_product_id"),
                col("product_effective_date").alias("effective_date")
            )
            .distinct()
        )

        bronze_df = spark.table(bronze_table_path)
        # Join on the renamed columns
        result_df = bronze_df.join(
            key_df,
            on=[
                bronze_df["facets_product_id"] == key_df["facets_product_id"],
                bronze_df["effective_date"] == key_df["effective_date"]
            ],
            how="inner"
        ).drop(key_df["facets_product_id"]).drop(key_df["effective_date"])
        result_df.write.format("delta").option("mergeSchema", "true").mode("append").saveAsTable(target_table)

        
except Exception as e:
    print(f"Error: {e}")

# COMMAND ----------

# DBTITLE 1,merged into master table
   
if df_new_rows.count() > 0:
    client.merge_upsert(
    source_df=df_final,
    keys=["facets_product_id", "product_effective_date","product_type"],
    updates="*",                                     # or dict of custom expressions
    insert_when_not_matched=True,
    delete_when_not_matched_by_source=False,
    schema_evolve=True,
)
    print(f"Merged {df_new_rows.count()} rows into master_table.")
else:
    print("Nothing to merge; master is up to date with CSV keys.")

# COMMAND ----------

# DBTITLE 1,plans ready for load into the bronze table
try:
    if spark.catalog.tableExists(bronze_table_path):
        plans_ready_for_bronze = df_final.filter((df_final["bronze_ready_flag"] == "Y") | (df_final["data_issue"].isNull()))
        
except Exception as e:
    plans_ready_for_bronze = df_final

# COMMAND ----------

# ---- 1. Read JSONs into a clean DF for Bronze ----
df_clean = prepare_volume_dataframe(
    spark,
    master_df=plans_ready_for_bronze,
    volume_path=output_dir,
    key1_col="facets_product_id",
    key2_col="product_effective_date",
    product_type_col="product_type"
)

# COMMAND ----------

if df_clean.count() > 0:
    bronze_table_path = f"{env}_adb.{schema_name_bronze}.{bronze_table}"

    #merged data into the bronze table
    MERGE_KEYS_BRONZE = ["file_name"]
    # ---- 3. Prepare Master update with data_issue + bronze_ready_flag ----
    bronze = DeltaTableClient(spark, identifier=bronze_table_path, is_path=False)
    bronze.merge_upsert(
        source_df=df_clean,
        keys=MERGE_KEYS_BRONZE,
        updates="*",
        insert_when_not_matched=True,
        delete_when_not_matched_by_source=False,
        schema_evolve=True
    )

    #update only flags and issues into the master table
    # ---- 4. Merge into Master (update only flags & issues) ----
    master = DeltaTableClient(spark, master_table_path, is_path=False)
    df_issues = compute_data_isssue(df_clean)
    src_for_master = df_issues.select(
        "facets_product_id",
        "effective_date",
        "product_line_of_business",
        "data_issue",
        "bronze_ready_flag"
    )
    src_for_master = src_for_master.withColumnRenamed("product_line_of_business", "product_type")
    src_for_master = src_for_master.withColumnRenamed("effective_date", "product_effective_date")

    updates_map = {
        "bronze_ready_flag": "src.`bronze_ready_flag`",
        "data_issue": "src.`data_issue`"
    }
    MERGE_KEYS = ["facets_product_id", "product_effective_date", "product_type"]
    master.merge_upsert(
        source_df=src_for_master,
        keys=MERGE_KEYS,
        updates=updates_map,
        insert_when_not_matched=True,
        delete_when_not_matched_by_source=False,
        schema_evolve=True
    )

    #deleting the bronze_ready_load column from master table
    try:
        columns = [field.name for field in spark.table(master_table_path).schema.fields]
        if "bronze_ready_load" in columns:
            spark.sql(f"ALTER TABLE {master_table_path} DROP COLUMN IF EXISTS bronze_ready_load")
            print("Dropped column 'bronze_ready_load' from master_table.")
    except Exception as e:
        print(f"Error while dropping 'bronze_ready_load' column from master_table: {e}")