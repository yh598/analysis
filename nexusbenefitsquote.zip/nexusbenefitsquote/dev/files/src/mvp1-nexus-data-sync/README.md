# Nexus Benefits Data Sync - Data Pipeline Documentation

## Project Overview

The **Nexus Benefits Data Sync** project is a comprehensive data pipeline built on Databricks that ingests, transforms, and synchronizes health insurance plan data from external APIs into a multi-layered Delta Lake architecture. The pipeline processes Evidence of Coverage (EOC) documents, generates vector embeddings for semantic search, and maintains bidirectional synchronization with a PostgreSQL Lakebase database.

### Key Features

* **Multi-layer Delta Lake Architecture**: Bronze → Silver → Gold data layers with full lineage tracking
* **Automated API Integration**: Syncs plan data from external REST APIs with incremental updates
* **Vector Search Capabilities**: Generates embeddings for semantic search using Databricks BGE-Large-EN model
* **Master Data Management**: Centralized master table tracking data quality and processing status
* **Lakebase Synchronization**: Bidirectional sync between Delta Lake and PostgreSQL for operational workloads
* **Data Quality Validation**: Built-in validation and issue tracking throughout the pipeline

---

## Table of Contents

1. [Project Structure](#project-structure)
2. [Architecture Overview](#architecture-overview)
3. [Installation & Setup](#installation--setup)
4. [Pipeline Notebooks](#pipeline-notebooks)
5. [Utility Modules](#utility-modules)
6. [Helper Modules](#helper-modules)
7. [Configuration](#configuration)
8. [Usage Guide](#usage-guide)
9. [Data Quality & Monitoring](#data-quality--monitoring)
10. [Troubleshooting](#troubleshooting)

---

## Project Structure

```
src/
├── configs/
│   ├── dev_config.yml              # Development environment configuration
│   ├── prod_config.yml             # Production environment configuration
│   ├── lakebase_sync.yml           # Lakebase PostgreSQL sync configuration
│   └── create_schema_and_directory # Schema and volume initialization
├── mvp1-nexus-data-sync/
│   ├── 01_ingest_to_bronze.py      # API ingestion to Bronze layer
│   ├── 02_ingest_to_silver.py      # Bronze to Silver transformation
│   ├── 03_generate_embeddings.py   # Vector index creation
│   ├── gold_layer.py               # Silver to Gold enrichment
│   └── sync_lakebase.py            # Delta Lake ↔ PostgreSQL sync
├── utilities/
    ├── delta_table_utils.py        # Delta table merge/upsert operations
    └── data_pipeline/
        ├── ingestion.py            # API fetching and JSON processing
        └── transformation.py       # Data transformation functions

```

---

## Architecture Overview

### Data Flow Diagram

```
┌─────────────────┐
│  External API   │
│  (Plan Data)    │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│                    01_ingest_to_bronze.py                   │
│  • Fetch plan data from REST API                            │
│  • Store raw JSON in /Volumes                               │
│  • Update master_table with metadata                        │
│  • Track data issues and validation flags                   │
└────────┬────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│                Bronze Layer (Raw Data)                      │
│  Table: tbl_nexus_plans_mvp1                                │
│  • Raw JSON from API                                        │
│  • File-level metadata                                      │
│  • No transformations applied                               │
└────────┬────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│                    02_ingest_to_silver.py                   │
│  • Parse nested JSON structures                             │
│  • Explode arrays (EOC categories, sections, programs)      │
│  • Normalize schema                                         │
│  • Create relational tables                                 │
└────────┬────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│                Silver Layer (Normalized Data)               │
│  Tables:                                                    │
│  • tbl_plan_details                                         │
│  • tbl_eoc_categories                                       │
│  • tbl_eoc_sections                                         │
│  • tbl_eoc_program_categories                               │
└────────┬────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│                      gold_layer.py                          │
│  • Clean HTML tags and whitespace                           │
│  • Generate semantic summaries                              │
│  • Create eoc_categories_summary field                      │
│  • Prepare for vector embedding                             │
└────────┬────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│                Gold Layer (Enriched Data)                   │
│  Table: tbl_eoc_categories                                  │
│  • Cleaned content                                          │
│  • Semantic summaries                                       │
│  • Ready for embedding                                      │
└────────┬────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│                 03_generate_embeddings.py                   │
│  • Enable Change Data Feed (CDF)                            │
│  • Create Vector Search endpoint                            │
│  • Generate embeddings using BGE-Large-EN                   │
│  • Build Delta Sync indexes                                 │
└────────┬────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────┐
│              Vector Search Indexes                          │
│  • tbl_eoc_program_categories_index                         │
│  • tbl_eoc_categories_index                                 │
│  • Semantic search enabled                                  │
└─────────────────────────────────────────────────────────────┘

         ┌────────────────────────────────┐
         │     sync_lakebase.py           │
         │  Bidirectional Sync            │
         └────────┬───────────────────────┘
                  │
                  ▼
         ┌────────────────────────────────┐
         │  PostgreSQL Lakebase           │
         │  • master_table                │
         │  • tbl_benefitsquote_feedback  │
         └────────────────────────────────┘
```

### Master Table - Central Control Hub

The `master_table` acts as the central orchestration point for the entire pipeline:

| Column | Type | Purpose |
|--------|------|------------|
| `facets_product_id` | STRING | Unique plan identifier |
| `product_effective_date` | STRING | Plan effective date (YYYYMMDD) |
| `product_type` | STRING | Plan type (HMO, PPO, etc.) |
| `plan_type` | STRING | Plan category |
| `product_description` | STRING | Human-readable plan name |
| `plan_id` | STRING | Internal plan ID |
| `requested_time` | TIMESTAMP | When plan was requested |
| `requester_id` | STRING | User who requested the plan |
| `bronze_ready_flag` | STRING | Y/N - Bronze layer complete |
| `dbr_silver_layer_ready` | STRING | Y/N - Silver layer complete |
| `vector_db_ready` | STRING | Y/N - Vector index complete |
| `ready_for_agent` | STRING | Y/N - Ready for agent use |
| `data_issue` | STRING | Validation errors/warnings |
| `insert_time` | TIMESTAMP | First insert timestamp |
| `update_time` | TIMESTAMP | Last update timestamp |
| `comments` | STRING | Additional notes |

---

## Installation & Setup

### Prerequisites

* Databricks Runtime 13.3 LTS or higher
* Python 3.10+
* Access to Databricks Unity Catalog
* Databricks Vector Search enabled
* PostgreSQL Lakebase instance (for sync operations)

### Step 1: Install Dependencies

```python
# Install required packages
%pip install pyyaml
%pip install databricks-vectorsearch
%pip install psycopg[binary]
%pip install --upgrade databricks-sdk

dbutils.library.restartPython()
```

### Step 2: Configure Environment

Create configuration files in the `configs/` directory:

**`configs/dev_config.yml`**
```yaml
project_name: "nexus-benefits-mvp1"
catalog_name: "dev_adb"
schema_name_bronze: "nexusbenefitsquote_bronze_mvp1"
schema_name_silver: "nexusbenefitsquote_silver_mvp1"
schema_name_gold: "nexusbenefitsquote_gold_mvp1"
api_url: "https://api.example.com/plans"
api_product_sync: "https://api.example.com/product-sync"
VS_ENDPOINT: "nexus_benefits_vector_search"
```

**`configs/lakebase_sync.yml`**
```yaml
instance_dev: "lakebase-dev-instance"
instance_prod: "lakebase-prod-instance"
sslmode: "require"
delta_lake_schema: "nexusbenefitsquote_gold_mvp1"
remove_old_chat_days_dev: 90
remove_old_chat_days_prod: 180
```

### Step 3: Initialize Schemas and Volumes

```python
%run ./configs/create_schema_and_directory
```

This creates:
* Unity Catalog schemas (bronze, silver, gold)
* Volumes for raw JSON storage
* Master table with proper schema

---

## Pipeline Notebooks

### 1. `01_ingest_to_bronze.py` - API Ingestion

**Purpose**: Fetch plan data from external APIs and store raw JSON in Bronze layer.

#### Key Functions

##### API Synchronization
```python
# Fetch plans modified since specific date
headers = {'If-Modified-Since': '2024-01-01T00:00:00Z'}
response = requests.get(api_url, headers=headers)
data = response.json()
```

##### Master Table Management
* **New Plans**: Plans in API but not in master table
* **Updated Plans**: Plans where `lastPublished > update_time`
* **CSV Keys**: Manual plan additions from CSV file

#### Workflow

1. **Load existing master table**
2. **Fetch API updates** (incremental sync)
3. **Read CSV keys** for manual additions
4. **Identify new/updated plans**
5. **Delete outdated records** from silver/gold layers
6. **Fetch full plan JSON** from API
7. **Store JSON in /Volumes**
8. **Validate data quality**
9. **Merge into master table**
10. **Load validated plans to Bronze**

---

### 2. `02_ingest_to_silver.py` - Data Normalization

**Purpose**: Parse nested JSON and create normalized relational tables.

#### Transformation Functions

##### Plan Details Extraction
```python
def process_plan_details(bronze_df):
    """
    Extracts top-level plan metadata:
    - Plan name, type, description
    - Deductibles (individual/family, in/out network)
    - Out-of-pocket maximums
    - Accumulator types
    - HSA eligibility
    
    Returns: Flattened DataFrame with plan-level attributes
    """
```

##### EOC Categories Processing
```python
def process_eoc_categories(bronze_df):
    """
    Explodes nested EOC categories structure:
    - eocCategories (top level)
      └─ benefitSubCategories
         └─ benefits
            └─ providerCostShares
    
    Creates benefit_id: {facets_product_id}_{nexusId}
    Stores full JSON in eoc_categories_all_fields
    
    Returns: One row per benefit with all nested data
    """
```

#### Workflow

1. **Read Bronze table** (filter by `bronze_ready_flag = 'Y'`)
2. **Parse JSON** using transformation functions
3. **Write to Silver tables**:
   * `tbl_plan_details`
   * `tbl_eoc_categories`
   * `tbl_eoc_sections`
   * `tbl_eoc_program_categories`
4. **Update master table**:
   * Set `dbr_silver_layer_ready = 'Y'`
   * Update `insert_time` and `update_time`

---

### 3. `gold_layer.py` - Data Enrichment

**Purpose**: Clean and enrich data for vector embedding and agent consumption.

#### Data Cleaning Pipeline

```python
# Remove HTML tags
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r"<.*?>", " "))

# Normalize whitespace
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r"\\.\\s+", "."))
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r",\\s+", ","))
df = df.withColumn(cleaned_col, regexp_replace(cleaned_col, r" {2,}", " "))
```

#### Semantic Summary Generation

```python
def create_eoc_summary(json_str):
    """
    Generates human-readable summary from EOC category JSON.
    
    Process:
    1. Extract category name and content
    2. List all subcategories
    3. List all covered benefits
    4. Map to service concepts (nexusBenefitName)
    
    Output Format:
    "This category includes the subcategories [A, B, C]. 
     Covered benefits under this category include [X, Y, Z].
     These benefits correspond to service concepts such as [P, Q, R]."
    """
```

---

### 4. `03_generate_embeddings.py` - Vector Search Setup

**Purpose**: Create vector search indexes for semantic retrieval.

#### Vector Search Configuration

```python
tables_config = [
    {
        "table_name": "dev_adb.nexusbenefitsquote_silver_mvp1.tbl_eoc_program_categories",
        "id_field": "program_id",
        "text_field": "combined_eoc_program_categories"
    },
    {
        "table_name": "dev_adb.nexusbenefitsquote_gold_mvp1.tbl_eoc_categories",
        "id_field": "benefit_id",
        "text_field": "eoc_categories_summary"
    }
]
```

#### Workflow

1. **Enable Change Data Feed (CDF)** on source tables
2. **Create Vector Search Endpoint**
3. **Create Delta Sync Indexes**
4. **Sync indexes** (manual trigger or automatic via CDF)

---

### 5. `sync_lakebase.py` - PostgreSQL Synchronization

**Purpose**: Bidirectional sync between Delta Lake and PostgreSQL Lakebase.

#### Sync Direction 1: Delta Lake → PostgreSQL (Master Table)

```python
def _conn(autocommit=False):
    """
    Creates authenticated connection to Lakebase PostgreSQL.
    Uses Databricks SDK to generate short-lived credentials.
    """
    inst = w.database.get_database_instance(name=instance)
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()),
        instance_names=[instance]
    )
    return psycopg.connect(
        host=host,
        port=5432,
        dbname=db_name,
        user=user_name,
        password=cred.token,
        sslmode=sslmode
    )
```

#### Sync Direction 2: PostgreSQL → Delta Lake (Feedback Table)

```python
# Read from PostgreSQL
with _conn() as conn:
    with conn.cursor(row_factory=tuple_row) as cur:
        cur.execute("SELECT * FROM tbl_benefitsquote_feedback")
        rows = cur.fetchall()

# Merge into Delta Lake
MERGE INTO dev_adb.nexusbenefitsquote_gold_mvp1.tbl_benefitsquote_feedback AS target
USING feedback_source AS source
ON target.response_id = source.response_id
   AND target.question_id = source.question_id
WHEN NOT MATCHED THEN INSERT (...)
```

---

## Utility Modules

### Overview

The `utilities/` directory contains generic, reusable functions for Delta table operations and data pipeline processing. These modules are environment-agnostic and can be used across multiple projects.

### `utilities/delta_table_utils.py`

**Purpose**: Provides a high-level wrapper for Delta table merge/upsert operations.

#### Class: `DeltaTableClient`

```python
class DeltaTableClient:
    """
    Simplifies Delta table merge operations with automatic schema evolution.
    
    Features:
    - Merge/upsert with composite keys
    - Automatic schema evolution
    - Delete when not matched by source
    - Custom update expressions
    """
    
    def __init__(self, spark, identifier, is_path=False, partition_by=None):
        """
        Args:
            spark: SparkSession
            identifier: Table name or path
            is_path: True if identifier is a path, False if table name
            partition_by: List of partition columns
        """
```

#### Method: `merge_upsert`

```python
def merge_upsert(
    self,
    source_df,
    keys,
    updates="*",
    insert_when_not_matched=True,
    delete_when_not_matched_by_source=False,
    schema_evolve=True
):
    """
    Performs merge/upsert operation on Delta table.
    
    Args:
        source_df: Source DataFrame to merge
        keys: List of column names for join condition
        updates: "*" for all columns, or dict of {col: expression}
        insert_when_not_matched: Insert new records
        delete_when_not_matched_by_source: Delete records not in source
        schema_evolve: Allow schema changes
    
    Example:
        client = DeltaTableClient(spark, "catalog.schema.table")
        client.merge_upsert(
            source_df=new_data,
            keys=["facets_product_id", "effective_date"],
            updates={"status": "src.status", "update_time": "current_timestamp()"},
            schema_evolve=True
        )
    """
```

---

### `utilities/data_pipeline/ingestion.py`

**Purpose**: API fetching, JSON processing, and volume management.

#### Function: `fetch_and_build_rows_df`

```python
def fetch_and_build_rows_df(
    spark,
    master_df,
    output_dir,
    api_url,
    requester_id
):
    """
    Fetches plan data from API and stores JSON in volumes.
    
    Process:
    1. Iterate through master_df rows
    2. Call API for each plan (facets_product_id + effective_date)
    3. Save JSON to /Volumes/{output_dir}/{facets_product_id}_{effective_date}.json
    4. Build DataFrame with metadata
    
    Returns:
        DataFrame with columns:
        - facets_product_id
        - product_effective_date
        - product_type
        - plan_type
        - product_description
        - plan_id
        - requested_time
        - requester_id
        - bronze_ready_flag (default: 'N')
        - data_issue (validation errors)
    """
```

---

### `utilities/data_pipeline/transformation.py`

**Purpose**: Data transformation functions for Silver and Gold layers.

#### Function: `process_plan_details`

```python
def process_plan_details(bronze_df):
    """
    Extracts plan-level details from Bronze JSON.
    
    Extracted Fields:
    - Plan metadata: name, type, description
    - Deductibles (Individual/Family, In/Out network)
    - Out-of-pocket maximums
    - Accumulator type (embedded/aggregate)
    - HSA eligibility
    
    Returns:
        DataFrame with flattened plan details
    """
```

---

## Helper Modules

### Overview

Helper modules contain domain-specific integration scripts for external systems and APIs. Unlike utilities (which are generic), helpers are tailored to specific business logic and system integrations.

### Helper: API Client Wrapper

**Location**: Embedded in `utilities/data_pipeline/ingestion.py`

**Purpose**: Provides authenticated REST API calls to external plan data service.

#### Function: `call_api_with_retry`

```python
def call_api_with_retry(
    url,
    headers=None,
    params=None,
    max_retries=3,
    backoff_factor=2
):
    """
    Calls REST API with exponential backoff retry logic.
    
    Retry Conditions:
    - HTTP 429 (Rate Limit)
    - HTTP 500-599 (Server Errors)
    - Connection timeouts
    
    Example:
        response = call_api_with_retry(
            url="https://api.example.com/plans",
            headers={"Authorization": "Bearer token"},
            params={"facetsProductId": "MG011320", "effectiveDate": "20240101"}
        )
    """
```

---

### Helper: PostgreSQL Lakebase Connector

**Location**: `sync_lakebase.py`

**Purpose**: Manages bidirectional sync between Delta Lake and PostgreSQL.

#### Function: `_conn`

```python
def _conn(autocommit=False):
    """
    Creates authenticated PostgreSQL connection using Databricks SDK.
    
    Security:
    - Uses short-lived credentials (expires in 1 hour)
    - No hardcoded passwords
    - SSL/TLS encryption enforced
    
    Example:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM master_table LIMIT 10")
                rows = cur.fetchall()
    """
```

---

## Configuration

### Environment Variables

Set via Databricks widgets:

```python
dbutils.widgets.text("config_file", "dev_config.yml")
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("date_input", "")  # Optional: for incremental sync
```

### Configuration Files

#### `dev_config.yml`

```yaml
# Project metadata
project_name: "nexus-benefits-mvp1"

# Unity Catalog configuration
catalog_name: "dev_adb"
schema_name_bronze: "nexusbenefitsquote_bronze_mvp1"
schema_name_silver: "nexusbenefitsquote_silver_mvp1"
schema_name_gold: "nexusbenefitsquote_gold_mvp1"

# API endpoints
api_url: "https://api.example.com/plans"
api_product_sync: "https://api.example.com/product-sync"

# Vector Search
VS_ENDPOINT: "nexus_benefits_vector_search"
```

---

## Usage Guide

### Running the Full Pipeline

#### Step 1: Ingest to Bronze

```python
# Run notebook: 01_ingest_to_bronze.py
dbutils.notebook.run(
    "./01_ingest_to_bronze",
    timeout_seconds=3600,
    arguments={
        "config_file": "dev_config.yml",
        "environment": "dev",
        "date_input": "2024-01-01,2024-01-02"  # Optional
    }
)
```

#### Step 2: Transform to Silver

```python
# Run notebook: 02_ingest_to_silver.py
dbutils.notebook.run(
    "./02_ingest_to_silver",
    timeout_seconds=1800,
    arguments={
        "config_file": "dev_config.yml",
        "environment": "dev"
    }
)
```

#### Step 3: Enrich to Gold

```python
# Run notebook: gold_layer.py
dbutils.notebook.run(
    "./gold_layer",
    timeout_seconds=1200,
    arguments={
        "config_file": "dev_config.yml",
        "environment": "dev"
    }
)
```

#### Step 4: Generate Embeddings

```python
# Run notebook: 03_generate_embeddings.py
dbutils.notebook.run(
    "./03_generate_embeddings",
    timeout_seconds=3600,
    arguments={
        "config_file": "dev_config.yml",
        "environment": "dev"
    }
)
```

#### Step 5: Sync to Lakebase

```python
# Run notebook: sync_lakebase.py
dbutils.notebook.run(
    "./sync_lakebase",
    timeout_seconds=600,
    arguments={
        "config_file": "dev_config.yml",
        "config_file_lakebase": "lakebase_sync.yml",
        "environment": "dev"
    }
)
```

---

## Data Quality & Monitoring

### Master Table Status Tracking

Query to check pipeline status:

```sql
SELECT 
    facets_product_id,
    product_effective_date,
    bronze_ready_flag,
    dbr_silver_layer_ready,
    vector_db_ready,
    ready_for_agent,
    data_issue,
    update_time
FROM dev_adb.nexusbenefitsquote_bronze_mvp1.master_table
WHERE bronze_ready_flag = 'Y'
  AND (dbr_silver_layer_ready IS NULL OR dbr_silver_layer_ready = 'N')
ORDER BY update_time DESC
```

### Data Quality Checks

#### Check for Missing Data

```sql
-- Plans with data issues
SELECT 
    facets_product_id,
    product_effective_date,
    data_issue,
    update_time
FROM dev_adb.nexusbenefitsquote_bronze_mvp1.master_table
WHERE data_issue IS NOT NULL
  AND data_issue != ''
ORDER BY update_time DESC
```

---

## Troubleshooting

### Common Issues

#### Issue 1: API Call Failures

**Symptoms**:
* `data_issue` column shows "API call failed"
* Bronze table not populated

**Solutions**:
1. Check API endpoint configuration in `dev_config.yml`
2. Verify network connectivity from Databricks
3. Check API authentication credentials
4. Review API rate limits

#### Issue 2: JSON Parsing Errors

**Symptoms**:
* `data_issue` column shows "Invalid JSON structure"
* Silver tables empty

**Solutions**:
1. Inspect raw JSON in Bronze table
2. Check for malformed JSON (missing brackets, quotes)
3. Validate against expected schema

#### Issue 3: Vector Index Not Syncing

**Symptoms**:
* Index status shows "OFFLINE" or "FAILED"
* Queries return no results

**Solutions**:
1. Check if CDF is enabled on source table
2. Manually trigger index sync
3. Verify embedding model endpoint is available

---

## Best Practices

1. **Always validate data before processing**
   * Check `bronze_ready_flag` before Silver transformation
   * Review `data_issue` column for validation errors

2. **Use incremental processing**
   * Filter by `dbr_silver_layer_ready = 'N'` to process only new data
   * Leverage master table flags for efficient processing

3. **Monitor pipeline progress**
   * Track master table status regularly
   * Set up alerts for data quality issues

4. **Maintain data lineage**
   * Keep master table updated with processing timestamps
   * Document data transformations in comments

---

## Contact & Support

For questions or issues, please contact:
* **Project Lead**: pmane01@blueshieldca.com
* **Documentation**: This README.md
* **Repository**: mvp1-nexus-data-sync

---

**Last Updated**: January 2026  
**Version**: 1.0  
**Maintained By**: Nexus Benefits Data Engineering Team
