from fastapi import FastAPI, HTTPException, status, Request
from pydantic import BaseModel, Field
import sys
import uuid
from databricks.sdk import WorkspaceClient
import asyncpg
import os 
from typing import List

# config = load_config()
w = WorkspaceClient()

host_name = os.environ['DATABRICKS_APP_URL']

if '640321604414221' in host_name :
    pg_instance_nme=os.getenv("dev_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_dev")
    }
elif '370726302632140' in host_name :
    pg_instance_nme=os.getenv("qa_prod_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_qa")
    }
else:
    pg_instance_nme=os.getenv("qa_prod_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_prod")
    }	

    

async def get_asyncpg_connection():
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()),
        instance_names=[config["INSTANCE"]]
    )
    conn = await asyncpg.connect(
        host=config["HOST"],
        port=5432,
        database=config["DBNAME"],
        user=config["USERNAME"],
        password=cred.token,
        ssl="require"
    )
    return conn

feedback = FastAPI()

class FeedbackRequest(BaseModel):
    response_id: str = Field(..., min_length=1)
    question_id: str = Field(..., min_length=1)
    user_id: str = Field(..., min_length=1)
    user_name: str = Field(..., min_length=1)
    feedback_type: str = Field(..., min_length=0)
    reason_code: List[str] = Field(default_factory=list)
    additional_comments: str = Field(..., min_length=0)
    session_id: str = Field(..., min_length=1)

@feedback.post("/submit", status_code=status.HTTP_201_CREATED)
async def submit_feedback( feedback: FeedbackRequest,  request: Request):
 
    try:
        conn = await get_asyncpg_connection()
        feedback_response_id = f"fb{uuid.uuid4().hex[:6]}"
        await conn.execute(
            """
            INSERT INTO tbl_benefitsquote_feedback (
                response_id, question_id, user_id, user_name,
                feedback_type, reason_code, additional_comments, session_id,feedback_response_id
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8,$9)
            ON CONFLICT (session_id, user_id, question_id)
            DO UPDATE SET
                response_id = EXCLUDED.response_id,
                user_name = EXCLUDED.user_name,
                feedback_type = EXCLUDED.feedback_type,
                reason_code = EXCLUDED.reason_code,
                additional_comments = EXCLUDED.additional_comments,
                feedback_response_id=EXCLUDED.feedback_response_id
            """,
            feedback.response_id,
            feedback.question_id,
            feedback.user_id,
            feedback.user_name,
            feedback.feedback_type,
            feedback.reason_code,
            feedback.additional_comments,
            feedback.session_id,
            feedback_response_id,
        )

        await conn.close()
        return {
            "status": "success",
            "feedback_response_id": feedback_response_id,
            "message": "Thank you for your feedback. It has been recorded.",
            "next_steps": None
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )