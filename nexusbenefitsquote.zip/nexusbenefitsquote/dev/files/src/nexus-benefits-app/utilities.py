import uuid
from databricks.sdk import WorkspaceClient
import asyncpg

def load_config():
    # Replace this with code to load from your asset bundle
    return {
        "INSTANCE": "benefit-quote-lakebase",
        "USERNAME": "aramya01@blueshieldca.com",
        "DBNAME": "databricks_postgres",
        "HOST": "instance-ce60c166-f33f-4642-b5b5-d64acaeb6086.database.azuredatabricks.net",
        "PORT": 5432
    }

config = load_config()
w = WorkspaceClient()

async def get_asyncpg_connection():
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()),
        instance_names=[config["INSTANCE"]]
    )
    conn = await asyncpg.connect(
        host=config["HOST"],
        port=config["PORT"],
        database=config["DBNAME"],
        user=config["USERNAME"],
        password=cred.token,
        ssl="require"
    )
    return conn