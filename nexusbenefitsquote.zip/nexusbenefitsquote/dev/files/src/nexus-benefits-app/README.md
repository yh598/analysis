%md
# Nexus Benefits App

## Overview

The **Nexus Benefits App** is a FastAPI-based microservices application that provides intelligent benefits information through an AI-powered agent. The application integrates with Databricks Model Serving endpoints and PostgreSQL databases to deliver real-time benefits queries, feedback collection, and frequently asked questions.

### Key Features

* **AI-Powered Benefits Agent**: Natural language query interface for benefits information
* **Feedback System**: Collect and store user feedback on agent responses
* **Top Questions**: Retrieve frequently asked questions for specific benefit plans
* **Multi-Environment Support**: Automatic configuration for dev, QA, and production environments
* **Async Database Operations**: High-performance PostgreSQL integration using asyncpg

---

## Architecture

The application follows a modular  architecture:  
nexus-benefits-app/  
├── agent/ # Benefits query agent endpoint   
├── feedback/ # User feedback collection endpoint   
├── topquestions/ # Top questions retrieval endpoint  
├── main.py # FastAPI application entry point  
├── utilities.py # Shared database utilities  
├── app.yaml # Environment configuration   
└── requirements.txt # Python dependencies




## Installation

### Prerequisites

* Python 3.9+
* Databricks Workspace access
* PostgreSQL database instance
* Valid Databricks authentication credentials

### Setup Instructions

1. **Clone the repository**
bash git clone <repository-url> cd nexus-benefits-app
2. **Install dependencies**
bash pip install -r requirements.txt

3. **Configure environment variables**
   
   The application automatically detects the environment based on `DATABRICKS_APP_URL`. Ensure the following environment variables are set:
   
   * `DATABRICKS_APP_URL`: Your Databricks workspace URL
   * `DATABRICKS_CLIENT_ID`: Service principal client ID
   * Environment-specific variables are loaded from `app.yaml`

4. **Run the application**

bash gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app

5. **Access the API**
   
   * API Root: `https://nexus-benefits-app-<workspace-id>.1.azure.databricksapps.com/`
   * Agent Endpoint: `https://nexus-benefits-app-<workspace-id>.1.azure.databricksapps.com/agent/chat`
   * Feedback Endpoint: `https://nexus-benefits-app-<workspace-id>.1.azure.databricksapps.com//feedback/submit`
   * Top Questions: `https://nexus-benefits-app-<workspace-id>.1.azure.databricksapps.com//topquestions/{facets_product_id}/{effective_date}`

---
## Environment Configuration

The application supports three environments, automatically selected based on workspace URL:

| Environment | Workspace ID | Database Instance | Agent Endpoint |
|-------------|--------------|-------------------|----------------|
| **Development** | 640321604414221 | db-benefits-ci-cd-test | agents_dev_adb-nexusbenefitsquote_gold_mvp1-mvp1 |
| **QA** | 370726302632140 | benefit-quote-mvp1-db | agents_qa_adb-nexusbenefitsquote_gold_mvp1-mvp1 |
| **Production** | 3693588177658856 | benefit-quote-mvp1-db | agents_prod_adb-nexusbenefitsquote_gold_mvp1-mvp1 |

Configuration is managed in `app.yaml` and automatically loaded at runtime.

---

## API Endpoints

### 1. Agent Chat Endpoint

**POST** `/agent/chat`

Send a benefits query to the AI agent.

**Request Body:**
json { "message": "What is my emergency room copay?", "user_id": "user123", "user_name": "John Doe", "session_id": "session456", "facets_product_id": "PLAN001", "effective_date": "2024-01-01", "question_id": "q789" }


**Response:**
json { "question_id": "q789", "session_id": "session456", "content": "Your emergency room copay is $250 per visit...", "response_id": "resp-uuid" }

### 2. Feedback Submission

**POST** `/feedback/submit`

Submit user feedback on agent responses.

**Request Body:**
json { "response_id": "resp-uuid", "question_id": "q789", "user_id": "user123", "user_name": "John Doe", "feedback_type": "positive", "reason_code": "accurate", "additional_comments": "Very helpful!", "session_id": "session456" }

### 3. Top Questions

**GET** `/topquestions/{facets_product_id}/{effective_date}`

Retrieve top 4 frequently asked questions for a plan.

**Response:**
json { "id": 1, "facets_product_id": "PLAN001", "effective_date": "2024-01-01", "questions": [ {"sequence": 1, "question": "What is my deductible?"}, {"sequence": 2, "question": "What is my copay for primary care?"} ] }


---

## Database Schema

### Tables

#### `master_table`
Tracks plan configuration status for vector database readiness.

| Column | Type | Description |
|--------|------|-------------|
| facets_product_id | VARCHAR | Plan identifier |
| product_effective_date | DATE | Plan effective date |
| vector_db_ready | CHAR(1) | 'Y' if plan is configured |

#### `tbl_benefitsquote_feedback`
Stores user feedback on agent responses.

| Column | Type | Description |
|--------|------|-------------|
| response_id | VARCHAR | Agent response identifier |
| question_id | VARCHAR | Question identifier |
| user_id | VARCHAR | User identifier |
| feedback_type | VARCHAR | positive/negative |
| reason_code | VARCHAR | Feedback reason |
| additional_comments | TEXT | User comments |
| session_id | VARCHAR | Session identifier |
| feedback_response_id | VARCHAR | Unique feedback ID |

#### `plans_questions`
Stores frequently asked questions per plan.

| Column | Type | Description |
|--------|------|-------------|
| questions | JSONB | Array of question objects |

---

## Error Handling

### Common Error Responses

* **400 Bad Request**: Invalid input or plan not configured
* **404 Not Found**: Resource not found (e.g., no top questions)
* **500 Internal Server Error**: Database or model serving errors
* **504 Gateway Timeout**: Model taking too long to respond

### Retry Logic

The agent endpoint implements automatic retry logic:
* **Max retries**: 3 attempts
* **Retry delay**: 20 seconds between attempts
* **Timeout message**: "Model is taking some time to respond. Please try again after 1 minute."

---

## CORS Configuration

All endpoints support CORS with the following settings:
* **Allow Origins**: `*` (all origins)
* **Allow Credentials**: `true`
* **Allow Methods**: All HTTP methods
* **Allow Headers**: All headers

---

## Dependencies

See [requirements.txt](requirements.txt) for full dependency list.

**Key Dependencies:**
* `fastapi` - Web framework
* `uvicorn` - ASGI server
* `gunicorn` - Production server
* `databricks-sdk>=0.60.0` - Databricks integration
* `asyncpg` - Async PostgreSQL driver
* `pydantic` - Data validation

---





## Troubleshooting

### Issue: "Plan is not configured for the query"

**Cause**: The plan's vector database is not ready.

**Solution**: Ensure `vector_db_ready = 'Y'` in `master_table` for the specified `facets_product_id` and `effective_date`.

### Issue: "Model is taking some time to respond"

**Cause**: Model serving endpoint is slow or unavailable.

**Solution**: 
1. Check model serving endpoint status in Databricks
2. Wait 1 minute and retry
3. Contact administrators if issue persists


