from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel
import sys
import json
import os

import uuid
from databricks.sdk import WorkspaceClient
import asyncpg

host_name = os.environ['DATABRICKS_APP_URL']
w = WorkspaceClient()

if '640321604414221' in host_name :
    pg_instance_nme=os.getenv("dev_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_dev")
    }
elif '370726302632140' in host_name :
    pg_instance_nme=os.getenv("qa_prod_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_qa")
    }
else:
    pg_instance_nme=os.getenv("qa_prod_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_prod")
    }	

async def get_asyncpg_connection():
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()),
        instance_names=[config["INSTANCE"]]
    )
    conn = await asyncpg.connect(
        host=config["HOST"],
        port=5432,
        database=config["DBNAME"],
        user=config["USERNAME"],
        password=cred.token,
        ssl="require"
    )
    return conn
topquestions = FastAPI()

class Question(BaseModel):
    sequence: int
    question: str

class TopQuestionsRequest(BaseModel):
    facets_product_id: str
    effective_date: str
    questions: list[Question]

# @topquestions.post("/insert", status_code=status.HTTP_201_CREATED)
# async def insert_questions(req: TopQuestionsRequest):
#     try:
#         conn = await get_asyncpg_connection()
#         await conn.execute(
#             """
#             INSERT INTO top_questions_table (
#                 facets_product_id,
#                 effective_date,
#                 questions
#             ) VALUES ($1, $2, $3)
#             """,
#             req.facets_product_id,
#             req.effective_date,
#             json.dumps([q.dict() for q in req.questions])
#         )
#         await conn.close()
#         return {"status": "success"}
#     except Exception as e:
#         raise HTTPException(
#             status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
#             detail=f"Database error: {str(e)}"
#         )

@topquestions.get("/{facets_product_id}/{effective_date}", status_code=status.HTTP_200_OK)
async def get_top_questions(facets_product_id: str, effective_date: str):
    try:
        planid=facets_product_id
        effective_date=effective_date
        conn = await get_asyncpg_connection()

        #The below code will be utilized when when have questions per line of business available. top_questions_table will hold the plan wise top search question , 
        #It's not needed now , but it'll be required in the future phases
        # row = await conn.fetchrow(
        #     """
        #     SELECT facets_product_id, effective_date, questions
        #     FROM top_questions_table
        #     WHERE facets_product_id = $1 AND effective_date = $2
        #     """,
        #     facets_product_id, effective_date
        # )

        row = await conn.fetchrow(
            """
            select questions from plans_questions limit 1;
            """
        )
        await conn.close()
        if not row:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Not found"
            )
        questions = sorted(json.loads(row['questions']), key=lambda x: x['popularity'])[:4]
        return {
            "id":1,
            "facets_product_id":facets_product_id,
            "effective_date": effective_date,
            "questions": questions
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error: {str(e)}"
        )