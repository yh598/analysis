from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from topquestions.topquestions import topquestions
from feedback.feedback import feedback
from agent.agent import agent


# middleware to the topquestions FastAPI instance
topquestions.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
#middleware to the feedback FastAPI instance
feedback.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

agent.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# This is your main, top-level FastAPI application
app = FastAPI()

app.mount("/topquestions", topquestions)
app.mount("/feedback", feedback)
app.mount("/agent", agent)

@app.get("/")
async def root():
    return {"message": "Databricks App is active"}

