from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import time
from datetime import datetime


from mlflow.deployments import get_deploy_client

import os
import uuid


import sys
import uuid
from databricks.sdk import WorkspaceClient
import asyncpg
import os 

# config = load_config()
w = WorkspaceClient()

host_name = os.environ['DATABRICKS_APP_URL']

if '640321604414221' in host_name :
    pg_instance_nme=os.getenv("dev_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_dev")
    }
elif '370726302632140' in host_name :
    pg_instance_nme=os.getenv("qa_prod_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_qa")
    }
else:
    pg_instance_nme=os.getenv("qa_prod_INSTANCE")
    database_instance_id = w.database.get_database_instance(name=pg_instance_nme).read_write_dns
    config = {
        "INSTANCE": pg_instance_nme,
        "USERNAME": os.environ['DATABRICKS_CLIENT_ID'],
        "DBNAME": os.getenv("DBNAME"),
        "HOST": database_instance_id,
        "agent_name": os.getenv("benefitsagent_prod")
    }	


async def get_asyncpg_connection():
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()),
        instance_names=[config["INSTANCE"]]
    )
    conn = await asyncpg.connect(
        host=config["HOST"],
        port=5432,
        database=config["DBNAME"],
        user=config["USERNAME"],
        password=cred.token,
        ssl="require"
    )
    return conn



client = get_deploy_client("databricks")

agent = FastAPI()

class ChatRequest(BaseModel):
    message: str
    user_id: str
    user_name: str
    session_id: str
    facets_product_id: str
    effective_date: str
    question_id: str

class ChatResponse(BaseModel):
    question_id: str
    session_id: str
    content: str
    response_id: str

class ModelService:
    @staticmethod
    def predict(request: ChatRequest) -> str:
        payload = {
            "input": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": request.message
                        }
                    ]
                }
            ],
            "custom_inputs": {
                "user_id": request.user_id,
                "user_name": request.user_name,
                "session_id": request.session_id,
                "facets_product_id": request.facets_product_id,
                "effective_date": request.effective_date,
                "question_id": request.question_id
            }
        }
        response = client.predict(
            endpoint=config["agent_name"],
            inputs=payload
        )
        assistant_text = None
        try:
            output = response.get("output", [])
            if output and "content" in output[0]:
                response_id=output[0]["id"]
                content_list = output[0]["content"]
                for item in content_list:
                    if item.get("type") == "output_text" and "text" in item:
                        assistant_text = item["text"]
                        break
        except Exception:
            assistant_text = response
        return assistant_text ,response_id
@agent.post("/chat", response_model=ChatResponse, tags=["Prediction"])
async def chat_endpoint(request: ChatRequest):
    """
    Send a message to the Databricks model and receive a response.
    """
    if request is None or not request.message.strip():
        raise HTTPException(
            status_code=400,
            detail="No query received. Please provide a valid message."
        )

    conn = await get_asyncpg_connection()
    row = await conn.fetchrow(
        """
        SELECT 1 FROM master_table
        WHERE vector_db_ready = 'Y'
        AND facets_product_id = $1
        AND product_effective_date = $2
        LIMIT 1
        """,
        request.facets_product_id,
        request.effective_date
    )
    await conn.close()
    if not row:
        raise HTTPException(
            status_code=400,
            detail="Plan is not configured for the query.For More details connect with the Admins"
        )    
    # Insert initial log with insert_ts//added by sg
    insert_ts = datetime.utcnow()
    conn = await get_asyncpg_connection()
    log_id = await conn.fetchval(
        """
        INSERT INTO tbl_agent_api_logs (question_id, insert_ts)
        VALUES ($1, $2)
        RETURNING ctid
        """,
        request.question_id,
        insert_ts
    )
    await conn.close()

    try:
        max_retries = 3
        retries = 0
        result = None
        #added by sg
        start_time = time.time()        
        while retries < max_retries:
            result, response_id = ModelService.predict(request)
            if result:
                break
            time.sleep(20)
            retries += 1   
        #added by sg
        end_time = time.time()
        response_status = "success" if result else "fail" 
        response_time_sec = int(end_time - start_time)
        # Update log with response_status and response_time
        conn = await get_asyncpg_connection()
        await conn.execute(
            """
            UPDATE tbl_agent_api_logs
            SET response_status = $1, 
            response_time_sec = $2
            WHERE ctid = $3
            """,
            response_status,
            response_time_sec,
            log_id
        )
        await conn.close()                   
        if not result:
            raise HTTPException(
                status_code=504,
                detail="Model is taking some time to respond.Please try again after 1 minute."
            )
        return ChatResponse(
            question_id=request.question_id,
            session_id=request.session_id,
            response_id=response_id,
            content=result
        )
    except Exception as e:
        # Optionally update log with failure status here as well//added by sg
        conn = await get_asyncpg_connection()
        await conn.execute(
            """
            UPDATE tbl_agent_api_logs
            SET response_status = $1, response_time_sec = $2
            WHERE ctid = $3
            """,
            "fail",
            None,
            log_id
        )
        await conn.close()        
        raise HTTPException(status_code=500, detail=str(e))