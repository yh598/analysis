

import sys
import os
import json
import yaml
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct
from databricks.vector_search.client import VectorSearchClient
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
)
from uuid import uuid4
from mlflow.pyfunc import ResponsesAgent



template_json={
  "PPO": {
  
    "PPO_IN: Subject to Deductible & Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Coinsurance' and subjectToDeductible=='true'",
      "Description Explicit": "Deductible applies • Coinsurance applies after deductible • No copay.",
      "Description": "Member pays the deductible first, then a coinsurance percentage until the out-of-pocket maximum is reached.",
      
	  "scripting": {
        "In Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. After the deductible has been met, the coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },"PPO_Out: Subject to Deductible & Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' AND structureType == 'Coinsurance' AND subjectToDeductible=='true'",
      "Description Explicit": "Deductible applies • Coinsurance applies after deductible  • No copay.",
      "Description": "Member pays the deductible first, then a coinsurance percentage until the out-of-pocket maximum is reached.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. After the deductible has been met, the coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  ."
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Subject to Deductible & Copay": {
      "guardrail": "Choose this template ONLY if  provider_type=='Participating Provider' and structureType == 'Copay' AND subjectToDeductible=='true'",
      "Description Explicit": "Deductible applies • Copay applies after deductible",
      "Description": "Member pays the deductible first, then a flat copay for the service until the out-of-pocket maximum is reached.",
     
	  "scripting": {
        "In Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. After the deductible is met, your copay for [service] is [$X] and applies to your copayment maximum of [$X], not to exceed [$X] per family. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Subject to Deductible & Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Copay' AND subjectToDeductible=='true'",
      "Description Explicit": "Deductible applies • Copay applies after deductible",
      "Description": "Member pays the deductible first, then a flat copay for the service until the out-of-pocket maximum is reached.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. After the deductible is met, your copay for [service] is [$X] and applies to your copayment maximum of [$X], not to exceed [$X] per family. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Subject to Deductible, No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and subjectToDeductible=='true' and structureType == 'No Charge'",
      "Description Explicit": "Deductible applies • After deductible, plan pays 100% • No coinsurance or copay.",
      "Description": "Member pays toward the deductible, then nothing further for the covered service.",
      
	  "scripting": {
        "In Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. Once the deductible has been met, BSC will reimburse your provider 100% of the allowed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Subject to Deductible, No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and subjectToDeductible=='true' and structureType == 'No Charge'",
      "Description Explicit": "Deductible applies • After deductible, plan pays 100% • No coinsurance or copay.",
      "Description": "Member pays toward the deductible, then nothing further for the covered service.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. Once the deductible has been met, BSC will reimburse you 100% of the allowed amount.\n\n*Your out-of-network provider has the right to balance bill. What this means to you is you may be responsible for the difference between the allowed amount and billed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Not Subject to Deductible;Plan deductible is not zero; Subject to  Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Coinsurance' and subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is not zero •Coinsurance applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
     
	  "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is not zero Subject to  Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Coinsurance' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is not zero• Coinsurance applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible.The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
	 "PPO_IN: Not Subject to Deductible;Plan deductible is zero; Subject to  Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Coinsurance' and subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is zero •Coinsurance applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
     
	  "scripting": {
        "In Network Provider Scripting": "The plan does not have deductible.The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is zero; Subject to  Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Coinsurance' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is  zero• Coinsurance applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "The plan does not have deductible.The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Not Subject to Deductible;Plan deductible is not zero; Subject to Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Copay' and subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is not zero •Copay applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a flat copay for the service;",
    
	  "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. The copay for [service] is [$X].{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is not zero ;Subject to Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Copay' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is not zero • Copay applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a flat copay for the service;",
  
	  "scripting": {
        "Out of Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. The copay for [service] is [$X].{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
	"PPO_IN: Not Subject to Deductible;Plan deductible is zero; Subject to Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Copay' and subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is zero •Copay applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a flat copay for the service;",
    
	  "scripting": {
        "In Network Provider Scripting": "The plan does not have a deductible.The copay for [service] is [$X].{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is zero ;Subject to Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Copay' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is zero • Copay applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a flat copay for the service;",
  
	  "scripting": {
        "Out of Network Provider Scripting": "The plan does not have a deductible.The copay for [service] is [$X].{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Not Subject to Deductible;Plan deductible is not zero;No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'No Charge' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible •Plan deductible is not zero •No oopm •Plan pays 100% • No coinsurance and No copay.",
      "Description": "Service is covered at 100% when using an in-network provider; member owes $0.",
    
	  "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. Blue Shield will reimburse the provider 100% of the allowed amount.[Any additional maximum plan payment/allowance (defined by bscMaxText)]. "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is not zero ;No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'No Charge' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible •Plan deductible is not zero • No oopm •Plan pays 100% • No coinsurance or copay.",
      "Description": "Service is covered at 100% when using an in-network provider; member owes $0.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. Blue Shield will reimburse the provider 100% of the allowed amount. "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
	"PPO_IN: Not Subject to Deductible;Plan deductible is zero;No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'No Charge' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible •Plan deductible is zero •No oopm •Plan pays 100% • No coinsurance and No copay.",
      "Description": "Service is covered at 100% when using an in-network provider; member owes $0.",
    
	  "scripting": {
        "In Network Provider Scripting": "The plan does not have a deductible.Blue Shield will reimburse the provider 100% of the allowed amount.[Any additional maximum plan payment/allowance (defined by bscMaxText)]. "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is zero ;No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'No Charge' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible •Plan deductible is zero • No oopm •Plan pays 100% • No coinsurance or copay.",
      "Description": "Service is covered at 100% when using an in-network provider; member owes $0.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "The plan does not have a deductible.Blue Shield will reimburse the provider 100% of the allowed amount. "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: NAB or General Exclusion": {
      "guardrail": "Choose this template ONLY if structureType == 'Not Covered' OR costShareText contains 'Not Covered' (case-insensitive).",
      "Description Explicit": "[NOT-COVERED] Service is NOT covered • Plan pays 0% • Member pays 100% • Deductible, copay, coinsurance, and OOPM do NOT apply.",
      "Description": "This service is excluded from the plan. You would pay the full billed amount.",
      "scripting": {
        "In Network Provider Scripting": "The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount."
      }
    },
    "PPO_Out: NAB or General Exclusion": {
      "guardrail": "Choose this template ONLY if structureType == 'Not Covered' OR costShareText contains 'Not Covered' (case-insensitive).",
      "Description Explicit": "[NOT-COVERED] Service is NOT covered • Plan pays 0% • Member pays 100% • Deductible, copay, coinsurance, and OOPM do NOT apply.",
      "Description": "This service is excluded from the plan. You would pay the full billed amount.",
      "scripting": {
        "Out of Network Provider Scripting": "The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount."
      }
    },
    "PPO_IN: Not Covered through OON/OOS Provider": {
      "Description Explicit": "Service is only covered in-network • Out-of-network benefit is 0%.",
      "Description": "Member must use in-network or affiliate providers; otherwise responsible for full billed amount.",
      "scripting": {
        "In Network Provider Scripting": "- [Any additional maximum plan payment/allowance (defined by bscMaxText)]. "
      }
    },
    "PPO_Out: Not Covered through OON/OOS Provider": {
      "Description Explicit": "Service is only covered in-network • Out-of-network benefit is 0%.",
      "Description": "Member must use in-network or affiliate providers; otherwise responsible for full billed amount.",
      "scripting": {
        "Out of Network Provider Scripting": "You must seek services from either an in-network provider or a provider associated with your provider group to be eligible for benefits. As the member, this means you are responsible for 100% of the billed amount. [Any additional maximum plan payment/allowance (defined by bscMaxText)]. "
      }
    },
   
    "SpecialCases": {
      "Emergency": {
        "guardrail": "benefitHeader ILIKE '%emergency%' OR placeOfService IN ('Emergency Room','Emergency Department') OR emergencyMedicalCondition == true",
        "Description Explicit": "Emergency services are covered at the in-network cost share even if treated by a non-participating provider, until the member is stabilized.",
        "Description": "Emergency care is treated as in-network. If admitted to an out-of-network hospital, in-network benefits apply until stabilized and transferable.",
        "scripting": {
          "Member Scripting": "Emergency services are covered at your in-network cost share even if the hospital or provider is out-of-network. If you are admitted to an out-of-network facility, the in-network benefit applies until your condition stabilizes and you can be safely transferred to an in-network facility. Balance billing protections may apply per state/federal law."
        }
      },
      "Acupuncture / Chiropractic / Therapeutic Massage": {
        "guardrail": "service IN ('Acupuncture','Chiropractic','Therapeutic Massage')",
        "Description Explicit": "Discount program available via ChooseHealthy (American Specialty Health Group).",
        "Description": "Members can access discounted rates through ChooseHealthy providers.",
        "scripting": {
          "Member Scripting": "Discounts for service are available through the ChooseHealthy program provided by American Specialty Health Group. Visit https://www.blueshieldca.com/en/home/be-well/live-healthy to find a participating provider and see what’s included."
        }
      },
      "Annual Physical (PPO)": {
        "guardrail": "benefitHeader ILIKE '%annual physical%' OR benefitCategory ILIKE '%preventive%'",
        "Description Explicit": "One annual physical per calendar year.",
        "Description": "PPO members are eligible for one annual physical each calendar year.",
        "scripting": {
          "Member Scripting": "Your plan allows one annual physical per calendar year when using an in-network provider."
        }
      },
      "Inpatient Facility / Hospital": {
        "guardrail": "placeOfService IN ('Inpatient Hospital','Acute Care Hospital')",
        "Description Explicit": "Admission notification required; related professional fees billed separately.",
        "Description": "Hospitals must contact MCS after admission. Expect separate bills for professional services.",
        "scripting": {
          "Provider Scripting": "The facility must contact Medical Care Solutions (MCS) within 5 days of a scheduled admission or within 24 hours of an emergent admission at 1 (800) 541-6652 (say \"Authorizations\"). In addition to the hospital bill, members may receive separate professional bills for surgery, anesthesia, radiology, pathology, or laboratory services."
        }
      },
      "Outpatient Facility / Hospital": {
        "guardrail": "placeOfService IN ('Outpatient Hospital','Ambulatory Surgery Center')",
        "Description Explicit": "Related professional fees billed separately.",
        "Description": "Expect separate bills for anesthesia and diagnostic services.",
        "scripting": {
          "Member Scripting": "Besides the facility bill, you may also see separate professional charges for services such as anesthesia and diagnostic testing (radiology or laboratory)."
        }
      },
      "Physical Therapy (PPO self-referral rule)": {
        "guardrail": "planType == 'PPO' AND service == 'Physical Therapy'",
        "Description Explicit": "Self-referral PT allowed for 45 days or 12 visits (whichever comes first) under specific circumstances.",
        "Description": "PPO members may start PT without prior physician exam within limits.",
        "scripting": {
          "Member Scripting": "A physical therapist can treat a self-referred PPO member for 45 calendar days or 12 visits, whichever comes first, when requirements are met."
        }
      },
      "Physical Therapy (All members)": {
        "guardrail": "service == 'Physical Therapy'",
        "Description Explicit": "PT programs available via Blue Shield of California.",
        "Description": "Members can access PT programs and resources.",
        "scripting": {
          "Member Scripting": "Blue Shield of California offers physical therapy programs. See details at https://www.blueshieldca.com/en/home/be-well/live-healthy."
        }
      },
      "Surgery": {
        "guardrail": "benefitCategory ILIKE '%surgery%' OR service ILIKE '%surgery%'",
        "Description Explicit": "Surgical package includes pre-op, day-of medical visits, and routine post-op care.",
        "Description": "Separate anesthesia/diagnostic fees may apply.",
        "scripting": {
          "Member Scripting": "In addition to the surgeon’s bill, you may see separate fees for anesthesia and diagnostic testing. A standard surgical package includes the procedure, pre-operative care, same-day medical visits, and routine uncomplicated follow-up."
        }
      },
      "Urgent Care (PPO)": {
        "guardrail": "benefitCategory ILIKE '%urgent care%' AND planType == 'PPO'",
        "Description Explicit": "Separate professional/diagnostic fees may apply.",
        "Description": "Expect charges for radiology or lab services in addition to the urgent care bill.",
        "scripting": {
          "Member Scripting": "In addition to the urgent care center bill, you may receive separate charges for diagnostic services like radiology or laboratory."
        }
      },
      "Hearing Aids (Discount Program)": {
        "guardrail": "benefitCategory ILIKE '%hearing%' OR service ILIKE '%hearing aid%'",
        "Description Explicit": "Discount program via EPIC Hearing Healthcare.",
        "Description": "Members can access hearing aid discounts.",
        "scripting": {
          "Member Scripting": "A discount program is available through EPIC Hearing Healthcare. Learn more at https://www.blueshieldca.com/en/home/be-well/live-healthy/hearing-aid-discount."
        }
      },
      "Fitness / Gym / Exercise": {
        "guardrail": "benefitCategory ILIKE '%fitness%' OR service ILIKE '%gym%'",
        "Description Explicit": "Gym and digital fitness discounts available.",
        "Description": "Members can access fitness discount programs.",
        "scripting": {
          "Member Scripting": "Blue Shield of California offers gym membership discounts and digital fitness programs. See https://www.blueshieldca.com/en/home/be-well/live-healthy."
        }
      },
      "Vision (Vendor present)": {
        "guardrail": "visionVendor IS NOT NULL",
        "Description Explicit": "Vision benefits administered by a third-party administrator.",
        "Description": "Contact the administrator for details, coverage, and providers.",
        "scripting": {
          "Member Scripting": "This member’s [benefit type] benefits are administered by [administrator]. Let me give you their toll-free number."
        }
      },
      "Vision (All members)": {
        "guardrail": "benefitCategory ILIKE '%vision%'",
        "Description Explicit": "Discount vision program available to members.",
        "Description": "Members can access discounted vision services.",
        "scripting": {
          "Member Scripting": "A discount vision program is available to Blue Shield members. Learn more at https://www.blueshieldca.com/en/home/be-well/live-healthy."
        }
      },
      "Pharmacy (Tiering & OOP only)": {
        "guardrail": "benefitCategory ILIKE '%pharmacy%' OR benefitCategory ILIKE '%drug%'",
        "Description Explicit": "Show tiered pharmacy benefits and pharmacy-specific OOP information.",
        "Description": "Include tier information (Preferred/Non-Preferred/Generic/Specialty) and any pharmacy OOP caps.",
        "scripting": {
          "Member Scripting": "Your pharmacy benefits vary by tier (e.g., Generic, Preferred Brand, Non-Preferred Brand, Specialty). [Display member cost share per tier and any pharmacy-specific out-of-pocket maximum or caps.]"
        }
      },
      "Dental (Vendor present)": {
        "guardrail": "dentalVendor IS NOT NULL",
        "Description Explicit": "Dental benefits administered by a third-party administrator.",
        "Description": "Contact the administrator for coverage details and providers.",
        "scripting": {
          "Member Scripting": "This member’s [benefit type] benefits are administered by [administrator]. Let me give you their toll-free number."
        }
      }
    }
  },
  
  "HMO": {
 
    "HMO: Subject to Deductible &  Coinsurance": {
      "Description Explicit": "Deductible applies • Coinsurance applies after deductible • Out-of-Pocket Maximum applies • HMO covers in-network only.",
      "Description": "Member pays the deductible first and then a coinsurance percentage for in-network services until the out-of-pocket maximum is reached.",

      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family.After the deductible has been met, the coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, your responsibility is 100% of the provider's billed amount, as your plan only covers in-network providers."
      },
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },

    "HMO: Subject to Deductible &  Copay": {
      "Description Explicit": "Deductible applies • Copay applies after deductible • Out-of-Pocket Maximum applies • HMO covers in-network only.",
      "Description": "Member pays the deductible first and then a flat copay for the service.",
      
  
      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family.After the deductible is met, your copay for [service] is [$X] and applies to your copayment maximum of [$X], not to exceed [$X] per family. {{OOPM_LINE}} {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, your responsibility is 100% of the provider's billed amount, as your plan only covers in-network providers."
      }
      ,
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    
    },

    "HMO: Not Subject to Deductible ; plan deductible is not zero; Subject to  Coinsurance": {
      "Description Explicit": "No deductible for service•Deductible not zero • Coinsurance applies • Out-of-Pocket Maximum applies • HMO covers in-network only.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
      
      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family However,service is not subject to the deductible.The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, your responsibility is 100% of the provider's billed amount, as your plan only covers in-network providers."
      },
      
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },

      "HMO: Not Subject to Deductible ;plan deductible is  zero; Subject to  Coinsurance": {
      "Description Explicit": "No deductible for service•Deductible is zero • Coinsurance applies • Out-of-Pocket Maximum applies • HMO covers in-network only.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
      
      "scripting": {
        "In Network Provider Scripting": "The plan does not have a deductible.The coinsurance is [%X] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, your responsibility is 100% of the provider's billed amount, as your plan only covers in-network providers."
      },
      
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },
    "HMO: Not Subject to Deductible ; plan Deductible is not zero; Subject to Copay": {
        "Description Explicit": "No deductible applies for service/benefit •plan deductible is not zero • Copay applies • HMO covers in-network only.",
      "Description": "Member pays a flat copay for the service; amounts count toward the out-of-pocket maximum.",
      
      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family However, service is not subject to the deductible. The copay for [service] is [$X].[% OOPM_LINE] {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, your responsibility is 100% of the provider's billed amount, as your plan only covers in-network providers."
      },
      
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },
	  "HMO: Not Subject to Deductible ;plan Deductible is  zero; Subject to Copay": {
        "Description Explicit": "No deductible applies for service/benefit •plan deductible is  zero • Copay applies • HMO covers in-network only.",
      "Description": "Member pays a flat copay for the service; amounts count toward the out-of-pocket maximum.",
      
      "scripting": {
        "In Network Provider Scripting": "The plan does not have a deductible. The copay for [service] is [$X].[% OOPM_LINE] {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, your responsibility is 100% of the provider's billed amount, as your plan only covers in-network providers."
      },
      
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },


    "HMO: Not Subject to Deductible ;Plan deductible is not zero; No Patient Liability": {
      "guardrail": "Choose this template ONLY if if structureType == 'No Charge' AND subjectToDeductible=='false' AND plan deductible is not zero",
      "Description Explicit": "No plan deductible •Plan deductible is not zero • No Charge• HMO covers in-network only.",
      "Description": "Member owes $0 for the covered service when using an in-network provider.",
       
           
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  },
      "scripting": {
        "In Network Provider Scripting":"The plan has a [$X] deductible per person, not to exceed [$X] per family However, service is not subject to the deductible. Blue Shield will reimburse the provider 100% of the allowed amount.[% oopm_line] ",
        "Out of Network Provider Scripting": "For out-of-network providers, your responsibility is 100% of the provider's billed amount, as your plan only covers in-network providers."
      }
      
 
    },
	   "HMO: Not Subject to Deductible ; plan deductible is  zero; No Patient Liability": {
        "guardrail": "Choose this template ONLY if if structureType == 'No Charge' AND subjectToDeductible=='false' AND deductible is  zero",
      "Description Explicit": "No plan deductible •plan deductible is  zero •No Charge • HMO covers in-network only.",
      "Description": "Member owes $0 for the covered service when using an in-network provider.",
       
           
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  },
      "scripting": {
        "In Network Provider Scripting":"The plan does not have a deductible. Blue Shield will reimburse the provider 100% of the allowed amount.[% oopm_line] ",
        "Out of Network Provider Scripting": "For out-of-network providers, your responsibility is 100% of the provider's billed amount, as your plan only covers in-network providers."
      }
      
 
    },

    "HMO: NAB or General Exclusion; plan deductible is not zero;": {
      "guardrail":"plan deductible is not zero;Choose this template ONLY if structureType == 'Not Covered' OR costShareText contains 'Not Covered",

    "Description Explicit":
      "[NOT-COVERED] Service is NOT covered • Plan pays 0% • Member pays 100% • "
      "Deductible, copay, coinsurance, and OOPM do NOT apply.",

  "Description":
    "This service is excluded from the plan. You would pay the full billed amount.",
      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family However, service is not subject to the deductible.The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount.",
        "Out of Network Provider Scripting": "The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount."
      }
    },
    "HMO: NAB or General Exclusion; plan deductible is  zero;": {
      "guardrail":"plan deductible is  zero;Choose this template ONLY if structureType == 'Not Covered' OR costShareText contains 'Not Covered",

    "Description Explicit":
      "[NOT-COVERED] Service is NOT covered • Plan pays 0% • Member pays 100% • "
      "Deductible, copay, coinsurance, and OOPM do NOT apply.",

  "Description":
    "This service is excluded from the plan. You would pay the full billed amount.",
      "scripting": {
        "In Network Provider Scripting": "The plan does not have deductible.The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount.",
        "Out of Network Provider Scripting": "The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount."
      }
    },

    "HMO: Not Covered through OON/OOS Provider": {
      "Description Explicit": "Service must be obtained from an in-network or aligned provider • Out-of-network benefit is 0%.",
      "Description": "Member is responsible for the full billed amount if services are obtained out-of-network.",
      "scripting": {
        "In Network Provider Scripting": "- [Any additional maximum plan payment/allowance (defined by bscMaxText)]. ",
        "Out of Network Provider Scripting": "You must seek services from either an in-network provider or a provider associated with your provider group to be eligible for benefits. As the member, this means you are responsible for 100% of the billed amount."
      }
    },
  "SpecialCases": {
    "Emergency": {
      "guardrail": "service IN ('Emergency','Emergency room','Emergency services')",
      "Description Explicit": "Emergency services are covered at the in-network cost share even if treated by a non-participating provider, until stabilized.",
      "Description": "Emergency care is treated as in-network. If admitted to an out-of-network hospital, in-network benefits apply until stabilized and transferable.",
      "scripting": {
        "Member Scripting": "Emergency services are covered at your in-network cost share even if the hospital or provider is out-of-network. If admitted out-of-network, in-network benefits apply until you are stabilized and can be moved to an in-network facility. Check balance-billing protections per state/federal law."
      }
    },
    "Acupuncture / Chiropractic / Therapeutic Massage": {
      "guardrail": "service IN ('Acupuncture','Chiropractic','Therapeutic Massage')",
      "Description Explicit": "Discount program available via ChooseHealthy (American Specialty Health Group).",
      "Description": "Members can access discounted rates through ChooseHealthy providers.",
      "scripting": {
        "Member Scripting": "Discounts for service are available through the ChooseHealthy program provided by American Specialty Health Group. Visit https://www.blueshieldca.com/en/home/be-well/live-healthy to find a participating provider and what’s included."
      }
    },
    "Annual Physical (HMO)": {
      "guardrail": "benefitHeader ILIKE '%annual physical%' OR benefitCategory ILIKE '%preventive%'",
      "Description Explicit": "Medical group/IPA may apply a rolling 12-month schedule for routine physicals.",
      "Description": "HMO routine physicals may be on a rolling 12-month basis set by the medical group/IPA.",
      "scripting": {
        "Member Scripting": "Your medical group or IPA may limit routine physical exams using a rolling 12-month schedule. Check with your PCP/IPA for exact timing."
      }
    },
    "Inpatient Facility / Hospital": {
      "guardrail": "placeOfService IN ('Inpatient Hospital','Acute Care Hospital')",
      "Description Explicit": "Admission notification required; related professional fees billed separately.",
      "Description": "Hospitals must contact MCS after admission. Expect separate bills for professional services.",
      "scripting": {
        "Provider Scripting": "The facility must contact Medical Care Solutions (MCS) within 5 days of a scheduled admission or within 24 hours of an emergent admission at 1 (800) 541-6652 (say “Authorizations”). In addition to the hospital bill, members may receive separate professional bills for surgery, anesthesia, radiology, pathology, or laboratory services."
      }
    },
    "Outpatient Facility / Hospital": {
      "guardrail": "placeOfService IN ('Outpatient Hospital','Ambulatory Surgery Center')",
      "Description Explicit": "Related professional fees billed separately.",
      "Description": "Expect separate anesthesia/diagnostic fees.",
      "scripting": {
        "Member Scripting": "Besides the facility bill, you may also see separate professional charges for anesthesia and diagnostic testing (radiology or laboratory)."
      }
    },
    "Physical Therapy (All members)": {
      "guardrail": "service == 'Physical Therapy'",
      "Description Explicit": "PT programs available via Blue Shield of California.",
      "Description": "Members can access PT programs and resources.",
      "scripting": {
        "Member Scripting": "Blue Shield of California offers physical therapy programs. See details at https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Surgery": {
      "guardrail": "benefitCategory ILIKE '%surgery%' OR service ILIKE '%surgery%'",
      "Description Explicit": "Surgical package includes pre-op, day-of medical visits, and routine post-op care.",
      "Description": "Separate anesthesia/diagnostic fees may apply.",
      "scripting": {
        "Member Scripting": "In addition to the surgeon’s bill, you may see separate fees for anesthesia and diagnostic testing. A standard surgical package includes the procedure, pre-operative care, same-day medical visits, and routine uncomplicated follow-up."
      }
    },
    "Urgent Care (HMO)": {
      "guardrail": "benefitCategory ILIKE '%urgent care%' AND planType == 'HMO'",
      "Description Explicit": "Check PCP/IPA or Medical Group for in-network urgent care clinics within service area.",
      "Description": "HMO members should verify in-network urgent care locations with PCP/IPA/MG.",
      "scripting": {
        "Member Scripting": "If you need to visit an urgent care center and you are in your Medical Group Service Area, go to the urgent care center designated by your Medical Group or call your PCP. If you are outside of your Medical Group Service Area but within California and need urgent care, you may visit any urgent care center near you."
      }
    },
    "Hearing Aids (Discount Program)": {
      "guardrail": "benefitCategory ILIKE '%hearing%' OR service ILIKE '%hearing aid%'",
      "Description Explicit": "Discount program via EPIC Hearing Healthcare.",
      "Description": "Members can access hearing aid discounts.",
      "scripting": {
        "Member Scripting": "A discount program is available through EPIC Hearing Healthcare. Learn more at https://www.blueshieldca.com/en/home/be-well/live-healthy/hearing-aid-discount."
      }
    },
    "Fitness / Gym / Exercise": {
      "guardrail": "benefitCategory ILIKE '%fitness%' OR service ILIKE '%gym%'",
      "Description Explicit": "Gym and digital fitness discounts available.",
      "Description": "Members can access fitness discount programs.",
      "scripting": {
        "Member Scripting": "Blue Shield of California offers gym membership discounts and digital fitness programs. See https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Vision (Vendor present)": {
      "guardrail": "visionVendor IS NOT NULL",
      "Description Explicit": "Vision benefits administered by a third-party administrator.",
      "Description": "Contact the administrator for details, coverage, and providers.",
      "scripting": {
        "Member Scripting": "This member’s [benefit type] benefits are administered by [administrator]. Let me give you their toll-free number."
      }
    },
    "Vision (All members)": {
      "guardrail": "benefitCategory ILIKE '%vision%'",
      "Description Explicit": "Discount vision program available to members.",
      "Description": "Members can access discounted vision services.",
      "scripting": {
        "Member Scripting": "A discount vision program is available to Blue Shield members. Learn more at https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Pharmacy (Tiering & OOP only)": {
      "guardrail": "benefitCategory ILIKE '%pharmacy%' OR benefitCategory ILIKE '%drug%'",
      "Description Explicit": "Show tiered pharmacy benefits and pharmacy-specific OOP information.",
      "Description": "Include tier information (Preferred/Non-Preferred/Generic/Specialty) and any pharmacy OOP caps.",
      "scripting": {
        "Member Scripting": "Your pharmacy benefits vary by tier (e.g., Generic, Preferred Brand, Non-Preferred Brand, Specialty). [Display member cost share per tier and any pharmacy-specific out-of-pocket maximum or caps.]"
      }
    },
    "Dental (Vendor present)": {
      "guardrail": "dentalVendor IS NOT NULL",
      "Description Explicit": "Dental benefits administered by a third-party administrator.",
      "Description": "Contact the administrator for coverage details and providers.",
      "scripting": {
        "Member Scripting": "This member’s [benefit type] benefits are administered by [administrator]. Let me give you their toll-free number."
      }
    }
  }
}
}



generic_template={"PPO":"The patient must receive services from either an in-network provider or a provider associated with their medical group to be eligible for benefits.","HMO":"The patient must receive services from either an in-network provider or a provider associated with their medical group to be eligible for benefits. A referral from the patient's primary care physician (PCP)  is usually required when the patient wants to see a specialist or other provider, but there are some exceptions."}



def generate_prompt(question, plan_type, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Handling (Highest Priority):
  Before applying any template or cost-share logic, intelligently analyze the exclusion list to determine whether the question or benefit/service is fully excluded or only partially excluded under certain conditions.
  Consider overlapping or conditional cases also.
  If the service is determined to be fully excluded, respond exactly:
    “The service you are requesting is an exclusion under your current policy.”
  If the service is partially excluded or conditionally covered, clarify the covered portion using the standard template rules defined below and mention the exclusion condition briefly.

If not excluded, continue with the standard template-based generation.
1. Answer only the specific user query. Do not include assumptions or external information.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.
4. Use clear, simple language suitable for users with no technical background.
5. If the query involves multiple service types or settings e.g., (standalone vs. hospital),(outpatient radiology center vs outpatient department of hospital) or facility vs. physician, write a separate breakdown for Participating and Non-Participating providers.
6. For each service setting, provide a separate section.e.g., (freestanding vs. hospital urgent care),(outpatient radiology center vs outpatient department of hospital))
7.Analyze the question intelligently and answer it. 
8.Do not collapse or omit variants that share the same broad category.  
  – If several distinct “flavors” of the benefit exist (e.g., standard vs. non-standard contact lenses, elective vs. medically-necessary lenses, fitting vs. supply, professional vs. facility, hospital vs. freestanding), treat each as its own **separate section** in the response.  
  – Use the exact wording from `benefit_header` or `description` to craft clear section titles, so the user can see every covered option.  
  – Letter the sections A., B., C.… in the order they appear in the data.  
  – **Never stop after the first matching benefit** if additional variants remain in the same data block.
9.Always follow the template while answering.
10.Referral rule: If the benefit/service is any of the following, append the exact line below at the end of the **In-network Provider** text and omit it otherwise:
   – Emergency Services
   – Urgent Services
   – Trio visits
   – OB/GYN services by an obstetrician, gynecologist, or family practice Physician within the patient’s Medical Group
   – Office visits with the patient’s primary care physician (PCP)
   – Outpatient Mental Health and Substance Use Disorder services with an MHSA Participating Provider.
        Exact line to append (no changes):
        “The patient does not need a referral for this service."
  Do not include this line if the benefit/service is a Specialist Visit/Second opinion generalist.
11.Always Strictly fill deductible placeholders . **Do not leave [$X] deductible visible**.
12.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < >), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.


</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure:

A. [Service Setting] (e.g., Hospital-Based Urgent Care)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM) and any additional information]

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM) and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

B. [Service Setting] (e.g., Services Outside Your Physician’s Service Area)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM) and any additional information]

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM) and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

At the very end, add the content from special cases and include only those entries from SpecialCases whose guardrails match the current query/context; if none match, omit this section.Do not print the title “Special Cases (if applicable)” — just append the matching special case text naturally at the end of the answer.
Only plain text / Markdown. No JSON, no placeholders.
</RESPONSE FORMAT>
"""






from typing import TypedDict, Dict
from typing import Annotated
from langchain.tools import BaseTool
from typing import Union
from collections import defaultdict
import json
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_core.messages import HumanMessage, AIMessage
from databricks_langchain import ChatDatabricks
import re
from dataclasses import asdict
from pydantic import BaseModel, Field
from langchain.tools import StructuredTool
from langchain_community.chat_models import ChatDatabricks
from typing import ClassVar, Type, List, Dict, Any
import mlflow


from typing import ClassVar, Type, List
from pydantic import BaseModel, Field
import json, ast, re

# --- Args schema ---
class ClassifyIntentArgs(BaseModel):
    input: str = Field(..., description="Original user question")

# --- Known intents (exact, case-sensitive as emitted by the prompt) ---
KNOWN_INTENTS = {
    "PlanCostShares",
    "BenefitCostShares",
    "EoCCategory",
    "EoCSection",
    "ProgramCategories",
    "GenericDefinition",
    "Exclusions",
}

def _coerce_json(text: str) -> dict:
    """
    Try JSON first; if that fails, try Python-literal (for when a model returns a Python dict).
    """
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        # Remove common accidental code fences
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
        try:
            return json.loads(text)
        except Exception:
            try:
                return ast.literal_eval(text)
            except Exception as e:
                raise ValueError(f"Unable to parse model output as JSON/dict: {e}\nRAW:\n{text[:500]}")

def _normalize_intents(raw_intent) -> List[str]:
    """
    Accepts a string (single or comma-separated) or a list. Returns a cleaned list filtered to KNOWN_INTENTS.
    """
    if raw_intent is None:
        return []
    if isinstance(raw_intent, str):
        parts = [p.strip() for p in raw_intent.split(",") if p.strip()]
    elif isinstance(raw_intent, list):
        parts = [str(p).strip() for p in raw_intent if str(p).strip()]
    else:
        parts = [str(raw_intent).strip()]
    # Keep only valid intents, preserve original case if matches known set (case-insensitive match allowed)
    normalized = []
    for p in parts:
        # exact match first
        if p in KNOWN_INTENTS:
            normalized.append(p)
            continue
        # case-insensitive match
        for ki in KNOWN_INTENTS:
            if p.lower() == ki.lower():
                normalized.append(ki)
                break
    # de-dup while preserving order
    seen = set()
    out = []
    for i in normalized:
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out

class ClassifyIntentTool(StructuredTool):
    name: ClassVar[str] = "ClassifyIntent"
    description: ClassVar[str] = (
        "Classifies a user question and expands known terms. Returns ExpandedQuestion, FollowUp, and Intent(s)."
    )
    args_schema: ClassVar[Type[BaseModel]] = ClassifyIntentArgs

    @mlflow.trace(name="ClassifyIntent_run", span_type="tool")
    def _run(self, input: str) -> dict:
        # Prompt: force strict JSON with fixed keys
        prompt = f"""
You are an insurance intent classification agent designed to identify the type of user question about a health insurance plan and expand common abbreviations/aliases to canonical benefit names for clarity.

STRICT OUTPUT INSTRUCTIONS:
- Respond with a single JSON object only (no prose, no code fences).
- Keys must be exactly: "ExpandedQuestion", "FollowUp", "Intent".
- "Intent" MUST be either a JSON array of strings or a single string. (Array is preferred.)
- "FollowUp" MUST be "Yes" or "No".

STEP 0: NORMALIZE & EXPAND TERMS (do this first)
Expand known abbreviations at their first occurrence using parentheses (append only; do not change original words).
Case-insensitive. Expand each unique term only once.
Canonical map:
- PCP -> Primary Care Physician
- Infertility -> Infertility - Assisted Reproductive Benefits

Examples:
"what is my cost share of PCP" -> "what is my cost share of Primary Care Physician"
"am I covered for infertility treatments?" -> "am I covered for infertility - Assisted Reproductive Benefits treatments?"

If no terms match, ExpandedQuestion must equal the original input verbatim.

STEP 1: DETERMINE IF THIS IS A FOLLOW-UP
A follow-up depends on prior context, continues an earlier topic, or would be confusing alone.
Return "Yes" or "No".

STEP 2: CLASSIFY THE INTENT(S) (return one or more)
A single question may contain multiple intents.  
Return one or more intents separated by commas.  
Never invent new ones. Always return at least one.
Available intents:
1. PlanCostShares  
→ Plan-level cost details.  
Includes deductible (per person/family), out-of-pocket maximum, accumulator type, HSA eligibility, INN/OON deductible, or plan-level coinsurance.  
Keywords: deductible, OOP max, accumulator, embedded, aggregate, HSA, plan type.  
Examples:  
- “What is the deductible for this plan?”  
- “Is this plan HSA-eligible?”
2. BenefitCostShares  
→ Service-level cost sharing (specific copay or coinsurance).  
Includes ER copay, per-visit copay, coinsurance %, waived if admitted, etc.  
Keywords: copay, coinsurance, ER, per-visit, per-admission, OOP applies.  
Examples:  
- “What is the ER copay?”  
- “How much does a specialist visit cost?”
3. EoCCategory  
→ Whether a category/service is covered or included at all.  
Keywords: cover, included, benefit name (maternity, infertility, DME, mental health, vision, preventive).  
Examples:  
- “Does this plan cover infertility treatment?”  
- “Is preventive care included?”  
- “Are DME items covered?”
4. EoCSection  
→ Detailed rules, limits, or conditions under a covered benefit.  
Includes: prior authorization, step therapy, referral, visit/frequency limits, waiting periods, medical necessity, conditional coverage.  
Keywords: prior auth, pre-cert, referral, limit, step therapy, medically necessary, authorization required.  
Examples:  
- “Is prior authorization required for MRI?”  
- “Are PT visits limited to 30 per year?”
5. ProgramCategories  
→ Add-on or wellness programs and vendor-based offerings.  
Includes: nurse line,out of state,out of californial, travelling coverage telehealth, case management, advocacy, BlueCard, EAP, disease management, diabetes program.  
Keywords: nurse line, telehealth, concierge, case management, BlueCard, EAP, wellness program.  
Examples:  
- “Does this plan have a nurse hotline?”  
-"Am I covered out of sate?"
-"Am I covered while travelling?"
- “Is there a diabetes management program?”
-"Can I talk to a nurse?"
6. GenericDefinition  
→ Definitions of insurance or healthcare terms.  
Keywords: what is, define, explain, meaning of.  
Examples:  
- “What is a deductible?”  
- “Explain out-of-pocket maximum.”
7. Exclusions  
→ Items, services, or drugs that are NOT COVERED under the plan — permanently or conditionally.  
Includes cosmetic or elective procedures, experimental services, OTC drugs, vitamins, supplies, or limitations listed under Exclusions & Limitations.  
Keywords: excluded, not covered, exclusion list, exception, limitation, not payable, not eligible, experimental, cosmetic, over-the-counter.  
Examples:  
- “Are over-the-counter drugs excluded?”  
- “Is cosmetic surgery not covered?”  
- “Which services are under exclusions?”  
- “Are infertility treatments excluded?”  
- “Is acupuncture excluded?”
-------------------------------
EXCLUSIONS vs COVERAGE RULE
-------------------------------
If question asks:
- “Covered(not out of state/travelling)/included?” → EoCCategory  
- “Excluded/not covered/exception?” → Exclusions  
- Both coverage & exclusion → EoCCategory, Exclusions  
- Coverage + rule (prior auth, limit) → EoCCategory, EoCSection  
- Excluded with condition (“unless medically necessary”) → Exclusions, EoCSection  
- If ambiguous, default to EoCCategory.


RETURN EXAMPLE (JSON):
{{
  "ExpandedQuestion": "what is my cost share of PCP (Primary Care Physician)",
  "FollowUp": "No",
  "Intent": ["BenefitCostShares"]
}}

Now classify this input:
{json.dumps(input)}
""".strip()

        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
        raw = llm.invoke([HumanMessage(content=prompt)])

        # Parse robustly
        payload = _coerce_json(raw.content)

        # Extract fields with safe defaults
        expanded = payload.get("ExpandedQuestion", input) or input
        followup = payload.get("FollowUp", "No")
        intent = _normalize_intents(payload.get("Intent"))

        # Safety defaults if model went off-spec
        if followup not in {"Yes", "No"}:
            followup = "No"
        if not intent:
            # If truly nothing recognized, default to EoCCategory per rule
            intent = ["EoCCategory"]

        result = {
            "expanded_question": expanded,
            "followup": followup,
            "intent": intent,
        }
        print("ClassifyIntentTool result ->", result)
        return result



class GenerateAnswerArgs(BaseModel):
    question: str = Field(..., description="User question")
    plan_meta: str = Field(..., description="Plan-wide metadata (JSON string)")
    cost_share: List[Dict[str, Any]] = Field(default_factory=list, description="Benefits list (parsed)")
    exclusion: List[Dict[str, Any]] = Field(default_factory=list, description="Exclusions list (parsed)")
    plan_type: str = Field(..., description="plan_type")
    plan_name: str = Field(..., description="Plan name")
    

   

class GenerateAnswerTool(StructuredTool):
    name: ClassVar[str] = "GeneratePlanAnswer"
    description: ClassVar[str] = "Merge cost-share details, templates,exclusion and plan metadata into final Markdown."
    args_schema: ClassVar[Type[BaseModel]] = GenerateAnswerArgs

    @mlflow.trace(name="GenerateAnswer_run", span_type="tool")
    def _run(
        self,
        question: str,
        plan_meta: str,
        cost_share: List[Dict[str, Any]],
        exclusion: List[Dict[str, Any]],
        plan_type: str,
        plan_name: str,
    ) -> str:
        try:
            scripting_key = "HMO" if "HMO" in plan_type else "PPO"
            templates = template_json[scripting_key]
            scripting_format = json.dumps(templates, indent=4)

            data = {
                "plan_data": plan_meta,     # already a dict
                "benefits":  cost_share,
                "exclusion": exclusion    # already a list[dict]
            }
        except Exception:
            return ("We are unable to find relevant benefit details in the current plan "
                    "data to answer this question accurately.")

        prompt = generate_prompt(question, plan_type, data, scripting_format)
        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
        response = llm.invoke([HumanMessage(content=prompt)])
        final_llm_response=response.content.strip() or "[EMPTY RESPONSE]"
        generic_line=generic_template[plan_type]
        final_answer = f"Plan: {plan_name}\n\n{final_llm_response}"
        if plan_type=="HMO" and ("emergency" not in final_llm_response.lower() and "the service you are requesting is either not a benefit" not in final_llm_response.lower() and "exclusion under your current policy" not in final_llm_response.lower()):
            final_answer = f"Plan: {plan_name}\n\n{generic_line}\n\n{final_llm_response}"
        else:
            final_answer = f"Plan: {plan_name}\n\n{final_llm_response}"

       

        return final_answer
      
class FallbackArgs(BaseModel):
    question: str = Field(..., description="Original or expanded user question")


class FallbackAgentTool(StructuredTool):
    name: ClassVar[str] = "FallbackAgent"
    description: ClassVar[str] = (
        "Handles queries that are neither cost-share nor benefits. "
        "Simply replies that the question is outside scope, or asks for clarification."
    )
    args_schema: ClassVar[Type[BaseModel]] = FallbackArgs

    def _run(self, question: str) -> str:
        prompt = f"""
You are a health-insurance assistant.

The user asked a question that does not match cost-share or benefits look-up.

Politely respond in one sentence, either:
• apologising that you can’t answer, OR
• asking a clarifying follow-up question
so you can route them correctly next time.

User question: "{question}"
"""
        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0.2)
        resp = llm.invoke([HumanMessage(content=prompt)])
        return resp.content.strip()
    



import json
import re
import logging
import pandas as pd
from typing import Any, List, Dict, Type, ClassVar, Pattern
from dataclasses import asdict
from pydantic import BaseModel, Field
from typing import Dict
import json
from langchain.schema import HumanMessage
from langchain.chat_models import ChatDatabricks
import mlflow
from mlflow.pyfunc import PythonModel, PythonModelContext 
from databricks.vector_search.reranker import DatabricksReranker
from langchain.tools import StructuredTool
from langchain_community.chat_models import ChatDatabricks
from langchain.agents import initialize_agent, AgentType
from langchain.schema import SystemMessage
from databricks.vector_search.client import VectorSearchClient
import os
logging.basicConfig(level=logging.INFO)
from mlflow.models.rag_signatures import (
    ChatCompletionRequest,
    ChatCompletionResponse, 
    StringResponse,
    Message,
)




import mlflow.deployments

import pandas as pd
import mlflow.deployments

def get_data_from_online_table(
    fq_table_name: str,
    query_payload: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """
    Batch‐fetch records from the serving endpoint, returning a flat list of dicts.
    """
    # derive the endpoint name
    _, _, table = fq_table_name.split(".")
    endpoint = f"{table}_endpoint".replace("_", "-")
    client = mlflow.deployments.get_deploy_client("databricks")

    
    # call the endpoint
    resp = client.predict(
        endpoint=endpoint,
        inputs={"dataframe_records": query_payload}
    )

    


    # resp is a PredictionsResponse (aka DatabricksEndpoint)
    
    # 1) If it has get_predictions(), use that to get a pandas DataFrame
    if hasattr(resp, "get_predictions"):
        df = resp.get_predictions()  # default predictions_format="dataframe"
        return df.to_dict(orient="records")
    
    # 2) Otherwise it may be a simple list or dict
    data = resp if isinstance(resp, list) else resp if isinstance(resp, dict) else None
    if isinstance(data, dict) and "outputs" in data:
        return data["outputs"]
    if isinstance(data, list):
        return data
    
    # 3) As a last resort, try to .to_json() then json.loads()
    if hasattr(resp, "to_json"):
        json_str = resp.to_json()
        parsed = json.loads(json_str)
        return parsed.get("predictions", parsed.get("outputs", []))
    
    raise ValueError(f"Unrecognized PredictionsResponse shape: {type(resp)}")


def vs_search(
    q: str,
    nexus: int | None,
    k: int,
    index_name: str,
    columns: list[str] | None = None,
    score_threshold: float | None = None,
    filters: dict[str, Any] | None = None,
    rerank_column:str=None,
) -> list[dict[str, Any]]:
    if columns is None:
        columns = ["benefit_id", "search_text"]

    # build filters safely
    if filters is not None:
        search_filters = filters
    elif nexus is not None:
        search_filters = {"nexusId": int(nexus)}
    else:
        search_filters = None      
                     

    idx = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=index_name)
   
    raw = idx.similarity_search(
        query_text=q,
        num_results=k,
        #query_type="hybrid",
        
        filters=search_filters,
            reranker=DatabricksReranker(
        columns_to_rerank=[rerank_column]
    ),
        columns=columns,
        score_threshold=score_threshold,
    )


    result = raw.get("result", raw)
    cols   = result.get("column_names", columns)
    rows   = result.get("data_array", [])

    out = []
    for r in rows:
        row = {cols[i]: r[i] for i in range(len(cols))}  # keep everything
        row["id"]   = row[cols[0]]      
        row["text"] = row[cols[1]]      
        out.append(row)
  
    return out


class PlanDetectArgs(BaseModel):
    facets_product_id: str = Field(..., description="facets_product_id")
    effective_date: str = Field(..., description="effective_date")

class PlanDetectTool(StructuredTool):
    name: ClassVar[str] = "PlanDetect"
    description: ClassVar[str] = (
        "Detect the health‑plan the user is asking about. "
        "Returns BOTH plan_nexus and its plan_cost_share JSON."
    )
    args_schema: ClassVar[Type[BaseModel]] = PlanDetectArgs

    #plan_summary_index_name="tbl_plan_summary_index"
    @mlflow.trace(name="PlanDetect_run", span_type="tool")
    def _run(self,facets_product_id:str,effective_date:str ) -> str:
        query = facets_product_id
        print(query ) 
      
   

        # columns MUST include the JSON string/struct that holds cost‑share rows
        cols = ["nexusId", "planStructureType", "planCostShares","product_line_of_business","planName"]

        hits = vs_search(
            q=query,
            nexus=None,
            k=1,
            index_name=PLAN_INDEX,
            columns=cols,
            score_threshold=0.9,
            filters={"effective_date":effective_date},
                         # <- no nexus filter on first pass
        )
        print(hits)

        # Fallback: append default plan name if no hit
        if not hits:
            augmented_q = f" {DEFAULT_PLAN_NAME}"
            augmented_q=augmented_q.replace("?","")
            print("augmented_q",augmented_q)
            hits = vs_search(
                q            = augmented_q,
                nexus        = DEFAULT_PLAN,     
                k            = 1,
                index_name   = PLAN_INDEX,
                columns      = cols,
                score_threshold = 0.9,              
                #filters      = {"nexusId": DEFAULT_PLAN}
            )


       
        top             = hits[0]
        #print("top",top)
        plan_nexus      = top["nexusId"]            # ID field
        plan_cost_json  = top["planCostShares"]
        plan_name=top["planName"]
        plan_type=top["planStructureType"]

        return json.dumps(
            {"plan_nexus": plan_nexus, "plan_cost_share": plan_cost_json,"plan_name":plan_name,"plan_type":plan_type},
            default=str
        )




class DefinitionArgs(BaseModel):
    input: str = Field(..., description="User question asking for a definition")

class DefinitionTool(StructuredTool):
    name: ClassVar[str] = "DefinitionTool"
    description: ClassVar[str] = "Returns concise health-insurance definitions (deductible, copay, coinsurance, OOPM, BlueCard, etc.)"
    args_schema: ClassVar[Type[BaseModel]] = DefinitionArgs

    @mlflow.trace(name="DefinitionTool_run", span_type="tool")
    def _run(self, input: str) -> str:
        prompt = f"""
You are a Health Insurance Specialist.

Define the insurance term mentioned in the user's question.

Requirements:
- Give a direct, accurate definition relevant to health insurance.
- Use clear, plain language for members/patients.
- No comparisons, plan-specific details, company names, or dollar amounts.
- Keep it concise (2–4 sentences).
- Output only the definition text (no headings or formatting).

Term to define:
{input}
"""
        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
        raw = llm.invoke([HumanMessage(content=prompt)])
        return raw.content.strip()



class FallbackArgs(BaseModel):
    question: str = Field(..., description="Original or expanded user question")


class FallbackAgentTool(StructuredTool):
    name: ClassVar[str] = "FallbackAgent"
    description: ClassVar[str] = (
        "Handles queries that are neither cost-share nor benefits. "
        "Simply replies that the question is outside scope, or asks for clarification."
    )
    args_schema: ClassVar[Type[BaseModel]] = FallbackArgs

    def _run(self, question: str) -> str:
        prompt = f"""
You are a health-insurance assistant.

The user asked a question that does not match cost-share or benefits look-up.

Politely respond in one sentence, either:
• apologising that you can’t answer, OR
• asking a clarifying follow-up question
so you can route them correctly next time.

User question: "{question}"
"""
        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0.2)
        resp = llm.invoke([HumanMessage(content=prompt)])
        return resp.content.strip()
    



from typing import Optional
  
_CONTENT_SPLIT = re.compile(r"Content\s*:", flags=re.IGNORECASE)

def _trim_header(txt: str) -> str:
    """
    Returns the part of search_text that precedes 'Content:' (case-insensitive).
    If 'Content:' is absent, returns the original text.
    """
    m = _CONTENT_SPLIT.search(txt)
    return txt[:m.start()].strip() if m else txt.strip()
# ─────────────────────────────────────────────────────────────────────────────
# CopayCoinsuranceTool: vector-search + online fetch for cost-share rows
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# CopayCoinsuranceTool: vector-search + online fetch for cost-share rows
# ─────────────────────────────────────────────────────────────────────────────
from typing import ClassVar, Type, Dict, Any, List
from pydantic import BaseModel, Field

class CopayArgs(BaseModel):
    input: str = Field(..., description="Original question string.")
    plan_nexus: int = Field(..., description="Current plan nexusId")

class CopayCoinsuranceTool(StructuredTool):
    name: ClassVar[str] = "CopayCoinsurance"
    description: ClassVar[str] = (
        "Answer cost-share questions for the current plan. Returns a JSON list of benefit dicts."
    )
    args_schema: ClassVar[Type[BaseModel]] = CopayArgs

    @mlflow.trace(name="CopayCoinsurance_run", span_type="tool")
    def _run(self, input: str, plan_nexus: int) -> str:
        hits = vs_search(
            q=input,
            nexus=plan_nexus,
            k=5,
            index_name=BENEFIT_INDEX,
            columns=[
                "benefit_id",
                "eoc_categories_all_fields",
                # add whatever columns you actually need
            ],
            filters={"nexusId": plan_nexus},
            rerank_column="eoc_categories_all_fields"  
)

        if not hits:
            return "[]"


        # Ensure hits are dicts (normalize if your vs_search returns objects)
        def to_dict(h):
            if isinstance(h, dict):
                return h
            # fallback for objects with __dict__ or attributes
            try:
                return dict(h)
            except Exception:
                return {"value": str(h)}

        payload: List[Dict[str, Any]] = [to_dict(h) for h in hits]
        return json.dumps(payload)  # <-- JSON list of dicts
    
    





# ─────────────────────────────────────────────────────────────────────────────
# CopayCoinsuranceTool: vector-search + online fetch for cost-share rows
# ─────────────────────────────────────────────────────────────────────────────
from typing import ClassVar, Type, Dict, Any, List
from pydantic import BaseModel, Field

class ProgramArgs(BaseModel):
    input: str = Field(..., description="Original question string.")
    plan_nexus: int = Field(..., description="Current plan nexusId")

class ProgrammanagementTool(StructuredTool):
    name: ClassVar[str] = "Programmanagement"
    description: ClassVar[str] = (
        "Answer cost-share questions for the current plan. Returns a JSON list of benefit dicts."
    )
    args_schema: ClassVar[Type[BaseModel]] = ProgramArgs

    @mlflow.trace(name="Programmanagement_run", span_type="tool")
    def _run(self, input: str, plan_nexus: int) -> str:
        hits = vs_search(
            q=input,
            nexus=plan_nexus,
            k=4,
            index_name=PROGRAM_INDEX,
            columns=[
                "program_id",
                "combined_eoc_program_categories",
                # add whatever columns you actually need
            ],
            filters={"nexusId": plan_nexus} 
)

        if not hits:
            return "[]"


        # Ensure hits are dicts (normalize if your vs_search returns objects)
        def to_dict(h):
            if isinstance(h, dict):
                return h
            # fallback for objects with __dict__ or attributes
            try:
                return dict(h)
            except Exception:
                return {"value": str(h)}

        payload: List[Dict[str, Any]] = [to_dict(h) for h in hits]
        program_categories_json=json.dumps(payload)
        prompt = f"""
                You are a Health Plan Program Assistant.

                Use only the provided Program Categories data to answer the user question.

                User Question: {input}  
                Program Data: {program_categories_json}

                Rules:
                1. Identify if the question matches a program (e.g., “talk to a nurse” → Nurse Advice Line, 24/7 Nurse Line, Nurse Hotline, etc.).
                2. If a matching program exists, summarize:
                • Program name and purpose  
                • How to access (phone/app)  
                • Availability or hours  
                • Cost (if given)
                3. If marked as excluded or not covered, reply exactly:
                “This service is not covered under the plan.”
                4. If no matching program exists, reply:
                “This information isn’t available in the provided program data. Please contact Member Services for help.”
                5. Use only plain text or simple bullets, no JSON, no placeholders.
                """
        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0.2)
        resp = llm.invoke([HumanMessage(content=prompt)])
        return resp.content.strip()
      
    
    





# ─────────────────────────────────────────────────────────────────────────────
# ExclusionCheckTool: vector-search + online fetch for exclusion rows
# ─────────────────────────────────────────────────────────────────────────────

from typing import ClassVar, Type, Dict, Any, List
from pydantic import BaseModel, Field

class ExclusionArgs(BaseModel):
 
    plan_nexus: int = Field(..., description="Current plan nexusId")

class ExclusionCheckTool(StructuredTool):
    name: ClassVar[str] = "CopayCoinsurance"
    description: ClassVar[str] = (
        "Answer cost-share questions for the current plan. Returns a JSON list of benefit dicts."
    )
    args_schema: ClassVar[Type[BaseModel]] = ExclusionArgs

    @mlflow.trace(name="ExclusionCheck_run", span_type="tool")
    def _run(self,plan_nexus: int) -> str:
        hits = vs_search(
            q="Exclusions and Limitations",
            nexus=plan_nexus,
            k=1,
            index_name=EXCLUSION_INDEX,
            columns=[
                "section_id",
                "eoc_sections_combined"

            ],
            filters={"nexusId": plan_nexus}
          
)

        if not hits:
            return "[]"


        # Ensure hits are dicts (normalize if your vs_search returns objects)
        def to_dict(h):
            if isinstance(h, dict):
                return h
            # fallback for objects with __dict__ or attributes
            try:
                return dict(h)
            except Exception:
                return {"value": str(h)}

        payload: List[Dict[str, Any]] = [to_dict(h) for h in hits]
        return json.dumps(payload)  # <-- JSON list of dicts
    
    




class State(TypedDict):
    messages: Annotated[list, add_messages]
    productid_effectivedate_product:str
    input: str
    expanded_question:str
    plan_nexus: Optional[str]
    plan_name: Optional[str]
    plan_cost_share:Optional[str]
    scenarios:Optional[list]
    plan_meta: Optional[str]
    benefits: Optional[str]
    cost_share: Optional[str]
    exclusion: Optional[str]
    intent: Optional[list]
    prompt:Optional[str]
    templates:Optional[str]
    uid:Optional[str]
    sid:Optional[str]
    question_id:Optional[str]
    facets_product_id:Optional[str]
    effective_date:Optional[str]
    product_line_of_business:Optional[str]
    plan_type:Optional[str]


def detect_plan(state: State) -> State:
    tool = PlanDetectTool()
    result = tool.invoke({"facets_product_id": state["facets_product_id"],"effective_date":state["effective_date"]})
    parsed = json.loads(result)
    state["plan_nexus"] = parsed.get("plan_nexus")
    state["plan_cost_share"] = parsed.get("plan_cost_share")
    state["plan_name"] = parsed.get("plan_name")
    state["plan_type"]=parsed.get("plan_type")
    
    return state

def fetch_definition(state: State) -> State:
    tool = DefinitionTool()
    result = tool.invoke({"input": state["input"]})
    state["answer"] = result
    return state
    
def fetch_intent(state: State) -> State:
    tool   = ClassifyIntentTool()
    result = tool.invoke({
        "input":      state["input"]
        
    })


    state["intent"] = result.get("intent", "none")
    state["expanded_question"] = result.get("expanded_question", state.get("input", ""))
    state["followup"] = result.get("followup", "")
    return state

def fallback_answer(state: State) -> State:
    tool = FallbackAgentTool()
    txt  = tool.invoke({"question": state["input"]})
    state["answer"] = txt
    state["messages"].append(AIMessage(content=txt))
    return state
def route_to_next_tool(state: State) -> str:
    intent = state["intent"]

    print(f"[Routing] Intent detected: '{intent}'")

    # Handle if intent is a list
    if isinstance(intent, list):
        # Flatten list to string for matching, or check each item
        if any("EoCCategory" in i or "BenefitCostShares" in i for i in intent):
            return "get_cost_share"
        elif any("ProgramCategories" in i for i in intent):
            return "get_programdetail"
        elif "definition" in intent:
            return "get_definition"
        else:
            return "fallback"
    else:
        if "EoCCategory" in intent or "BenefitCostShares" in intent:
            return "get_cost_share"
        elif intent == "definition":
            return "get_definition"
        elif "internt"=="ProgramCategories":
            return "get_programdetail"
        else:
            return "fallback"
def fetch_cost_share(state: State) -> State:
    tool   = CopayCoinsuranceTool()
    result = tool.invoke({
        "input":      state["expanded_question"],
        "plan_nexus": state["plan_nexus"],
    })
    # result is a JSON string of list[dict]
    try:
        parsed = json.loads(result) if result else []
    except Exception:
        parsed = []
    state["cost_share"] = parsed   # <-- list[dict]
    return state
    #ProgrammanagementTool
def fetch_programcategory(state: State) -> State:
    tool   = ProgrammanagementTool()
    answer = tool.invoke({
        "input":      state["expanded_question"],
        "plan_nexus": state["plan_nexus"],
    })
   
    state["answer"] = answer
    state["messages"].append(AIMessage(content=answer))
    return state
def fetch_exclusion(state: State) -> State:
    tool   = ExclusionCheckTool()
    result = tool.invoke({
       
        "plan_nexus": state["plan_nexus"],
    })
    # result is a JSON string of list[dict]
    try:
        parsed = json.loads(result) if result else []
    except Exception:
        parsed = []
    state["exclusion"] = parsed   # <-- list[dict]
    return state
def generate_answer(state: State) -> State:
    tool = GenerateAnswerTool()
    
    answer = tool.invoke({
        "question":        state["expanded_question"],
        "plan_meta":       state.get("plan_cost_share", ""),
        "cost_share":      state["cost_share"],  
        "exclusion":       state["exclusion"],
        "plan_type":      state["plan_type"],
        "plan_name":       state["plan_name"]
   
    })
    
    state["answer"] = answer
    state["messages"].append(AIMessage(content=answer))
    return state


def build_graph():
    # --- Build Graph ---
    builder = StateGraph(State)

    builder.add_node("detect_plan", detect_plan)
    #fetch_definition
    builder.add_node("classify_intent", fetch_intent)
    builder.add_node("fallback", fallback_answer)
    builder.add_node("get_definition", fetch_definition)
    builder.add_node("get_cost_share", fetch_cost_share)
    builder.add_node("fetch_exclusion", fetch_exclusion)
    builder.add_node("generate_answer", generate_answer)
    builder.add_node("get_programdetail", fetch_programcategory)
    

    # Conditional routing
    builder.set_entry_point("detect_plan")
    builder.add_edge("detect_plan","classify_intent")
    
    
    builder.add_conditional_edges("classify_intent", route_to_next_tool, {
        "get_cost_share": "get_cost_share",
        "get_definition": "get_definition",
        "get_programdetail": "get_programdetail",
        "fallback":       "fallback"
        
    })
    
 
    builder.add_edge("fallback", END)

    builder.add_edge("get_definition", END)
    builder.add_edge("get_programdetail", END)
    
    builder.add_edge("get_cost_share", "fetch_exclusion")
    builder.add_edge("fetch_exclusion", "generate_answer")
 

    builder.add_edge("generate_answer", END)
   

    graph = builder.compile()
    return graph

def _extract_text_from_content_parts(parts) -> str:
    if not parts:
        return ""
    chunks = []
    for p in parts:
        if hasattr(p, "text"):       # pydantic ResponseInputTextParam
            chunks.append(p.text)
        elif isinstance(p, dict):    # plain dict
            t = p.get("text")
            if isinstance(t, str):
                chunks.append(t)
    return "\n".join(chunks).strip()

def _last_user_text(request: ResponsesAgentRequest) -> str:
    msgs = request.input or []
    for m in reversed(msgs):
        role = getattr(m, "role", None) if not isinstance(m, dict) else m.get("role")
        if role == "user":
            content = getattr(m, "content", None) if not isinstance(m, dict) else m.get("content")
            return _extract_text_from_content_parts(content)
    if msgs:
        m = msgs[-1]
        content = getattr(m, "content", None) if not isinstance(m, dict) else m.get("content")
        return _extract_text_from_content_parts(content)
    return ""
class BenefitCostResponsesAgent(ResponsesAgent):
    def load_context(self, context: PythonModelContext):
        self.cfg={}
        os.environ["DATABRICKS_HOST"] = "https://adb-640321604414221.1.azuredatabricks.net/"
        os.environ["DATABRICKS_TOKEN"] = "dapif8dab299d451859c467c049af8ed7bd7-2" 
   

        #os.environ["DATABRICKS_TOKEN"]=dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
        mlflow.set_tracking_uri("databricks")
    
        config_path = context.artifacts.get("config")
        if not config_path or not os.path.exists(config_path):
            raise FileNotFoundError("Config artifact 'config' not found or missing from model context.")
        
        with open(config_path, "r") as f:
            self.cfg = json.load(f)
        global VS_ENDPOINT, BENEFIT_INDEX, PLAN_INDEX, DEFAULT_PLAN, DEFAULT_PLAN_NAME, LLM_ENDPOINT, CURRENT_PLAN_NEXUS, vsc,EXCLUSION_INDEX,PROGRAM_INDEX
        VS_ENDPOINT         = self.cfg["vs_endpoint"]
        BENEFIT_INDEX       = self.cfg["benefit_index"]
        PLAN_INDEX          = self.cfg["plan_index"]
        DEFAULT_PLAN        = self.cfg["DEFAULT_PLAN"]
        DEFAULT_PLAN_NAME   = self.cfg["DEFAULT_PLAN_NAME"]
        LLM_ENDPOINT        = self.cfg["LLM_ENDPOINT"]
        EXCLUSION_INDEX =     self.cfg["EXCLUSION_INDEX"]
        PROGRAM_INDEX = self.cfg["PROGRAM_INDEX"]
        CURRENT_PLAN_NEXUS  = DEFAULT_PLAN

        vsc = VectorSearchClient()
        self.agent = build_graph()   

    def initialize(self):           
        self.load_with_artifacts({})

    def predict(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
        if self.agent is None:
            self.initialize()

        ci = request.custom_inputs or {}
        print(ci)
        self.uid = ci.get("user_id")
     
        self.sid = ci.get("session_id")
        self.question_id = ci.get("question_id")
        print(self.question_id)
        self.facets_product_id = ci.get("facets_product_id")
        self.effective_date = ci.get("effective_date")
      

        # last user text from Responses schema
        user_q = _last_user_text(request)
        print({"input": user_q,"uid":self.uid,"sid":self.sid,"question_id":self.question_id,"facets_product_id":self.facets_product_id,"effective_date":self.effective_date})
        # run LangGraph
        final_state = self.agent.invoke({"input": user_q,"uid":self.uid,"sid":self.sid,"question_id":self.question_id,"facets_product_id":self.facets_product_id,"effective_date":self.effective_date})

        # extract assistant reply
        reply = ""
        for m in reversed(final_state.get("messages", [])):
            if isinstance(m, AIMessage):
                reply = m.content
                break
        if not reply:
            reply = "[EMPTY RESPONSE]"

        out = self.create_text_output_item(text=reply, id=str(uuid4()))
        ci = {k: v for k, v in ci.items() if k in ("session_id", "question_id")}
        #return {"content": reply}
        return ResponsesAgentResponse(output=[out], custom_outputs=ci)
        #return 


# Tell MLflow logging where to find your chain.
mlflow.models.set_model(model=BenefitCostResponsesAgent())
  















