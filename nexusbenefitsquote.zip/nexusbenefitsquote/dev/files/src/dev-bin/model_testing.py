# Databricks notebook source
# MAGIC %pip install databricks-vectorsearch
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %pip install --upgrade \
# MAGIC   mlflow[databricks]>=3.1.3 \
# MAGIC   databricks-langchain \
# MAGIC   langchain>=0.3.0 \
# MAGIC   langgraph \
# MAGIC   databricks-vectorsearch>=0.40
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

input_example = {
    "input": [
        {
            "role": "user",
            "content": [
                {"type": "input_text", "text": "what is the cost share for urgent care services?"}
            ],
        }
    ],
    "custom_inputs": {
        "user_id": "u-123",
        "username": "Priyanka",
        "session_id": "s-456",
        "question_id": "q-789",
        "facets_product_id": "MG011320",
        "effective_date": "20240101"
       
    },
}
import mlflow.pyfunc
import pandas as pd
df = input_example
model = mlflow.pyfunc.load_model("models:/dev_adb.benefits_quote_gold.benefit_quote_MVP1/19")
print( model.predict(df))


# COMMAND ----------

import mlflow.pyfunc
import pandas as pd
import json

INPUT_CSV_PATH  = "/Volumes/dev_adb/nexusbenefitsquote_bronze_mvp1/test_file/model_testing_q.csv"
OUTPUT_CSV_PATH = "/Volumes/dev_adb/nexusbenefitsquote_bronze_mvp1/test_file/questions_with_answer_30.csv"
MODEL_URI       = "models:/dev_adb.benefits_quote_gold.benefit_quote_MVP1/27"

def extract_answer(resp: dict) -> str:
    try:
        output = resp.get("output", [])
        for msg in output:
            for block in msg.get("content", []):
                if block.get("type") == "output_text":
                    return block.get("text", "")
        return ""
    except Exception:
        return ""

# Read CSV using pandas for serial processing
df = pd.read_csv(INPUT_CSV_PATH)


if "questions" not in df.columns:
    raise ValueError("Input CSV must contain a 'questions' column")

model = mlflow.pyfunc.load_model(MODEL_URI)

def get_answer(q):
    try:
        input_payload = {
            "input": [
                {
                    "role": "user",
                    "content": [{"type": "input_text", "text": q}],
                }
            ],
            "custom_inputs": {
                "user_id": "u-123",
                "username": "Priyanka",
                "session_id": "s-456",
                "question_id": "q-789",
                "facets_product_id": "M0033822",
                "effective_date": "20240101"
            },
        }
        result = model.predict(input_payload)
        if isinstance(result, str):
            result = json.loads(result)
        return extract_answer(result)
    except Exception as e:
        return f"Error: {str(e)}"

df["answer"] = df["questions"].apply(get_answer)

# Save to CSV
df.to_csv(OUTPUT_CSV_PATH, index=False)

display(spark.createDataFrame(df).limit(5))