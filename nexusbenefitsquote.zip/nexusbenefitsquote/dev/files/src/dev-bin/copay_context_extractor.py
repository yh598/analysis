# Databricks notebook source
# MAGIC %pip install --upgrade \
# MAGIC   mlflow[databricks]>=3.1.3 \
# MAGIC   databricks-langchain \
# MAGIC   langchain>=0.3.0 \
# MAGIC   langgraph \
# MAGIC   databricks-vectorsearch>=0.40

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("input_csv_file_name", "", "Input CSV File Name")
dbutils.widgets.text("environment", "", "Environment")

input_csv_file_name = dbutils.widgets.get("input_csv_file_name")
environment = dbutils.widgets.get("environment")

# COMMAND ----------

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from typing import *
from databricks.vector_search.client import VectorSearchClient
# Databricks LLM client
from databricks_langchain import ChatDatabricks
from databricks.vector_search.reranker import DatabricksReranker


# Pydantic v2
from pydantic import BaseModel, Field
import mlflow


# COMMAND ----------

template_json={
  "PPO": {
  
    "PPO_IN: Subject to Deductible & Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Coinsurance' and subjectToDeductible=='true'",
      "Description Explicit": "Deductible applies • Coinsurance applies after deductible • No copay.",
      "Description": "Member pays the deductible first, then a coinsurance percentage until the out-of-pocket maximum is reached.",
      
	  "scripting": {
        "In Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. After the deductible has been met, the coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },"PPO_Out: Subject to Deductible & Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' AND structureType == 'Coinsurance' AND subjectToDeductible=='true'",
      "Description Explicit": "Deductible applies • Coinsurance applies after deductible  • No copay.",
      "Description": "Member pays the deductible first, then a coinsurance percentage until the out-of-pocket maximum is reached.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. After the deductible has been met, the coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  ."
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Subject to Deductible & Copay": {
      "guardrail": "Choose this template ONLY if  provider_type=='Participating Provider' and structureType == 'Copay' AND subjectToDeductible=='true'",
      "Description Explicit": "Deductible applies • Copay applies after deductible",
      "Description": "Member pays the deductible first, then a flat copay for the service until the out-of-pocket maximum is reached.",
     
	  "scripting": {
        "In Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. After the deductible is met, your copay for [service] is [$X] and applies to your copayment maximum of [$X], not to exceed [$X] per family. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Subject to Deductible & Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Copay' AND subjectToDeductible=='true'",
      "Description Explicit": "Deductible applies • Copay applies after deductible",
      "Description": "Member pays the deductible first, then a flat copay for the service until the out-of-pocket maximum is reached.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. After the deductible is met, your copay for [service] is [$X] and applies to your copayment maximum of [$X], not to exceed [$X] per family. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Subject to Deductible, No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and subjectToDeductible=='true' and structureType == 'No Charge'",
      "Description Explicit": "Deductible applies • After deductible, plan pays 100% • No coinsurance or copay.",
      "Description": "Member pays toward the deductible, then nothing further for the covered service.",
      
	  "scripting": {
        "In Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. Once the deductible has been met, BSC will reimburse your provider 100% of the allowed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Subject to Deductible, No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and subjectToDeductible=='true' and structureType == 'No Charge'",
      "Description Explicit": "Deductible applies • After deductible, plan pays 100% • No coinsurance or copay.",
      "Description": "Member pays toward the deductible, then nothing further for the covered service.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "This plan has a deductible of [$X] per person, not to exceed [$X] per family. Once the deductible has been met, BSC will reimburse you 100% of the allowed amount.\n\n*Your out-of-network provider has the right to balance bill. What this means to you is you may be responsible for the difference between the allowed amount and billed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Not Subject to Deductible;Plan deductible is not zero; Subject to  Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Coinsurance' and subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is not zero •Coinsurance applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
     
	  "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is not zero; Subject to  Coinsurance;subjectToDeductible=='false'": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Coinsurance' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is not zero• Coinsurance applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible.The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
	 "PPO_IN: Not Subject to Deductible;Plan deductible is zero; Subject to  Coinsurance;subjectToDeductible=='false'": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Coinsurance' and subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is zero •Coinsurance applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
     
	  "scripting": {
        "In Network Provider Scripting": "The plan does not have deductible.The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is zero; Subject to  Coinsurance": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Coinsurance' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is  zero• Coinsurance applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "The plan does not have deductible.The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Not Subject to Deductible;Plan deductible is not zero; Subject to Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Copay' and subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is not zero •Copay applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a flat copay for the service;",
    
	  "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. The copay for [service] is [$X].{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is not zero ;Subject to Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Copay' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is not zero • Copay applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a flat copay for the service;",
  
	  "scripting": {
        "Out of Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. The copay for [service] is [$X].{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
	"PPO_IN: Not Subject to Deductible;Plan deductible is zero; Subject to Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and structureType == 'Copay' and subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is zero •Copay applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a flat copay for the service;",
    
	  "scripting": {
        "In Network Provider Scripting": "The plan does not have a deductible.The copay for [service] is [$X].{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is zero ;Subject to Copay": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and structureType == 'Copay' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible for service •Plan deductible is zero • Copay applies • Out-of-Pocket Maximum applies.",
      "Description": "Member pays a flat copay for the service;",
  
	  "scripting": {
        "Out of Network Provider Scripting": "The plan does not have a deductible.The copay for [service] is [$X].{{OOPM_LINE}} {{LIMIT_LINE}}  "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: Not Subject to Deductible;Plan deductible is not zero;No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider' and Plan deductible is not zero and structureType == 'No Charge' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible •Plan deductible is not zero •No oopm •Plan pays 100% • No coinsurance and No copay.",
      "Description": "Service is covered at 100% when using an in-network provider; member owes $0.",
    
	  "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. Blue Shield will reimburse the provider 100% of the allowed amount.[Any additional maximum plan payment/allowance (defined by bscMaxText)]. "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan deductible is not zero ;No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and Plan deductible is not zero and structureType == 'No Charge' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible •Plan deductible is not zero• No oopm •Plan pays 100% • No coinsurance or copay.",
      "Description": "Service is covered at 100% when using an in-network provider; member owes $0.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family. However, service is not subject to the deductible. Blue Shield will reimburse the provider 100% of the allowed amount. "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
	"PPO_IN: Not Subject to Deductible;Plan deductible is zero;No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Participating Provider'and Plan deductible is not zero and structureType == 'No Charge' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible •Plan deductible is not zero•No oopm •Plan pays 100% • No coinsurance and No copay.",
      "Description": "Service is covered at 100% when using an in-network provider; member owes $0.",
    
	  "scripting": {
        "In Network Provider Scripting": "The plan does not have a deductible.Blue Shield will reimburse the provider 100% of the allowed amount.[Any additional maximum plan payment/allowance (defined by bscMaxText)]. "
      },
      
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_Out: Not Subject to Deductible;Plan Individual and Family Deductible is zero ;No Patient Liability": {
      "guardrail": "Choose this template ONLY if provider_type=='Non-Participating Provider' and Plan Individual and Family Deductible is zero and structureType == 'No Charge' AND subjectToDeductible=='false'",
      "Description Explicit": "No deductible •Plan Individual and Family Deductible is zero • No oopm •Plan pays 100% • No coinsurance or copay.",
      "Description": "Service is covered at 100% when using an in-network provider; member owes $0.",
     
	  "scripting": {
        "Out of Network Provider Scripting": "The plan does not have a deductible.Blue Shield will reimburse the provider 100% of the allowed amount. "
      },
      "oopm_text": {
        "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
        "does_not_apply": ""
      },
      "limit_text": {
        "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
        "does_not_apply": ""
      }
    },
    "PPO_IN: NAB or General Exclusion": {
      "guardrail": "Choose this template ONLY if structureType == 'Not Covered' OR costShareText contains 'Not Covered' (case-insensitive).",
      "Description Explicit": "[NOT-COVERED] Service is NOT covered • Plan pays 0% • Member pays 100% • Deductible, copay, coinsurance, and OOPM do NOT apply.",
      "Description": "This service is excluded from the plan. You would pay the full billed amount.",
      "scripting": {
        "In Network Provider Scripting": "The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount."
      }
    },
    "PPO_Out: NAB or General Exclusion": {
      "guardrail": "Choose this template ONLY if structureType == 'Not Covered' OR costShareText contains 'Not Covered' (case-insensitive).",
      "Description Explicit": "[NOT-COVERED] Service is NOT covered • Plan pays 0% • Member pays 100% • Deductible, copay, coinsurance, and OOPM do NOT apply.",
      "Description": "This service is excluded from the plan. You would pay the full billed amount.",
      "scripting": {
        "Out of Network Provider Scripting": "The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount."
      }
    },
    "PPO_IN: Not Covered through OON/OOS Provider": {
      "Description Explicit": "Service is only covered in-network • Out-of-network benefit is 0%.",
      "Description": "Member must use in-network or affiliate providers; otherwise responsible for full billed amount.",
      "scripting": {
        "In Network Provider Scripting": "- [Any additional maximum plan payment/allowance (defined by bscMaxText)]. "
      }
    },
    "PPO_Out: Not Covered through OON/OOS Provider": {
      "Description Explicit": "Service is only covered in-network • Out-of-network benefit is 0%.",
      "Description": "Member must use in-network or affiliate providers; otherwise responsible for full billed amount.",
      "scripting": {
        "Out of Network Provider Scripting": "You must seek services from either an in-network provider or a provider associated with your provider group to be eligible for benefits. As the member, this means you are responsible for 100% of the billed amount. [Any additional maximum plan payment/allowance (defined by bscMaxText)]. "
      }
    },
   
     "SpecialCases": {
    "Emergency": {
      "guardrail": "service IN ('Emergency','Emergency room','Emergency services')",
      "Description Explicit": "Emergency services are covered at the in-network cost share even if treated by a non-participating provider, until stabilized.",
      "Description": "Emergency care is treated as in-network. If admitted to an out-of-network hospital, in-network benefits apply until stabilized and transferable.",
      "scripting": {
        "Member Scripting": "Emergency services are covered at your in-network cost share even if the hospital or provider is out-of-network. If admitted out-of-network, in-network benefits apply until you are stabilized and can be moved to an in-network facility. Check balance-billing protections per state/federal law."
      }
    },
    "Acupuncture / Chiropractic / Therapeutic Massage": {
      "guardrail": "service IN ('Acupuncture','Chiropractic','Therapeutic Massage')",
      "Description Explicit": "Discount program available via ChooseHealthy (American Specialty Health Group).",
      "Description": "Members can access discounted rates through ChooseHealthy providers.",
      "scripting": {
        "Member Scripting": "Discounts for service are available through the ChooseHealthy program provided by American Specialty Health Group. Visit https://www.blueshieldca.com/en/home/be-well/live-healthy to find a participating provider and what’s included."
      }
    },
    "Annual Physical (HMO)": {
      "guardrail": "benefitHeader ILIKE '%annual physical%' OR benefitCategory ILIKE '%preventive%'",
      "Description Explicit": "Medical group/IPA may apply a rolling 12-month schedule for routine physicals.",
      "Description": "HMO routine physicals may be on a rolling 12-month basis set by the medical group/IPA.",
      "scripting": {
        "Member Scripting": "Your medical group or IPA may limit routine physical exams using a rolling 12-month schedule. Check with your PCP/IPA for exact timing."
      }
    },
    "Inpatient Facility / Hospital": {
      "guardrail": "placeOfService IN ('Inpatient Hospital','Acute Care Hospital')",
      "Description Explicit": "Admission notification required; related professional fees billed separately.",
      "Description": "Hospitals must contact MCS after admission. Expect separate bills for professional services.",
      "scripting": {
        "Provider Scripting": "The facility must contact Medical Care Solutions (MCS) within 5 days of a scheduled admission or within 24 hours of an emergent admission at 1 (800) 541-6652 (say “Authorizations”). In addition to the hospital bill, members may receive separate professional bills for surgery, anesthesia, radiology, pathology, or laboratory services."
      }
    },
    "Outpatient Facility / Hospital": {
      "guardrail": "placeOfService IN ('Outpatient Hospital','Ambulatory Surgery Center')",
      "Description Explicit": "Related professional fees billed separately.",
      "Description": "Expect separate anesthesia/diagnostic fees.",
      "scripting": {
        "Member Scripting": "Besides the facility bill, you may also see separate professional charges for anesthesia and diagnostic testing (radiology or laboratory)."
      }
    },
    "Physical Therapy (All members)": {
      "guardrail": "service == 'Physical Therapy'",
      "Description Explicit": "PT programs available via Blue Shield of California.",
      "Description": "Members can access PT programs and resources.",
      "scripting": {
        "Member Scripting": "Blue Shield of California offers physical therapy programs. See details at https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Surgery": {
      "guardrail": "benefitCategory ILIKE '%surgery%' OR service ILIKE '%surgery%'",
      "Description Explicit": "Surgical package includes pre-op, day-of medical visits, and routine post-op care.",
      "Description": "Separate anesthesia/diagnostic fees may apply.",
      "scripting": {
        "Member Scripting": "In addition to the surgeon’s bill, you may see separate fees for anesthesia and diagnostic testing. A standard surgical package includes the procedure, pre-operative care, same-day medical visits, and routine uncomplicated follow-up."
      }
    },
    "Urgent Care (HMO)": {
      "guardrail": "benefitCategory ILIKE '%urgent care%' AND planType == 'HMO'",
      "Description Explicit": "Check PCP/IPA or Medical Group for in-network urgent care clinics within service area.",
      "Description": "HMO members should verify in-network urgent care locations with PCP/IPA/MG.",
      "scripting": {
        "Member Scripting": "If you need to visit an urgent care center and you are in your Medical Group Service Area, go to the urgent care center designated by your Medical Group or call your PCP. If you are outside of your Medical Group Service Area but within California and need urgent care, you may visit any urgent care center near you."
      }
    },
    "Hearing Aids (Discount Program)": {
      "guardrail": "benefitCategory ILIKE '%hearing%' OR service ILIKE '%hearing aid%'",
      "Description Explicit": "Discount program via EPIC Hearing Healthcare.",
      "Description": "Members can access hearing aid discounts.",
      "scripting": {
        "Member Scripting": "A discount program is available through EPIC Hearing Healthcare. Learn more at https://www.blueshieldca.com/en/home/be-well/live-healthy/hearing-aid-discount."
      }
    },
    "Fitness / Gym / Exercise": {
      "guardrail": "benefitCategory ILIKE '%fitness%' OR service ILIKE '%gym%'",
      "Description Explicit": "Gym and digital fitness discounts available.",
      "Description": "Members can access fitness discount programs.",
      "scripting": {
        "Member Scripting": "Blue Shield of California offers gym membership discounts and digital fitness programs. See https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Vision (Vendor present)": {
      "guardrail": "visionVendor IS NOT NULL",
      "Description Explicit": "Vision benefits administered by a third-party administrator.",
      "Description": "Contact the administrator for details, coverage, and providers.",
      "scripting": {
        "Member Scripting": "This member’s [benefit type] benefits are administered by [administrator]. Let me give you their toll-free number."
      }
    },
    "Vision (All members)": {
      "guardrail": "benefitCategory ILIKE '%vision%'",
      "Description Explicit": "Discount vision program available to members.",
      "Description": "Members can access discounted vision services.",
      "scripting": {
        "Member Scripting": "A discount vision program is available to Blue Shield members. Learn more at https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Pharmacy (Tiering & OOP only)": {
      "guardrail": "benefitCategory ILIKE '%pharmacy%' OR benefitCategory ILIKE '%drug%'",
      "Description Explicit": "Show tiered pharmacy benefits and pharmacy-specific OOP information.",
      "Description": "Include tier information (Preferred/Non-Preferred/Generic/Specialty) and any pharmacy OOP caps.",
      "scripting": {
        "Member Scripting": "Your pharmacy benefits vary by tier (e.g., Generic, Preferred Brand, Non-Preferred Brand, Specialty). [Display member cost share per tier and any pharmacy-specific out-of-pocket maximum or caps.]"
      }
    },
    "Dental (Vendor present)": {
      "guardrail": "dentalVendor IS NOT NULL",
      "Description Explicit": "Dental benefits administered by a third-party administrator.",
      "Description": "Contact the administrator for coverage details and providers.",
      "scripting": {
        "Member Scripting": "This member’s [benefit type] benefits are administered by [administrator]. Let me give you their toll-free number."
      }
    }
  }
  },
  
  "HMO": {
 
    "HMO: Subject to Deductible &  Coinsurance": {
      "Description Explicit": "Deductible applies • Coinsurance applies after deductible • Out-of-Pocket Maximum applies • HMO covers in-network only.",
      "Description": "Member pays the deductible first and then a coinsurance percentage for in-network services until the out-of-pocket maximum is reached.",

      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family.After the deductible has been met, the coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount. {{OOPM_LINE}} {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, the patient is responsible for 100% of the provider's billed amount because the plan only covers services from in-network providers."
      },
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },

    "HMO: Subject to Deductible &  Copay": {
      "Description Explicit": "Deductible applies • Copay applies after deductible • Out-of-Pocket Maximum applies • HMO covers in-network only.",
      "Description": "Member pays the deductible first and then a flat copay for the service.",
      
  
      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family.After the deductible is met, your copay for [service] is [$X] and applies to your copayment maximum of [$X], not to exceed [$X] per family. {{OOPM_LINE}} {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, the patient is responsible for 100% of the provider's billed amount because the plan only covers services from in-network providers."
      }
      ,
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    
    },

    "HMO: Not Subject to Deductible ; Plan deductible is not zero; Subject to  Coinsurance": {
      "Description Explicit": "No deductible for service•Plan Deductible not zero • Coinsurance applies • Out-of-Pocket Maximum applies • HMO covers in-network only.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
      
      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family However,service is not subject to the deductible.The coinsurance is [%] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, the patient is responsible for 100% of the provider's billed amount because the plan only covers services from in-network providers."
      },
      
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },

      "HMO: Not Subject to Deductible ;Plan deductible is  zero; Subject to  Coinsurance": {
      "Description Explicit": "No deductible for service•Plan Deductible is zero • Coinsurance applies • Out-of-Pocket Maximum applies • HMO covers in-network only.",
      "Description": "Member pays a coinsurance percentage for the service; amounts count toward the out-of-pocket maximum.",
      
      "scripting": {
        "In Network Provider Scripting": "The plan does not have a deductible.The coinsurance is [%X] of the allowed amount, and Blue Shield will  reimburse the provider for [remaining %] of the allowed amount.{{OOPM_LINE}} {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, the patient is responsible for 100% of the provider's billed amount because the plan only covers services from in-network providers."
      },
      
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },
    "HMO: Not Subject to Deductible ;Plan Deductible is not zero; Subject to Copay": {
        "Description Explicit": "No deductible applies for service/benefit •Plan deductible is not zero • Copay applies • HMO covers in-network only.",
      "Description": "Member pays a flat copay for the service; amounts count toward the out-of-pocket maximum.",
      
      "scripting": {
        "In Network Provider Scripting": "The plan has a [$X] deductible per person, not to exceed [$X] per family However, service is not subject to the deductible. The copay for [service] is [$X].[% OOPM_LINE] {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, the patient is responsible for 100% of the provider's billed amount because the plan only covers services from in-network providers."
      },
      
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },
	  "HMO: Not Subject to Deductible ;Plan Deductible is  zero; Subject to Copay": {
        "Description Explicit": "No deductible applies for service/benefit Subject to deductible is false •plan deductible is  zero • Copay applies • HMO covers in-network only.",
      "Description": "Member pays a flat copay for the service; amounts count toward the out-of-pocket maximum.",
      
      "scripting": {
        "In Network Provider Scripting": "The plan does not have a deductible. The copay for [service] is [$X].[% OOPM_LINE] {{LIMIT_LINE}}  ",
        "Out of Network Provider Scripting": "For out-of-network providers, the patient is responsible for 100% of the provider's billed amount because the plan only covers services from in-network providers."
      },
      
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount.",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  }
    },


    "HMO: Not Subject to Deductible ;Plan deductible is not zero; No Patient Liability(subjectToDeductible=='false')": {
      "guardrail": "Choose this template ONLY if plan deductible is not zero and structureType == 'No Charge' AND subjectToDeductible=='false' ",
      "Description Explicit": "No plan deductible •Plan deductible is not zero • No Charge• HMO covers in-network only.",
      "Description": "Member owes $0 for the covered service when using an in-network provider.",
       
           
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  },
      "scripting": {
        "In Network Provider Scripting":"The plan has a [$X] deductible per person, not to exceed [$X] per family However, service is not subject to the deductible. Blue Shield will reimburse the provider 100% of the allowed amount.[% oopm_line] ",
        "Out of Network Provider Scripting": "For out-of-network providers, the patient is responsible for 100% of the provider's billed amount because the plan only covers services from in-network providers."
      }
      
 
    },
	   "HMO: Not Subject to Deductible ; Plan deductible is  zero; No Patient Liability(subjectToDeductible=='false')": {
        "guardrail": "Choose this template ONLY if if structureType == 'No Charge' AND subjectToDeductible=='false' AND deductible is  zero",
      "Description Explicit": "No plan deductible •plan deductible is  zero •No Charge • HMO covers in-network only.",
      "Description": "Member owes $0 for the covered service when using an in-network provider.",
       
           
  "oopm_text": {
    "applies": "The service applies to the plan's out-of-pocket maximum amount of  [$X], not to exceed [$X] per family. When the plan's out-of-pocket maximum amount is satisfied, Blue Shield will reimburse the provider 100% of the allowed amount..",
    "does_not_apply": ""
  },
  "limit_text": {
    "applies": "This service has a limit of $LIMIT_COUNT per $LIMIT_PERIOD.",
    "does_not_apply": ""
  },
      "scripting": {
        "In Network Provider Scripting":"The plan does not have a deductible. Blue Shield will reimburse the provider 100% of the allowed amount.[% oopm_line] ",
        "Out of Network Provider Scripting": "For out-of-network providers, the patient is responsible for 100% of the provider's billed amount because the plan only covers services from in-network providers."
      }
      
 
    },

    "HMO: NAB or General Exclusion; plan deductible is not zero;": {
      "guardrail":"plan deductible is not zero;Choose this template ONLY if structureType == 'Not Covered' OR costShareText contains 'Not Covered",

    "Description Explicit":
      "[NOT-COVERED] Service is NOT covered • Plan pays 0% • Member pays 100% • "
      "Deductible, copay, coinsurance, and OOPM do NOT apply.",

  "Description":
    "This service is excluded from the plan. You would pay the full billed amount.",
      "scripting": {
        "In Network Provider Scripting": ".The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount."
      }
    },
    "HMO: NAB or General Exclusion; plan deductible is  zero;": {
      "guardrail":"plan deductible is  zero;Choose this template ONLY if structureType == 'Not Covered' OR costShareText contains 'Not Covered",

    "Description Explicit":
      "[NOT-COVERED] Service is NOT covered • Plan pays 0% • Member pays 100% • "
      "Deductible, copay, coinsurance, and OOPM do NOT apply.",

  "Description":
    "This service is excluded from the plan. You would pay the full billed amount.",
      "scripting": {
        "In Network Provider Scripting": "The service you are requesting is either not a benefit or it is an exclusion under your current policy. As the member, this means you are responsible for 100% of the billed amount."
      }
    },

    "HMO: Not Covered through OON/OOS Provider": {
      "Description Explicit": "Service must be obtained from an in-network or aligned provider • Out-of-network benefit is 0%.",
      "Description": "Member is responsible for the full billed amount if services are obtained out-of-network.",
      "scripting": {
        "In Network Provider Scripting": "- [Any additional maximum plan payment/allowance (defined by bscMaxText)]. ",
        "Out of Network Provider Scripting": "You must seek services from either an in-network provider or a provider associated with your provider group to be eligible for benefits. As the member, this means you are responsible for 100% of the billed amount."
      }
    },
  "SpecialCases": {
    "Emergency": {
      "guardrail": "service IN ('Emergency','Emergency room','Emergency services')",
      "Description Explicit": "Emergency services are covered at the in-network cost share even if treated by a non-participating provider, until stabilized.",
      "Description": "Emergency care is treated as in-network. If admitted to an out-of-network hospital, in-network benefits apply until stabilized and transferable.",
      "scripting": {
        "Member Scripting": "Emergency services are covered at your in-network cost share even if the hospital or provider is out-of-network. If admitted out-of-network, in-network benefits apply until you are stabilized and can be moved to an in-network facility. Check balance-billing protections per state/federal law."
      }
    },
    "Acupuncture / Chiropractic / Therapeutic Massage": {
      "guardrail": "service IN ('Acupuncture','Chiropractic','Therapeutic Massage')",
      "Description Explicit": "Discount program available via ChooseHealthy (American Specialty Health Group).",
      "Description": "Members can access discounted rates through ChooseHealthy providers.",
      "scripting": {
        "Member Scripting": "Discounts for service are available through the ChooseHealthy program provided by American Specialty Health Group. Visit https://www.blueshieldca.com/en/home/be-well/live-healthy to find a participating provider and what’s included."
      }
    },
    "Annual Physical (HMO)": {
      "guardrail": "benefitHeader ILIKE '%annual physical%' OR benefitCategory ILIKE '%preventive%'",
      "Description Explicit": "Medical group/IPA may apply a rolling 12-month schedule for routine physicals.",
      "Description": "HMO routine physicals may be on a rolling 12-month basis set by the medical group/IPA.",
      "scripting": {
        "Member Scripting": "Your medical group or IPA may limit routine physical exams using a rolling 12-month schedule. Check with your PCP/IPA for exact timing."
      }
    },
    "Inpatient Facility / Hospital": {
      "guardrail": "placeOfService IN ('Inpatient Hospital','Acute Care Hospital')",
      "Description Explicit": "Admission notification required; related professional fees billed separately.",
      "Description": "Hospitals must contact MCS after admission. Expect separate bills for professional services.",
      "scripting": {
        "Provider Scripting": "The facility must contact Medical Care Solutions (MCS) within 5 days of a scheduled admission or within 24 hours of an emergent admission at 1 (800) 541-6652 (say “Authorizations”). In addition to the hospital bill, members may receive separate professional bills for surgery, anesthesia, radiology, pathology, or laboratory services."
      }
    },
    "Outpatient Facility / Hospital": {
      "guardrail": "placeOfService IN ('Outpatient Hospital','Ambulatory Surgery Center')",
      "Description Explicit": "Related professional fees billed separately.",
      "Description": "Expect separate anesthesia/diagnostic fees.",
      "scripting": {
        "Member Scripting": "Besides the facility bill, you may also see separate professional charges for anesthesia and diagnostic testing (radiology or laboratory)."
      }
    },
    "Physical Therapy (All members)": {
      "guardrail": "service == 'Physical Therapy'",
      "Description Explicit": "PT programs available via Blue Shield of California.",
      "Description": "Members can access PT programs and resources.",
      "scripting": {
        "Member Scripting": "Blue Shield of California offers physical therapy programs. See details at https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Surgery": {
      "guardrail": "benefitCategory ILIKE '%surgery%' OR service ILIKE '%surgery%'",
      "Description Explicit": "Surgical package includes pre-op, day-of medical visits, and routine post-op care.",
      "Description": "Separate anesthesia/diagnostic fees may apply.",
      "scripting": {
        "Member Scripting": "In addition to the surgeon’s bill, you may see separate fees for anesthesia and diagnostic testing. A standard surgical package includes the procedure, pre-operative care, same-day medical visits, and routine uncomplicated follow-up."
      }
    },
    "Urgent Care (HMO)": {
      "guardrail": "benefitCategory ILIKE '%urgent care%' AND planType == 'HMO'",
      "Description Explicit": "Check PCP/IPA or Medical Group for in-network urgent care clinics within service area.",
      "Description": "HMO members should verify in-network urgent care locations with PCP/IPA/MG.",
      "scripting": {
        "Member Scripting": "If you need to visit an urgent care center and you are in your Medical Group Service Area, go to the urgent care center designated by your Medical Group or call your PCP. If you are outside of your Medical Group Service Area but within California and need urgent care, you may visit any urgent care center near you."
      }
    },
    "Hearing Aids (Discount Program)": {
      "guardrail": "benefitCategory ILIKE '%hearing%' OR service ILIKE '%hearing aid%'",
      "Description Explicit": "Discount program via EPIC Hearing Healthcare.",
      "Description": "Members can access hearing aid discounts.",
      "scripting": {
        "Member Scripting": "A discount program is available through EPIC Hearing Healthcare. Learn more at https://www.blueshieldca.com/en/home/be-well/live-healthy/hearing-aid-discount."
      }
    },
    "Fitness / Gym / Exercise": {
      "guardrail": "benefitCategory ILIKE '%fitness%' OR service ILIKE '%gym%'",
      "Description Explicit": "Gym and digital fitness discounts available.",
      "Description": "Members can access fitness discount programs.",
      "scripting": {
        "Member Scripting": "Blue Shield of California offers gym membership discounts and digital fitness programs. See https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Vision (Vendor present)": {
      "guardrail": "visionVendor IS NOT NULL",
      "Description Explicit": "Vision benefits administered by a third-party administrator.",
      "Description": "Contact the administrator for details, coverage, and providers.",
      "scripting": {
        "Member Scripting": "This member’s [benefit type] benefits are administered by [administrator]. Let me give you their toll-free number."
      }
    },
    "Vision (All members)": {
      "guardrail": "benefitCategory ILIKE '%vision%'",
      "Description Explicit": "Discount vision program available to members.",
      "Description": "Members can access discounted vision services.",
      "scripting": {
        "Member Scripting": "A discount vision program is available to Blue Shield members. Learn more at https://www.blueshieldca.com/en/home/be-well/live-healthy."
      }
    },
    "Pharmacy (Tiering & OOP only)": {
      "guardrail": "benefitCategory ILIKE '%pharmacy%' OR benefitCategory ILIKE '%drug%'",
      "Description Explicit": "Show tiered pharmacy benefits and pharmacy-specific OOP information.",
      "Description": "Include tier information (Preferred/Non-Preferred/Generic/Specialty) and any pharmacy OOP caps.",
      "scripting": {
        "Member Scripting": "Your pharmacy benefits vary by tier (e.g., Generic, Preferred Brand, Non-Preferred Brand, Specialty). [Display member cost share per tier and any pharmacy-specific out-of-pocket maximum or caps.]"
      }
    },
    "Dental (Vendor present)": {
      "guardrail": "dentalVendor IS NOT NULL",
      "Description Explicit": "Dental benefits administered by a third-party administrator.",
      "Description": "Contact the administrator for coverage details and providers.",
      "scripting": {
        "Member Scripting": "This member’s [benefit type] benefits are administered by [administrator]. Let me give you their toll-free number."
      }
    }
  }
}
}

# COMMAND ----------

generic_template={"PPO":"","HMO":"The patient must receive services from either an in-network provider or a provider associated with their medical group to be eligible for benefits. A referral from the patient's primary care physician (PCP)  is usually required when the patient wants to see a specialist or other provider, but there are some exceptions."}

# COMMAND ----------

def extract_bsc_maxtext_block(text):
    text = json.dumps(text)
    # Find the position of "bscMaxInterval"
    if "bscMaxInterval".lower() not in text.lower():
        print("Keyword 'bscMaxInterval' not found in the text.")
        return None
    else:
        print('Keyword "bscMaxInterval" found in the text.')
        bsc_pos = text.find("bscMaxInterval")
        # Find the preceding "[{" before "bscMaxInterval"
        start = text.rfind('[{', 0, bsc_pos)
        if start == -1:
            print("Could not find the starting delimiter '[{' before 'bscMaxInterval'.")
            return None
        # Find the first "}]"" after "bscMaxInterval"
        end = text.find('}]', bsc_pos)
        if end == -1:
            print("Could not find the ending delimiter '}]' after 'bscMaxInterval'.")
            return None
        end += 2  # Include the "}]"
       
        return text[start:end]
    
def exclusive_check_prompt(prompt_key, additional_data, previous_response):
    prompts = {
        "max_text": f"""
You are a Health Insurance Agent. Your task is to enhance the provided answer by adding a concise, user-friendly summary of the 'providerCostShares' information.

Instructions:
- Do not repeat or restate details already present in the original answer.
- Do not add a new section or heading.
- Instead, add 1-2 sentences at the end of the original answer that clearly explain, in plain language, what the 'providerCostShares' mean for the user.But don't include the keywork 'providerCostShares', it just for you to get the context.
- Focus on the practical impact for the user (e.g., what they will pay, what is covered, any important limits).
- Do not include raw JSON, code, or bullet points; use only plain text.
- The summary should blend naturally with the original answer and help the user understand the main takeaway.

Inputs:
- Original Answer:
{previous_response}

- Raw providerCostShares text:
{additional_data}

Return the improved answer with the summary appended at the end, making sure it reads as a natural conclusion to the original answer.
"""
    }
    return prompts[prompt_key]

# COMMAND ----------

def generate_ppo_prompt(question, plan_type, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse excluded;skilled home health covered”).

   c. Pure exclusion.
      If no benefit is found and an exclusion clearly matches, return exactly:
      “The [service] you are requesting is an exclusion under your current policy.”

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.

    If not excluded,** continue with the standard template-based generation**.
1. Always refer in network and out network separately from the template for the spcific service.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.
4. Use clear, simple language suitable for users with no technical background.
5. If the query involves multiple service types or settings e.g., (standalone vs. hospital),(outpatient radiology center vs outpatient department of hospital) or facility vs. physician, write a separate breakdown for Participating and Non-Participating providers.
6. For each service setting, provide a separate section.e.g., (freestanding vs. hospital urgent care),(outpatient radiology center vs outpatient department of hospital))
7.Analyze the question intelligently and answer it.For e.g (if the question asks Telehealth consultation, also looks for teladoc service as well.)
8.Do not collapse or omit variants that share the same broad category.  
  – If several distinct “flavors” of the benefit exist (e.g., standard vs. non-standard contact lenses, elective vs. medically-necessary lenses, fitting vs. supply, professional vs. facility, hospital vs. freestanding), treat each as its own **separate section** in the response.  
  – Use the exact wording from `benefit_header` or `description` to craft clear section titles, so the user can see every covered option.  
  – Letter the sections A., B., C.… in the order they appear in the data.  
  – **Never stop after the first matching benefit** if additional variants remain in the same data block.
9.Always follow the template while answering.
10.Deductible Rule:For each benefit, strictly **determine separately for In-network and Out-of-network** from the template(refer ppo_in and ppo_out separately).From the scripting, choose the correct template for the service and strictly fill the values accordingly.Do not keep the "[$X]" placeholder" in your answer.
11. If the service is not an exclusion in the plan,Try to frame the response in natural language as well by analyzing the question. For e.g:for question Do I need to have a Primary Care Physician?, answer could be yes/no followed by a short text. Notes or additional information should be at the end of the repsonse.
12.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.


</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure:

A. [Service Setting] (e.g., Hospital-Based Urgent Care)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) if any and any additional information]
IMPORTANT:1.If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.
          2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

B. [Service Setting] (e.g., Services Outside Your Physician’s Service Area)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.
          
2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT:1.If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.
          2.For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

At the very end, add the content from special cases and include only those entries from SpecialCases whose guardrails match the current query/context; if none match, omit this section.Do not print the title “Special Cases (if applicable)” — just append the matching special case text naturally at the end for coverage and exclusions as well.
Only plain text / Markdown. No JSON, no placeholders.
</RESPONSE FORMAT>
"""



# COMMAND ----------

def generate_hmo_prompt(question, plan_type, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse excluded;skilled home health covered”).

   c. Pure exclusion.
      If no benefit is found and an exclusion clearly matches, return exactly:
      “[Service name]\nThe [service] you are requesting is an exclusion under your current policy.This means that the patient would be responsible for 100% of the billed amount.”

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.

    If not excluded,** continue with the standard template-based generation**.
1. Answer only the specific user query. Do not include assumptions or external information.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.
4. Use clear, simple language suitable for users with no technical background.
5. If the query involves multiple service types or settings e.g., (standalone vs. hospital),(outpatient radiology center vs outpatient department of hospital) or facility vs. physician, write a separate breakdown for Participating and Non-Participating providers.
6. For each service setting, provide a separate section.e.g., (freestanding vs. hospital urgent care),(outpatient radiology center vs outpatient department of hospital),(Emergency Room Visit vs Emergency Room Physician Services vs Emergency Room Services Resulting in Admission))
7.Analyze the question intelligently and answer it.For e.g (if the question asks Telehealth consultation,provide the answer for both Teladoc and Teleconsultation service as well.),(for specialist visit, include trio-specialist visit as well)
8.Do not collapse or omit variants that share the same broad category.  
  – If several distinct “flavors” of the benefit exist (e.g., standard vs. non-standard contact lenses, elective vs. medically-necessary lenses, fitting vs. supply, professional vs. facility, hospital vs. freestanding), treat each as its own **separate section** in the response.  
  – Use the exact wording from **`benefit_header` or `description`** to craft clear section titles, so the user can see every covered option.  
  – Letter the sections A., B., C.… in the order they appear in the data.  
  – **Never stop after the first matching benefit** if additional variants remain in the same data block.
9.Always follow the template while answering.
10.Deductible Rule:If plan has deductible and a specific service is not subject to deductible,never say "The Plan does not have deductible" and do not add any out of pocket maximum line.From the scripting, choose the correct template for the service and strictly fill the values accordingly.Do not keep the "[$X]" placeholder" in your answer.
11.Referral rule:
   - append the line “The patient does not need a referral for this service.” strictly and only if the benefit/service clearly belongs to one of these categories:
       • Emergency Services
       • Urgent Services
       • Trio visits
       • OB/GYN services by an obstetrician, gynecologist, or family practice physician within the patient’s Medical Group
       • Office visits with the patient’s Primary Care Physician (PCP)
       • Outpatient Mental Health and Substance Use Disorder services.

   - Do NOT include this line for imaging (e.g., MRI, CT, X-ray), diagnostic tests,Pediatric vision, or specialist visits unless explicitly stated in plan data.
12. If the service is not an exclusion in the plan,Try to frame the response in natural language as well by analyzing the question. For e.g:for question Do I need to have a Primary Care Physician?, answer could be yes/no followed by a short text. Notes or additional information should be at the end of the repsonse.
13.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.


</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure:

A. [Service Setting] (e.g., Hospital-Based Urgent Care)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) if any and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

B. [Service Setting] (e.g., Services Outside Your Physician’s Service Area)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

At the very end, add the content from special cases and include only those entries from SpecialCases whose guardrails match the current query/context/response. for e.g (chiropractor maps to chiropractice); if none match, omit this section.Do not print the title “Special Cases (if applicable)” — just append the matching special case text naturally at the end for coverage and exclusions services as well.
Only plain text / Markdown. No JSON, no placeholders.
</RESPONSE FORMAT>
"""



# COMMAND ----------


def generate_hmo_access_prompt(question, plan_type,plan_name, data, scripting_format):  # Use your stable HMO prompt here
    return f"""
<ROLE>
You are a Health Insurance Agent. Your role is to answer user queries using both the user’s personal question and the structured plan data.
</ROLE>

<INSTRUCTION>
Given the user query: {question}

Use the following information to formulate your answer:
- Insurance plan data: {data}

Your response must rely **only** on the provided data and follow the formatting and guidelines below.
</INSTRUCTION>

<GUIDELINES>
0. Exclusion Decision (Concise Rule Set)

   a. Search both Benefits and Exclusions for the service.
      Look at titles and descriptions — use exact or close matches first.

   b. Benefit > Exclusion.
      If any matching benefit exists, analyze and check if it as covered or conditionally covered,if partially covered for few services
      summarize its cost share, and mention only related limits strictly following the template provided.
      (e.g., “private duty nursing/Private home health care nurse excluded;skilled home health covered”).

   c. Pure exclusion.
      If no benefit is found and an exclusion clearly matches, return exactly:
      “The [service] you are requesting is an exclusion under your current policy.”

   d. Conflict handling.
      When both match:
         If the exclusion is generic (“home services,” “cosmetic”),
         and the benefit is specific (“Home Health Services,” “Reconstructive Surgery”),
         show it as covered with limit strictly following the template provideds.
         If the exclusion explicitly says “not covered except when…” — treat that
         “except” condition as conditionally covered strictly following the template provided.
         

      Output.
      End with a brief note if limits/exclusions apply.
      Use the exclusion line only when nothing in Benefits covers the topic.

    If not excluded,** continue with the standard template-based generation**.
1. Answer only the specific user query. Do not include assumptions or external information.
2. Treat “HMO Provider” and “In-network Provider” and **Participating Provider** as **“In-network Provider”**.
3. Treat “Out-network Provider” and “Non-Participating Provider” as **“Out-of-network Provider”**.
4. Use clear, simple language suitable for users with no technical background.
5. If the query involves multiple service types or settings e.g., (standalone vs. hospital),(outpatient radiology center vs outpatient department of hospital) or facility vs. physician write a separate breakdown for Participating and Non-Participating providers.
6. For each service setting, if the question asks about surgery, provide cost share for procedure and surgery separately.
7.Analyze the question intelligently and answer it.For e.g (if the question asks Telehealth consultation, also looks for teladoc service as well.),(if the questions ask about surgery that do not require overnight stay such as cataract, provide ambulatory surgery center services cost share and provide procedure and surgery cost differently)
8.Do not collapse or omit variants that share the same broad category.  
  – If several distinct “flavors” of the benefit exist (e.g., standard vs. non-standard contact lenses, elective vs. medically-necessary lenses, fitting vs. supply, professional vs. facility, hospital vs. freestanding), treat each as its own **separate section** in the response.  
  – Use the exact wording from `benefit_header` or `description` to craft clear section titles, so the user can see every covered option.  
  – Letter the sections A., B., C.… in the order they appear in the data.  
  – **Never stop after the first matching benefit** if additional variants remain in the same data block.
9.Always follow the template while answering.
10.Deductible Rule:If plan has deductible and a specific service is not subject to deductible,never say "The Plan does not have deductible" and do not add any out of pocket maximum line.From the scripting, choose the correct template for the service and strictly fill the values accordingly.Do not keep the "[$X]" placeholder" in your answer.
11.Referral rule:
   - Strictly, append the line “The patient does not need a referral for this service.”if the benefit/service clearly belongs to one of these categories:
       • Emergency Services
       • Urgent Services
       • Trio visits
       • OB/GYN services by an obstetrician, gynecologist, or family practice physician within the patient’s Medical Group
       • Office visits with the patient’s Primary Care Physician (PCP)
       • Outpatient Mental Health and Substance Use Disorder services.

   - Do NOT include this line for imaging (e.g., MRI, CT, X-ray), diagnostic tests,Pediatric vision, or specialist visits unless explicitly stated in plan data.
12.If the service is not an exclusion in the plan,Try to frame the response in natural language as well by analyzing the question. For e.g:for question Do I need to have a Primary Care Physician?, answer could be yes/no followed by a short text. Notes or additional information should be at the end of the repsonse.
13.**Before you send your answer:**  
    • Scan your draft.  
    • **If you still see any placeholder mark (anything inside [ ] or < > or [$X]), regenerate that part** until every placeholder is replaced with a real value or with “information not available”.  
    • Under no circumstances return an answer that contains an unreplaced placeholder.Only send the valid answer.


</GUIDELINES>

<RESPONSE FORMAT>
When responding, use the following values [Copay/Benefit/Cost Share, Coinsurance, Out of pocket Maximum (OOPM), Deductibility] to decide the structure to respond with and return the corresponding response format. Do include any additional details on the service regarding information from <SERVICE_DETAILS> content. If the query involves multiple services or settings, format each as its own labeled section (A, B, C, etc.) with both network types included under each.

{scripting_format}

From the scripting format I want the answer in the below structure:

A. [Service Setting] (e.g., Hospital-Based Urgent Care)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) if any and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

B. [Service Setting] (e.g., Services Outside Your Physician’s Service Area)  
1. **In-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance(bscMaxText) and any additional information]
IMPORTANT:If service has  no cost share(copay/coinsurance) , do not include OOPM line in your answer.

2. **Out-of-network Provider:**  
[output from scripting format filled with the relevant values in sequence deductible from 'deductible_text' ->Copay/Cost Share/Coinsurance->Out of pocket Maximum (OOPM)/Maximum allowance->bscMaxText if any and any additional information]
IMPORTANT: For emergency/Ambulance benefit/service, do not include **Out-of-network Provider:** section as it is covered by in-network provider.(Note:Ambulance services are part of emergency service)

At the very end, add the content from special cases and include only those entries from SpecialCases whose guardrails match the current query/context; if none match, omit this section.Do not print the title “Special Cases (if applicable)” — just append the matching special case text naturally at the end for coverage and exclusions as well.
Only plain text / Markdown. No JSON, no placeholders.
</RESPONSE FORMAT>
"""



# COMMAND ----------



catalog: str = f"dev_adb"
silver_schema="nexusbenefitsquote_silver_mvp1"

benefit_index_name="dev_adb.nexusbenefitsquote_silver_mvp1.tbl_eoc_categories_index"


# ─────────────────────────────────────────────────────────────────────────────
# Configuration and Globals
# ─────────────────────────────────────────────────────────────────────────────
VS_ENDPOINT    = "benefits_quote_test"
BENEFIT_INDEX  = "dev_adb.nexusbenefitsquote_gold_mvp1.tbl_eoc_categories_index"
PROGRAM_INDEX= "dev_adb.nexusbenefitsquote_silver_mvp1.tbl_eoc_program_categories_index"
EXCLUSION_INDEX= "dev_adb.nexusbenefitsquote_silver_mvp1.tbl_eoc_sections_index"

#DEFAULT_PLAN = "60 PFO"  # Default plan if none detected
#dev_adb.nexusbenefitsquote_silver_mvp1.tbl_plan_details_index
PLAN_INDEX     = "dev_adb.nexusbenefitsquote_silver_mvp1.tbl_plan_details"

vsc   = VectorSearchClient()

LLM_ENDPOINT   = "accenture-azure-gpt-4o-2024-08-06-sp"

#"azure-gpt-4o-2024-08-06-call-qa"

#"accenture-azure-gpt-4o-2024-08-06-sp"


# COMMAND ----------

from typing import ClassVar, Type, List
from pydantic import BaseModel, Field
import json, ast, re

# --- Args schema ---
class ClassifyIntentArgs(BaseModel):
    input: str = Field(..., description="Original user question")

# --- Known intents (exact, case-sensitive as emitted by the prompt) ---
KNOWN_INTENTS = {
    "PlanCostShares",
    "BenefitCostShares",
    "EoCCategory",
    "EoCSection",
    "ProgramCategories",
    "GenericDefinition",
    "Exclusions",
}

def _coerce_json(text: str) -> dict:
    """
    Try JSON first; if that fails, try Python-literal (for when a model returns a Python dict).
    """
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        # Remove common accidental code fences
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
        try:
            return json.loads(text)
        except Exception:
            try:
                return ast.literal_eval(text)
            except Exception as e:
                raise ValueError(f"Unable to parse model output as JSON/dict: {e}\nRAW:\n{text[:500]}")

def _normalize_intents(raw_intent) -> List[str]:
    """
    Accepts a string (single or comma-separated) or a list. Returns a cleaned list filtered to KNOWN_INTENTS.
    """
    if raw_intent is None:
        return []
    if isinstance(raw_intent, str):
        parts = [p.strip() for p in raw_intent.split(",") if p.strip()]
    elif isinstance(raw_intent, list):
        parts = [str(p).strip() for p in raw_intent if str(p).strip()]
    else:
        parts = [str(raw_intent).strip()]
    # Keep only valid intents, preserve original case if matches known set (case-insensitive match allowed)
    normalized = []
    for p in parts:
        # exact match first
        if p in KNOWN_INTENTS:
            normalized.append(p)
            continue
        # case-insensitive match
        for ki in KNOWN_INTENTS:
            if p.lower() == ki.lower():
                normalized.append(ki)
                break
    # de-dup while preserving order
    seen = set()
    out = []
    for i in normalized:
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out

class ClassifyIntentTool(StructuredTool):
    name: ClassVar[str] = "ClassifyIntent"
    description: ClassVar[str] = (
        "Classifies a user question and expands known terms. Returns ExpandedQuestion, FollowUp, and Intent(s)."
    )
    args_schema: ClassVar[Type[BaseModel]] = ClassifyIntentArgs

    @mlflow.trace(name="ClassifyIntent_run", span_type="tool")
    def _run(self, input: str) -> dict:
        # Prompt: force strict JSON with fixed keys
        prompt = f"""
You are an insurance intent classification agent designed to identify the type of user question about a health insurance plan and expand common abbreviations/aliases to canonical benefit names for clarity.

STRICT OUTPUT INSTRUCTIONS:
- Respond with a single JSON object only (no prose, no code fences).
- Keys must be exactly: "ExpandedQuestion", "FollowUp", "Intent".
- "Intent" MUST be either a JSON array of strings or a single string. (Array is preferred.)
- "FollowUp" MUST be "Yes" or "No".

STEP 0: NORMALIZE & EXPAND TERMS (do this first)
Expand known abbreviations at their first occurrence using parentheses (append only; do not change original words).
Case-insensitive. Expand each unique term only once.
Canonical map:
- PCP -> Primary Care Physician
- Infertility -> Infertility - Assisted Reproductive Benefits
- homedialysis -> Dialysis care benefits
-Telehealth Consulatation-

Examples:
"what is my cost share of PCP" -> "what is my cost share of Primary Care Physician"
"am I covered for infertility treatments?" -> "am I covered for infertility - Assisted Reproductive Benefits treatments?"

If no terms match, ExpandedQuestion must equal the original input verbatim.

STEP 1: DETERMINE IF THIS IS A FOLLOW-UP
A follow-up depends on prior context, continues an earlier topic, or would be confusing alone.
Return "Yes" or "No".

STEP 2: CLASSIFY THE INTENT(S) (return one or more)
A single question may contain multiple intents.  
Return one or more intents separated by commas.  
Never invent new ones. Always return at least one.
Available intents:
1. PlanCostShares  
→ Plan-level cost details.  
Includes deductible (per person/family), out-of-pocket maximum, accumulator type, HSA eligibility, INN/OON deductible, or plan-level coinsurance.  
Keywords: deductible, OOP max, accumulator, embedded, aggregate, HSA, plan type.  
Examples:  
- “What is the deductible for this plan?”  
- “Is this plan HSA-eligible?”
2. BenefitCostShares  
→ Service-level cost sharing (specific copay or coinsurance).  
Includes ER copay, per-visit copay, coinsurance %, waived if admitted, etc.  
Keywords: copay, coinsurance, ER, per-visit, per-admission, OOP applies.  
Examples:  
- “What is the ER copay?”  
- “How much does a specialist visit cost?”
- “Can I get second opinion from another doctor?
3. EoCCategory  
→ Whether a category/service is covered or included at all.  
Keywords: cover, included, benefit name (maternity, infertility, DME, mental health, vision, preventive,telehealth).  
Examples:  
- “Does this plan cover infertility treatment?”  
- “Is preventive care included?”  
- “Are DME items covered?”
--“Is telehealth an option on this plan?”
4. EoCSection  
→ Detailed rules, limits, or conditions under a covered benefit.  
Includes: prior authorization, step therapy, referral, visit/frequency limits, waiting periods, medical necessity, conditional coverage.  
Keywords: prior auth, pre-cert, referral, limit, step therapy, medically necessary, authorization required.  
Examples:  
- “Is prior authorization required for MRI?”  
- “Are PT visits limited to 30 per year?”
5. ProgramCategories  
→ Add-on or wellness programs and vendor-based offerings.  
Includes: nurse line,out of state,out of californial, travelling coverage telehealth, case management, advocacy, BlueCard, EAP, disease management, diabetes program.  
Keywords: nurse line, telehealth, concierge, case management, BlueCard, EAP, wellness program.  
Examples:  
- “Does this plan have a nurse hotline?”  
-"Am I covered out of sate?"
-"Am I covered while travelling?"
- “Is there a diabetes management program?”
-"Can I talk to a nurse?"
6. GenericDefinition  
→ Definitions of insurance or healthcare terms.  
Keywords: what is, define, explain, meaning of.  
Examples:  
- “What is a deductible?”  
- “Explain out-of-pocket maximum.”
7. Exclusions  
→ Items, services, or drugs that are NOT COVERED under the plan — permanently or conditionally.  
Includes cosmetic or elective procedures, experimental services, OTC drugs, vitamins, supplies, or limitations listed under Exclusions & Limitations.  
Keywords: excluded, not covered, exclusion list, exception, limitation, not payable, not eligible, experimental, cosmetic, over-the-counter.  
Examples:  
- “Are over-the-counter drugs excluded?”  
- “Am I covered out of state?”
- “Is cosmetic surgery not covered?”  
- “Which services are under exclusions?”  
- “Are infertility treatments excluded?”  
- “Is acupuncture excluded?”
-------------------------------
EXCLUSIONS vs COVERAGE RULE
-------------------------------
If question asks:
- “Covered(not out of state/travelling)/included?” → EoCCategory  
- “Excluded/not covered/covered(out ofstate)/exception?” → Exclusions  
- Both coverage & exclusion → EoCCategory, Exclusions  
- Coverage + rule (prior auth, limit) → EoCCategory, EoCSection  
- Excluded with condition (“unless medically necessary”) → Exclusions, EoCSection  
- If ambiguous, default to EoCCategory.


RETURN EXAMPLE (JSON):
{{
  "ExpandedQuestion": "what is my cost share of PCP (Primary Care Physician)",
  "FollowUp": "No",
  "Intent": ["BenefitCostShares"]
}}

Now classify this input:
{json.dumps(input)}
""".strip()

        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
        raw = llm.invoke([HumanMessage(content=prompt)])

        # Parse robustly
        payload = _coerce_json(raw.content)

        # Extract fields with safe defaults
        expanded = payload.get("ExpandedQuestion", input) or input
        followup = payload.get("FollowUp", "No")
        intent = _normalize_intents(payload.get("Intent"))

        # Safety defaults if model went off-spec
        if followup not in {"Yes", "No"}:
            followup = "No"
        if not intent or "EoCSection" in intent:
            # If truly nothing recognized, default to EoCCategory per rule
            intent = ["EoCCategory"]

        result = {
            "expanded_question": expanded,
            "followup": followup,
            "intent": intent,
        }
        print("ClassifyIntentTool result ->", result)
        return result


# COMMAND ----------

class GenerateAnswerArgs(BaseModel):
    question: str = Field(..., description="User question")
    plan_meta: str = Field(..., description="Plan-wide metadata (JSON string)")
    plan_type: str = Field(..., description="plan_type")
    plan_name: str = Field(..., description="Plan name")
    intent: Optional[list] = None
    exclusion: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Exclusions list (parsed)"
    )
    cost_share: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Benefits list (parsed)"
    )
    def_cost_share: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list, description="Definition cost share list (parsed)"
    )
    program_details: Optional[List[Dict[str, Any]]] = Field(default_factory=list, description="Program details list (parsed)"),


class GenerateAnswerTool(StructuredTool):
    name: ClassVar[str] = "GeneratePlanAnswer"
    description: ClassVar[str] = "Merge cost-share details, templates, exclusion and plan metadata into final Markdown."
    args_schema: ClassVar[Type[BaseModel]] = GenerateAnswerArgs

    @mlflow.trace(name="GenerateAnswer_run", span_type="tool")
    def _run(
        self,
        question: str,
        plan_meta: str,
        plan_type: str,
        plan_name: str,
        intent: Optional[list] = None,
        exclusion: Optional[List[Dict[str, Any]]] = None,
        cost_share: Optional[List[Dict[str, Any]]] = None,
        def_cost_share: Optional[List[Dict[str, Any]]] = None,
        program_details:Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        # Safe defaults for optional args
        exclusion = exclusion or []
        cost_share = cost_share or []
        def_cost_share = def_cost_share or []

        # ----- Program Categories -----
        if  "ProgramCategories" in intent:
         
            program_categories_json={"ProgramCategories": program_details}
            print(type(program_details))
            print(program_categories_json)

            if plan_type == "HMO":
                prompt = f"""
                You are a Health Plan Program Assistant.

                Use only the provided Program Categories data to answer the user question.

                User Question: {question}  
                data:{program_details}   

                Rules:
                1. Identify if the question matches a program (e.g., “talk to a nurse” → Nurse Advice Line, 24/7 Nurse Line, Nurse Hotline, etc.).
                2. If a matching program exists, summarize:
                • Program name and purpose  
                • How to access (phone/app)  
                • Availability or hours  
                • Cost (if given)
                3. If marked as excluded or not covered, reply exactly:
                “This service is not covered under the plan.”
4. If no matching program exists, reply:
   “This information isn’t available in the provided program data. Please contact Member Services for help.”
5. Use only plain text or simple bullets, no JSON, no placeholders.
"""
                llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
                resp = llm.invoke([HumanMessage(content=prompt)])
                return resp.content.strip()

            elif plan_type == "PPO":
                # Expecting you have the helper defined elsewhere:
                # def check_bluecard_program(program_data_list): -> bool
                is_bluecard = check_bluecard_program(cost_share)
                if is_bluecard:
                    return (
                        "Under the BlueCard® Program, when you receive Out-of-Area Covered Health Care Services within "
                        "the geographic area served by a Host Blue, Blue Shield will remain responsible for the provisions "
                        "of this Agreement. However, the Host Blue is responsible for contracting with and generally handling "
                        "all interactions with its participating healthcare providers, including direct payment to the provider. "
                        "The BlueCard® Program enables you to obtain Out-of-Area Covered Health Care Services, as defined above, "
                        "from a health care provider participating with a Host Blue, where available. The participating health care "
                        "provider will automatically file a claim for the Out-of-Area Covered Health Care Services provided to you."
                    )
                else:
                    return (
                        "This Blue Shield plan provides limited coverage for health care services received outside of the Plan "
                        "Service Area. Out-of-Area Covered Health Care Services are restricted to Emergency Services, Urgent Services, "
                        "and Out-of-Area Follow-up Care. Any other services will not be covered when processed through an Inter-Plan "
                        "Arrangement unless prior authorized by Blue Shield."
                    )

        # ----- Concept/Definition questions -----
        elif "GenericDefinition" in intent:
            data = {
                "plan_data": plan_meta,
                "benefits": def_cost_share or cost_share,
            }

            prompt = f"""
<ROLE>
You are a Health Insurance Agent. Explain key insurance terms using only the attached plan and cost-share data.
When users ask “What is deductible?” or similar, define the term clearly and describe how it appears in this plan.
</ROLE>

<INSTRUCTION>
User question: {question}

Use this information:
{json.dumps(data, ensure_ascii=False)}
Rely only on the given plan details — no external definitions.
</INSTRUCTION>

<GUIDELINES>
• Start with a short, plain-language definition.
• Then in next line add how it applies in this plan (values, tiers, limits, etc.).

</GUIDELINES>

<RESPONSE FORMAT>
Write one short paragraph combining the definition and plan-specific explanation in natural language.
</RESPONSE FORMAT>
"""
            llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
            response = llm.invoke([HumanMessage(content=prompt)])
            return response.content.strip() or "[EMPTY RESPONSE]"

        # ----- Benefit Cost Shares -----
        elif "BenefitCostShares" in intent or "EoCCategory" in intent:
            try:
                scripting_key = "HMO" if "HMO" in plan_type else "PPO"
                templates = template_json[scripting_key]
                scripting_format = json.dumps(templates, indent=4)

                data = {
                    "plan_data": plan_meta,
                    "benefits": cost_share,
                    "exclusion": exclusion,
                }
            except Exception as e:
                print(e)
                return (
                    "We are unable to find relevant benefit details in the current plan "
                    "data to answer this question accurately."
                )

            if plan_type == "HMO" and "access+" not in plan_name.lower():
                prompt = generate_hmo_prompt(
                    question, plan_type, data, scripting_format
                )
            elif plan_type == "HMO" and "access+" in plan_name.lower():
                prompt = generate_hmo_access_prompt(
                    question, plan_type, plan_name, data, scripting_format
                )
            else:  # PPO
                prompt = generate_ppo_prompt(
                    question, plan_type, data, scripting_format
                )

            llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
            response = llm.invoke([HumanMessage(content=prompt)])

            final_llm_response = response.content.strip() or "[EMPTY RESPONSE]"
            max_text=""
            maxt_text=extract_bsc_maxtext_block(data)
            if max_text is not None and max_text !='':
                prompt_ex=exclusive_check_prompt("max_text",max_text, response.content.strip())
                response= llm.invoke([HumanMessage(content=prompt_ex)])
            generic_line = generic_template.get(plan_type, "")

            # Prepend HMO generic line unless emergency/not-covered
            if (
                plan_type == "HMO"
                and "emergency" not in final_llm_response.lower()
                and "the service you are requesting is either not a benefit" not in final_llm_response.lower()
                and "exclusion under your current policy" not in final_llm_response.lower()
                and "not covered under your current policy" not in final_llm_response.lower()
            ):
                final_answer = f"Plan: {plan_name}\n\n{generic_line}\n\n{final_llm_response}"
            else:
                final_answer = f"Plan: {plan_name}\n\n{final_llm_response}"

            return final_answer

        # ----- Fallback if intent missing or unsupported -----
        return (
            "Sorry, I couldn't determine how to answer this with the provided intent. "
            "Please try rephrasing your question."
        )


# COMMAND ----------

class FallbackArgs(BaseModel):
    question: str = Field(..., description="Original or expanded user question")


class FallbackAgentTool(StructuredTool):
    name: ClassVar[str] = "FallbackAgent"
    description: ClassVar[str] = (
        "Handles queries that are neither cost-share nor benefits. "
        "Simply replies that the question is outside scope, or asks for clarification."
    )
    args_schema: ClassVar[Type[BaseModel]] = FallbackArgs

    def _run(self, question: str) -> str:
        prompt = f"""
You are a health-insurance assistant.

The user asked a question that does not match cost-share or benefits look-up.

Politely respond in one sentence, either:
• apologising that you can’t answer, OR
• asking a clarifying follow-up question
so you can route them correctly next time.

User question: "{question}"
"""
        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0.2)
        resp = llm.invoke([HumanMessage(content=prompt)])
        return resp.content.strip()
    

# COMMAND ----------

import json
import re
import logging



def vs_search(
    q: str,
    nexus: int | None,
    k: int,
    index_name: str,
    columns: list[str] | None = None,
    score_threshold: float | None = None,
    filters: dict[str, Any] | None = None,
    rerank_column:str=None,
) -> list[dict[str, Any]]:
    if columns is None:
        columns = ["benefit_id", "search_text"]

    # build filters safely
    if filters is not None:
        search_filters = filters
    elif nexus is not None:
        search_filters = {"nexusId": int(nexus)}
    else:
        search_filters = None      
                     

    idx = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=index_name)
   
    raw = idx.similarity_search(
        query_text=q,
        num_results=k,
        #query_type="hybrid",
        
        filters=search_filters,
        reranker=DatabricksReranker(
        columns_to_rerank=[rerank_column]
    ),
           
        columns=columns,
        score_threshold=score_threshold,
    )


    result = raw.get("result", raw)
    cols   = result.get("column_names", columns)
    rows   = result.get("data_array", [])

    out = []
    for r in rows:
        row = {cols[i]: r[i] for i in range(len(cols))}  # keep everything
        row["id"]   = row[cols[0]]      
        row["text"] = row[cols[1]]      
        out.append(row)
  
    return out

# COMMAND ----------

# Standard library imports
import sys
import os
import json
import yaml
import re
import logging
import mlflow
from uuid import uuid4
from typing import *
from dataclasses import asdict

# Third-party imports
import pandas as pd
from pydantic import BaseModel, Field
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode, concat_ws, struct


# Databricks sdk import
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementParameterListItem

# LangChain / LangGraph imports
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import StructuredTool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# Databricks imports
from databricks_langchain import ChatDatabricks
from databricks.vector_search.client import VectorSearchClient
from databricks.vector_search.reranker import DatabricksReranker
from tool_desc.core.config_store import ConfigStore
from tool_desc.core.vector_search import *
from databricks.sdk import WorkspaceClient
from tool_desc.core.config_store import ConfigStore
def get_warehouse_id_by_name(warehouse_name: str):
    client = WorkspaceClient()
    warehouses = client.warehouses.list()  # returns list of SQL warehouses

    for wh in warehouses:
        if wh.name == warehouse_name:
            return wh.id

    raise ValueError(f"Warehouse '{warehouse_name}' not found")

class PlanDetectArgs(BaseModel):
    facets_product_id: str = Field(..., description="facets_product_id")
    effective_date: str = Field(..., description="effective_date")

class PlanDetectTool(StructuredTool):
    name: ClassVar[str] = "PlanDetect"
    description: ClassVar[str] = (
        "Detect the health‑plan the user is asking about. "
        "Returns BOTH plan_nexus and its plan_cost_share JSON."
    )
    args_schema: ClassVar[Type[BaseModel]] = PlanDetectArgs

    #plan_summary_index_name="tbl_plan_summary_index"
    @mlflow.trace(name="PlanDetect_run", span_type="tool")
    def _run(self,facets_product_id:str,effective_date:str ) -> str:
        env=ConfigStore.get("env")
        #LLM_ENDPOINT=ConfigStore.get("LLM_ENDPOINT")
        plan_details=ConfigStore.get("plan_details")
        #VS_ENDPOINT=ConfigStore.get("VS_ENDPOINT")
        query = facets_product_id
        warehouse_name="Shared-SQL-Warehouse-Pro"
        warehouse_id=get_warehouse_id_by_name(warehouse_name)
        client = WorkspaceClient()
        # columns MUST include the JSON string/struct that holds cost‑share rows
        cols = ["nexusId", "planStructureType", "planCostShares","product_line_of_business","planName"]

        stmt = f"SELECT * FROM dev_adb.nexusbenefitsquote_silver_mvp1.tbl_plan_details WHERE facets_product_id = :facets_product_id and effective_date = :effective_date"

  

        result =client.statement_execution.execute_statement(
            warehouse_id=warehouse_id,
            statement=stmt,
            wait_timeout="30s",
            parameters=[
                StatementParameterListItem(
                    name="facets_product_id",
                    value=str(facets_product_id),
                ),
                StatementParameterListItem(
                    name="effective_date",
                    value=str(effective_date),
                )
            ]
        )

        if result.result is None or result.result.data_array is None:
            return []
        print("result",result)
        data= result.result.data_array
        plan_type = data[0][-1]
        plan_cost_json = data[0][-2]
        plan_nexus=data[0][4]
        plan_name=data[0][12]

        
        if "HMO" in plan_type:
            plan_type="HMO"
        if plan_type:
            return json.dumps(
                {"plan_nexus": plan_nexus, "plan_cost_share": plan_cost_json,"plan_name":plan_name,"plan_type":plan_type},
                default=str
            )
        else:
             return json.dumps(
                {"plan_nexus": "", "plan_cost_share": "","plan_name":"","plan_type":""},
                default=str
            ) 
        

# COMMAND ----------

class DefinitionArgs(BaseModel):
    input: str = Field(..., description="User question asking for a definition")
    plan_nexus: int = Field(..., description="Current plan nexusId")

class DefinitionTool(StructuredTool):
    name: ClassVar[str] = "DefinitionTool"
    description: ClassVar[str] = "Returns concise health-insurance definitions (deductible, copay, coinsurance, OOPM, BlueCard, etc.)"
    args_schema: ClassVar[Type[BaseModel]] = DefinitionArgs

    @mlflow.trace(name="DefinitionTool_run", span_type="tool")
    def _run(self, input: str, plan_nexus: int) -> str:
        hits = vs_search(
            q=input,
            nexus=plan_nexus,
            k=5,
            index_name=BENEFIT_INDEX,
            columns=[
                "benefit_id",
                "eoc_categories_all_fields",
                # add whatever columns you actually need
            ],
            filters={"nexusId": plan_nexus},
            rerank_column="eoc_categories_all_fields"  
)

        if not hits:
            return "[]"


        # Ensure hits are dicts (normalize if your vs_search returns objects)
        def to_dict(h):
            if isinstance(h, dict):
                return h
            # fallback for objects with __dict__ or attributes
            try:
                return dict(h)
            except Exception:
                return {"value": str(h)}

        payload: List[Dict[str, Any]] = [to_dict(h) for h in hits]
        return json.dumps(payload)  # <-- JSON list of dicts


# COMMAND ----------

class FallbackArgs(BaseModel):
    question: str = Field(..., description="Original or expanded user question")


class FallbackAgentTool(StructuredTool):
    name: ClassVar[str] = "FallbackAgent"
    description: ClassVar[str] = (
        "Handles queries that are neither cost-share nor benefits. "
        "Simply replies that the question is outside scope, or asks for clarification."
    )
    args_schema: ClassVar[Type[BaseModel]] = FallbackArgs

    def _run(self, question: str) -> str:
        prompt = f"""
You are a health-insurance assistant.

The user asked a question that does not match cost-share or benefits look-up.

Politely respond in one sentence, either:
• apologising that you can’t answer, OR
• asking a clarifying follow-up question
so you can route them correctly next time.

User question: "{question}"
"""
        llm = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0.2)
        resp = llm.invoke([HumanMessage(content=prompt)])
        return resp.content.strip()
    


# COMMAND ----------

from typing import Optional
  
_CONTENT_SPLIT = re.compile(r"Content\s*:", flags=re.IGNORECASE)

def _trim_header(txt: str) -> str:
    """
    Returns the part of search_text that precedes 'Content:' (case-insensitive).
    If 'Content:' is absent, returns the original text.
    """
    m = _CONTENT_SPLIT.search(txt)
    return txt[:m.start()].strip() if m else txt.strip()
# ─────────────────────────────────────────────────────────────────────────────
# CopayCoinsuranceTool: vector-search + online fetch for cost-share rows
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# CopayCoinsuranceTool: vector-search + online fetch for cost-share rows
# ─────────────────────────────────────────────────────────────────────────────
from typing import ClassVar, Type, Dict, Any, List
from pydantic import BaseModel, Field

class CopayArgs(BaseModel):
    input: str = Field(..., description="Original question string.")
    plan_nexus: int = Field(..., description="Current plan nexusId")

class CopayCoinsuranceTool(StructuredTool):
    name: ClassVar[str] = "CopayCoinsurance"
    description: ClassVar[str] = (
        "Answer cost-share questions for the current plan. Returns a JSON list of benefit dicts."
    )
    args_schema: ClassVar[Type[BaseModel]] = CopayArgs

    @mlflow.trace(name="CopayCoinsurance_run", span_type="tool")
    def _run(self, input: str, plan_nexus: int) -> str:
        hits = vs_search(
            q=input,
            nexus=plan_nexus,
            k=6,
            index_name=BENEFIT_INDEX,
            columns=[
                "benefit_id",
                "eoc_categories_all_fields",
            ],
            rerank_column="eoc_categories_all_fields",
            filters={"nexusId": plan_nexus},
        )

        if not hits or "manifest" not in hits or "result" not in hits:
            return "[]"

        columns = [col["name"] for col in hits["manifest"]["columns"]]
        rows = hits["result"].get("data_array", [])
        payload = [dict(zip(columns, row)) for row in rows]

        print("copay:" + str(payload) + "end")
        return json.dumps(payload)

# COMMAND ----------

# %skip
# # Example: Run the CopayCoinsuranceTool for a given question and plan_nexus
# tool = CopayCoinsuranceTool()
# result = tool.invoke({
#     "input": "what is the cost share for emergency room?",
#     "plan_nexus": 23085  # Replace with actual plan_nexus as needed
# })
# print(result)

# COMMAND ----------

from typing import TypedDict, Optional, List, Dict, Any

class State(TypedDict):
    messages: list
    productid_effectivedate_product: str
    input: str
    expanded_question: str
    plan_nexus: Optional[int]
    plan_name: Optional[str]
    plan_cost_share: Optional[str]
    scenarios: Optional[list]
    plan_meta: Optional[str]
    benefits: Optional[str]
    cost_share: Optional[List[Dict[str, Any]]]
    def_cost_share: Optional[List[Dict[str, Any]]]
    exclusion: Optional[List[Dict[str, Any]]]
    intent: Optional[str]
    prompt: Optional[str]
    templates: Optional[str]
    uid: Optional[str]
    sid: Optional[str]
    question_id: Optional[str]
    facets_product_id: Optional[str]
    effective_date: Optional[str]
    product_line_of_business: Optional[str]
    plan_type: Optional[str]
    program_details: Optional[List[Dict[str, Any]]]
    error: Optional[str]

# COMMAND ----------

def detect_plan(state: State) -> State:
    tool = PlanDetectTool()
    result = tool.invoke({
        "facets_product_id": state["facets_product_id"],
        "effective_date": state["effective_date"]
    })
    parsed = json.loads(result)
    state["plan_nexus"] = parsed.get("plan_nexus")
    state["plan_cost_share"] = parsed.get("plan_cost_share")
    state["plan_name"] = parsed.get("plan_name")
    state["plan_type"] = parsed.get("plan_type")
    return state

def fetch_intent(state: State) -> State:
    tool = ClassifyIntentTool()
    result = tool.invoke({"input": state["input"]})
    state["intent"] = result.get("intent", "none")
    state["expanded_question"] = result.get("expanded_question", state.get("input", ""))
    state["followup"] = result.get("followup", "")
    return state

def fetch_cost_share(state: State) -> State:
    tool = CopayCoinsuranceTool()
    result = tool.invoke({
        "input": state["expanded_question"],
        "plan_nexus": state["plan_nexus"],
    })
    print("Raw CopayCoinsuranceTool response:", result)
    print("expanded_question:", state.get("expanded_question"))
    print("plan_nexus:", state.get("plan_nexus"))
    try:
        parsed = json.loads(result) if result else []
    except Exception:
        parsed = []
    state["cost_share"] = parsed
    return state

# COMMAND ----------

def build_graph():
    # --- Build Graph ---
    builder = StateGraph(State)

    builder.add_node("plandetect_run", detect_plan)
    builder.add_node("classify_intent_run", fetch_intent)
    builder.add_node("copay_run", fetch_cost_share)

    builder.set_entry_point("plandetect_run")
    builder.add_edge("plandetect_run", "classify_intent_run")
    builder.add_edge("classify_intent_run", "copay_run")
    builder.add_edge("copay_run", END)

    graph = builder.compile()
    return graph

# COMMAND ----------


"""
tool = PlanDetectTool()
res = tool._run({"input": "MJ002168_20240101_IFP"})
print(json.loads(res))
"""


# COMMAND ----------

graph = build_graph()
mermaid_code = graph.get_graph().draw_mermaid()
print(mermaid_code)

# COMMAND ----------

# input_data = {
#     "input": "what is the cost share for emergency room?",
#     "facets_product_id": "MG011320",
#     "effective_date": "20240101"
# }

# state = graph.invoke(input_data)

# COMMAND ----------

import pandas as pd

INPUT_CSV_PATH = (
    f"/Volumes/{environment}_adb/benefits_quote_silver/"
    f"benefit_quoting_mvp1-mg011320_20240101_ifp_answers/{input_csv_file_name}"
)

pdf = pd.read_csv(INPUT_CSV_PATH)

rename_map = {
    "Test Question": "question",
    "facetsProductId": "facets_product_id",
    "effectiveDate": "effective_date"
}
pdf = pdf.rename(
    columns={k: v for k, v in rename_map.items() if k in pdf.columns}
)

required_cols = ["question", "facets_product_id", "effective_date"]
missing_cols = [col for col in required_cols if col not in pdf.columns]
if missing_cols:
    raise Exception(f"Missing required columns in input CSV: {missing_cols}")

pdf["effective_date"] = pdf["effective_date"].astype(str)

results = []
for idx in range(len(pdf)):
    row = pdf.iloc[idx]
    input_data = {
        "input": row["question"],
        "facets_product_id": row["facets_product_id"],
        "effective_date": row["effective_date"]
    }
    try:
        state = graph.invoke(input_data)
        if isinstance(state, list):
            # If graph.invoke returns a list, wrap it in a dict for compatibility
            state = {"cost_share": state}
        context = state.get("cost_share", [])
    except Exception as e:
        context = []
    results.append({
        "question": row["question"],
        "facets_product_id": row["facets_product_id"],
        "effective_date": row["effective_date"],
        "context": context
    })

result_df = spark.createDataFrame(results)
display(result_df)

# COMMAND ----------

from pyspark.sql import functions as F

result_df = result_df.withColumn(
    "id",
    F.concat_ws(
        "_",
        F.col("facets_product_id"),
        F.col("effective_date"),
        F.concat(F.lit("q"), F.monotonically_increasing_id())
    )
)
result_df.write.mode("overwrite").saveAsTable(f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_context_re")
#display(result_df)