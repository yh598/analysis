# Databricks notebook source
# MAGIC %pip install databricks-vectorsearch
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %pip install --upgrade \
# MAGIC   mlflow[databricks]>=3.1.3 \
# MAGIC   databricks-langchain \
# MAGIC   langchain>=0.3.0 \
# MAGIC   langgraph \
# MAGIC   databricks-vectorsearch>=0.40
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# input_example = {
#     "input": [
#         {
#             "role": "user",
#             "content": [
#                 {"type": "input_text", "text": "what is the cost share for urgent care services?"}
#             ],
#         }
#     ],
#     "custom_inputs": {
#         "user_id": "u-123",
#         "username": "Priyanka",
#         "session_id": "s-456",
#         "question_id": "q-789",
#         "facets_product_id": "MG011320",
#         "effective_date": "20240101"
       
#     },
# }
# import mlflow.pyfunc
# import pandas as pd
# df = input_example
# model = mlflow.pyfunc.load_model("models:/dev_adb.benefits_quote_gold.benefit_quote_MVP1/19")
# print( model.predict(df))


# COMMAND ----------

# {
#   "input": [
#     {
#       "role": "user",
#       "content": [
#         {
#           "type": "input_text",
#           "text": "what is deductible?"
#         }
#       ]
#     }
#   ],
#   "custom_inputs": {
#     "user_id": "u-123",
#     "username": "Priyanka",
#     "session_id": "s-456",
#     "question_id": "q-789",
#     "facets_product_id": "M0033807",
#     "effective_date": "20240101"
#   }
# }
# #https://adb-640321604414221.1.azuredatabricks.net/serving-endpoints/agents_dev_adb-nexusbenefitsquote_gold_mvp1-mvp1/invocations

# COMMAND ----------

import mlflow.pyfunc
import pandas as pd
import json
import requests

INPUT_CSV_PATH  = "/Volumes/dev_adb/benefits_quote_silver/benefit_quoting_mvp1-mg011320_20240101_ifp_answers/response_255_part1_sg.csv"
OUTPUT_CSV_PATH = "/Volumes/dev_adb/benefits_quote_silver/benefit_quoting_mvp1-mg011320_20240101_ifp_answers/Output_response_225_que_pm.csv"
WORKSPACE_ID    = "640321604414221"
ENDPOINT_URL    = f"https://adb-{WORKSPACE_ID}.1.azuredatabricks.net/serving-endpoints/agents_dev_adb-nexusbenefitsquote_gold_mvp1-mvp1-gpt5-backup/invocations"
DATABRICKS_TOKEN = "dapibb845be09e87e1de619e69c0214475dd-2"  

def extract_answer(resp: dict) -> str:
    try:
        output = resp.get("output", [])
        for msg in output:
            for block in msg.get("content", []):
                if block.get("type") == "output_text":
                    return block.get("text", "")
        return ""
    except Exception:
        return ""

df = pd.read_csv(INPUT_CSV_PATH, encoding='ISO-8859-1')
df = df.rename(columns={"ï»¿effectiveDate": "effectiveDate"})
display(df)

required_columns = ["Test Question", "facetsProductId", "effectiveDate"]
for col in required_columns:
    if col not in df.columns:
        raise ValueError(f"Input CSV must contain a '{col}' column")

def get_answer(row):
    try:
        input_payload = {
            "input": [
                {
                    "role": "user",
                    "content": [{"type": "input_text", "text": row["Test Question"]}],
                }
            ],
            "custom_inputs": {
                "user_id": "u-123",
                "username": "Priyanka",
                "session_id": "s-456",
                "question_id": "q-789",
                "facets_product_id": str(row["facetsProductId"]),
                "effective_date": str(row["effectiveDate"])
            },
        }
        headers = {
            "Authorization": f"Bearer {DATABRICKS_TOKEN}",
            "X-Databricks-Workspace-Id": WORKSPACE_ID,
            "Content-Type": "application/json"
        }
        response = requests.post(ENDPOINT_URL, headers=headers, data=json.dumps(input_payload))
        result = response.json()
        return extract_answer(result)
    except Exception as e:
        return f"Error: {str(e)}"

df["answer"] = df.apply(get_answer, axis=1)

df.to_csv(OUTPUT_CSV_PATH, index=False)

display(spark.createDataFrame(df).limit(5))