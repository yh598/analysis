# Databricks notebook source
import os
import yaml
import json

# COMMAND ----------

# Check if the notebook is run interactively. Only then create the text widget to input the config file
# Otherwise, the config_file parameters will be passed from the bundle. This will allow us to set the
# config file manually when running the notewook interactively. 
context = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
is_interactive = context.get("tags", {}).get("browserHostName") is not None
if is_interactive:
    dbutils.widgets.text("config_file", "")
    
config_file = dbutils.widgets.get("config_file")
# print(f"config_file: {config_file}")

# Load parameters from YAML file
config_path = os.path.join('..','configs', config_file)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

# Extract variable from YAML configuration file
project_name = config['project_name']

print("Project name loaded from config: " + project_name)

# COMMAND ----------

print("Notebook 2 Executed")