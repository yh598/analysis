import argparse
import os
import yaml

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config_file', required=True)
    args = parser.parse_args()

    # Now you can use args.config_file in your script
    print(f"Config file name: {args.config_file}")
    config_file = args.config_file

    # Load parameters from YAML file
    config_path = os.path.join('..','configs', config_file)
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)

    # Extract variable from YAML configuration file
    project_name = config['project_name']
    print("Project name loaded from config: " + project_name)

    print("Python Script Executed")

if __name__ == "__main__":
    main()
