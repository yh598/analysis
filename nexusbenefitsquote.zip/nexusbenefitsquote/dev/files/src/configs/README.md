# Nexus Benefits Quote - Configuration Documentation

## Project Overview

The Nexus Benefits Quote project is a Databricks-based solution for managing and querying health insurance plan benefits data. This project integrates with multiple data sources, provides AI-powered benefits search capabilities, and maintains data across bronze, silver, and gold layers in a medallion architecture.

### Key Features

* Multi-environment support (Dev, QA, Stage, Production)
* Unity Catalog integration for data governance
* Vector search capabilities for intelligent benefits querying
* Azure integration with external APIs
* PostgreSQL synchronization for chat history
* Automated schema and volume creation

### Project Structure

```
configs/
├── README.md (this file)
├── init.py
├── create_schema_and_directory.py
├── dev_config.yml
├── qa_config.yml
├── prod_config.yml
├── stage_config.yml
├── user_space_dev_config.yml
└── lakebase_sync.yml
```

## Installation & Setup

### Prerequisites

* Databricks workspace with Unity Catalog enabled
* Azure subscription with appropriate permissions
* Python 3.8 or higher
* Required Python packages: `pyyaml`, `databricks-sdk`

### Quick Start

1. **Clone the repository** to your Databricks workspace
2. **Configure environment** by selecting the appropriate config file
3. **Run schema creation** using the `create_schema_and_directory` notebook
4. **Deploy pipelines** according to your environment

### Environment Configuration

Choose the appropriate configuration file based on your deployment environment:

* **Development**: `dev_config.yml` - For development and testing
* **QA**: `qa_config.yml` - For quality assurance testing
* **Production**: `prod_config.yml` - For production deployment
* **Stage**: `stage_config.yml` - For staging environment
* **User Space**: `user_space_dev_config.yml` - For individual developer workspaces

---

## Module Documentation

### Utility Module

The utility module provides generic, reusable functions for configuration management, schema creation, and workspace setup.

#### Core Components

**Configuration Loader** (`create_schema_and_directory.py`)

The configuration loader provides essential utility functions for managing Databricks resources:

* `load_config(config_file)` - Load YAML configuration files
* `is_interactive()` - Detect notebook execution context
* `create_schema(config_file, layer_name)` - Create Unity Catalog schemas
* `create_volume(config_file, layer_name)` - Create Unity Catalog volumes
* `create_directory()` - Create workspace directories for experiments

**Detailed Documentation**: See [Configuration Utilities Details](#configuration-utilities-details) below

---

### Helper Module

The helper module contains specific system integration scripts for external services and APIs.

#### Integration Components

* **API Client Wrapper** - Handles communication with external product search APIs
* **Database Sync** - Manages PostgreSQL synchronization (see `lakebase_sync.yml`)
* **Authentication** - Azure AD authentication for service principals

---

## Configuration Utilities Details

### Function: `load_config(config_file)`

Loads and parses YAML configuration files from the configs directory.

**Parameters:**
* `config_file` (str): Name of the configuration file (e.g., 'dev_config.yml')

**Returns:**
* `dict`: Parsed configuration dictionary

**Raises:**
* `FileNotFoundError`: If configuration file doesn't exist
* `yaml.YAMLError`: If YAML parsing fails

**Description:**

This function constructs the path to the configuration file relative to the configs directory, reads the file, and parses it using PyYAML's safe loader. It includes comprehensive error handling for missing files and malformed YAML.

**Example:**

```python
# Load development configuration
config = load_config('dev_config.yml')

# Access configuration values
catalog_name = config['catalog_name']  # 'dev_adb'
schema_bronze = config['schema_name_bronze']  # 'nexusbenefitsquote_bronze_mvp1'
api_url = config['api_url']
```

---

### Function: `is_interactive()`

Determines if the notebook is running in an interactive browser session.

**Parameters:**
* None

**Returns:**
* `bool`: True if running interactively, False otherwise

**Description:**

This utility function checks the notebook execution context by examining the Databricks notebook tags. It's useful for conditional logic that should only execute during interactive development versus automated job execution.

**Example:**

```python
if is_interactive():
    # Create widgets for interactive parameter input
    dbutils.widgets.text("config_file", "dev_config.yml")
else:
    # Use job parameters
    config_file = dbutils.widgets.get("config_file")
```

---

### Function: `create_schema(config_file, layer_name)`

Creates a Unity Catalog schema for the specified data layer if it doesn't already exist.

**Parameters:**
* `config_file` (str): Name of the configuration file
* `layer_name` (str): Data layer name ('bronze', 'silver', or 'gold')

**Returns:**
* None

**Description:**

This function creates schemas in Unity Catalog following the medallion architecture pattern. It first verifies the catalog exists, then checks for existing schemas, and creates the schema only if needed. The function provides clear console output about the schema status.

**Example:**

```python
# Create bronze layer schema
create_schema('dev_config.yml', 'bronze')
# Output: Schema 'nexusbenefitsquote_bronze_mvp1' created successfully.

# Create silver layer schema
create_schema('dev_config.yml', 'silver')

# Create gold layer schema
create_schema('dev_config.yml', 'gold')
```

---

### Function: `create_volume(config_file, layer_name)`

Creates a Unity Catalog volume in the specified schema for file storage.

**Parameters:**
* `config_file` (str): Name of the configuration file
* `layer_name` (str): Data layer name ('bronze', 'silver', or 'gold')

**Returns:**
* None

**Description:**

Creates a managed volume in Unity Catalog for storing files like plan data, EOC documents, and other artifacts. Volumes provide a file system interface within Unity Catalog's governance framework.

**Example:**

```python
# Create volume in bronze schema
create_volume('dev_config.yml', 'bronze')
# Output: Volume 'plan_data_mvp1' created in dev_adb.nexusbenefitsquote_bronze_mvp1.
```

---

### Function: `create_directory()`

Creates a workspace directory for storing ML experiment artifacts.

**Parameters:**
* None (reads from notebook widgets)

**Returns:**
* None

**Description:**

Creates a user-specific directory in the Databricks workspace for storing model artifacts and experiment results. The directory path is dynamically constructed using the current user's email and project name from the configuration.

**Example:**

```python
# Set config file widget
dbutils.widgets.text("config_file", "dev_config.yml")

# Create directory
create_directory()
# Output: Directory ensured: /Workspace/Users/user@example.com/experiments/nexusbenefitsquote
```

---

## Configuration Files Reference

### Environment Configurations

#### `dev_config.yml`

Development environment configuration with test endpoints and dev catalog.

**Key Settings:**
* Catalog: `dev_adb`
* API Endpoint: Non-production Azure App Service
* LLM Endpoints: Primary (GPT-5 POC) and Secondary (GPT-4o)
* Database Instance: `db-benefits-ci-cd-test`
* Default Plan: 28115 (Bronze 60 HDHP PPO)

#### `qa_config.yml`

QA environment configuration for testing and validation.

**Key Settings:**
* Catalog: `qa_adb`
* API Endpoint: Non-production Azure App Service
* LLM Endpoint: GPT-4o (2024-08-06)
* Database Instance: `benefit-quote-mvp1-db`
* Workspace URL: QA Databricks workspace

#### `prod_config.yml`

Production environment configuration with production endpoints.

**Key Settings:**
* Catalog: `prod_adb`
* API Endpoint: Production Azure App Service
* LLM Endpoint: GPT-4o (2024-08-06)
* Database Instance: `benefit-quote-mvp1-db`
* Workspace URL: Production Databricks workspace

#### `stage_config.yml`

Staging environment configuration (minimal setup).

**Key Settings:**
* Catalog: `stage_adb`
* Schema: `nexusbenefitsquote`
* Model Alias: `champion`

#### `user_space_dev_config.yml`

Individual developer workspace configuration.

**Key Settings:**
* User: `cli02`
* Catalog: `dev_adb`
* Schema: `nexusbenefitsquote_cli02` (user-specific)

---

### Database Synchronization Configuration

#### `lakebase_sync.yml`

PostgreSQL synchronization settings for chat history across environments.

**Configuration Structure:**

Each environment (dev, qa, prod) includes:
* `instance`: PostgreSQL server instance name
* `db_name`: Database name (databricks_postgres)
* `sslmode`: SSL connection requirement
* `delta_lake_schema`: Target schema in Delta Lake (gold)
* `remove_old_chat_days`: Retention period for chat history

**Example:**
```yaml
instance_dev: db-benefits-ci-cd-test
db_name_dev: databricks_postgres
remove_old_chat_days_dev: 8
```

---

## Common Configuration Parameters

### Catalog & Schema Settings

* `catalog_name`: Unity Catalog name (dev_adb, qa_adb, prod_adb)
* `schema_name_bronze`: Bronze layer schema for raw data
* `schema_name_silver`: Silver layer schema for cleaned data
* `schema_name_gold`: Gold layer schema for aggregated data
* `volume_name`: Volume name for file storage (plan_data_mvp1)

### API Integration

* `api_url`: Product search API endpoint
* `api_product_sync`: Product synchronization API endpoint
* `client_id`: Azure AD application client ID
* `client_secret`: Azure AD application secret (encrypted)
* `ws_url`: Databricks workspace URL

### AI/ML Configuration

* `VS_ENDPOINT`: Vector search endpoint name
* `LLM_ENDPOINT_PRIMARY`: Primary LLM endpoint (dev only)
* `LLM_ENDPOINT_SECONDARY`: Secondary LLM endpoint (dev only)
* `LLM_ENDPOINT`: LLM endpoint (qa/prod)
* `model_alias`: Model version alias (champion)

### Data Assets

* `plan_details`: Plan details table (silver layer)
* `eoc_sections`: Evidence of Coverage sections table (silver layer)
* `BENEFIT_INDEX`: Benefits category index (gold layer)
* `PLAN_INDEX`: Plan details index (silver layer)
* `PROGRAM_INDEX`: Program categories index (silver layer)
* `EXCLUSION_INDEX`: Exclusions and sections index (silver layer)

### Application Settings

* `DEFAULT_PLAN`: Default plan ID (28115)
* `DEFAULT_PLAN_NAME`: Default plan name (Bronze 60 HDHP PPO)
* `warehouse`: SQL warehouse name (SQL_WareHouse_Serverless)
* `fetch_chat_history_limit`: Number of chat messages to retrieve (3)
* `score_threshold`: Minimum similarity score for search results (0.2, dev only)

---

## Usage Examples

### Example 1: Initialize Development Environment

```python
# Import utility functions
from create_schema_and_directory import load_config, create_schema, create_volume, create_directory

# Load configuration
config = load_config('dev_config.yml')

# Create schemas for all layers
for layer in ['bronze', 'silver', 'gold']:
    create_schema('dev_config.yml', layer)
    create_volume('dev_config.yml', layer)

# Create experiment directory
dbutils.widgets.text("config_file", "dev_config.yml")
create_directory()
```

### Example 2: Access Configuration Values

```python
# Load configuration
config = load_config('prod_config.yml')

# Access table references
plan_details_table = config['plan_details']
# Result: 'prod_adb.nexusbenefitsquote_silver_mvp1.tbl_plan_details'

# Access API endpoints
api_url = config['api_url']
client_id = config['client_id']

# Access AI/ML settings
llm_endpoint = config['LLM_ENDPOINT']
vs_endpoint = config['VS_ENDPOINT']
```

### Example 3: Environment-Specific Logic

```python
import os

# Determine environment from config file
config_file = os.getenv('CONFIG_FILE', 'dev_config.yml')
config = load_config(config_file)

# Environment-specific behavior
if 'dev' in config['catalog_name']:
    print("Running in development mode")
    # Use primary and secondary LLM endpoints
    primary_llm = config.get('LLM_ENDPOINT_PRIMARY')
    secondary_llm = config.get('LLM_ENDPOINT_SECONDARY')
else:
    print("Running in production mode")
    # Use single LLM endpoint
    llm = config['LLM_ENDPOINT']
```

---

## Best Practices

### Configuration Management

1. **Never commit secrets**: Use Databricks secrets for sensitive values
2. **Environment isolation**: Always use the correct config file for your environment
3. **Schema naming**: Follow the pattern `{project}_{layer}_mvp{version}`
4. **Catalog organization**: Use separate catalogs per environment (dev_adb, qa_adb, prod_adb)

### Schema Creation

1. **Check before create**: Always verify existing resources before creation
2. **Layer order**: Create schemas in order: bronze → silver → gold
3. **Volume creation**: Create volumes after schemas are established
4. **Error handling**: Implement try-catch blocks for production code

### Development Workflow

1. **User spaces**: Use `user_space_dev_config.yml` for isolated development
2. **Testing**: Test in dev environment before promoting to QA
3. **Validation**: Verify schema and volume creation before running pipelines
4. **Documentation**: Update this README when adding new configuration parameters

---

## Troubleshooting

### Common Issues

**Issue**: Configuration file not found
```
Solution: Ensure the config file exists in the configs directory and the path is correct
```

**Issue**: Schema already exists error
```
Solution: The create_schema function handles this gracefully - check console output
```

**Issue**: Permission denied when creating schema
```
Solution: Verify you have CREATE SCHEMA privileges on the catalog
```

**Issue**: Volume creation fails
```
Solution: Ensure the schema exists first and you have CREATE VOLUME privileges
```

### Debug Tips

* Use `display()` to inspect DataFrames when checking existing resources
* Check Databricks workspace logs for detailed error messages
* Verify Unity Catalog permissions using `SHOW GRANTS ON CATALOG <catalog_name>`
* Test configuration loading independently before running full setup

---

## Support & Contact

For questions or issues related to this utilities module, please contact the MVP1 team.

