# Databricks notebook source
import os
import yaml
import json

def load_config(config_file):
    """Helper function to load the YAML configuration."""
    config_path = os.path.join('..', 'configs', config_file)
    try:
        with open(config_path, 'r') as file:
            return yaml.safe_load(file)
    except FileNotFoundError:
        print(f"Configuration file {config_file} not found.")
        raise
    except yaml.YAMLError as e:
        print(f"Error parsing YAML file {config_file}: {e}")
        raise

def is_interactive():
    """Helper function to check if the notebook is running interactively."""
    context = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
    return context.get("tags", {}).get("browserHostName") is not None

def create_schema(config_file,layer_name):
    """Create schema in Databricks workspace if it doesn't exist."""
 
    config = load_config(config_file)

    catalog_name = config['catalog_name']
    schema_name=f"schema_name_{layer_name}"
    
    schema_name = config[schema_name]
    

    # Check if catalog exists
    query = f"SHOW CATALOGS LIKE '{catalog_name}'"
    catalogs_df = spark.sql(query)
    display(catalogs_df)

    # Check if schema exists
    query = f"SHOW SCHEMAS IN {catalog_name}"
    existing_schemas_df = spark.sql(query)
    existing_schemas = [row['databaseName'] for row in existing_schemas_df.collect()]

    if schema_name in existing_schemas:
        print(f"Schema '{schema_name}' already exists. User can proceed with Data Engineering Jobs!")
    else:
        print(f"Schema '{schema_name}' not found. Creating it...")
        query = f"CREATE SCHEMA IF NOT EXISTS {catalog_name}.{schema_name}"
        spark.sql(query)
        print(f"Schema '{schema_name}' created successfully. User can proceed with Data Engineering Jobs!")

def create_volume(config_file,layer_name):
    """
    Create a volume in the specified catalog and schema.
    """
    config = load_config(config_file)
    schema_name=f"schema_name_{layer_name}"
    
    schema_name = config[schema_name]
    catalog_name = config['catalog_name']
  
    volume_name = config['volume_name']
    query = f"CREATE VOLUME IF NOT EXISTS {catalog_name}.{schema_name}.{volume_name}"
   
    spark.sql(query)
    print(f"Volume '{volume_name}' created in {catalog_name}.{schema_name}.")

def create_directory():
    """Create a directory in Databricks workspace for the current user and project."""
    if is_interactive():
        dbutils.widgets.text("config_file", "")

    config_file = dbutils.widgets.get("config_file")
    config = load_config(config_file)

    project_name = config['project_name']

    # Get the current user's email
    current_user = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()

    # Define the directory path dynamically based on the current user's email
    model_artifacts_directory_path = f"/Workspace/Users/{current_user}/experiments/{project_name}"

    # Check if the directory exists, and create it if not
    try:
        os.makedirs(model_artifacts_directory_path, exist_ok=True)
        print(f"Directory ensured: {model_artifacts_directory_path}")
    except Exception as e:
        print(f"Error creating directory {model_artifacts_directory_path}: {e}")
        raise

