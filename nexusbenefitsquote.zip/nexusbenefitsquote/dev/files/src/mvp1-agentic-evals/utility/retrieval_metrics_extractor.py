import re
import json
import math
import ast
from typing import List, Set, Dict, Any

from mlflow.entities import Feedback
from mlflow.genai.scorers import scorer


class RetrievalMetricsExtractor:
    """
    Reusable utility class for extracting and validating data needed for all retrieval ranking metrics.
    This class provides helper methods to handle parsing of context (which may come in various formats like lists, strings, etc.),
    extracting nexus IDs from documents and ground truth, and validating inputs.
    These methods are called by the scorers to avoid code duplication and ensure consistency in data handling.
    """

    @staticmethod
    def safe_parse_context(raw_context: Any) -> List[Dict[str, Any]]:
        """
        Robustly convert raw context into a list of document dicts.
        This method is crucial because context from data sources (e.g., Excel, traces) might be serialized as strings
        (JSON or Python literals) or already as lists. It attempts multiple parsing strategies to handle real-world data variations.
        If parsing fails, it logs a warning and returns an empty list to prevent scorer crashes.
        
        Why this is needed: Data preparation might not always yield perfect lists, so this ensures robustness.
        
        Handles:
          - Already a list[dict]: Returns as-is.
          - JSON string: Tries json.loads().
          - Python literal string: Tries ast.literal_eval().
          - None / NaN / empty string: Returns empty list.
          - Unexpected types: Logs warning and returns empty list.
        """
        if isinstance(raw_context, list):
            return raw_context
        if raw_context is None or (isinstance(raw_context, float) and math.isnan(raw_context)):
            return []
        if isinstance(raw_context, str):
            context_str = raw_context.strip()
            if not context_str:
                return []
            try:
                parsed = json.loads(context_str)
                if isinstance(parsed, list):
                    return parsed
            except json.JSONDecodeError:
                pass
            try:
                parsed = ast.literal_eval(context_str)
                if isinstance(parsed, list):
                    return parsed
            except (ValueError, SyntaxError):
                pass
            print(f"Warning: Failed to parse context, using empty list: {context_str[:100]}...")
            return []
        print(f"Warning: Unexpected context type {type(raw_context)}, using empty list")
        return []

    @staticmethod
    def extract_top_level_nexus_ids_from_ground_truth(ground_truth_text: str) -> Set[int]:
        """
        Extract ONLY the first bracketed nexusId from each top-level line (A., B., etc.) in the ground truth.
        Example: "A. ... [688] ...", "B. ... [254] ..." → {688, 254}
        """
        if not ground_truth_text:
            return set()
        # Match lines like "A. ... [number]"
        matches = re.findall(r"^\s*[A-Z]\.\s.*?\[(\d+)\]", ground_truth_text, re.MULTILINE)
        return {int(nid) for nid in matches if nid.isdigit()}

    @staticmethod
    def extract_nexus_ids_from_retrieved_context(documents: List[Dict[str, Any]]) -> List[int]:
        """
        Extract nexusIds from retrieved documents, PRESERVING RANK ORDER.
        Returns a list (not set) because ranking position matters for NDCG and @k metrics.
        
        Why list not set: Order is critical — higher rank = more credit in NDCG.
        Called after safe_parse_context to get ranked retrieved IDs.
        """
        ranked_nexus_ids = []
        for doc in documents:
         
            try:
                fields_str = doc.get("eoc_categories_all_fields")
                if not fields_str:
                    continue
                fields = json.loads(fields_str) if isinstance(fields_str, str) else fields_str
                nexus_id = fields.get("eocCategories_nexusId")
                if nexus_id is not None:
                    ranked_nexus_ids.append(nexus_id)
            except Exception:
                continue  # Skip malformed docs
        return ranked_nexus_ids

    @staticmethod
    def extract_top_level_nexus_ids_from_response(response_text: str) -> Set[int]:
        """
        Extract ONLY the first bracketed nexusId from each top-level line (A., B., etc.) in the assistant's response.
        Example: "A. ... [688] ...", "B. ... [254] ..." → {688, 254}
        """
        if not response_text:
            return set()
        matches = re.findall(r"^\s*[A-Z]\.\s.*?\[(\d+)\]", response_text, re.MULTILINE)
     

        return {int(nid) for nid in matches if nid.isdigit()}

    @staticmethod
    def extract_feedback_scores(feedback_obj):
        """
        Returns feedback scores as a list of floats
        """

        if not feedback_obj or not getattr(feedback_obj, "feedback", None):
            return []

        value = feedback_obj.feedback.value  # e.g. "0.9, 0.9"

        if isinstance(value, str):
            return [float(v.strip()) for v in value.split(",")]

        # fallback if already numeric
        if isinstance(value, (list, tuple)):
            return list(map(float, value))

        return []

    @staticmethod
    def result_to_feedback(result_dict, prefix=None):
        feedbacks = []
        for k, v in result_dict.items():
            name = f"{prefix}_{k}" if prefix else k

            # Only log numeric values
            if isinstance(v, (int, float)):
                feedbacks.append(Feedback(name=name, value=float(v)))
        return feedbacks

