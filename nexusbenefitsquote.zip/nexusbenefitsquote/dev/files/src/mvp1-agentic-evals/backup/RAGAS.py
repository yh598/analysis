# Databricks notebook source
# MAGIC %pip install ragas datasets 
# MAGIC %pip install langgraph
# MAGIC %pip install databricks_langchain
# MAGIC
# MAGIC dbutils.library.restartPython()
# MAGIC
# MAGIC

# COMMAND ----------

import ragas
print(ragas.__version__)

# COMMAND ----------

import os
import pandas as pd
from datasets import Dataset
from ragas import evaluate
from ragas.metrics import faithfulness, answer_correctness,answer_relevancy,context_recall,context_precision,context_precision
from databricks_langchain import ChatDatabricks,DatabricksEmbeddings

# COMMAND ----------


df = pd.read_excel("/Volumes/dev_adb/benefits_quote_bronze_mvp1/bsc/question_context.xlsx")
print(df.columns)

# COMMAND ----------

display(df)

# COMMAND ----------

dataset=Dataset.from_pandas(df[['question','assistant_answer','retrieved_context',"ground_truth"]])

# COMMAND ----------

df_renamed = df.rename(columns={'assistant_answer': 'response', 'retrieved_context': 'retrieved_contexts','ground_truth':'reference'})[['question', 'response', 'retrieved_contexts','reference']]
display(df_renamed)

# COMMAND ----------

df_renamed['retrieved_contexts'] = df_renamed['retrieved_contexts'].apply(lambda x: [x] if isinstance(x, str) else x)
#df_renamed=df_renamed.iloc[[0]]
display(df_renamed)

# COMMAND ----------

dataset = Dataset.from_pandas(df_renamed[['question', 'response', 'retrieved_contexts','reference']])

# COMMAND ----------

from ragas.embeddings import LangchainEmbeddings

# COMMAND ----------

chat_model=ChatDatabricks(endpoint="databricks-claude-sonnet-4-5", temperature=0)

# COMMAND ----------

results= evaluate(
    dataset,
    metrics=[
        faithfulness,
        answer_correctness,#require reference,
        #answer_relevancy,#reference,
        context_recall,#reference,
        ],
     llm = chat_model,
)
display(results)

# COMMAND ----------

# MAGIC %pip install litellm

# COMMAND ----------

from openai import AzureOpenAI

# COMMAND ----------

import os
import pandas as pd
from datasets import Dataset
import ast

import litellm
from ragas.llms import llm_factory
from ragas.embeddings.base import embedding_factory
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    answer_correctness,
    context_precision,
    context_recall,
)
from ragas import evaluate

# ---------- 2. Configure Databricks for LiteLLM (NO OpenAI) ----------
os.environ["DATABRICKS_API_BASE"] = "https://adb-640321604414221.1.azuredatabricks.net/serving-endpoints"
os.environ["DATABRICKS_API_KEY"] = "dapi632fec770fe40e223ced5d4cf05f34e1-2"

litellm.api_base = os.environ["DATABRICKS_API_BASE"]
litellm.api_key = os.environ["DATABRICKS_API_KEY"]
litellm.drop_params = ["top_p"]
litellm.drop_unk_params = True
litellm.max_tokens=256
eval_llm = llm_factory(
    "databricks/databricks-meta-llama-3-1-8b-instruct",
    provider="litellm",
    client=litellm.completion,
    temperature=1,
    top_p=None

    
)

eval_embeddings = embedding_factory(
    "litellm",
    model="databricks/databricks-bge-large-en",
)

metrics = [
    faithfulness,
    answer_relevancy,
    answer_correctness,
    context_precision,
    context_recall,
]

# ---------- 6. Run RAGAS evaluation ----------
results = evaluate(
    dataset,
    metrics=metrics,
    llm=eval_llm,
    embeddings=eval_embeddings,
)

# Convert RAGAS results to pandas DataFrame before merging
ragas_scores_df = results.to_pandas()

full_df = pd.concat(
    [df.reset_index(drop=True), ragas_scores_df.reset_index(drop=True)],
    axis=1
)

output_path = "/Volumes/dev_adb/benefits_quote_bronze_mvp1/bsc/ragas_scored.xlsx"
full_df.to_excel(output_path, index=False)

print("Saved RAGAS scored file to:", output_path)
display(full_df)

# COMMAND ----------

display(full_df)

# COMMAND ----------

litellm.completion(
    model="databricks/databricks-claude-sonnet-4-5",
    messages=[{"role": "user", "content": "hello"}],
    temperature=0.0,
)

# COMMAND ----------

# ---------- 5. Choose metrics ----------
metrics = [
    faithfulness,
    answer_relevancy,
    answer_correctness,
    context_precision,
    context_recall,
]

# ---------- 6. Run RAGAS evaluation (using Databricks models, not OpenAI) ----------
results = evaluate(
    dataset,
    metrics=metrics,
    llm=eval_llm,                # <- overrides default judge LLM
    embeddings=eval_embeddings,  # <- overrides default embeddings
)

ragas_scores = results.to_pandas()

# ---------- 7. Merge scores with original data & save ----------
full_df = pd.concat([df.reset_index(drop=True), ragas_scores], axis=1)

output_path = "/Volumes/dev_adb/benefits_quote_bronze_mvp1/bsc/ragas_scored.xlsx"
full_df.to_excel(output_path, index=False)

print("Saved RAGAS scored file to:", output_path)
display(full_df)

# COMMAND ----------

# MAGIC %md
# MAGIC