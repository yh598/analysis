# Databricks notebook source
# MAGIC %pip install pyyaml

# COMMAND ----------

# MAGIC %pip install mlflow==3.6.0

# COMMAND ----------

# MAGIC %pip install --upgrade openpyxl rouge-score
# MAGIC %pip install litellm
# MAGIC %pip install --upgrade databricks-sdk

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import mlflow
import pandas as pd
import numpy as np
import re
from mlflow.genai import make_judge
import json
import os,sys
import yaml
from typing import Optional
from pyspark.sql.functions import udf
from pyspark.sql.types import FloatType
from pyspark.sql.functions import expr
from rouge_score import rouge_scorer
from helper.benefit_template_comparator import BenefitTemplateComparator
from helper.template_evaluator import TemplateEvaluator
from helper.intent_identifier import classify_intent
from utility.retrieval_metrics_extractor import RetrievalMetricsExtractor
from helper.ndcg_metrics import NexusMetrics

# COMMAND ----------

parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
# print(parent_dir)

sys.path.insert(0, parent_dir)
print(os.getcwd())

dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()

dbutils.widgets.text("environment", "dev")
env: str = dbutils.widgets.get("environment").lower()

dbutils.widgets.text("excel_path", "/Volumes/dev_adb/benefits_quote_bronze/bsc/benchmark_exp_mterics_input_itr3.xlsx")
excel_path = dbutils.widgets.get("excel_path")

dbutils.widgets.text("context_table_path", "")
context_table_path = dbutils.widgets.get("context_table_path")

dbutils.widgets.text("experiment_run", "exp_benchmark")
experiment_run = dbutils.widgets.get("experiment_run")

dbutils.widgets.text("threshold_run", "0.9")
threshold_run = dbutils.widgets.get("threshold_run")

# Load parameters from YAML file
config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)

catalog = config['catalog_name']
schema_name_gold = config['schema_name_gold']
tbl_threshold_score_gt: str = "tbl_threshold_score_gt"
JUDGE_MODEL = config['JUDGE_MODEL']

# COMMAND ----------

def start_mlflow_experiment(experiment_name):
    user_email = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
    experiment_base_path = f"/Workspace/Users/asinha01@blueshieldca.com/as-mlflow-eval_benchmark_0.9_as_2"
    experiment_path = f"{experiment_base_path}/{experiment_name}"

    # Create the parent directory using Workspace API
    from databricks.sdk import WorkspaceClient
    w = WorkspaceClient()
    w.workspace.mkdirs(experiment_base_path)

    # No need to create the directory manually; MLflow will handle it
    experiment = mlflow.set_experiment(experiment_path)
    return experiment

# Usage
experiment_tag = "MVP1_Benefit_Agent_mlflow_benchmark_0.9_as_2"
experiment = start_mlflow_experiment(experiment_tag)

# COMMAND ----------


EXCEL_PATH = excel_path
#"openai:/gpt-4o-mini"

# COMMAND ----------

from mlflow.genai import evaluate
from mlflow.genai.scorers import Correctness

# COMMAND ----------

# DBTITLE 1,Cell 10
relevance_judge = make_judge(
    name="response_relevance",
    model=JUDGE_MODEL,
    instructions="""
    Rate the relevance and completeness each separately of the response to the user input by comparing the model response with ground truth on a scale of 0.0 to 1.0.
    Question: {{ inputs }}
    Ground Truth Answer: {{ expectations }}
    Model Output: {{ outputs }}
    
    Provide a brief rationale (max 2-3 sentences) and output the two float values.
    Output format: [relevance_score, completeness_score]
    Example: [0.95, 0.92]
    """,
    feedback_value_type=list[float]
)

# COMMAND ----------

# DBTITLE 1,Cell 11
correctness_judge = make_judge(
    name="correctness_pass_fail_and_score",
    model=JUDGE_MODEL,
    instructions="""
Evaluate the factual correctness of the model response with respect to the benefits information.

Inputs:
Question: {{ inputs }}
Ground Truth Answer: {{ expectations }}
Model Output: {{ outputs }}

Check whether benefit/subsections related to:
- deductibles
- out-of-pocket maximums (OOPM)
- cost share
- plan limit(if present in Ground Truth)
- plan maximum payable (if present in Ground Truth)

are factually correct when compared with Ground truth.

Guidelines:
- Exact wording match with ground truth is NOT required.
- All factual details and numeric values must be correct.
- Missing required benefits must be penalized.
- If the service is excluded, verify that the model response acknowledges the exclusion. A complete match with the ground truth is not required; as long as the exclusion is correctly mentioned, assign the highest score.
-If the model response defers answering—such as by asking a follow-up question—instead of providing a direct answer, it should not be considered an exact match to the ground truth,assign the higesh score.
- Additional related benefits/subsection are acceptable if factually correct and non-contradictory.
- Any incorrect, contradictory, or fabricated benefit information must be penalized.
- If a specific benefit (e.g., cost share, deductible, OOPM) is NOT present in the ground truth, check if the model response also does NOT include it. If both ground truth and model response are aligned (both absent or both present with matching information), this should be considered correct.
- If ground truth does not mention a benefit and model response also does not mention it, this is a match and should pass.
- Do no go on exact sentence match such as memeber owes $0 copay etc, it can be ignored and high score should be given in this case.
-Please disregard threshold scores. If threshold scores do not match, do not consider them in the evaluation.

Scoring:

CORRECTNESS SCORE (0.0–1.0):
   - 1.0: All required benefits present and fully correct, or correctly absent when not in ground truth
   - 0.7–0.9: Minor omissions or minor factual inaccuracies
   - 0.4–0.6: Multiple missing benefits or partially incorrect values
   - 0.1–0.3: Major factual errors or significant omissions
   - 0.0: Completely incorrect or fabricated benefits

Output ONLY one float value in this order:
correctness_score
""",
    feedback_value_type=float,
)

# COMMAND ----------

faithfulness_judge = make_judge(
    name="faithfulness",
    model=JUDGE_MODEL,
    instructions="""
Rate faithfulness and completeness of the model output
with respect to the ground truth.

Inputs:
Question: {{ inputs }}
Ground Truth Answer: {{ expectations }}
Model Output: {{ outputs }}

Score separately:
1. faithfulness (0.0–1.0):
   Are factual claims supported by ground truth?


Strictly,Output ONLY one float values in this order:
faithfulness
""",
    feedback_value_type=float,
)

# COMMAND ----------

# DBTITLE 1,Untitled
context_judge = make_judge(
    name="context_quality",
    model=JUDGE_MODEL,
    instructions="""
You are evaluating the quality of retrieved context for answering a question.

Inputs:
Question: {{ inputs }}
Retrieved Context: {{ expectations }}
Ground Truth Answer: {{ outputs }}

Your task: Evaluate ONLY the retrieved context. Do NOT evaluate the model response.

You must provide exactly THREE scores:

1. context_relevance (0.0 to 1.0):
   - How directly is the retrieved context related to the question topic?
   - If any part of the context clearly matches the question topic, score should be at least 0.4
   - Score 1.0 if highly relevant, 0.0 if completely irrelevant

2. context_precision (0.0 to 1.0):
   - How much of the retrieved context is actually useful?
   - Extra or irrelevant text should reduce this score
   - Score 1.0 if all content is useful, 0.0 if all is irrelevant

3. context_recall (0.0 to 1.0):
   - Does the retrieved context contain the key facts needed to produce the ground truth answer?
   - Do NOT reduce this score due to extra or irrelevant text
   - Score 1.0 if all key facts present, 0.0 if none present

Be tolerant of paraphrasing and formatting differences.

Provide a brief rationale (max 3 sentences) and output the three scores.

OUTPUT FORMAT REQUIREMENTS:
- You MUST output exactly 3 numbers separated by commas
- Each number must be between 0.0 and 1.0
- Format: number, number, number
- Example valid output: 0.9, 0.72, 0.90
- Do NOT include any text, labels, or explanations in the feedback value
- Do NOT use brackets, parentheses, or quotes
- ONLY output the three comma-separated numbers in feedback value

""",
    feedback_value_type=float,
)


# COMMAND ----------

# def extract_feedback_scores(feedback_obj):
#     """
#     Returns feedback scores as a list of floats
#     """
#     if not feedback_obj or not getattr(feedback_obj, "feedback", None):
#         return []

#     value = feedback_obj.feedback.value  # e.g. "0.9, 0.9"

#     if isinstance(value, str):
#         return [float(v.strip()) for v in value.split(",")]

#     # fallback if already numeric
#     if isinstance(value, (list, tuple)):
#         return list(map(float, value))

#     return []


# COMMAND ----------

# def result_to_feedback(result_dict, prefix=None):
#     feedbacks = []
#     for k, v in result_dict.items():
#         name = f"{prefix}_{k}" if prefix else k

#         # Only log numeric values
#         if isinstance(v, (int, float)):
#             feedbacks.append(Feedback(name=name, value=float(v)))
#     return feedbacks

# COMMAND ----------

# extractor = RetrievalMetricsExtractor()

# COMMAND ----------

# DBTITLE 1,Untitled
from mlflow.genai.scorers import scorer
from mlflow.entities import Feedback
import math
import time
import logging
import sys

# Configure logging to output to stderr (not captured by MLflow)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)

@scorer(name="core_agent_scorer", aggregations=["mean","p90"])
def core_agent_scorer(*, inputs=None, outputs=None, expectations=None, trace=None):
    question = inputs.get("request", "") if inputs else ""
    ground_truth = expectations.get("expected_response", "") if expectations else ""
    outputs=outputs.get("response", "") if expectations else ""
    context = expectations.get("context", "") if expectations else ""
    
    max_retries = 3
    retry_delay = 60  # seconds
    
    # Relevance judge with retry loop
    relevance_metrices = None
    for attempt in range(max_retries):
        relevance = relevance_judge(
            inputs={"question": question},
            outputs=outputs,
            expectations={"ground_truth": ground_truth},
        )
        logger.info(f"Relevance judge result (attempt {attempt + 1}): {relevance}")
        print("rele",relevance.feedback.value)
        relevance_metrices = RetrievalMetricsExtractor.extract_feedback_scores(relevance)
        logger.info(f"Relevance metrics extracted: {relevance_metrices} (length: {len(relevance_metrices) if relevance_metrices else 0})")
        
        # Check if valid (exactly 2 values, no NaN)
        if relevance_metrices and len(relevance_metrices) == 2 and not any(v is None or (isinstance(v, float) and math.isnan(v)) for v in relevance_metrices):
            logger.info(f"Relevance metrics valid on attempt {attempt + 1}")
            break
        
        if attempt < max_retries - 1:
            logger.warning(f"Relevance metrics invalid (got {len(relevance_metrices) if relevance_metrices else 0} values, expected 2) - attempt {attempt + 1}/{max_retries}, retrying...")
            time.sleep(retry_delay)
    
   

    # Correctness judge with retry loop
    correctness_metrices = None
    correctness_rationale = ""
    for attempt in range(max_retries):
        correctness_jdg = correctness_judge(
            inputs={"question": question},
            expectations={"expectations": ground_truth},
            outputs=outputs
        )
        logger.info(f"Correctness judge result (attempt {attempt + 1}): {correctness_jdg}")
        correctness_metrices = correctness_jdg.feedback.value if correctness_jdg and correctness_jdg.feedback else None
        correctness_rationale = correctness_jdg.rationale if correctness_jdg else ""
        
        # Check if valid
        if correctness_metrices is not None and not (isinstance(correctness_metrices, float) and math.isnan(correctness_metrices)):
            logger.info(f"Correctness metrics valid on attempt {attempt + 1}")
            break
        
        if attempt < max_retries - 1:
            logger.warning(f"Correctness metrics invalid (attempt {attempt + 1}/{max_retries}), retrying...")
            time.sleep(retry_delay)

   
    logger.info(f"Correctness score: {correctness_metrices}")
    #this is the threshold to identify the correctness of the answer 
    correctness = "yes" if correctness_metrices >= 0.9 else "no"
    
    # Context judge with retry loop
    context_metrices = None
    for attempt in range(max_retries):
        context_jdg = context_judge(
            inputs={"question": question},
            expectations={"retrieved_context": context},
            outputs=outputs
        )
        logger.info(f"Context judge result (attempt {attempt + 1}): {context_jdg}")
        context_metrices = RetrievalMetricsExtractor.extract_feedback_scores(context_jdg)
        logger.info(f"Context metrics extracted: {context_metrices} (length: {len(context_metrices) if context_metrices else 0})")
        
        # Check if valid (exactly 3 values, no NaN)
        if context_metrices and len(context_metrices) == 3 and not any(v is None or (isinstance(v, float) and math.isnan(v)) for v in context_metrices):
            logger.info(f"Context metrics valid on attempt {attempt + 1}")
            break
        
        if attempt < max_retries - 1:
            logger.warning(f"Context metrics invalid (got {len(context_metrices) if context_metrices else 0} values, expected 3) - attempt {attempt + 1}/{max_retries}, retrying...")
            time.sleep(retry_delay)
    

    

    faithfulness_jdg = faithfulness_judge(
        inputs={"question": question},
        expectations={"ground_truth": ground_truth},
        outputs=outputs
    )
    faithfulness_metrices=faithfulness_jdg.feedback.value
    logger.info(f"Faithfulness judge,{faithfulness_metrices}")
    #logger.info(f"Faithfulness judge result (attempt {attempt + 1}): {faithfulness_jdg}")


    return [
        Feedback(name="correctness", value=correctness, rationale=correctness_rationale),
        Feedback(name="correctness_score", value=float(correctness_metrices), rationale=correctness_rationale),
        Feedback(name="response_relevance", value=float(relevance_metrices[0])),
        Feedback(name="response_completeness", value=float(relevance_metrices[1])),
        Feedback(name="context_relevance", value=float(context_metrices[0])),
        Feedback(name="context_precision", value=float(context_metrices[1])),
        Feedback(name="context_recall", value=float(context_metrices[2])),
        Feedback(name="Faithfulness", value=float(faithfulness_metrices))
    ]

# COMMAND ----------

@scorer(name="text_overlap_scorer", aggregations=["mean","p90"])
def text_overlap_scorer(*, inputs=None, outputs=None, expectations=None, trace=None):
    question = inputs.get("request", "") if inputs else ""
    ground_truth = expectations.get("expected_response", "") if expectations else ""
    outputs=outputs.get("response", "") if expectations else ""
    context = expectations.get("context", "") if expectations else ""
        
    evaluator = TemplateEvaluator()
    rouge_l_score= evaluator.rouge_l(outputs,ground_truth)
    f1_overlap_score=evaluator.f1_overlap(outputs,ground_truth)
   
  
    return [
    Feedback(name="rouge_l_score", value=rouge_l_score),
    Feedback(name="f1_overlap_score", value=f1_overlap_score),
   
]



# COMMAND ----------

@scorer(name="domain_specific_scorer", aggregations=["mean","p90"])
def domain_specific_scorer(*, inputs=None, outputs=None, expectations=None, trace=None):
 

    question = inputs.get("request", "") if inputs else ""
    ground_truth = expectations.get("expected_response", "") if expectations else ""
    outputs=outputs.get("response", "") if expectations else ""
    context = expectations.get("context", "") if expectations else ""
       
    
    cmp = BenefitTemplateComparator(ground_truth, outputs)

    deductible_check, ded_titles = cmp.deductible_check()
    cost_share_check, cs_titles = cmp.cost_share_check()
    oopm_check, oopm_titles = cmp.oopm_check()
    #print(deductible_check)

    evaluator = TemplateEvaluator()
    url_match_check=evaluator.url_match(outputs,ground_truth)
    phone_number_match_check=evaluator.phone_number_match(outputs,ground_truth)
   
    template_accuracy=evaluator.derive_template_accuracy(
    phone_number_match_check,url_match_check,deductible_check,cost_share_check,oopm_check)
    template_accuracy_score=template_accuracy.get("score")
    template_accuracy_verdict=template_accuracy.get("verdict")
    #print(template_accuracy)

  
    return [
    Feedback(name="deductible_check", value=deductible_check),
    Feedback(name="url_match_check", value=url_match_check),
    Feedback(name="phone_number_match_check", value=phone_number_match_check),
    Feedback(name="cost_share_check", value=cost_share_check),
    Feedback(name="oopm_check", value=oopm_check),
    Feedback(name="template_accuracy_score", value=template_accuracy_score),
    Feedback(name="template_accuracy_verdict", value=template_accuracy_verdict),
   
]



# COMMAND ----------

# from mlflow.genai.scorers import scorer
# from mlflow.entities import Feedback
# import json 

# @scorer(name="ranking_scorer")
# def ranking_scorer(*, inputs=None, outputs=None, expectations=None, trace=None):
 

#     question = inputs.get("request", "") if inputs else ""
#     ground_truth = expectations.get("expected_response", "") if expectations else ""
#     outputs=outputs.get("response", "") if expectations else ""
#     context = expectations.get("context", "") if expectations else ""
   
#     #context=json.dumps(context)
    
#     metrics = NexusMetrics() 
    
#     result = metrics.compute_metrics_for_query( response_text=outputs, ground_truth=ground_truth, context_items=context )

#     #print("result",result)
  
  
#     return [
    
#       *result_to_feedback(result)
# ]



# COMMAND ----------

import pandas as pd# Load Excel as pandas DataFrame
from pyspark.sql.functions import *
df_excel = pd.read_excel(EXCEL_PATH); df_excel['effectiveDate'] = df_excel['effectiveDate'].astype(str)


# Convert pandas DataFrame to Spark DataFrame
df_excel_spark = spark.createDataFrame(df_excel,schema="""id STRING, facetsProductId STRING, effectiveDate STRING, question STRING, ground_truth STRING, assistant_answer STRING""")

# display(df_excel_spark)

print(df_excel_spark.printSchema())
df_excel_spark = df_excel_spark.withColumn(
    "effectiveDate",
    regexp_replace("effectiveDate", r"\.0$", "")
)

df_excel_spark = df_excel_spark.withColumn(
    "id",
    concat(
        df_excel_spark["facetsProductId"],
        lit("_"),
        col("effectiveDate").cast("string"),
        lit("_"),
        df_excel_spark["id"]
    )
)
df_excel_spark = df_excel_spark.withColumn(
    "id",
    regexp_replace("id", r"\.0$", "")
)

from pyspark.sql.functions import rtrim

df_excel_spark = df_excel_spark.withColumn("id", rtrim("id"))
display(df_excel_spark)



# COMMAND ----------

from pyspark.sql.functions import expr, array_join, col

# Extract all values between -> and -> arrows
df_normalized = df_excel_spark.withColumn(
    "values_between_arrows_array",
    expr("regexp_extract_all(ground_truth, '->(.*?)->', 1)")
).withColumn(
    "values_between_arrows",
    array_join(col("values_between_arrows_array"), " | ")
).withColumn(
    "numeric_values_array",
    expr("""
        transform(
            regexp_extract_all(values_between_arrows, '([0-9]+(?:\\.[0-9]+)?)', 1),
            x -> try_cast(x as double)
        )
    """)
).withColumn(
    "minimum_numeric_value",
    expr("array_min(numeric_values_array)")
).drop("numeric_values_array")

display(df_normalized)

#Fetching the minimum threshold score from the ground truth response
from pyspark.sql.functions import col

df_normalized = df_normalized.select(
    "id", 
    "facetsProductId", 
    "effectiveDate", 
    "question", 
    "ground_truth",
    col("minimum_numeric_value").alias("minimum_threshold_score")
)

display(df_normalized)
# df_normalized.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(f"{env}_adb.{schema_name_gold}.{tbl_threshold_score_gt}")

# COMMAND ----------

# DBTITLE 1,list of question whose threshold score is below 0.2
df_min = df_normalized.select("id","facetsProductId","effectiveDate","question","minimum_threshold_score").where(col("minimum_threshold_score")<0.2)
display(df_min)


# COMMAND ----------



from pyspark.sql import functions as F
# Register both DataFrames as temp views
df_excel_spark.createOrReplaceTempView("excel_df")
spark.table(
    f"{env}_adb.nexusbenefitsquote_gold_mvp1.{context_table_path}"
).createOrReplaceTempView("context_tbl")


model_version_filter = "test_context_model_as/1"
# Use Spark SQL to join with LIKE operator on question columns
query = f"""
SELECT 
    e.*, 
    t.context
FROM 
    excel_df e
LEFT JOIN 
    context_tbl t
ON 
    e.facetsProductId = t.facets_product_id
    AND e.effectiveDate = t.effective_date
    AND e.id=t.id
    

"""

result_spark_df = spark.sql(query)

# Convert back to pandas if needed
result_spark_df=result_spark_df.withColumn("context_json",F.to_json("context")).drop("context")
result_spark_df=result_spark_df.withColumnRenamed("context_json","context")
display(result_spark_df)
print(result_spark_df.count())
df_result = result_spark_df.toPandas()

display(df_result)


# COMMAND ----------

result_spark_df.count()

# COMMAND ----------

df_result.count()

# COMMAND ----------

# DBTITLE 1,NDCG
import math
from typing import List, Set, Dict, Any
import builtins

def _compute_ndcg(relevant_ids: Set[int], ranked_ids: List[int], k: int) -> float:
    """
    Compute NDCG@k for multi-relevant case.
    
    Formula:
    - DCG@k = Σ (rel_i / log2(i+1)) for i=1 to k
    - rel_i = 1 if ranked_ids[i-1] in relevant_ids, else 0
    - IDCG@k = DCG of ideal ranking (all relevant first)
    - NDCG@k = DCG / IDCG
    
    Interpretation:
    - 1.0: All relevant items retrieved and ranked perfectly at top
    - High score: Relevant items appear early
    - Penalizes: Burying relevant items deep (log discount), missing relevant items
    - How to read: Better than precision/recall for ranking quality
    """
    if not ranked_ids:
        return 0.0

    true_relevance = [1.0 if nid in relevant_ids else 0.0 for nid in ranked_ids]

    def dcg(scores: List[float], limit: int) -> float:
        return builtins.sum(score / math.log2(idx + 2) for idx, score in enumerate(scores[:limit]))

    actual_dcg = dcg(true_relevance, k)
    ideal_dcg = dcg(sorted(true_relevance, reverse=True), k)
    return actual_dcg / ideal_dcg if ideal_dcg > 0 else 0.0


# COMMAND ----------

# DBTITLE 1,RETRIEVAL METRICS
import re
import json
from utility.retrieval_metrics_extractor import RetrievalMetricsExtractor
# ==================== RETRIEVAL METRICS ====================

@scorer(name="retrieval_scorer", aggregations=["p90"])
def retrieval_scorer(*,inputs,expectations: Dict[str, Any], **kwargs) -> List[Feedback]:
    """
    Computes retrieval_hit@1/3/5, precision@1/3/5, recall@1/3/5, ndcg@1/3/5
    Now supports MULTIPLE relevant nexusIds in ground truth.
    """
    question = inputs.get("request", "") if inputs else ""
    raw_context = expectations.get("context", [])
    ground_truth = expectations.get("expected_response", "")
    intent=""
    print("question",question)
    
    if "is not covered under your current policy" in ground_truth:
        intent="Exclusions"
    special_intents=["GenericDefinition","ProgramCategories","Exclusions"]
    docs = RetrievalMetricsExtractor.safe_parse_context(raw_context)
    
    gt_nexus_ids = RetrievalMetricsExtractor.extract_top_level_nexus_ids_from_ground_truth(ground_truth)
    print("gt_nexus_ids from gt",gt_nexus_ids)
    
    if not docs or not gt_nexus_ids:
        intent_list=classify_intent(question)
        print("intent_list",intent_list)
        intent=intent_list[0] if intent!="Exclusions" else intent
        print("intent",intent)
        if intent in special_intents:
            msg = f"The question belongs to {intent}.It does not have nexusID to compute the retrieval metrics and it is kept as default 1.0, refer correctness metrics for this question"
         
            return [
                Feedback(name=f"retrieval_{m}@{k}", value=1.0, rationale=msg)
                for m in ["hit", "precision", "recall", "ndcg"] for k in [1, 3, 5]
            ]
        else:
            error = "Missing context or no relevant nexusIds in ground truth"
            return [
                Feedback(name=f"retrieval_{m}@{k}", value=0.0, rationale=error)
                for m in ["hit", "precision", "recall", "ndcg"] for k in [1, 3, 5]
            ]
    
    context_nexus_ids = RetrievalMetricsExtractor.extract_nexus_ids_from_retrieved_context(docs)
    print("context_nexus_ids from context",context_nexus_ids)
    if not context_nexus_ids:
        error = "No nexusIds extracted from retrieved context"
        return [
            Feedback(name=f"retrieval_{m}@{k}", value=0.0, rationale=error)
            for m in ["hit", "precision", "recall", "ndcg"] for k in [1, 3, 5]
        ]

    feedbacks = []
    total_relevant = len(gt_nexus_ids)

    for k in [1, 3, 5]:
        top_k = context_nexus_ids[:k]
        relevant_in_top_k = len([nid for nid in top_k if nid in gt_nexus_ids])

        # Hit@k: 1 if at least one relevant in top-k
        hit = 1.0 if relevant_in_top_k > 0 else 0.0

        # Precision@k: fraction of top-k that are relevant
        precision = relevant_in_top_k / k

        # Recall@k: fraction of all relevant retrieved in top-k
        recall = relevant_in_top_k / total_relevant

        # NDCG@k: ranking quality with discount
        ndcg = _compute_ndcg(gt_nexus_ids, context_nexus_ids, k)

        base = f"Relevant IDs: {sorted(gt_nexus_ids)} | Found in top-{k}: {relevant_in_top_k}/{total_relevant}"

        feedbacks.extend([
            Feedback(name=f"retrieval_hit@{k}", value=hit,
                        rationale=f"{base} → Hit: 1 if any relevant in top-{k}"),
            Feedback(name=f"retrieval_precision@{k}", value=precision,
                        rationale=f"{base} → Precision: relevant in top-{k} / {k}"),
            Feedback(name=f"retrieval_recall@{k}", value=recall,
                        rationale=f"{base} → Recall: retrieved relevant / total relevant ({total_relevant})"),
            Feedback(name=f"retrieval_ndcg@{k}", value=ndcg,
                        rationale=f"{base} → NDCG: rewards early ranking of relevant items"),
        ])

    return feedbacks


# COMMAND ----------

# DBTITLE 1,RESPONSE METRICS

# ==================== RESPONSE METRICS ====================

@scorer(name="response_scorer", aggregations=["p90"])
def response_scorer(*,inputs, outputs: Dict[str, Any], expectations: Dict[str, Any], **kwargs) -> List[Feedback]:
    """
    Computes response_hit@1/3/5, precision@1/3/5, recall@1/3/5, ndcg@1/3/5
    Checks how many correct nexusIds the final answer cited.
    Treats cited IDs as an unordered set (no ranking in response).
    """
    question = inputs.get("request", "") if inputs else ""
    response_text = outputs.get("response", "")
    ground_truth = expectations.get("expected_response", "")
    intent=""
    
    if "is not covered under your current policy" in ground_truth:
        intent="Exclusions"
    special_intents=["GenericDefinition","ProgramCategories","Exclusions"]

    gt_nexus_ids = RetrievalMetricsExtractor.extract_top_level_nexus_ids_from_ground_truth(ground_truth)
    response_nexus_ids = RetrievalMetricsExtractor.extract_top_level_nexus_ids_from_response(response_text)

    if not gt_nexus_ids:
        intent_list=classify_intent(question)
        print("intent_list",intent_list)
        intent=intent_list[0] if intent!="Exclusions" else intent
        print("intent",intent)
        if intent in special_intents:
            msg = f"The question belongs to {intent}.It does not have nexusID to compute the response metrics and it is kept as default 1.0, refer correctness metrics for this question"
         
            return [
                Feedback(name=f"response_{m}@{k}", value=1.0, rationale=msg)
                for m in ["hit", "precision", "recall", "ndcg"] for k in [1, 3, 5]
            ]
        else:
            error = "No relevant nexusIds in ground truth"
            return [
                Feedback(name=f"response_{m}@{k}", value=0.0, rationale=error)
                for m in ["hit", "precision", "recall", "ndcg"] for k in [1, 3, 5]
            ]

    total_relevant = len(gt_nexus_ids)
    correctly_cited = len(response_nexus_ids.intersection(gt_nexus_ids))

    # For response: no ranking → simulate flat list of cited IDs (all at "rank 1" effectively)
    # But to fit @k framework, we treat cited correct ones as retrieved in top positions
    ranked_for_response = list(response_nexus_ids.intersection(gt_nexus_ids))  # correct ones first

    feedbacks = []

    for k in [1, 3, 5]:
        # Effective top-k retrieved correct citations
        relevant_in_top = builtins.min(k, correctly_cited)  # can't exceed actual correct citations

        hit = 1.0 if correctly_cited > 0 else 0.0
        precision = relevant_in_top / k
        recall = correctly_cited / total_relevant
        ndcg = _compute_ndcg(gt_nexus_ids, ranked_for_response, k)

        base = f"Relevant: {sorted(gt_nexus_ids)} | Cited correctly: {correctly_cited}/{total_relevant}"

        feedbacks.extend([
            Feedback(name=f"response_hit@{k}", value=hit,
                        rationale=f"{base} → Hit: 1 if any correct ID cited"),
            Feedback(name=f"response_precision@{k}", value=precision,
                        rationale=f"{base} → Precision: correct citations / {k}"),
            Feedback(name=f"response_recall@{k}", value=recall,
                        rationale=f"{base} → Recall: correct citations / total relevant"),
            Feedback(name=f"response_ndcg@{k}", value=ndcg,
                        rationale=f"{base} → NDCG: higher if more correct citations"),
        ])

    return feedbacks



# COMMAND ----------

print(len(df_result))

# COMMAND ----------

#df_result=df_result[:2]

# COMMAND ----------

#df_result=df_result.iloc[:10]
display(df_result)

# COMMAND ----------

df_result.count()

# COMMAND ----------

# DBTITLE 1,Cell 35
records = []
 
required = ["question", "ground_truth", "assistant_answer", "context", "id"]
missing = [c for c in required if c not in df_result.columns]
if missing:
    raise ValueError(f"Excel missing columns: {missing}")
 
for _, row in df_result.iterrows():
    ground_truth = row["ground_truth"]
    context = row["context"]
    # Ensure required expectation fields are not None
    if pd.isna(ground_truth) or ground_truth is None:
        ground_truth = ""
    if pd.isna(context) or context is None:
        context = ""
    records.append(
        {
            "inputs": {"request": str(row["question"])},
            "outputs": {"response": str(row["assistant_answer"])},
            "expectations": {
                "expected_response": ground_truth,
                "context": context,
            },
            "id": str(row["id"])
        }
    )
trace_eval_results = evaluate(
    data=records,
    scorers=[
        retrieval_scorer,
        response_scorer,
        core_agent_scorer,
        text_overlap_scorer,
        domain_specific_scorer,
    ],
)

# Add id column to trace_eval_results if not present
if hasattr(trace_eval_results, "tables") and "eval_results" in trace_eval_results.tables:
    trace_eval = trace_eval_results.tables["eval_results"]
    if "id" not in trace_eval.columns:
        trace_eval["id"] = [r["id"] for r in records]
    trace_eval_results.tables["eval_results"] = trace_eval
elif hasattr(trace_eval_results, "result_df"):
    if "id" not in trace_eval_results.result_df.columns:
        trace_eval_results.result_df["id"] = [r["id"] for r in records]


# COMMAND ----------

import pandas as pd
result_dfs = [te.result_df for te in [trace_eval_results]]

# COMMAND ----------

print(len(records))

# COMMAND ----------

trace_eval_batch = pd.concat(result_dfs, ignore_index=True)

# COMMAND ----------

trace_eval_batch.count()

# COMMAND ----------

# Getting the evaluation results as a pandas DataFrame
pdf = trace_eval_batch.astype(str)
# display(pdf)
 
pdf = spark.createDataFrame(pdf)
 
from pyspark.sql.functions import col, from_unixtime
 
# Convert milliseconds to seconds and create a readable timestamp column
pdf = pdf.withColumn(
    "request_time",
    from_unixtime(col("request_time")/ 1000)
)
 
cols = [
    col("id"),
    col("trace_id"),
    col("request"),
    col("response"),
    col("expected_response/value").alias("expected_response"),
    col("context/value").alias("context"),
    col("request_time"),
    col("execution_duration"),
    col("correctness/value").alias("correctness"),
    col("correctness_score/value").alias("correctness_score"),
    
    col("response_hit@1/value").alias("response_hit@1"),
    col("response_hit@3/value").alias("response_hit@3"),
    col("response_hit@5/value").alias("response_hit@5"),
    col("response_recall@1/value").alias("response_recall@1"),
    col("response_recall@3/value").alias("response_recall@3"),
    col("response_recall@5/value").alias("response_recall@5"),
    col("response_precision@1/value").alias("response_precision@1"),
    col("response_precision@3/value").alias("response_precision@3"),
    col("response_precision@5/value").alias("response_precision@5"),
    col("response_ndcg@1/value").alias("response_ndcg@1"),
    col("response_ndcg@3/value").alias("response_ndcg@3"),
    col("response_ndcg@5/value").alias("response_ndcg@5"),
    col("retrieval_hit@1/value").alias("retrieval_hit@1"),
    col("retrieval_hit@3/value").alias("retrieval_hit@3"),
    col("retrieval_hit@5/value").alias("retrieval_hit@5"),
    col("retrieval_recall@1/value").alias("retrieval_recall@1"),
    col("retrieval_recall@3/value").alias("retrieval_recall@3"),
    col("retrieval_recall@5/value").alias("retrieval_recall@5"),
    col("retrieval_precision@1/value").alias("retrieval_precision@1"),
    col("retrieval_precision@3/value").alias("retrieval_precision@3"),
    col("retrieval_precision@5/value").alias("retrieval_precision@5"),
    col("retrieval_ndcg@1/value").alias("retrieval_ndcg@1"),
    col("retrieval_ndcg@3/value").alias("retrieval_ndcg@3"),
    col("retrieval_ndcg@5/value").alias("retrieval_ndcg@5"),
    col("response_completeness/value").alias("response_completeness"),
    col("response_relevance/value").alias("response_relevance"),
    col("context_recall/value").alias("context_recall"),
    col("context_precision/value").alias("context_precision"),
    col("deductible_check/value").alias("deductible_check"),
    col("phone_number_match_check/value").alias("phone_number_match_check"),
    col("url_match_check/value").alias("url_match_check"),
    col("cost_share_check/value").alias("cost_share_check"),
    col("oopm_check/value").alias("oopm_check"),
    col("template_accuracy_score/value").alias("template_accuracy_score"),
    col("template_accuracy_verdict/value").alias("template_accuracy_verdict"),
    col("context_relevance/value").alias("context_relevance"),
    col("f1_overlap_score/value").alias("f1_overlap_score"),
    col("rouge_l_score/value").alias("rouge_l_score"),
    col("client_request_id"),
    col("state"),
    col("trace_metadata"),
    col("tags"),
    col("spans"),
    col("assessments"),
    col("trace")
]
pdf_final = pdf.select(cols)
display(pdf_final)
 


# COMMAND ----------

from pyspark.sql.functions import lit

pdf_final = pdf_final.withColumn("experiment", lit(experiment_run)).withColumn("threshold_run", lit(threshold_run))

# COMMAND ----------

display(pdf_final)

# COMMAND ----------

display(pdf_final)

# COMMAND ----------

pdf_final.write.mode("overwrite").format("delta").option("mergeSchema", "true").saveAsTable(f"{env}_adb.{schema_name_gold}.mvp1_tbl_metrics_result")

# COMMAND ----------

# import ast
# def safe_parse_context(raw_context: Any) -> List[Dict[str, Any]]:
#     """
#     Robustly convert raw context into a list of document dicts.
#     This method is crucial because context from data sources (e.g., Excel, traces) might be serialized as strings
#     (JSON or Python literals) or already as lists. It attempts multiple parsing strategies to handle real-world data variations.
#     If parsing fails, it logs a warning and returns an empty list to prevent scorer crashes.
    
#     Why this is needed: Data preparation might not always yield perfect lists, so this ensures robustness.
    
#     Handles:
#         - Already a list[dict]: Returns as-is.
#         - JSON string: Tries json.loads().
#         - Python literal string: Tries ast.literal_eval().
#         - None / NaN / empty string: Returns empty list.
#         - Unexpected types: Logs warning and returns empty list.
#     """
#     if isinstance(raw_context, list):
#         return raw_context
#     if raw_context is None or (isinstance(raw_context, float) and math.isnan(raw_context)):
#         return []
#     if isinstance(raw_context, str):
#         context_str = raw_context.strip()
#         if not context_str:
#             return []
#         try:
#             parsed = json.loads(context_str)
#             if isinstance(parsed, list):
#                 return parsed
#         except json.JSONDecodeError:
#             pass
#         try:
#             parsed = ast.literal_eval(context_str)
#             if isinstance(parsed, list):
#                 return parsed
#         except (ValueError, SyntaxError):
#             pass
#         print(f"Warning: Failed to parse context, using empty list: {context_str[:100]}...")
#         return []
#     print(f"Warning: Unexpected context type {type(raw_context)}, using empty list")
#     return []

# def extract_nexus_ids_from_retrieved_context(documents: List[Dict[str, Any]]) -> List[int]:
#     """
#     Extract nexusIds from retrieved documents, PRESERVING RANK ORDER.
#     Returns a list (not set) because ranking position matters for NDCG and @k metrics.
    
#     Why list not set: Order is critical — higher rank = more credit in NDCG.
#     Called after safe_parse_context to get ranked retrieved IDs.
#     """
#     ranked_nexus_ids = []
#     for doc in documents:
#         print(doc)
#         try:
#             fields_str = doc.get("eoc_categories_all_fields")
#             if not fields_str:
#                 continue
#             fields = json.loads(fields_str) if isinstance(fields_str, str) else fields_str
#             nexus_id = fields.get("eocCategories_nexusId")
#             if nexus_id is not None:
#                 ranked_nexus_ids.append(nexus_id)
#         except Exception:
#             continue  # Skip malformed docs
#     return ranked_nexus_ids    