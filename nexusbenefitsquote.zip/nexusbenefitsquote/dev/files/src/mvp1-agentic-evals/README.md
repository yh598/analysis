%md
%md
# Nexus Benefits Agent - MLflow Evaluation Framework

## Project Overview

This project implements a comprehensive evaluation framework for the Nexus Benefits conversational agent using MLflow. It assesses agent performance across multiple dimensions including retrieval quality, response accuracy, domain-specific template compliance, and text overlap metrics.

---

## Table of Contents

1. [Project Structure](#project-structure)
2. [Installation & Setup](#installation--setup)
3. [Core Components](#core-components)
4. [Evaluation Metrics](#evaluation-metrics)
5. [Helper Modules](#helper-modules)
6. [Utility Modules](#utility-modules)
7. [Usage Guide](#usage-guide)
8. [Configuration](#configuration)

---

## Project Structure

```
nexus-benefits-app/

├── helper/                          # Domain-specific integration scripts
│   ├── benefit_template_comparator.py
│   ├── template_evaluator.py
│   ├── intent_identifier.py
│   └── ndcg_metrics.py
├── utility/                         # Generic reusable functions
│   └── retrieval_metrics_extractor.py
├── main_evaluation.py
```

---

## Installation & Setup

### Prerequisites

* Python 3.8+
* Databricks workspace access
* MLflow 3.1+

### Installation

```bash
# Install core dependencies
%pip install --upgrade "mlflow[databricks]>=3.1"
%pip install --upgrade openpyxl rouge-score

# Restart Python kernel
dbutils.library.restartPython()
```

### Environment Configuration

```python
# Set environment (dev/prod)
dbutils.widgets.text("environment", "dev")
env = dbutils.widgets.get("environment").lower()

# Configure paths
EXCEL_PATH = "/Volumes/dev_adb/benefits_quote_bronze/bsc/question_answer_51_as.xlsx"
JUDGE_MODEL = "databricks:/databricks-claude-sonnet-4-5"
```

---

## Core Components

### 1. MLflow Experiment Setup

**Location:** Cell 6

```python
def start_mlflow_experiment(experiment_name):
    """
    Initialize MLflow experiment for tracking evaluation runs.
    
    Args:
        experiment_name (str): Name of the experiment
        
    Returns:
        mlflow.entities.Experiment: Configured experiment object
    """
    experiment_base_path = f"/Workspace/Users/aramya01@blueshieldca.com/ak-mlflow-eval"
    experiment_path = f"{experiment_base_path}/{experiment_name}"
    return mlflow.set_experiment(experiment_path)
```

### 2. LLM-as-Judge Evaluators

**Location:** Cells 9-11

Three specialized judges assess different aspects:

#### Relevance Judge
```python
relevance_judge = make_judge(
    name="response_relevance",
    instructions="Rate relevance and completeness separately (0.0-1.0)",
    feedback_value_type=float
)
```
**Outputs:** `response_relevance`, `response_completeness`

#### Faithfulness Judge
```python
faithfulness_judge = make_judge(
    name="faithfulness_and_completeness",
    instructions="Rate faithfulness and completeness vs ground truth",
    feedback_value_type=float
)
```
**Outputs:** `faithfulness`, `completeness`

#### Context Quality Judge
```python
context_judge = make_judge(
    name="context_quality",
    instructions="Rate retrieved context quality for answering questions",
    feedback_value_type=float
)
```
**Outputs:** `context_relevance`, `context_precision`, `context_recall`

---

## Evaluation Metrics

### Overview

The framework implements **4 custom scorers** with **28 total metrics**:

| Scorer | Metrics Count | Purpose |
|--------|---------------|----------|
| `core_agent_scorer` | 6 | LLM-judged quality metrics |
| `retrieval_scorer` | 12 | Retrieval ranking performance |
| `response_scorer` | 12 | Response citation accuracy |
| `text_overlap_scorer` | 2 | Lexical similarity |
| `domain_specific_scorer` | 7 | Benefits template compliance |

---

### 1. Core Agent Scorer

**Location:** Cell 15  
**File:** Main evaluation notebook

```python
@scorer(name="core_agent_scorer", aggregations=["mean","p90"])
def core_agent_scorer(*, inputs, outputs, expectations, trace):
    """
    Evaluates agent responses using LLM judges.
    
    Metrics:
    - response_relevance (0.0-1.0): How relevant the response is to the question
    - response_completeness (0.0-1.0): Whether response covers all aspects
    - context_relevance (0.0-1.0): Retrieved context relevance to question
    - context_precision (0.0-1.0): Proportion of useful context
    - context_recall (0.0-1.0): Coverage of key facts in context
    - Faithfulness (0.0-1.0): Factual alignment with ground truth
    """
```

**Interpretation:**
* **High scores (>0.8):** Excellent quality
* **Medium scores (0.5-0.8):** Acceptable, may need review
* **Low scores (<0.5):** Requires attention

---

### 2. Retrieval Scorer

**Location:** Cell 26  
**Documentation:** [Retrieval Metrics Details](#retrieval-metrics-details)

```python
@scorer(name="retrieval_scorer", aggregations=["p90"])
def retrieval_scorer(*, inputs, expectations, **kwargs):
    """
    Evaluates retrieval system performance using nexusId matching.
    
    Computes @1, @3, @5 variants for:
    - retrieval_hit@k: Binary - did we retrieve ANY relevant doc in top-k?
    - retrieval_precision@k: What fraction of top-k are relevant?
    - retrieval_recall@k: What fraction of ALL relevant docs did we retrieve?
    - retrieval_ndcg@k: Ranking quality with position discount
    """
```

**Special Handling:**
* Questions without nexusIds (GenericDefinition, ProgramCategories, Exclusions) default to 1.0
* Uses intent classification to identify these cases

**Example Output:**
```
Relevant IDs: {254, 688} | Found in top-3: 2/2
→ Hit@3: 1.0 (at least one relevant found)
→ Precision@3: 0.67 (2 relevant out of 3 retrieved)
→ Recall@3: 1.0 (all 2 relevant docs retrieved)
→ NDCG@3: 0.95 (excellent ranking)
```

---

### 3. Response Scorer

**Location:** Cell 27  
**Documentation:** [Response Metrics Details](#response-metrics-details)

```python
@scorer(name="response_scorer", aggregations=["p90"])
def response_scorer(*, inputs, outputs, expectations, **kwargs):
    """
    Evaluates which nexusIds the agent cited in its final response.
    
    Computes @1, @3, @5 variants for:
    - response_hit@k: Did agent cite ANY correct nexusId?
    - response_precision@k: Fraction of citations that are correct
    - response_recall@k: Fraction of relevant nexusIds cited
    - response_ndcg@k: Citation quality score
    """
```

**Key Difference from Retrieval:**
* Retrieval = what the system found
* Response = what the agent actually used/cited

---

### 4. Text Overlap Scorer

**Location:** Cell 17

```python
@scorer(name="text_overlap_scorer", aggregations=["mean","p90"])
def text_overlap_scorer(*, inputs, outputs, expectations, trace):
    """
    Lexical similarity metrics.
    
    Metrics:
    - rouge_l_score: Longest common subsequence F1
    - f1_overlap_score: Token-level F1 score
    """
```

---

### 5. Domain-Specific Scorer

**Location:** Cell 18  
**Documentation:** [Domain Metrics Details](#domain-metrics-details)

```python
@scorer(name="domain_specific_scorer", aggregations=["mean","p90"])
def domain_specific_scorer(*, inputs, outputs, expectations, trace):
    """
    Benefits-specific template validation.
    
    Metrics:
    - deductible_check: yes/no - Deductible amounts match
    - cost_share_check: yes/no - Cost sharing percentages match
    - oopm_check: yes/no - Out-of-pocket max rules match
    - url_match_check: yes/no - URLs present and correct
    - phone_number_match_check: yes/no - Phone numbers match
    - template_accuracy_score: 0-100 weighted score
    - template_accuracy_verdict: Pass/Needs Review/Action Required/Fail
    """
```

---

## Helper Modules

### 1. Benefit Template Comparator

**File:** `helper/benefit_template_comparator.py`  
**Purpose:** Domain-specific validation for benefits cost-sharing templates

#### Class: `BenefitTemplateComparator`

```python
class BenefitTemplateComparator:
    """
    Compares ground truth and predicted benefit templates.
    Extracts structured data from semi-structured benefit text.
    """
    
    def __init__(self, ground_truth: str, expected_response: str):
        """Parse both texts into structured format."""
        
    def deductible_check(self) -> Tuple[str, List[str]]:
        """Returns ('yes'/'no', list_of_matching_titles)"""
        
    def cost_share_check(self) -> Tuple[str, List[str]]:
        """Validates cost-sharing percentages/copays."""
        
    def oopm_check(self) -> Tuple[str, List[str]]:
        """Validates out-of-pocket maximum rules."""
```

**Key Features:**
* Order-independent comparison (subsections can appear in any order)
* Handles In-network vs Out-of-network provider blocks
* Regex-based extraction of structured benefit data

**Example Usage:**
```python
cmp = BenefitTemplateComparator(ground_truth, model_output)
deductible_ok, matched_titles = cmp.deductible_check()
print(f"Deductible check: {deductible_ok}")  # 'yes' or 'no'
print(f"Matched sections: {matched_titles}")  # ['emergency transport - air', ...]
```

---

### 2. Template Evaluator

**File:** `helper/template_evaluator.py`  
**Purpose:** Generic template validation utilities

#### Class: `TemplateEvaluator`

```python
class TemplateEvaluator:
    """
    Provides text similarity and entity extraction methods.
    """
    
    @staticmethod
    def rouge_l(pred: str, ref: str) -> float:
        """ROUGE-L F1 score (0.0-1.0)."""
        
    @staticmethod
    def f1_overlap(pred: str, truth: str) -> float:
        """Token-level F1 score."""
        
    @staticmethod
    def phone_number_match(response: str, expected: str) -> str:
        """Returns 'yes'/'no' for phone number match."""
        
    @staticmethod
    def url_match(response: str, expected: str) -> str:
        """Returns 'yes'/'no' for URL match."""
        
    @staticmethod
    def derive_template_accuracy(
        phone_ok: bool, url_ok: bool, 
        deductible_ok: bool, cost_share_ok: bool, oopm_ok: bool
    ) -> Dict[str, Any]:
        """
        Computes weighted accuracy score and verdict.
        
        Weights:
        - phone: 10%
        - url: 10%
        - deductible: 30%
        - cost_share: 30%
        - oopm: 20%
        
        Returns:
            {'score': 0-100, 'verdict': 'Pass'|'Needs Review'|'Action Required'|'Fail'}
        """
```

**Verdict Logic:**
* **Pass (100):** All checks pass
* **Needs Review (80-99):** Minor issues, but deductible & cost_share correct
* **Action Required (50-79):** Significant issues
* **Fail (<50):** Critical failures

---

### 3. Intent Identifier

**File:** `helper/intent_identifier.py`  
**Purpose:** Classify user questions into benefit intent categories

#### Function: `classify_intent`

```python
def classify_intent(question: str) -> List[str]:
    """
    Classifies question into one or more intent categories.
    
    Args:
        question: User's question text
        
    Returns:
        List of intent strings (e.g., ['EoCCategory', 'EoCSection'])
        
    Intent Categories:
    - PlanCostShares: Plan-level costs (deductible, OOP max, HSA)
    - BenefitCostShares: Service-level costs (copay, coinsurance)
    - EoCCategory: Coverage questions (is X covered?)
    - EoCSection: Rules, limits, prior auth requirements
    - ProgramCategories: Wellness programs, nurse line, telehealth
    - GenericDefinition: Term definitions
    - Exclusions: What's NOT covered
    - Fallback: Out-of-scope questions
    """
```

**Usage in Evaluation:**
```python
intent_list = classify_intent(question)
if intent_list[0] in ["GenericDefinition", "ProgramCategories", "Exclusions"]:
    # These don't have nexusIds, set retrieval metrics to 1.0
    return default_metrics
```

**Key Rules:**
* Questions can have multiple intents
* "Covered?" → EoCCategory
* "Excluded?" → Exclusions
* "How much?" → BenefitCostShares
* "Is prior auth required?" → EoCSection

---

## Utility Modules

### Retrieval Metrics Extractor

**File:** `utility/retrieval_metrics_extractor.py`  
**Purpose:** Generic utilities for parsing and extracting evaluation data

#### Class: `RetrievalMetricsExtractor`

```python
class RetrievalMetricsExtractor:
    """
    Reusable utility for handling retrieval evaluation data.
    Provides robust parsing and extraction methods.
    """
```

---

#### Method: `safe_parse_context`

```python
@staticmethod
def safe_parse_context(raw_context: Any) -> List[Dict[str, Any]]:
    """
    Robustly convert raw context into list of document dicts.
    
    Handles:
    - Already a list[dict]: Returns as-is
    - JSON string: Tries json.loads()
    - Python literal string: Tries ast.literal_eval()
    - None/NaN/empty: Returns []
    - Unexpected types: Logs warning, returns []
    
    Why needed: Data sources may serialize context differently.
    Excel, traces, or databases might store as strings.
    """
```

**Example:**
```python
# Input could be:
raw = '[{"nexusId": 688, "text": "..."}]'  # JSON string
raw = "[{'nexusId': 688}]"  # Python literal
raw = [{"nexusId": 688}]  # Already parsed

# All become:
docs = RetrievalMetricsExtractor.safe_parse_context(raw)
# [{"nexusId": 688, ...}]
```

---

#### Method: `extract_top_level_nexus_ids_from_ground_truth`

```python
@staticmethod
def extract_top_level_nexus_ids_from_ground_truth(ground_truth_text: str) -> Set[int]:
    """
    Extract ONLY the first bracketed nexusId from each top-level line.
    
    Example:
        Input:
            A. Emergency transport - air [688]
               Additional details [999]  # ignored
            B. Specialist visit [254]
            
        Output:
            {688, 254}
    
    Pattern: ^\s*[A-Z]\.\s.*?\[(\d+)\]
    
    Why only first: Nested IDs are sub-categories, not primary answers.
    """
```

---

#### Method: `extract_nexus_ids_from_retrieved_context`

```python
@staticmethod
def extract_nexus_ids_from_retrieved_context(documents: List[Dict[str, Any]]) -> List[int]:
    """
    Extract nexusIds from retrieved documents, PRESERVING RANK ORDER.
    
    Returns:
        List[int]: Ranked nexusIds (not set, order matters for NDCG)
    
    Process:
    1. Iterate through documents in retrieval order
    2. Parse 'eoc_categories_all_fields' JSON
    3. Extract 'eocCategories_nexusId'
    4. Append to list (preserving rank)
    
    Why list not set: Ranking position is critical for NDCG@k.
    """
```

**Example:**
```python
docs = [
    {"eoc_categories_all_fields": '{"eocCategories_nexusId": 688}'},
    {"eoc_categories_all_fields": '{"eocCategories_nexusId": 254}'},
    {"eoc_categories_all_fields": '{"eocCategories_nexusId": 688}'},  # duplicate
]

ranked_ids = RetrievalMetricsExtractor.extract_nexus_ids_from_retrieved_context(docs)
# [688, 254, 688]  # Order preserved, duplicates kept
```

---

#### Method: `extract_top_level_nexus_ids_from_response`

```python
@staticmethod
def extract_top_level_nexus_ids_from_response(response_text: str) -> Set[int]:
    """
    Extract nexusIds that the agent CITED in its final response.
    
    Same pattern as ground truth extraction:
        A. Service name [688]
        B. Another service [254]
    
    Returns:
        Set[int]: Unique cited nexusIds
    
    Use case: Measure if agent cited correct sources.
    """
```

---

#### Method: `extract_feedback_scores`

```python
@staticmethod
def extract_feedback_scores(feedback_obj) -> List[float]:
    """
    Parse LLM judge feedback into list of floats.
    
    Input formats handled:
    - String: "0.9, 0.85" → [0.9, 0.85]
    - List/Tuple: [0.9, 0.85] → [0.9, 0.85]
    - None/missing: → []
    
    Used by: core_agent_scorer to parse judge outputs.
    """
```

---

## Usage Guide

### Running a Complete Evaluation

**Step 1: Prepare Data**

```python
# Load evaluation dataset
df_excel = pd.read_excel(EXCEL_PATH)
df_excel['effectiveDate'] = df_excel['effectiveDate'].astype(str)

# Join with context data
df_excel_spark = spark.createDataFrame(df_excel)
result_spark_df = spark.sql("""
    SELECT e.*, t.context
    FROM excel_df e
    JOIN context_tbl t
    ON e.facetsProductId = t.facets_product_id
    AND e.effectiveDate = t.effective_date
    AND e.id = t.id
""")

df_result = result_spark_df.toPandas()
```

**Step 2: Format Records**

```python
records = []
for _, row in df_result.iterrows():
    records.append({
        "inputs": {"request": str(row["question"])},
        "outputs": {"response": str(row["assistant_answer"])},
        "expectations": {
            "expected_response": row["ground_truth"],
            "context": row["context"],
        },
    })
```

**Step 3: Run Evaluation**

```python
trace_eval = evaluate(
    data=records,
    scorers=[
        Correctness(),
        retrieval_scorer,
        response_scorer,
        core_agent_scorer,
        text_overlap_scorer,
        domain_specific_scorer,
    ],
)
```

**Step 4: Analyze Results**

```python
# View aggregated metrics
print(trace_eval.metrics)

# Access per-row scores
for row in trace_eval.tables['eval_results']:
    print(f"Question: {row['inputs/request']}")
    print(f"Retrieval NDCG@3: {row['retrieval_ndcg@3']}")
    print(f"Template Accuracy: {row['template_accuracy_score']}")
```

---

## Configuration

### Environment Variables

```python
# Environment (dev/prod)
env = dbutils.widgets.get("environment").lower()

# Data paths
EXCEL_PATH = "/Volumes/dev_adb/benefits_quote_bronze/bsc/question_answer_51_as.xlsx"
CONTEXT_TABLE = "dev_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_context_re"

# Model configuration
JUDGE_MODEL = "databricks:/databricks-claude-sonnet-4-5"
INTENT_ENDPOINT = "accenture-azure-gpt-4o-2024-08-06-sp"

# MLflow
EXPERIMENT_NAME = "Benefit_Agent_mlflow_make_Judge_goldendataset"
```

### Scorer Aggregations

```python
# Mean + P90 for most metrics
@scorer(name="core_agent_scorer", aggregations=["mean", "p90"])

# P90 only for retrieval (focus on worst cases)
@scorer(name="retrieval_scorer", aggregations=["p90"])
```

---

## Appendix: Detailed Metric Explanations

### Retrieval Metrics Details

#### Hit@k
**Formula:** `1 if any(retrieved_id in relevant_ids for retrieved_id in top_k) else 0`

**Interpretation:**
* Binary success metric
* Answers: "Did we retrieve at least one relevant document?"
* Useful for: Measuring basic retrieval success rate

**Example:**
```
Relevant: {688, 254}
Top-3 Retrieved: [100, 688, 200]
→ Hit@3 = 1.0 (found 688)
```

---

#### Precision@k
**Formula:** `relevant_in_top_k / k`

**Interpretation:**
* What fraction of retrieved docs are relevant?
* Penalizes irrelevant results
* Range: 0.0 (all irrelevant) to 1.0 (all relevant)

**Example:**
```
Relevant: {688, 254}
Top-3 Retrieved: [688, 100, 254]
→ Precision@3 = 2/3 = 0.67
```

---

#### Recall@k
**Formula:** `relevant_in_top_k / total_relevant`

**Interpretation:**
* What fraction of ALL relevant docs did we retrieve?
* Penalizes missing relevant docs
* Range: 0.0 (missed all) to 1.0 (found all)

**Example:**
```
Relevant: {688, 254, 300}
Top-3 Retrieved: [688, 254, 100]
→ Recall@3 = 2/3 = 0.67 (missed 300)
```

---

#### NDCG@k (Normalized Discounted Cumulative Gain)
**Formula:** `DCG@k / IDCG@k`

Where:
* `DCG@k = Σ(relevance_i / log2(position_i + 1))`
* `IDCG@k` = DCG of ideal ranking (all relevant first)

**Interpretation:**
* Rewards relevant docs appearing early
* Penalizes burying relevant docs deep
* Range: 0.0 (worst) to 1.0 (perfect ranking)

**Example:**
```
Relevant: {688, 254}
Top-3 Retrieved: [688, 100, 254]

DCG = 1/log2(2) + 0/log2(3) + 1/log2(4) = 1.0 + 0 + 0.5 = 1.5
IDCG = 1/log2(2) + 1/log2(3) + 0/log2(4) = 1.0 + 0.63 + 0 = 1.63
NDCG@3 = 1.5 / 1.63 = 0.92
```

**Why NDCG matters:**
* Precision/Recall ignore order
* NDCG rewards better ranking
* Critical for user experience (users read top results first)

---

### Domain Metrics Details

#### Template Accuracy Score Calculation

```python
WEIGHTS = {
    "phone": 10,
    "url": 10,
    "deductible": 30,
    "cost_share": 30,
    "oopm": 20,
}

score = sum(WEIGHTS[check] for check, passed in checks.items() if passed)
```

**Scoring Examples:**

| Checks Passed | Score | Verdict |
|---------------|-------|----------|
| All 5 | 100 | Pass |
| All except phone | 90 | Needs Review |
| Deductible + cost_share + oopm | 80 | Needs Review |
| Only deductible + cost_share | 60 | Action Required |
| Only phone + url | 20 | Fail |

**Critical Fields:**
* Deductible and cost_share are weighted highest (30% each)
* Must pass both for "Needs Review" or better
* Failing these results in "Action Required" or "Fail"

---

## Troubleshooting

### Common Issues

**1. Empty Context**
```python
# Check if context is null
df_result[df_result["context"].notnull()].count()

# Verify join conditions
result_spark_df.filter("context IS NULL").display()
```

**2. NexusId Extraction Failures**
```python
# Debug ground truth extraction
gt_text = "A. Emergency transport [688]\nB. Specialist [254]"
ids = RetrievalMetricsExtractor.extract_top_level_nexus_ids_from_ground_truth(gt_text)
print(ids)  # Should be {688, 254}
```

**3. Intent Classification Issues**
```python
# Test intent classifier
intents = classify_intent("What is the ER copay?")
print(intents)  # Should include 'BenefitCostShares'
```

---

## Best Practices

1. **Always validate data before evaluation**
   ```python
   assert df_result["context"].notnull().all(), "Missing context data"
   assert df_result["ground_truth"].notnull().all(), "Missing ground truth"
   ```

2. **Use P90 aggregations for retrieval metrics**
   * Focuses on worst-case performance
   * More actionable than mean for debugging

3. **Monitor template accuracy trends**
   * Track verdict distribution over time
   * Investigate "Action Required" cases first

4. **Combine metrics for holistic view**
   * High NDCG + Low faithfulness → Retrieval good, generation bad
   * Low NDCG + High faithfulness → Retrieval bad, generation good
   * Both low → Systemic issues

---



**Last Updated:** January 2026  
**Maintained By:** Nexus Benefits Evaluation Team  
**Contact:** pmane01@blueshieldca.com