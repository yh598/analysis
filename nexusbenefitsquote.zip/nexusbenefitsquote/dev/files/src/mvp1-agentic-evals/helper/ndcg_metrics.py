import importlib.util
import re
import math
import json
from typing import Dict, List, Optional, Sequence, Set, Any


class NexusMetrics:
    def __init__(self):
        self.avail = {p: self._has_pkg(p) for p in ["numpy", "pandas", "sklearn", "scipy", "mlflow"]}
        print("Package availability:", self.avail)

        self.use_sklearn_ndcg = bool(self.avail.get("sklearn"))
        if self.use_sklearn_ndcg:
            from sklearn.metrics import ndcg_score
            self._sk_ndcg_score = ndcg_score

        # Robust ID matcher: [688], ［688］, 【688】, (688)
        self.ID_RE = re.compile(r"[\[\(\uFF3B\u3010]\s*(\d+)\s*[\]\)\uFF3D\u3011]")

        # Extract ONLY the first bracketed ID on each top-level line (A., B., C., ...)
        # Example: "A. Something [688] -> Something [1513]"  => captures 688 only
        self.TOP_LEVEL_CHUNK_ID_RE = re.compile(
            r"^\s*[A-Z]\.\s.*?[\[\(\uFF3B\u3010]\s*(\d+)\s*[\]\)\uFF3D\u3011]",
            re.MULTILINE,
        )

        # Context item parsing
        self.EOC_NEXUS_RE = re.compile(r'"eocCategories_nexusId"\s*:\s*(\d+)')
        self.BENEFIT_ID_SUFFIX_RE = re.compile(r"_(\d+)$")

    def _has_pkg(self, name: str) -> bool:
        return importlib.util.find_spec(name) is not None

    # -----------------------------
    # Extraction utilities
    # -----------------------------
    def extract_all_ids(self, text: str) -> List[str]:
        """Extract all bracket-like numeric IDs, preserving order and de-duping."""
        if not text:
            return []
        ids = self.ID_RE.findall(text)
        seen: Set[str] = set()
        out: List[str] = []
        for x in ids:
            if x not in seen:
                out.append(x)
                seen.add(x)
        return out

    def extract_top_level_chunk_ids(self, text: str) -> List[str]:
        """Extract only chunk IDs (first bracket ID) from each A./B./C. line, preserving order and de-duping."""
        if not text:
            return []
        ids = self.TOP_LEVEL_CHUNK_ID_RE.findall(text)
        seen: Set[str] = set()
        out: List[str] = []
        for x in ids:
            if x not in seen:
                out.append(x)
                seen.add(x)
        return out

    def extract_nexus_id_from_context_item(self, item: dict) -> Optional[str]:
        """Extract eocCategories_nexusId from context item; fallback to benefit_id suffix."""
        s = item.get("eoc_categories_all_fields")
        if isinstance(s, str):
            m = self.EOC_NEXUS_RE.search(s)
            if m:
                return m.group(1)

        b = item.get("benefit_id")
        if isinstance(b, str):
            m2 = self.BENEFIT_ID_SUFFIX_RE.search(b)
            if m2:
                return m2.group(1)

        return None

    def extract_ranked_retrieved_ids_from_context(self, context_items: Sequence[dict]) -> List[str]:
        """Extract ranked retrieved nexus IDs in the given context order (assumed already ranked)."""
        ids: List[str] = []
        for item in context_items:
            nid = self.extract_nexus_id_from_context_item(item)
            if nid:
                ids.append(nid)
        return ids

    # -----------------------------
    # Metric primitives
    # -----------------------------
    def precision_at_k(self, pred_ids: List[str], relevant_ids: Set[str], k: int) -> float:
        if k <= 0:
            return 0.0
        topk = pred_ids[:k]
        if not topk:
            return 0.0
        hits = sum(1 for x in topk if x in relevant_ids)
        return hits / len(topk)

    def recall_at_k(self, pred_ids: List[str], relevant_ids: Set[str], k: int) -> float:
        if not relevant_ids:
            return 0.0
        topk = pred_ids[:k]
        hits = sum(1 for x in topk if x in relevant_ids)
        return hits / len(relevant_ids)

    def hit_at_k(self, pred_ids: List[str], relevant_ids: Set[str], k: int) -> float:
        topk = pred_ids[:k]
        return 1.0 if any(x in relevant_ids for x in topk) else 0.0

    def _dcg_at_k(self, rels: List[float], k: int) -> float:
        s = 0.0
        for i, rel in enumerate(rels[:k], start=1):
            s += rel / math.log2(i + 1)
        return s

    def _ndcg_at_k_custom(self, pred_ids: List[str], relevant_ids: Set[str], k: int) -> float:
        if k <= 0 or not pred_ids:
            return 0.0
        rels = [1.0 if pid in relevant_ids else 0.0 for pid in pred_ids]
        dcg = self._dcg_at_k(rels, k)
        ideal = sorted(rels, reverse=True)
        idcg = self._dcg_at_k(ideal, k)
        return (dcg / idcg) if idcg > 0 else 0.0

    def ndcg_at_k(self, pred_ids: List[str], relevant_ids: Set[str], k: int) -> float:
        if k <= 0 or not pred_ids or not relevant_ids:
            return 0.0
        # Build the candidate universe (what sklearn uses internally)
        universe = list(dict.fromkeys(list(pred_ids) + list(relevant_ids)))
        # In that case, NDCG is trivially 1.0 if that doc is relevant else 0.0
        if len(universe) < 2:
            return 1.0 if pred_ids[0] in relevant_ids else 0.0
        # If sklearn exists, use it; else fallback to custom
        if self.use_sklearn_ndcg:
            y_true = [[1.0 if uid in relevant_ids else 0.0 for uid in universe]]
            # Higher score for earlier rank in pred_ids; missing items get 0
            rank_map = {pid: float(len(pred_ids) - idx) for idx, pid in enumerate(pred_ids)}
            y_score = [[rank_map.get(uid, 0.0) for uid in universe]]
            # k must not exceed number of scandidates
            return float(self._sk_ndcg_score(y_true, y_score, k=min(k, len(universe))))
        return self._ndcg_at_k_custom(pred_ids, relevant_ids, k)

    # -----------------------------
    # Main metric computation
    # -----------------------------
    def compute_metrics_for_query(
        self,
        *,
        response_text: str,
        ground_truth: str,
        context_items: Sequence[dict] | str,
        expected_relevant_ids: Optional[Set[str]] = None,
        ks: Sequence[int] = (1, 3, 5),
        use_top_level_only: bool = True,
    ) -> Dict[str, Any]:

        # Choose extraction strategy
        extractor = self.extract_top_level_chunk_ids if use_top_level_only else self.extract_all_ids

        # Response IDs
        response_ids = extractor(response_text)

        # Expected relevant IDs
        if expected_relevant_ids is None:
            expected_relevant_ids = set(extractor(ground_truth))
        else:
            expected_relevant_ids = set(expected_relevant_ids)

        # Parse context_items if passed as JSON string
        if isinstance(context_items, str):
            context_items = json.loads(context_items)

        retrieved_ids = self.extract_ranked_retrieved_ids_from_context(context_items)
        print(retrieved_ids)

        # Special case: exclusion
        if isinstance(ground_truth, str) and "is an exclusion under your current policy" in ground_truth:
            expected_relevant_ids = {"3"}
            response_ids = ["3"]
            retrieved_ids = ["3"]

        out: Dict[str, Any] = {
            "expected_relevant_ids": sorted(expected_relevant_ids),
            "response_ranked_ids": response_ids,
            "retrieval_ranked_ids": retrieved_ids,
        }

        for k in ks:
            out[f"retrieval_precision@{k}"] = self.precision_at_k(retrieved_ids, expected_relevant_ids, k)
            out[f"retrieval_recall@{k}"]    = self.recall_at_k(retrieved_ids, expected_relevant_ids, k)
            out[f"retrieval_hit@{k}"]       = self.hit_at_k(retrieved_ids, expected_relevant_ids, k)
            out[f"retrieval_ndcg@{k}"]      = self.ndcg_at_k(retrieved_ids, expected_relevant_ids, k)

        for k in ks:
            out[f"response_precision@{k}"] = self.precision_at_k(response_ids, expected_relevant_ids, k)
            out[f"response_recall@{k}"]    = self.recall_at_k(response_ids, expected_relevant_ids, k)
            out[f"response_hit@{k}"]       = self.hit_at_k(response_ids, expected_relevant_ids, k)
            out[f"response_ndcg@{k}"]      = self.ndcg_at_k(response_ids, expected_relevant_ids, k)

        return out




