import re
from typing import Dict, List, Tuple
import re
from rouge_score import rouge_scorer


class BenefitTemplateComparator:
    # Matches: "a. Emergency transport - air"
    SUBSECTION_HEADER = re.compile(
        r"^\s*([a-z])\.\s*(.+?)\s*$",
        re.IGNORECASE | re.MULTILINE,
    )

    PROVIDER_BLOCK = re.compile(
        r"(In-network Provider:|Out-of-network Provider:)\s*"
        r"(.*?)"
        r"(?=(?:In-network Provider:|Out-of-network Provider:|^\s*[a-z]\.\s+|\Z))",
        re.DOTALL | re.IGNORECASE | re.MULTILINE,
    )

    OOPM_PREFIX = "the service applies"

    def __init__(self, ground_truth: str, expected_response: str):
        self.gt = self._extract_by_title(ground_truth)
        self.exp = self._extract_by_title(expected_response)

    # ---------- Helpers ----------

    @staticmethod
    def _norm(s: str) -> str:
        return re.sub(r"\s+", " ", s).strip()

    @staticmethod
    def _provider_key(label: str) -> str:
        return "In-network" if "in-network" in label.lower() else "Out-of-network"

    def _meaningful_lines(self, block: str) -> List[str]:
        lines = []
        for ln in block.splitlines():
            x = self._norm(ln)
            if x:
                lines.append(x)
        return lines

    # ---------- Core Extraction (order-independent) ----------

    def _extract_by_title(
        self, text: str
    ) -> Dict[Tuple[str, str], Dict[str, str]]:
        """
        Key: (subsection_title_lower, provider)
        Value: {deductible, cost_share, oopm}
        """
        out = {}

        headers = [
            (m.start(), m.end(), self._norm(m.group(2)).lower())
            for m in self.SUBSECTION_HEADER.finditer(text)
        ]

        for i, (_, header_end, title) in enumerate(headers):
            body_end = headers[i + 1][0] if i + 1 < len(headers) else len(text)
            subsection_body = text[header_end:body_end]

            for provider_label, provider_text in self.PROVIDER_BLOCK.findall(subsection_body):
                provider = self._provider_key(provider_label)
                lines = self._meaningful_lines(provider_text)

                deductible = lines[0] if len(lines) >= 1 else ""
                cost_share = lines[1] if len(lines) >= 2 else ""

                oopm = ""
                for ln in lines:
                    if ln.lower().startswith(self.OOPM_PREFIX):
                        oopm = ln
                        break

                out[(title, provider)] = {
                    "deductible": deductible,
                    "cost_share": cost_share,
                    "oopm": oopm,
                }

        #print(f"This is for the {text}--->"+str(out))
        return out

    # ---------- Public Checks ----------

    def deductible_check(self) -> Tuple[bool, List[str]]:
        """
        Returns:
          (passed, matching_titles)
        """
        failed = []
        matched = []

        #print("input to the deductible_check gt-->"+str(self.gt))
        #print("input to the deductible_check gt-->"+str(self.exp))

        common_keys = set(self.gt.keys()) & set(self.exp.keys())

        #print("common keys -->"+str(common_keys))
     
        for (title, provider) in common_keys:
            if self.gt[(title, provider)]["deductible"].lower() == \
               self.exp[(title, provider)]["deductible"].lower():
                matched.append(title)
            else:
                failed.append(title)

        return "yes" if len(failed) == 0 else "no", sorted(set(matched))

    def cost_share_check(self) -> Tuple[bool, List[str]]:
        failed = []
        matched = []

        common_keys = set(self.gt.keys()) & set(self.exp.keys())
        for (title, provider) in common_keys:
            if self.gt[(title, provider)]["cost_share"].lower() == \
               self.exp[(title, provider)]["cost_share"].lower():
                matched.append(title)
            else:
                failed.append(title)

        return "yes" if len(failed) == 0 else "no", sorted(set(matched))

    def oopm_check(self) -> Tuple[bool, List[str]]:
        """
        Rules:
        - If GT has OOPM and Expected does NOT → fail
        - If both have OOPM → must match
        - If GT does NOT have OOPM → pass
        """
        failed = []
        matched = []

        common_keys = set(self.gt.keys()) & set(self.exp.keys())
        for (title, provider) in common_keys:
            gt_oopm = self.gt[(title, provider)]["oopm"]
            exp_oopm = self.exp[(title, provider)]["oopm"]

            if gt_oopm:
                if not exp_oopm or gt_oopm.lower() != exp_oopm.lower():
                    failed.append(title)
                else:
                    matched.append(title)
            else:
                matched.append(title)

        return "yes" if len(failed) == 0 else "no", sorted(set(matched))
   