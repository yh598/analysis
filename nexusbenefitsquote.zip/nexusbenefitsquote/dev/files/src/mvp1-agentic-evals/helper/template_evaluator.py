import re
from typing import Dict, List, Tuple
import re
from rouge_score import rouge_scorer

class TemplateEvaluator:
    WORD_PATTERN = re.compile(r"\w+", re.UNICODE)

    WEIGHTS = {
        "phone": 10,
        "url": 10,
        "deductible": 30,
        "cost_share": 30,
        "oopm": 20,
    }

    @staticmethod
    def tokenize(text: str):
        if not isinstance(text, str):
            return []
        return TemplateEvaluator.WORD_PATTERN.findall(text.lower())

    @staticmethod
    def f1_overlap(pred: str, truth: str) -> float:
        pred_tokens = TemplateEvaluator.tokenize(pred)
        truth_tokens = TemplateEvaluator.tokenize(truth)

        if not pred_tokens or not truth_tokens:
            return 0.0

        pred_set = set(pred_tokens)
        truth_set = set(truth_tokens)

        common = len(pred_set & truth_set)
        if common == 0:
            return 0.0

        precision = common / len(pred_set)
        recall = common / len(truth_set)

        if precision + recall == 0:
            return 0.0
        return 2 * precision * recall / (precision + recall)

    @staticmethod
    def lcs_length(a, b):
        dp = [[0]*(len(b)+1) for _ in range(len(a)+1)]
        for i in range(1, len(a)+1):
            for j in range(1, len(b)+1):
                if a[i-1] == b[j-1]:
                    dp[i][j] = dp[i-1][j-1] + 1
                else:
                    dp[i][j] = max(dp[i-1][j], dp[i][j-1])
        return dp[-1][-1]

    @staticmethod
    def rouge_l(pred: str, ref: str) -> float:
        scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)
        if not pred or not ref:
            return 0.0
        score = scorer.score(ref, pred)
        return score["rougeL"].fmeasure

    @staticmethod
    def phone_number_match(response: str, expected_response: str):
        def extract_phone(text):
            digits = re.sub(r'\D', '', str(text))
            return digits if 7 <= len(digits) <= 15 else None
        phone1 = extract_phone(response)
        phone2 = extract_phone(expected_response)
        if phone2:
            return "yes" if phone1 and phone2 and phone1 == phone2 else "no"
        elif not phone1 and not phone2:
            return "yes"

    @staticmethod
    def url_match(response: str, expected_response: str):
        def extract_urls(text):
            return set(re.findall(r'https?://[^\s,;]+', str(text)))
        urls_pred = extract_urls(response)
        urls_gt = extract_urls(expected_response)
        if not urls_gt:
            return "yes" if not urls_pred else "no"
        if len(urls_pred & urls_gt) / len(urls_gt) == 1:
            return "yes"
        else:
            return "no"

    @staticmethod
    def derive_template_accuracy(
        phone_ok: bool,
        url_ok: bool,
        deductible_ok: bool,
        cost_share_ok: bool,
        oopm_ok: bool,
    ):
        checks = {
            "phone": phone_ok,
            "url": url_ok,
            "deductible": deductible_ok,
            "cost_share": cost_share_ok,
            "oopm": oopm_ok,
        }

        score = sum(
            TemplateEvaluator.WEIGHTS[k] for k, passed in checks.items() if passed
        )

        if score == 100:
            verdict = "Pass"
        elif score >= 80 and deductible_ok and cost_share_ok:
            verdict = "Needs Review"
        elif score >= 50:
            verdict = "Action Required"
        else:
            verdict = "Fail"

        return {
            "score": score,
            "verdict": verdict
        }

