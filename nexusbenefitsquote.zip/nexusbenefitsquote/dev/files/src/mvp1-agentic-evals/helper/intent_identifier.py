import json
import re
from typing import List, Dict, Any, Union

# --- Known intents (exact, case-sensitive as emitted by the prompt) ---
KNOWN_INTENTS = {
    "PlanCostShares",
    "BenefitCostShares",
    "EoCCategory",
    "EoCSection",
    "ProgramCategories",
    "GenericDefinition",
    "Exclusions",
    "Fallback",
}

def _coerce_json(text: str) -> Dict[str, Any]:
    """Parse model output as JSON (robust to code fences)."""
    text = (text or "").strip()
    try:
        return json.loads(text)
    except Exception:
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())
        return json.loads(text)

def _normalize_intents(raw_intent: Union[str, List[Any], None]) -> List[str]:
    """Normalize and filter intents to KNOWN_INTENTS."""
    if raw_intent is None:
        return []

    if isinstance(raw_intent, str):
        parts = [p.strip() for p in raw_intent.split(",") if p.strip()]
    elif isinstance(raw_intent, list):
        parts = [str(p).strip() for p in raw_intent if str(p).strip()]
    else:
        parts = [str(raw_intent).strip()]

    normalized: List[str] = []
    for p in parts:
        if p in KNOWN_INTENTS:
            normalized.append(p)
            continue
        for ki in KNOWN_INTENTS:
            if p.lower() == ki.lower():
                normalized.append(ki)
                break

    # de-dup preserving order
    seen = set()
    out: List[str] = []
    for i in normalized:
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out

def classify_intent(question: str) -> List[str]:
    """
    Simple function:
    - accepts a question
    - keeps the ORIGINAL intent prompt AS-IS
    - returns intent(s)
    """
    import mlflow.deployments

    # --- ORIGINAL INTENT PROMPT (UNCHANGED) ---
    prompt = f"""
STEP 1: CLASSIFY THE INTENT(S) (return one or more)
A single question may contain multiple intents.  
Return one or more intents separated by commas.  
Never invent new ones. Always return at least one.
Available intents:
1. PlanCostShares  
→ Plan-level cost details.  
Includes deductible (per person/family), out-of-pocket maximum, accumulator type, HSA eligibility, INN/OON deductible, or plan-level coinsurance.  
Keywords: deductible, OOP max, accumulator, embedded, aggregate, HSA, plan type.  
Examples:  
- “Is this plan HSA-eligible?”
2. BenefitCostShares  
→ Service-level cost sharing (specific copay or coinsurance).  
Includes ER copay, per-visit copay, coinsurance %, waived if admitted, etc.  
Keywords: copay, coinsurance, ER, per-visit, per-admission, OOP applies,cost.  
Examples:  
- “What is the ER copay?”  
- “How much does a specialist visit cost?”
-what does any specific service cost?"
- “Are non-FDA (Food and Drug Administration) approved drugs covered?”
3. EoCCategory  
→ Whether a category/service/medical equipment is covered or included at all. Any question that ask about coverage which may oe may not be related to medical/insurance terminology.
Keywords: cover, included, benefit name (maternity, infertility, DME, mental health, vision, preventive,telehealth). 
Examples:  
- “Does this plan cover infertility treatment?”  
- “Is preventive care included?”  
- "Is a car transport to an office visit covered?"
- “Are DME items covered?”
- “Is telehealth an option on this plan?”
- “How much does Liposuction cost?”
4. EoCSection  
→ Detailed rules, limits, or conditions under a covered benefit.  
Includes: prior authorization, step therapy, referral, visit/frequency limits, waiting periods, medical necessity, conditional coverage.  
Keywords: prior auth, pre-cert, referral, limit, step therapy, medically necessary, authorization required.  
Examples:  
- “Is prior authorization required for MRI?”  
- “Are PT visits limited to 30 per year?”
5. ProgramCategories  
→ Add-on or wellness programs and vendor-based offerings.  
Includes: nurse line,out of state,out of californial, travelling coverage telehealth, case management, advocacy, BlueCard, EAP, disease management, diabetes program.  
Keywords: nurse line, telehealth, concierge, case management, BlueCard, EAP, wellness program.  
Examples:  
- “Does this plan have a nurse hotline?”  
-"Am I covered out of sate?"
-"Am I covered while travelling?"
- “Is there a diabetes management program?”
-"Can I talk to a nurse?"
6. GenericDefinition  
→ If question is about Definitions of insurance or healthcare terms .  
Keywords: what is, define, explain, meaning of, my deductible, my out of pcoket maximum.  
Examples:  
- “What is a deductible?”  
- “What is my out of pocket maximum?.”
7. Exclusions  
→ Items, services, or drugs that are NOT COVERED under the plan — permanently or conditionally.  
Includes cosmetic or elective procedures, experimental services, OTC drugs, vitamins, supplies, or limitations listed under Exclusions & Limitations.  
Keywords: excluded, not covered, exclusion list, exception, limitation, not payable, not eligible, experimental, cosmetic, over-the-counter.  
Examples:  
- “Are over-the-counter drugs excluded?”  
- “Is cosmetic surgery not covered?”  
- “Which services are under exclusions?”  
- “Are infertility treatments excluded?”  
- “Is acupuncture excluded?”
-------------------------------
EXCLUSIONS vs COVERAGE RULE
-------------------------------
If question asks:
- “Covered(not out of state/travelling)/included?” → EoCCategory  
- “Excluded/not covered/covered(out ofstate)/exception?” → Exclusions  
- Both coverage & exclusion → EoCCategory, Exclusions  
- Coverage + rule (prior auth, limit) → EoCCategory, EoCSection  
- Excluded with condition (“unless medically necessary”) → Exclusions, EoCSection  
- If ambiguous, default to EoCCategory.
8. Fallback  
→ Use this ONLY when the user question is completely outside the domain of health insurance or benefits.  
For example:
- Greetings or conversational prompts (e.g., “hi”, “hello”, “how are you?”)
- Weather, location, travel time, or any general-knowledge queries unrelated to insurance
- Personal or unrelated topics (e.g., food, movies, relationships, general health advice)
- Any question where the intent cannot reasonably map to PlanCostShares, BenefitCostShares, EoCCategory, EoCSection, ProgramCategories, GenericDefinition, or Exclusions.

Important:  
Do NOT classify a question as Fallback if it is even loosely about insurance, benefits, coverage, cost shares, limits, rules, or plan terminology.  
Fallback is strictly for out-of-scope, non-insurance questions only.

RETURN JSON ONLY:
{{
  "Intent": ["<one or more intents from the list>"]
}}

Question:
{json.dumps(question)}
""".strip()
    # --- END ORIGINAL PROMPT ---

    client = mlflow.deployments.get_deploy_client("databricks")
    response = client.predict(
        endpoint="accenture-azure-gpt-4o-2024-08-06-sp",
        inputs={
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0,
        },
    )

    raw = response["choices"][0]["message"]["content"]
    payload = _coerce_json(raw)
    intents = _normalize_intents(payload.get("Intent"))

    # safety defaults
    if not intents:
        intents = ["EoCCategory"]

    # preserve your earlier safeguard
    if "EoCSection" in intents:
        intents = ["EoCCategory"]

    return intents

# Example:
# intents = classify_intent("What is the ER copay for this plan?", LLM_ENDPOINT_SECONDARY)
# print(intents)
