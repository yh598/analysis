# Q&A Pairs Pipeline - Healthcare Benefits Context Extraction

## Overview

The **Q&A Pairs Pipeline** is a comprehensive system for generating high-quality question-answer pairs and extracting healthcare benefits context from the Nexus Benefits Quote system. This pipeline consists of two main components:

1. **Copay Context Extractor**: LangGraph-based agentic system for extracting cost-share context from healthcare benefits data
2. **Q&A Pairs Generator**: Automated pipeline for generating evaluation datasets from production inference logs

This pipeline supports the evaluation and continuous improvement of the healthcare benefits agent by providing structured training and evaluation data.

---

## Project Structure

```
qa_pairs_pipeline/
├── README.md                          # This file - main pipeline documentation
├── copay_context_extractor.py         # LangGraph-based context extraction system
└── qa_pairs.py                        # Q&A pair generation from inference logs
```

---

## Key Features

* **LangGraph-Based Extraction**: State-driven workflow for extracting healthcare benefits context
* **Template-Driven Responses**: Comprehensive template system for PPO and HMO plan types
* **Vector Search Integration**: Databricks Vector Search for semantic retrieval
* **Automated Q&A Generation**: Extract Q&A pairs from production inference logs
* **Context Preservation**: Maintains full context including questions, answers, and retrieved documents
* **Volume-Based Storage**: Organized storage in Databricks Volumes for easy access

---

## System Requirements

### Python Version
* Python 3.8 or higher

### Core Dependencies
* **MLflow 3.1.3+**: Model tracking and deployment
* **LangChain 0.3.0+**: LLM orchestration framework
* **LangGraph**: State graph workflow management
* **Databricks LangChain**: Databricks-specific LangChain integrations
* **Databricks Vector Search 0.40+**: Semantic search capabilities
* **PySpark**: Data processing and table operations

---

## Installation

### 1. Install Dependencies

```python
%pip install --upgrade \
  mlflow[databricks]>=3.1.3 \
  databricks-langchain \
  langchain>=0.3.0 \
  langgraph \
  databricks-vectorsearch>=0.40
```

### 2. Restart Python Environment

```python
dbutils.library.restartPython()
```

### 3. Configure Environment Variables

Set up required widgets for environment configuration:

```python
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("input_csv_file_name", "")
dbutils.widgets.text("last_date", "")
dbutils.widgets.text("max_rows", "150")
```

---

## Component 1: Copay Context Extractor

### Overview

The **Copay Context Extractor** is a sophisticated LangGraph-based system that extracts healthcare benefits cost-share context using a state-driven workflow. It processes user questions about healthcare benefits and returns structured context including plan details, cost shares, and benefit information.

### Architecture

#### State Graph Workflow

```
[Entry] → PlanDetect → ClassifyIntent → CopayCoinsurance → [End]
```

**State Components**:
* `messages`: Conversation history
* `input`: User question
* `expanded_question`: LLM-expanded question for better retrieval
* `plan_nexus`: Plan identifier
* `plan_name`: Plan name
* `plan_cost_share`: Plan-level cost sharing details
* `cost_share`: Service-level cost sharing information
* `intent`: Classified user intent
* `facets_product_id`: Product identifier
* `effective_date`: Plan effective date

### Tools

#### 1. PlanDetectTool

Detects plan information from product ID and effective date.

**Input**:
```python
{
    "facets_product_id": "MG011320",
    "effective_date": "20240101"
}
```

**Output**:
```python
{
    "plan_nexus": 23085,
    "plan_name": "Gold 80 HMO",
    "plan_cost_share": "...",
    "plan_type": "HMO"
}
```

#### 2. ClassifyIntentTool

Classifies user intent and expands the question for better retrieval.

**Available Intents**:
* `PlanCostShares`: Plan-level costs (deductible, OOP max)
* `BenefitCostShares`: Service-level costs (copays, coinsurance)
* `EoCCategory`: Coverage questions
* `EoCSection`: Benefit rules and limits
* `ProgramCategories`: Wellness programs
* `GenericDefinition`: Term definitions
* `Exclusions`: Non-covered services
* `Fallback`: Out-of-scope queries

**Input**:
```python
{
    "input": "What is the ER copay?"
}
```

**Output**:
```python
{
    "intent": "BenefitCostShares",
    "expanded_question": "What is the emergency room copayment amount for this plan?",
    "followup": ""
}
```

#### 3. CopayCoinsuranceTool

Retrieves cost-share information using vector search.

**Input**:
```python
{
    "input": "What is the ER copay?",
    "plan_nexus": 23085
}
```

**Output**:
```json
[
    {
        "benefit_id": "23085_688",
        "eoc_categories_all_fields": "{...}"
    }
]
```

#### 4. DefinitionTool

Returns concise health insurance definitions.

**Input**:
```python
{
    "input": "What is a deductible?",
    "plan_nexus": 23085
}
```

**Output**:
```json
[
    {
        "benefit_id": "23085_definition",
        "eoc_categories_all_fields": "{...}"
    }
]
```

#### 5. FallbackAgentTool

Handles out-of-scope queries with polite responses.

**Input**:
```python
{
    "question": "What's the weather today?"
}
```

**Output**:
```
"I apologize, but I can only answer questions about your health insurance benefits. Is there anything about your plan coverage I can help you with?"
```

### Template System

The system uses comprehensive templates for PPO and HMO plan types covering various cost-share scenarios:

#### PPO Templates

* **Subject to Deductible & Coinsurance**: Deductible applies, then coinsurance
* **Subject to Deductible & Copay**: Deductible applies, then flat copay
* **Not Subject to Deductible; Subject to Coinsurance**: Coinsurance only
* **Not Subject to Deductible; Subject to Copay**: Copay only
* **Not Subject to Deductible; No Patient Liability**: 100% covered
* **NAB or General Exclusion**: Not covered
* **Not Covered through OON/OOS Provider**: In-network only

#### HMO Templates

* **Subject to Deductible & Coinsurance**: Deductible applies, then coinsurance (in-network only)
* **Subject to Deductible & Copay**: Deductible applies, then copay (in-network only)
* **Not Subject to Deductible; Subject to Coinsurance**: Coinsurance only (in-network only)
* **Not Subject to Deductible; Subject to Copay**: Copay only (in-network only)
* **Not Subject to Deductible; No Patient Liability**: 100% covered (in-network only)
* **NAB or General Exclusion**: Not covered
* **Not Covered through OON/OOS Provider**: In-network only

#### Special Cases

* **Emergency**: Emergency services covered at in-network rate
* **Acupuncture/Chiropractic/Therapeutic Massage**: Discount program via ChooseHealthy
* **Annual Physical (HMO)**: Rolling 12-month schedule
* **Inpatient/Outpatient Facility**: Admission notification required
* **Physical Therapy**: PT programs available
* **Surgery**: Surgical package includes pre-op and post-op care
* **Urgent Care (HMO)**: Check PCP/IPA for in-network clinics
* **Hearing Aids**: Discount program via EPIC Hearing Healthcare
* **Fitness/Gym**: Gym membership discounts available
* **Vision**: Discount vision program or vendor-administered
* **Pharmacy**: Tiered pharmacy benefits
* **Dental**: Vendor-administered benefits

### Usage Example

```python
# Build the graph
graph = build_graph()

# Invoke with input data
input_data = {
    "input": "what is the cost share for emergency room?",
    "facets_product_id": "MG011320",
    "effective_date": "20240101"
}

state = graph.invoke(input_data)

# Access results
print(f"Plan Nexus: {state['plan_nexus']}")
print(f"Plan Name: {state['plan_name']}")
print(f"Intent: {state['intent']}")
print(f"Cost Share: {state['cost_share']}")
```

### Batch Processing

Process multiple questions from CSV:

```python
import pandas as pd

INPUT_CSV_PATH = (
    f"/Volumes/{environment}_adb/benefits_quote_silver/"
    f"benefit_quoting_mvp1-mg011320_20240101_ifp_answers/{input_csv_file_name}"
)

pdf = pd.read_csv(INPUT_CSV_PATH)

results = []
for idx in range(len(pdf)):
    row = pdf.iloc[idx]
    input_data = {
        "input": row["question"],
        "facets_product_id": row["facets_product_id"],
        "effective_date": row["effective_date"]
    }
    try:
        state = graph.invoke(input_data)
        context = state.get("cost_share", [])
    except Exception as e:
        context = []
    results.append({
        "question": row["question"],
        "facets_product_id": row["facets_product_id"],
        "effective_date": row["effective_date"],
        "context": context
    })

result_df = spark.createDataFrame(results)
result_df.write.mode("overwrite").saveAsTable(
    "dev_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_context_re"
)
```

---

## Component 2: Q&A Pairs Generator

### Overview

The **Q&A Pairs Generator** extracts question-answer pairs from production inference logs stored in the `tbl_inference_token_costs` table. This component supports evaluation dataset creation and continuous improvement of the healthcare benefits agent.

### Features

* **Date Range Filtering**: Extract Q&A pairs for specific date ranges
* **Row Limiting**: Control dataset size with configurable max rows
* **Context Extraction**: Parse and extract context from inference requests
* **Volume Storage**: Save results to Databricks Volumes for easy access
* **CSV Export**: Export Q&A pairs as CSV files with timestamps

### Configuration

#### Widgets

```python
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("last_date", "")  # Format: MM-DD-YY
dbutils.widgets.text("max_rows", "150")
```

#### Parameters

* **environment**: Environment (dev, qa, prod)
* **last_date**: End date for Q&A extraction (default: today)
* **max_rows**: Maximum number of rows to extract (default: 150)

### Data Flow

#### 1. Extract Q&A Pairs

```python
from pyspark.sql.functions import col, lit
from datetime import datetime, timedelta

# Get parameters
max_rows = int(dbutils.widgets.get("max_rows"))
last_date_str = dbutils.widgets.get("last_date")

# Calculate date range
today = datetime.today().date()
if last_date_str:
    last_date = datetime.strptime(last_date_str, "%m-%d-%y").date()
else:
    last_date = today

start_date = last_date if last_date_str else today - timedelta(days=7)

# Read from inference table
df_qa_context = spark.table(
    f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_inference_token_costs"
).filter(
    (col("request_date") >= lit(start_date)) & 
    (col("request_date") <= lit(last_date))
).select(
    "request_date", "databricks_request_id", "question", "answer"
).limit(max_rows)
```

#### 2. Extract Context

```python
from pyspark.sql.functions import split, trim, try_element_at

start_point = "Insurance plan data:"
end_point = "Your response must rely"

df_qa_context = df_qa_context.withColumn(
    "split_by_start",
    split(col("request"), start_point, 2)
).withColumn(
    "after_start",
    try_element_at(col("split_by_start"), lit(2))
).withColumn(
    "split_by_end",
    split(col("after_start"), end_point, 2)
).withColumn(
    "context",
    trim(try_element_at(col("split_by_end"), lit(1)))
).drop("split_by_start", "after_start", "split_by_end")
```

#### 3. Save to Volume

```python
from datetime import datetime

# Create volume if not exists
catalog = f"{environment}_adb"
schema = "nexusbenefitsquote_gold_mvp1"
volume = "qa_pairs_volume"
spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")

# Save as CSV with timestamp
now = datetime.now()
file_name = f"qa_pairs_{now.strftime('%d-%m-%y_%H_%M')}.csv"
file_path = f"/Volumes/{catalog}/{schema}/{volume}/{file_name}"
df_qa_context.write.mode("overwrite").option("header", "true").csv(file_path)
```

### Output Format

#### CSV Structure

```csv
request_date,databricks_request_id,question,answer,context
2024-01-15,abc-123-def,What is the ER copay?,"The ER copay is $300 per visit.","[{...}]"
2024-01-15,abc-124-def,Is preventive care covered?,"Yes, preventive care is covered at 100%.","[{...}]"
```

#### Columns

* **request_date**: Date of the inference request
* **databricks_request_id**: Unique request identifier
* **question**: User question
* **answer**: Agent response
* **context**: Retrieved context (JSON array of documents)

### Usage Example

#### Extract Last 7 Days

```python
# Set widgets
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("last_date", "")  # Empty = today
dbutils.widgets.text("max_rows", "150")

# Run extraction (automatically uses last 7 days)
# Output: /Volumes/dev_adb/nexusbenefitsquote_gold_mvp1/qa_pairs_volume/qa_pairs_15-01-24_14_30.csv
```

#### Extract Specific Date Range

```python
# Set widgets
dbutils.widgets.text("environment", "dev")
dbutils.widgets.text("last_date", "01-15-24")  # MM-DD-YY
dbutils.widgets.text("max_rows", "200")

# Run extraction (uses specified end date)
# Output: /Volumes/dev_adb/nexusbenefitsquote_gold_mvp1/qa_pairs_volume/qa_pairs_15-01-24_14_30.csv
```

---

## Integration with Evaluation Pipeline

The Q&A pairs generated by this pipeline are used in the [MVP1 Agentic Evaluation System](../mvp1-agentic-evals/README.md) for:

* **Ground Truth Validation**: Compare agent responses against expected answers
* **Retrieval Metrics**: Evaluate context retrieval quality (NDCG, precision@k, recall@k)
* **Template Accuracy**: Validate response structure and content
* **Intent Classification**: Verify intent detection accuracy

### Workflow

```
[Production Inference] → [Q&A Pairs Generator] → [CSV Export] → [Evaluation Pipeline]
                                                                         ↓
                                                                  [MLflow Metrics]
```

---

## Best Practices

### Copay Context Extractor

* **Template Selection**: Ensure correct template is selected based on plan type (PPO/HMO) and cost-share structure
* **Vector Search Tuning**: Adjust `k` parameter based on query complexity (default: 6)
* **Reranking**: Use `rerank_column` for better relevance in vector search
* **Error Handling**: Wrap graph invocations in try-except blocks for batch processing
* **State Inspection**: Log intermediate state for debugging complex queries

### Q&A Pairs Generator

* **Date Range**: Use specific date ranges for targeted evaluation datasets
* **Row Limiting**: Start with smaller datasets (50-100 rows) for initial testing
* **Context Validation**: Verify context extraction is working correctly before large-scale runs
* **Volume Organization**: Use timestamped filenames for version control
* **Data Quality**: Filter out malformed or incomplete Q&A pairs

---

## Troubleshooting

### Issue: Graph Invocation Fails

**Symptoms**: `KeyError` or `AttributeError` during graph execution

**Solutions**:
1. Verify all required state fields are initialized
2. Check tool outputs are in expected format (JSON strings)
3. Ensure vector search index is available and populated
4. Validate input data format (facets_product_id, effective_date)

### Issue: Context Extraction Returns Empty

**Symptoms**: `context` column is empty or null

**Solutions**:
1. Verify `start_point` and `end_point` markers exist in request text
2. Check inference table has recent data
3. Validate date range filter is correct
4. Ensure request column contains full prompt text

### Issue: Template Not Found

**Symptoms**: No matching template for cost-share scenario

**Solutions**:
1. Review template guardrails for matching conditions
2. Check plan type (PPO vs HMO) is correctly detected
3. Verify cost-share structure fields (structureType, subjectToDeductible)
4. Add custom template for edge cases

### Issue: Vector Search Timeout

**Symptoms**: Vector search queries timeout or fail

**Solutions**:
1. Reduce `k` parameter (default: 6 → 3)
2. Check vector search index health
3. Verify index is not being rebuilt
4. Use simpler queries for testing

---

## Configuration

### Environment Variables

```python
# Environment
environment = "dev"  # dev, qa, prod

# Vector Search
BENEFIT_INDEX = "dev_adb.nexusbenefitsquote_gold_mvp1.benefit_index"

# LLM Endpoints
LLM_ENDPOINT = "accenture-azure-gpt-4o-2024-08-06-sp"
LLM_ENDPOINT_SECONDARY = "accenture-azure-gpt-4o-2024-08-06-sp"

# Tables
INFERENCE_TABLE = f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_inference_token_costs"
CONTEXT_TABLE = f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_mvp1_context_re"

# Volumes
QA_PAIRS_VOLUME = f"{environment}_adb.nexusbenefitsquote_gold_mvp1.qa_pairs_volume"
```

---

## Performance Considerations

### Copay Context Extractor

* **Vector Search**: O(log n) for index lookup, O(k) for reranking
* **LLM Calls**: 2-3 LLM calls per query (intent classification, question expansion, fallback)
* **Batch Processing**: Process 100-200 questions per batch for optimal performance
* **Caching**: Consider caching plan detection results for repeated queries

### Q&A Pairs Generator

* **Table Scan**: Full table scan with date filter (use partitioning for large tables)
* **Context Parsing**: O(n) string operations per row
* **CSV Export**: Coalesce to single partition for small datasets (<1000 rows)
* **Volume Storage**: Use Delta format for large datasets (>10,000 rows)

---

## Related Documentation

* **[Main Project README](../../README.md)**: Overall project documentation
* **[MVP1 Agentic Evaluation System](../mvp1-agentic-evals/README.md)**: Agent evaluation framework
* **[Setup Documentation](../setup/README.md)**: Infrastructure setup and configuration

---

## Support

For questions about the Q&A pairs pipeline: Please connect with MVP1 team

* **Team**: MVP1 Data Pipeline Team
* **Contact**: sgupta27@blueshieldca.com, pmane01@blueshieldca.com
* **Slack**: #nexus-benefits-quote

---

## Contributing

When modifying the Q&A pairs pipeline:

1. **Test in dev**: Always test changes in dev environment first
2. **Validate templates**: Ensure new templates follow existing structure
3. **Document changes**: Update this README with new features
4. **Code review**: Get approval from data pipeline team
5. **Monitor metrics**: Track extraction quality and performance

---


