# Databricks notebook source
dbutils.widgets.text("environment", "dev")
environment = dbutils.widgets.get("environment")
dbutils.widgets.text("last_date", "")
dbutils.widgets.text("max_rows", "150")

# COMMAND ----------

# DBTITLE 1,questions&answer
from pyspark.sql.functions import col, lit, regexp_extract
from datetime import datetime, timedelta
from pyspark.sql.functions import regexp_extract, col, concat_ws
from pyspark.sql.functions import split, col, element_at, trim, try_element_at, lit

# Get max_rows widget or default to 150
max_rows = int(dbutils.widgets.get("max_rows"))

# Get last_date widget or default to today
last_date_str = dbutils.widgets.get("last_date")
if not last_date_str:
    last_date_str = None

today = datetime.today().date()
if last_date_str:
    last_date = datetime.strptime(last_date_str, "%m-%d-%y").date()
else:
    last_date = today

start_date = last_date if last_date_str else today - timedelta(days=7)

# Read from table
df_qa_context = spark.table(f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_inference_token_costs").filter(
    (col("request_date") >= lit(start_date)) & (col("request_date") <= lit(last_date))
).select(
    "request_date","databricks_request_id", "question", "answer"
).limit(
    max_rows
)
display(df_qa_context)
# Create volume if not exists
catalog = f"{environment}_adb"
schema = "nexusbenefitsquote_gold_mvp1"
volume = "qa_pairs_volume"
spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")

# Save as file qa_pairs_curaten_date_hh_mm
now = datetime.now()
file_name = f"qa_pairs_{now.strftime('%d-%m-%y_%H_%M')}.csv"
file_path = f"/Volumes/{catalog}/{schema}/{volume}/{file_name}"
df_qa_context.write.mode("overwrite").option("header", "true").csv(file_path)

# COMMAND ----------

# MAGIC %md
# MAGIC context generation

# COMMAND ----------

from pyspark.sql.functions import col, lit, split, trim, try_element_at
from datetime import datetime, timedelta

input_ground_df = spark.table(f"{environment}_adb.nexusbenefitsquote_gold_mvp1.ground_table")

# Read from table
df_qa_context = spark.table(f"{environment}_adb.nexusbenefitsquote_gold_mvp1.tbl_inference_token_costs")

start_point = "Insurance plan data:"
end_point = "Your response must rely"

df_qa_context = df_qa_context.withColumn(
    "split_by_start",
    split(col("request"), start_point, 2)
).withColumn(
    "after_start",
    try_element_at(col("split_by_start"), lit(2))
).withColumn(
    "split_by_end",
    split(col("after_start"), end_point, 2)
).withColumn(
    "context",
    trim(try_element_at(col("split_by_end"), lit(1)))
).drop("split_by_start", "after_start", "split_by_end")

# Join with input_ground_df on databricks_request_id
df_joined = df_qa_context.join(
    input_ground_df,
    on="databricks_request_id",
    how="inner"
).select(
    df_qa_context["request_date"],
    df_qa_context["question"],
    df_qa_context["answer"],
    df_qa_context["context"],
    df_qa_context["databricks_request_id"]
)

# Create volume if not exists
catalog = f"{environment}_adb"
schema = "nexusbenefitsquote_gold_mvp1"
volume = "qa_pairs_volume"
spark.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}")

# Save as file qa_pairs_curaten_date_hh_mm
now = datetime.now()
file_name = f"qa_pairs_{now.strftime('%d-%m-%y_%H_%M')}.csv"
file_path = f"/Volumes/{catalog}/{schema}/{volume}/{file_name}"
df_qa_context.write.mode("overwrite").option("header", "true").csv(file_path)