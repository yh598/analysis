# Databricks notebook source
# MAGIC %pip install --upgrade databricks-sdk

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("environment", "dev")

env: str = dbutils.widgets.get("environment").lower()

# COMMAND ----------

import yaml
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.database import DatabaseInstance, DatabaseCatalog

# COMMAND ----------

import yaml
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.database import DatabaseInstance, DatabaseCatalog

class LakebaseManager:
    def __init__(self, config_path="config.yaml"):
        config_full_path = os.path.join(os.getcwd(), config_path)
        with open(config_full_path, "r") as f:
            config = yaml.safe_load(f)

        key = f"lakebase_db_instace_{env}"
        self.db_config =config[key]
        self.catalog_config = config.get("database_catalog", {})
        self.w = WorkspaceClient()

    def create_database_instance(self):
        try:
            instance = self.w.database.create_database_instance(
                DatabaseInstance(
                    name=self.db_config["name"],
                    capacity=self.db_config["capacity"],
                    node_count=self.db_config["node_count"] # the nodes are two for HA
                )
            )
            print(f"Created database instance: {instance.name}")
            print(f"Connection endpoint: {instance.read_write_dns}")
            return instance
        except Exception as e:
            print(f"Failed to create database instance: {e}")
    
            

    def stop_database_instance(self):
        try:
            self.w.database.update_database_instance(
                name=self.db_config["name"],
                database_instance=DatabaseInstance(
                    name=self.db_config["name"],
                    stopped=True
                ),
                update_mask="*"
            )
            print(f"Stopped database instance: {self.db_config['name']}")
        except Exception as e:
            print(f"Failed to stop database instance: {e}")

    def start_database_instance(self):
        try:
            self.w.database.update_database_instance(
                name=self.db_config["name"],
                database_instance=DatabaseInstance(
                    name=self.db_config["name"],
                    stopped=False
                ),
                update_mask="*"
            )
            print(f"Started database instance: {self.db_config['name']}")
        except Exception as e:
            print(f"Failed to start database instance: {e}")

    def register_database_catalog(self):
        try:
            catalog = self.w.database.create_database_catalog(
                DatabaseCatalog(
                    name=self.catalog_config["catalog_name"],
                    database_instance_name=self.db_config["name"],
                    database_name=self.catalog_config["database_name"],
                    create_database_if_not_exists=self.catalog_config.get("create_database_if_not_exists", True)
                )
            )
            print(f"Created and registered database catalog: {catalog.name}")
            return catalog
        except Exception as e:
            print(f"Failed to register database catalog: {e}")

    def create_schema(self, schema_name):
        try:
            self.w.schemas.create(
                name=schema_name,
                catalog_name=self.catalog_config["catalog_name"],
                comment="Created by LakebaseManager"
            )
            print(f"Created schema: {schema_name}")
        except Exception as e:
            print(f"Failed to create schema: {e}")


# COMMAND ----------

import os
lakebase = LakebaseManager("config.yaml")
lakebase.create_database_instance()


# COMMAND ----------

import time
time.sleep(300)

# COMMAND ----------

# MAGIC %pip install psycopg[binary]

# COMMAND ----------

# DBTITLE 1,configuration setup
# repo_root/.. (adjust if needed)
parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
# print(parent_dir)

import sys,os
sys.path.insert(0, parent_dir)

from utilities.delta_table_utils import DeltaTableClient
from utilities.data_pipeline.ingestion import *

dbutils.widgets.text("config_file", "dev_config.yml")
config_file: str = dbutils.widgets.get("config_file").lower()

# Load parameters from YAML file
config_path = os.path.join('..','configs', config_file)
print(config_path)

with open(config_path, 'r') as file:
    config = yaml.safe_load(file)
	
catalog = config['catalog_name']
gold_schema = config['schema_name_gold']
tbl_feedback_lookup: str = "tbl_feedback_lookup"

# COMMAND ----------

import pyspark.sql.functions as F

# Create a PySpark DataFrame with a single row and select the current user
df = spark.range(1).select(F.session_user().alias("current_user"))

# Convert the current user to a string
current_user_name = df.select("current_user").collect()[0]["current_user"]

# Print the current user name as a string
print(current_user_name)

# COMMAND ----------

config_full_path = os.path.join(os.getcwd(), "config.yaml")
with open(config_full_path, "r") as f:
    config = yaml.safe_load(f)
    key = f"lakebase_db_instace_{env}"
    instance_name = config[key]["name"]
    print(f"Insance name is-->{instance_name} ")

# COMMAND ----------


# Databricks notebook: provision_lakebase_role.py
# %pip install psycopg2-binary
import psycopg2, os

from databricks.sdk import WorkspaceClient
import psycopg
from psycopg.rows import tuple_row
import uuid

# ─── CONFIG ─────────────────────────────────────────────────────────
INSTANCE = instance_name  # Lakebase instance name
USERNAME = current_user_name  # Postgres role (must exist in Lakebase)
DBNAME = "databricks_postgres"  # fixed name per docs
# ────────────────────────────────────────────────────────────────────
w = WorkspaceClient()

def _conn(autocommit=False):
    inst = w.database.get_database_instance(name=INSTANCE)
    print(inst)
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()), instance_names=[INSTANCE]
    )
    return psycopg.connect(
        host=f"instance-{inst.uid}.database.azuredatabricks.net",
        port=5432,
        dbname="databricks_postgres",
        user=USERNAME,
        password=cred.token,
        sslmode="require",
        connect_timeout=10,
        autocommit=autocommit,
    )
with _conn(autocommit=True) as c:                     # one‑time DDL
    c.execute("""
      CREATE TABLE IF NOT EXISTS plans_questions (
    id INT PRIMARY KEY,
    plan_name TEXT,
    questions JSONB
);
    """)

with _conn(autocommit=True) as c:
    c.execute("""
        INSERT INTO plans_questions (id, plan_name, questions)
        VALUES (
            1,
            'smallgroup',
            '[
                {"question": "What is my copayment or cost for seeing my primary care physician (PCP)?", "popularity": 1},
                {"question": "What is my copayment or cost to see a specialist (e.g., dermatologist, cardiologist)?", "popularity": 2},
                {"question": "If I''m traveling outside of California, do I have coverage?", "popularity": 3},
                {"question": "What is my copayment for prescription drugs?", "popularity": 4}
            ]'::jsonb
        )
        ON CONFLICT (id) DO NOTHING;
    """)

with _conn(autocommit=True) as c:                     # one‑time DDL
    c.execute("""
     CREATE TABLE IF NOT EXISTS tbl_benefitsquote_feedback(
    response_id VARCHAR(64),
    question_id VARCHAR(64),
    user_id VARCHAR(64),
    user_name VARCHAR(128),
    feedback_type VARCHAR(32),
    reason_code VARCHAR(16)[],
    additional_comments TEXT,
    session_id VARCHAR(64),
    feedback_response_id varchar(50),
    insert_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (session_id, user_id, question_id)
);
    """)


# COMMAND ----------

with _conn(autocommit=True) as c:                     # one‑time DDL
    c.execute("""
CREATE TABLE IF NOT EXISTS master_table (
    facets_product_id VARCHAR(255),
    product_effective_date VARCHAR(255),
    product_type VARCHAR(255),
    plan_type VARCHAR(255),
    product_description VARCHAR(255),
    plan_id VARCHAR(255),
    requested_time TIMESTAMP,
    requester_id VARCHAR(255),
    dbr_silver_layer_ready VARCHAR(255),
    update_time TIMESTAMP,
    insert_time TIMESTAMP,
    vector_db_ready VARCHAR(255),
    ready_for_agent VARCHAR(255),
    comments VARCHAR(255),
    data_issue VARCHAR(255),
    bronze_ready_flag VARCHAR(255),
    CONSTRAINT unique_facets_id_and_date UNIQUE (facets_product_id, product_effective_date)
);
""")    

# COMMAND ----------

with _conn(autocommit=True) as c:                     # one‑time DDL
    c.execute("""
CREATE TABLE IF NOT EXISTS chat_history (
session_id VARCHAR(255),
user_id VARCHAR(255),
question_id  VARCHAR(255),
insert_timestamp TIMESTAMP,
qa_pairs JSONB,
is_summerized BOOLEAN,
summary TEXT
);
""")    

# COMMAND ----------

spark.sql(f"create schema if not exists {env}_adb.nexusbenefitsquote_bronze_mvp1")

# COMMAND ----------

# DBTITLE 1,Create Volume for CSV Place Holder
spark.sql(f"create volume if not exists {env}_adb.nexusbenefitsquote_bronze_mvp1.input_file")

# COMMAND ----------

# DBTITLE 1,remove old chat history
with _conn(autocommit=True) as c:
    c.execute("""
        CREATE OR REPLACE PROCEDURE remove_old_chat_records(days_ago integer)
        LANGUAGE plpgsql
        AS $$
        BEGIN
            DELETE FROM chat_history
            WHERE insert_timestamp < NOW() - (days_ago || ' days')::interval;
        END;
        $$;
""")

# COMMAND ----------

# DBTITLE 1,table- logging response request
with _conn(autocommit=True) as c:
    c.execute("""
CREATE TABLE IF NOT EXISTS tbl_agent_api_logs (
    question_id VARCHAR(255),
    response_status VARCHAR(255),
    insert_ts TIMESTAMP,
    response_time_sec BIGINT
);
""")    

# COMMAND ----------

# DBTITLE 1,Creating feedback lookup table and inserting data into this table
tbl_feedback_lookup_query = f"""
    CREATE TABLE IF NOT EXISTS {catalog}.{gold_schema}.{tbl_feedback_lookup} (
    code STRING,
    description STRING,
    feedback_type STRING
   )using delta
"""
spark.sql(tbl_feedback_lookup_query)

# Data insertion
spark.sql(f"""
INSERT INTO {catalog}.{gold_schema}.{tbl_feedback_lookup}
VALUES
  ('NF01', 'Wrong information', 'thumbs_down'),
  ('NF02', 'Missing details', 'thumbs_down'),
  ('NF03', "Didn't answer my question", 'thumbs_down'),
  ('NF04', 'Issue with sources', 'thumbs_down'),
  ('NF05', 'Information is old', 'thumbs_down'),
  ('PF01', 'Accurate', 'thumbs_up'),
  ('PF02', 'Easy to understand', 'thumbs_up'),
  ('PF03', 'Just the right length', 'thumbs_up'),
  ('PF04', 'Helpful sources', 'thumbs_up'),
  ('PF05', 'Very thorough', 'thumbs_up'),
  ('OT01', 'Other', 'thumbs_up, thumbs_down')
""")