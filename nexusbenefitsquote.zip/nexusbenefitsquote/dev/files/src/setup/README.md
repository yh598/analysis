# Nexus Benefits Setup - Infrastructure Provisioning Documentation

## Project Overview

The **Nexus Benefits Setup** project provides infrastructure provisioning and access management for the Nexus Benefits application on Databricks. It automates the creation and configuration of Lakebase PostgreSQL instances, manages access permissions for apps, agents, and database resources, and maintains configuration across development and production environments.

### Key Features

* **Lakebase PostgreSQL Provisioning**: Automated creation and management of Lakebase database instances
* **Access Management**: Centralized permission management for apps, agents, and database resources
* **Environment Configuration**: YAML-based configuration for dev/prod environments
* **Service Principal Integration**: Automatic SPN discovery and permission assignment
* **Database Schema Setup**: Automated table creation and stored procedure deployment

---

## Table of Contents

1. [Project Structure](#project-structure)
2. [Architecture Overview](#architecture-overview)
3. [Installation & Setup](#installation--setup)
4. [Configuration](#configuration)
5. [Notebooks](#notebooks)
6. [Utility Modules](#utility-modules)
7. [Helper Modules](#helper-modules)
8. [Usage Guide](#usage-guide)
9. [Troubleshooting](#troubleshooting)

---

## Project Structure

```
setup/
├── config.yaml                      # Main configuration file
├── access_provisioning.py           # Access management notebook
├── lakebase.py                      # Lakebase provisioning notebook
└── README.md                        # This file
```

---

## Architecture Overview

### Component Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                      config.yaml                            │
│  • Environment settings (dev/prod)                          │
│  • Resource IDs (apps, agents)                              │
│  • Access control lists                                     │
│  • Lakebase configuration                                   │
└────────┬────────────────────────────────────────────────────┘
         │
         ├──────────────────────┬──────────────────────────────┐
         │                      │                              │
         ▼                      ▼                              ▼
┌─────────────────┐   ┌─────────────────┐         ┌─────────────────┐
│  lakebase.py    │   │ access_         │         │  Databricks     │
│                 │   │ provisioning.py │         │  Resources      │
│ • Create DB     │   │                 │         │                 │
│   instance      │   │ • Grant app     │         │ • Apps          │
│ • Register      │   │   permissions   │         │ • Agents        │
│   catalog       │   │ • Grant agent   │         │ • Lakebase      │
│ • Create tables │   │   permissions   │         │                 │
│ • Deploy procs  │   │ • Grant DB      │         │                 │
│                 │   │   permissions   │         │                 │
└─────────────────┘   └─────────────────┘         └─────────────────┘
         │                      │                              │
         └──────────────────────┴──────────────────────────────┘
                                │
                                ▼
                    ┌─────────────────────┐
                    │  PostgreSQL         │
                    │  Lakebase Instance  │
                    │                     │
                    │  • master_table     │
                    │  • chat_history     │
                    │  • feedback         │
                    │  • plans_questions  │
                    └─────────────────────┘
```

---

## Installation & Setup

### Prerequisites

* Databricks workspace with admin access
* Python 3.10+
* Databricks SDK
* psycopg (PostgreSQL adapter)
* PyYAML

### Step 1: Install Dependencies

```python
%pip install --upgrade databricks-sdk
%pip install psycopg[binary]
%pip install pyyaml

dbutils.library.restartPython()
```

### Step 2: Configure Environment

Create or update `config.yaml` with your environment settings:

```yaml
# Environment selection
environment: dev  # or prod

# Resource IDs
resource_ids:
  agent_dev: "nexus-benefits-agent-dev"
  agent_prod: "nexus-benefits-agent-prod"
  app_name_dev: "nexus-benefits-app-dev"
  app_name_prod: "nexus-benefits-app-prod"

# Lakebase configuration
lakebase_db_instace_dev:
  name: "nexus-lakebase-dev"
  capacity: "SMALL"
  node_count: 2

lakebase_db_instace_prod:
  name: "nexus-lakebase-prod"
  capacity: "MEDIUM"
  node_count: 2

# Database catalog
database_catalog:
  catalog_name: "nexus_catalog"
  database_name: "databricks_postgres"
  create_database_if_not_exists: true

# Access control lists
access_app_dev:
  user_id_list:
    CAN_MANAGE:
      - "user1@example.com"
      - "user2@example.com"
    CAN_USE:
      - "user3@example.com"
  service_list:
    CAN_MANAGE: []

access_agents_dev:
  user_id_list:
    CAN_QUERY:
      - "user1@example.com"
  service_list:
    CAN_QUERY: []

access_lakebase_dev:
  service_list:
    - "service-principal-1"
  user_id_list:
    - "user1@example.com"

# Lakebase tables
lakebase_table_list:
  - "master_table"
  - "chat_history"
  - "tbl_benefitsquote_feedback"
  - "plans_questions"
```

---

## Configuration

### Configuration File Structure

The `config.yaml` file is the central configuration hub for the entire setup infrastructure.

#### Environment Settings

```yaml
environment: dev  # Current environment (dev/prod)
```

#### Resource IDs

Maps logical resource names to actual Databricks resource identifiers:

```yaml
resource_ids:
  agent_dev: "nexus-benefits-agent-dev"
  agent_prod: "nexus-benefits-agent-prod"
  app_name_dev: "nexus-benefits-app-dev"
  app_name_prod: "nexus-benefits-app-prod"
```

#### Lakebase Configuration

Defines database instance specifications:

```yaml
lakebase_db_instace_dev:
  name: "nexus-lakebase-dev"
  capacity: "SMALL"      # SMALL, MEDIUM, LARGE
  node_count: 2          # 2 for HA (High Availability)
```

**Capacity Options**:
* **SMALL**: Development/testing workloads
* **MEDIUM**: Production workloads with moderate traffic
* **LARGE**: High-traffic production workloads

**Node Count**:
* **1**: Single node (no HA)
* **2**: High availability with automatic failover

#### Access Control Lists

Defines who can access what resources:

```yaml
access_app_dev:
  user_id_list:
    CAN_MANAGE:
      - "user@example.com"
    CAN_USE:
      - "user@example.com"
  service_list:
    CAN_MANAGE: []
```

**Permission Levels**:
* **CAN_MANAGE**: Full control (create, update, delete)
* **CAN_USE**: Read and execute permissions
* **CAN_QUERY**: Query-only access (for agents)

---

## Notebooks

### 1. `lakebase.py` - Lakebase Provisioning

**Purpose**: Automates the creation and configuration of Lakebase PostgreSQL instances.

#### Class: `LakebaseManager`

```python
class LakebaseManager:
    """
    Manages Lakebase database instance lifecycle and configuration.
    
    Features:
    - Create/start/stop database instances
    - Register database catalogs
    - Create schemas
    - Deploy tables and stored procedures
    """
    
    def __init__(self, config_path="config.yaml"):
        """
        Initialize LakebaseManager with configuration.
        
        Args:
            config_path: Path to YAML configuration file
        """
```

#### Method: `create_database_instance`

```python
def create_database_instance(self):
    """
    Creates a new Lakebase database instance.
    
    Process:
    1. Load configuration from YAML
    2. Call Databricks SDK to create instance
    3. Wait for instance to become available
    4. Return instance details
    
    Returns:
        DatabaseInstance: Created instance object
        
    Raises:
        Exception: If instance creation fails
        
    Example:
        lakebase = LakebaseManager("config.yaml")
        instance = lakebase.create_database_instance()
        print(f"Instance created: {instance.name}")
        print(f"Connection endpoint: {instance.read_write_dns}")
    """
```

**Configuration Used**:
```yaml
lakebase_db_instace_dev:
  name: "nexus-lakebase-dev"
  capacity: "SMALL"
  node_count: 2
```

**Output**:
```
Created database instance: nexus-lakebase-dev
Connection endpoint: instance-abc123.database.azuredatabricks.net
```

#### Method: `stop_database_instance`

```python
def stop_database_instance(self):
    """
    Stops a running database instance to save costs.
    
    Use Case: Stop dev instances overnight or during weekends
    
    Example:
        lakebase = LakebaseManager("config.yaml")
        lakebase.stop_database_instance()
    """
```

#### Method: `start_database_instance`

```python
def start_database_instance(self):
    """
    Starts a stopped database instance.
    
    Example:
        lakebase = LakebaseManager("config.yaml")
        lakebase.start_database_instance()
    """
```

#### Method: `register_database_catalog`

```python
def register_database_catalog(self):
    """
    Registers the Lakebase database as a Unity Catalog.
    
    This enables:
    - SQL queries from Databricks notebooks
    - Integration with Delta Lake
    - Unified governance
    
    Returns:
        DatabaseCatalog: Registered catalog object
        
    Example:
        lakebase = LakebaseManager("config.yaml")
        catalog = lakebase.register_database_catalog()
        print(f"Registered catalog: {catalog.name}")
    """
```

#### Method: `create_schema`

```python
def create_schema(self, schema_name):
    """
    Creates a schema in the registered catalog.
    
    Args:
        schema_name: Name of the schema to create
        
    Example:
        lakebase = LakebaseManager("config.yaml")
        lakebase.create_schema("nexus_benefits")
    """
```

#### Database Table Creation

The notebook creates the following tables:

##### Table: `master_table`

```sql
CREATE TABLE IF NOT EXISTS master_table (
    facets_product_id VARCHAR(255),
    product_effective_date VARCHAR(255),
    product_type VARCHAR(255),
    plan_type VARCHAR(255),
    product_description VARCHAR(255),
    plan_id VARCHAR(255),
    requested_time TIMESTAMP,
    requester_id VARCHAR(255),
    dbr_silver_layer_ready VARCHAR(255),
    update_time TIMESTAMP,
    insert_time TIMESTAMP,
    vector_db_ready VARCHAR(255),
    ready_for_agent VARCHAR(255),
    comments VARCHAR(255),
    data_issue VARCHAR(255),
    bronze_ready_flag VARCHAR(255),
    CONSTRAINT unique_facets_id_and_date UNIQUE (facets_product_id, product_effective_date)
);
```

**Purpose**: Tracks data pipeline processing status for each plan.

##### Table: `chat_history`

```sql
CREATE TABLE IF NOT EXISTS chat_history (
    session_id VARCHAR(255),
    user_id VARCHAR(255),
    question_id VARCHAR(255),
    insert_timestamp TIMESTAMP,
    qa_pairs JSONB,
    is_summerized BOOLEAN,
    summary TEXT
);
```

**Purpose**: Stores conversation history for context-aware responses.

##### Table: `tbl_benefitsquote_feedback`

```sql
CREATE TABLE IF NOT EXISTS tbl_benefitsquote_feedback (
    response_id VARCHAR(64),
    question_id VARCHAR(64),
    user_id VARCHAR(64),
    user_name VARCHAR(128),
    feedback_type VARCHAR(32),
    reason_code VARCHAR(16),
    additional_comments TEXT,
    session_id VARCHAR(64),
    feedback_response_id VARCHAR(50),
    insert_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (session_id, user_id, question_id)
);
```

**Purpose**: Collects user feedback for response quality improvement.

##### Table: `plans_questions`

```sql
CREATE TABLE IF NOT EXISTS plans_questions (
    id INT PRIMARY KEY,
    plan_name TEXT,
    questions JSONB
);
```

**Purpose**: Stores frequently asked questions by plan type.

**Example Data**:
```sql
INSERT INTO plans_questions (id, plan_name, questions)
VALUES (
    1,
    'smallgroup',
    '[
        {"question": "What is my copayment for seeing my PCP?", "popularity": 1},
        {"question": "What is my copayment to see a specialist?", "popularity": 2},
        {"question": "If I am traveling outside California, do I have coverage?", "popularity": 3},
        {"question": "What is my copayment for prescription drugs?", "popularity": 4}
    ]'::jsonb
);
```

#### Stored Procedure: `remove_old_chat_records`

```sql
CREATE OR REPLACE PROCEDURE remove_old_chat_records(days_ago integer)
LANGUAGE plpgsql
AS $$
BEGIN
    DELETE FROM chat_history
    WHERE insert_timestamp < NOW() - (days_ago || ' days')::interval;
END;
$$;
```

**Purpose**: Cleanup old chat history to manage database size.

**Usage**:
```python
with _conn(autocommit=True) as c:
    c.execute("CALL remove_old_chat_records(90)")  # Remove records older than 90 days
```

#### Connection Helper: `_conn`

```python
def _conn(autocommit=False):
    """
    Creates authenticated PostgreSQL connection using Databricks SDK.
    
    Security:
    - Uses short-lived credentials (expires in 1 hour)
    - No hardcoded passwords
    - SSL/TLS encryption enforced
    
    Args:
        autocommit: Enable autocommit mode
    
    Returns:
        psycopg.Connection: Active PostgreSQL connection
    
    Example:
        with _conn(autocommit=True) as c:
            c.execute("CREATE TABLE test (id INT)")
    """
    inst = w.database.get_database_instance(name=INSTANCE)
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()), 
        instance_names=[INSTANCE]
    )
    return psycopg.connect(
        host=f"instance-{inst.uid}.database.azuredatabricks.net",
        port=5432,
        dbname="databricks_postgres",
        user=USERNAME,
        password=cred.token,
        sslmode="require",
        connect_timeout=10,
        autocommit=autocommit,
    )
```

---

### 2. `access_provisioning.py` - Access Management

**Purpose**: Manages permissions for apps, agents, and database resources.

#### Function: `grant_permission`

```python
def grant_permission(
    resource_type: str,
    resource_id: str,
    principal_type: str,
    principal_id: str,
    permission: str
):
    """
    Grants permission to a principal on a resource.
    
    Args:
        resource_type: Type of resource (apps, serving-endpoints)
        resource_id: Resource identifier (app name or model ID)
        principal_type: Type of principal (user_name, service_principal_name)
        principal_id: Principal identifier (email or SPN ID)
        permission: Permission level (CAN_MANAGE, CAN_USE, CAN_QUERY)
    
    Example:
        grant_permission(
            resource_type="apps",
            resource_id="nexus-benefits-app-dev",
            principal_type="user_name",
            principal_id="user@example.com",
            permission="CAN_MANAGE"
        )
    """
```

#### Function: `get_app_id`

```python
def get_app_id(app_name: str) -> str:
    """
    Retrieves the app ID for a given app name.
    
    Process:
    1. Call Databricks Apps API
    2. Check if app is ACTIVE and RUNNING
    3. Return app ID if available
    
    Args:
        app_name: Name of the Databricks app
    
    Returns:
        str: App ID if app is running, None otherwise
    
    Example:
        app_id = get_app_id("nexus-benefits-app-dev")
        print(f"App ID: {app_id}")
    """
```

#### Function: `get_databricks_id`

```python
def get_databricks_id(endpoint_name: str) -> str:
    """
    Retrieves the model serving endpoint ID.
    
    Args:
        endpoint_name: Name of the serving endpoint
    
    Returns:
        str: Endpoint ID
    
    Example:
        model_id = get_databricks_id("nexus-benefits-agent-dev")
        print(f"Model ID: {model_id}")
    """
```

#### Function: `get_latest_model_spn_id`

```python
def get_latest_model_spn_id(endpoint_name: str) -> str:
    """
    Extracts the service principal ID from the latest model version.
    
    Process:
    1. Get endpoint configuration
    2. Find latest model version
    3. Make test invocation to trigger error
    4. Parse SPN ID from error message
    
    Why this works: Model serving uses a dedicated SPN that needs
    database access. The SPN ID is embedded in error messages.
    
    Args:
        endpoint_name: Name of the serving endpoint
    
    Returns:
        str: Service principal ID
    
    Example:
        spn_id = get_latest_model_spn_id("nexus-benefits-agent-dev")
        print(f"Model SPN: {spn_id}")
    """
```

#### Access Provisioning Workflow

##### Step 1: Grant App Permissions

```python
for resource, access_config in [
    ("apps", config.get(f"access_app_{env}")),
    ("serving-endpoints", config.get(f"access_agents_{env}"))
]:
    if not access_config:
        continue

    for principal_type in ["user_id_list", "service_list"]:
        principals = access_config.get(principal_type, {})

        # Add app SPN to CAN_MANAGE list
        if principal_type == "service_list" and nexus_app_id:
            if 'CAN_MANAGE' not in principals:
                principals['CAN_MANAGE'] = []
            principals['CAN_MANAGE'].append(nexus_app_id)

        for permission, ids in principals.items():
            for principal_id in ids:
                grant_permission(
                    resource_type=resource,
                    resource_id=resource_id,
                    principal_type="user_name" if principal_type == "user_id_list" else "service_principal_name",
                    principal_id=principal_id,
                    permission=permission
                )
```

##### Step 2: Grant Lakebase Permissions

```python
lakebase_tables = config["lakebase_table_list"]
service_principals = config[f"access_lakebase_{env}"].get("service_list", [])
user_ids = config[f"access_lakebase_{env}"].get("user_id_list", [])

# Add app and model SPNs
if nexus_app_id:
    service_principals.append(nexus_app_id)
if model_served_spn_id:
    service_principals.append(model_served_spn_id)

sql_statements = ["CREATE EXTENSION IF NOT EXISTS databricks_auth;"]

# Grant permissions to service principals
for sp in service_principals:
    if sp and sp != "-":
        sql_statements.append(
            f"SELECT databricks_create_role('{sp}','SERVICE_PRINCIPAL');"
        )
        for table in lakebase_tables:
            sql_statements.append(
                f'GRANT SELECT, INSERT, UPDATE ON "{table}" TO "{sp}";'
            )

# Grant permissions to users
for user in user_ids:
    if user and user != "-":
        sql_statements.append(
            f"SELECT databricks_create_role('{user}','USER');"
        )
        for table in lakebase_tables:
            sql_statements.append(
                f'GRANT SELECT, INSERT, UPDATE, DELETE ON "{table}" TO "{user}";'
            )

# Execute SQL statements
with _conn(autocommit=True) as c:
    for statement in sql.split(";"):
        stmt = statement.strip()
        if stmt:
            c.execute(stmt)
```

---

## Utility Modules

### Overview

The setup project uses utility functions for common operations like configuration loading, credential management, and database connections.

### Utility: Configuration Loader

**Purpose**: Load and validate YAML configuration files.

```python
def load_config(config_path: str) -> dict:
    """
    Loads configuration from YAML file.
    
    Args:
        config_path: Path to YAML configuration file
    
    Returns:
        dict: Parsed configuration
    
    Raises:
        FileNotFoundError: If config file doesn't exist
        yaml.YAMLError: If config file is invalid
    
    Example:
        config = load_config("config.yaml")
        env = config["environment"]
    """
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)
```

### Utility: Credential Generator

**Purpose**: Generate short-lived database credentials.

```python
def generate_db_credentials(instance_name: str) -> dict:
    """
    Generates short-lived credentials for Lakebase access.
    
    Args:
        instance_name: Name of the Lakebase instance
    
    Returns:
        dict: Credentials with token and expiry
    
    Example:
        creds = generate_db_credentials("nexus-lakebase-dev")
        print(f"Token: {creds['token']}")
        print(f"Expires: {creds['expiry']}")
    """
    w = WorkspaceClient()
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()),
        instance_names=[instance_name]
    )
    return {
        "token": cred.token,
        "expiry": datetime.now() + timedelta(hours=1)
    }
```

---

## Helper Modules

### Overview

Helper modules provide domain-specific integration with Databricks services.

### Helper: Databricks Apps API Client

**Purpose**: Interact with Databricks Apps API.

```python
class AppsAPIClient:
    """
    Client for Databricks Apps API.
    
    Features:
    - Get app details
    - Check app status
    - Manage app permissions
    """
    
    def __init__(self, host: str, token: str):
        """
        Initialize API client.
        
        Args:
            host: Databricks workspace URL
            token: Personal access token
        """
        self.host = host
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    
    def get_app(self, app_name: str) -> dict:
        """
        Get app details.
        
        Args:
            app_name: Name of the app
        
        Returns:
            dict: App details including ID, status, compute status
        
        Example:
            client = AppsAPIClient(DATABRICKS_HOST, token)
            app = client.get_app("nexus-benefits-app-dev")
            print(f"App ID: {app['id']}")
            print(f"Status: {app['app_status']['state']}")
        """
        api_url = f"{self.host}/api/2.0/apps/{app_name}"
        response = requests.get(api_url, headers=self.headers)
        return response.json()
```

### Helper: Serving Endpoints API Client

**Purpose**: Interact with Model Serving API.

```python
class ServingEndpointsClient:
    """
    Client for Databricks Model Serving API.
    
    Features:
    - List serving endpoints
    - Get endpoint details
    - Manage endpoint permissions
    """
    
    def list_endpoints(self) -> list:
        """
        List all serving endpoints.
        
        Returns:
            list: List of endpoint objects
        
        Example:
            client = ServingEndpointsClient(DATABRICKS_HOST, token)
            endpoints = client.list_endpoints()
            for ep in endpoints:
                print(f"Endpoint: {ep['name']}")
        """
        response = requests.get(
            f"{self.host}/api/2.0/serving-endpoints",
            headers=self.headers
        )
        return response.json().get("endpoints", [])
    
    def get_endpoint(self, endpoint_name: str) -> dict:
        """
        Get endpoint details.
        
        Args:
            endpoint_name: Name of the endpoint
        
        Returns:
            dict: Endpoint configuration
        
        Example:
            client = ServingEndpointsClient(DATABRICKS_HOST, token)
            endpoint = client.get_endpoint("nexus-benefits-agent-dev")
            print(f"Model version: {endpoint['config']['served_models'][0]['model_version']}")
        """
        response = requests.get(
            f"{self.host}/api/2.0/serving-endpoints/{endpoint_name}",
            headers=self.headers
        )
        return response.json()
```

---

## Usage Guide

### Complete Setup Workflow

#### Step 1: Configure Environment

Edit `config.yaml` with your environment settings:

```yaml
environment: dev

resource_ids:
  agent_dev: "your-agent-name"
  app_name_dev: "your-app-name"

lakebase_db_instace_dev:
  name: "your-lakebase-instance"
  capacity: "SMALL"
  node_count: 2
```

#### Step 2: Run Lakebase Provisioning

```python
# Run lakebase.py notebook
dbutils.notebook.run(
    "./lakebase",
    timeout_seconds=1800,
    arguments={"environment": "dev"}
)
```

**Expected Output**:
```
Created database instance: nexus-lakebase-dev
Connection endpoint: instance-abc123.database.azuredatabricks.net
Created table: master_table
Created table: chat_history
Created table: tbl_benefitsquote_feedback
Created table: plans_questions
Created procedure: remove_old_chat_records
```

#### Step 3: Wait for Instance to be Ready

```python
import time
time.sleep(300)  # Wait 5 minutes for instance to fully initialize
```

#### Step 4: Run Access Provisioning

```python
# Run access_provisioning.py notebook
dbutils.notebook.run(
    "./access_provisioning",
    timeout_seconds=600,
    arguments={"environment": "dev"}
)
```

**Expected Output**:
```
App ID: abc-123-def
Model ID: xyz-789-ghi
Model SPN: service-principal-id
Granted CAN_MANAGE to user@example.com on apps/nexus-benefits-app-dev
Granted CAN_QUERY to user@example.com on serving-endpoints/nexus-benefits-agent-dev
Granted SELECT, INSERT, UPDATE on master_table to service-principal-id
```

#### Step 5: Verify Setup

```python
# Verify Lakebase connection
with _conn() as c:
    c.execute("SELECT * FROM databricks_list_roles;")
    roles = c.fetchall()
    print(f"Roles: {roles}")

# Verify app access
app_id = get_app_id("nexus-benefits-app-dev")
print(f"App is accessible: {app_id is not None}")

# Verify agent access
model_id = get_databricks_id("nexus-benefits-agent-dev")
print(f"Agent is accessible: {model_id is not None}")
```

---

## Troubleshooting

### Common Issues

#### Issue 1: Lakebase Instance Creation Fails

**Symptoms**:
* Error: "Instance creation failed"
* Timeout waiting for instance

**Solutions**:
1. Check workspace capacity limits
2. Verify instance name is unique
3. Check node_count is valid (1 or 2)

```python
# Check existing instances
w = WorkspaceClient()
instances = w.database.list_database_instances()
for inst in instances:
    print(f"Instance: {inst.name}, Status: {inst.state}")
```

#### Issue 2: Permission Grant Fails

**Symptoms**:
* Error: "Principal not found"
* Error: "Resource not found"

**Solutions**:
1. Verify principal exists (user or SPN)
2. Verify resource exists and is running
3. Check permission level is valid

```python
# Verify app exists
try:
    app = get_app_id("nexus-benefits-app-dev")
    print(f"App found: {app}")
except Exception as e:
    print(f"App not found: {e}")
```

#### Issue 3: Database Connection Fails

**Symptoms**:
* Error: "Connection timeout"
* Error: "Authentication failed"

**Solutions**:
1. Verify instance is running
2. Check credentials are not expired
3. Verify SSL mode is correct

```python
# Test connection
try:
    with _conn() as c:
        c.execute("SELECT 1")
        print("Connection successful")
except Exception as e:
    print(f"Connection failed: {e}")
```

#### Issue 4: SPN Extraction Fails

**Symptoms**:
* `get_latest_model_spn_id` returns None
* Error message doesn't contain SPN

**Solutions**:
1. Verify model is deployed
2. Check model has database access configured
3. Try manual SPN addition

```python
# Manual SPN addition
spn_id = "your-service-principal-id"
service_principals.append(spn_id)
```

---

## Best Practices

### 1. Environment Separation

Always maintain separate configurations for dev and prod:

```yaml
# dev_config.yaml
environment: dev
lakebase_db_instace_dev:
  capacity: "SMALL"

# prod_config.yaml
environment: prod
lakebase_db_instace_prod:
  capacity: "MEDIUM"
```

### 2. Credential Management

Never hardcode credentials:

```python
# ❌ Bad
password = "my-password"

# ✅ Good
cred = w.database.generate_database_credential(...)
password = cred.token
```

### 3. Permission Principle of Least Privilege

Grant minimum necessary permissions:

```yaml
# ❌ Bad - everyone has CAN_MANAGE
access_app_dev:
  user_id_list:
    CAN_MANAGE:
      - "user1@example.com"
      - "user2@example.com"
      - "user3@example.com"

# ✅ Good - only admins have CAN_MANAGE
access_app_dev:
  user_id_list:
    CAN_MANAGE:
      - "admin@example.com"
    CAN_USE:
      - "user1@example.com"
      - "user2@example.com"
```

### 4. Regular Cleanup

Schedule regular cleanup of old data:

```python
# Run weekly
with _conn(autocommit=True) as c:
    c.execute("CALL remove_old_chat_records(90)")
```

### 5. Monitoring

Monitor instance health and costs:

```python
# Check instance status
w = WorkspaceClient()
inst = w.database.get_database_instance(name="nexus-lakebase-dev")
print(f"Status: {inst.state}")
print(f"Capacity: {inst.capacity}")
```

---

## Configuration Reference

### Complete config.yaml Template

```yaml
# Environment
environment: dev

# Resource IDs
resource_ids:
  agent_dev: "nexus-benefits-agent-dev"
  agent_prod: "nexus-benefits-agent-prod"
  app_name_dev: "nexus-benefits-app-dev"
  app_name_prod: "nexus-benefits-app-prod"

# Lakebase Instances
lakebase_db_instace_dev:
  name: "nexus-lakebase-dev"
  capacity: "SMALL"
  node_count: 2

lakebase_db_instace_prod:
  name: "nexus-lakebase-prod"
  capacity: "MEDIUM"
  node_count: 2

# Database Catalog
database_catalog:
  catalog_name: "nexus_catalog"
  database_name: "databricks_postgres"
  create_database_if_not_exists: true

# Access Control - Apps (Dev)
access_app_dev:
  user_id_list:
    CAN_MANAGE:
      - "admin@example.com"
    CAN_USE:
      - "user1@example.com"
      - "user2@example.com"
  service_list:
    CAN_MANAGE: []

# Access Control - Apps (Prod)
access_app_prod:
  user_id_list:
    CAN_MANAGE:
      - "admin@example.com"
    CAN_USE:
      - "user1@example.com"
  service_list:
    CAN_MANAGE: []

# Access Control - Agents (Dev)
access_agents_dev:
  user_id_list:
    CAN_QUERY:
      - "user1@example.com"
  service_list:
    CAN_QUERY: []

# Access Control - Agents (Prod)
access_agents_prod:
  user_id_list:
    CAN_QUERY:
      - "user1@example.com"
  service_list:
    CAN_QUERY: []

# Access Control - Lakebase (Dev)
access_lakebase_dev:
  service_list:
    - "service-principal-1"
  user_id_list:
    - "admin@example.com"

# Access Control - Lakebase (Prod)
access_lakebase_prod:
  service_list:
    - "service-principal-1"
  user_id_list:
    - "admin@example.com"

# Lakebase Tables
lakebase_table_list:
  - "master_table"
  - "chat_history"
  - "tbl_benefitsquote_feedback"
  - "plans_questions"
```

---

## API Reference

### Databricks SDK Methods

#### Database Instance Management

```python
# Create instance
w.database.create_database_instance(DatabaseInstance(...))

# Get instance
w.database.get_database_instance(name="instance-name")

# Update instance
w.database.update_database_instance(name="instance-name", database_instance=DatabaseInstance(...))

# List instances
w.database.list_database_instances()

# Generate credentials
w.database.generate_database_credential(request_id=str(uuid.uuid4()), instance_names=["instance-name"])
```

#### Catalog Management

```python
# Create catalog
w.database.create_database_catalog(DatabaseCatalog(...))

# Create schema
w.schemas.create(name="schema-name", catalog_name="catalog-name")
```

### PostgreSQL Operations

```python
# Create connection
conn = psycopg.connect(host=host, port=5432, dbname=dbname, user=user, password=password, sslmode="require")

# Execute query
with conn.cursor() as cur:
    cur.execute("SELECT * FROM table")
    rows = cur.fetchall()

# Execute with autocommit
with _conn(autocommit=True) as c:
    c.execute("CREATE TABLE test (id INT)")
```

---

## Contact & Support

For questions or issues, please contact:
* **Project Lead**: pmane01@blueshieldca.com
* **Documentation**: This README.md
* **Repository**: setup/

---

**Last Updated**: January 2026  
**Version**: 1.0  
**Maintained By**: Nexus Benefits Infrastructure Team
