# Databricks notebook source
# MAGIC %pip install psycopg[binary]
# MAGIC %pip install --upgrade databricks-sdk
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("environment", "dev")
env = dbutils.widgets.get("environment")

dbutils.widgets.text("app_spn_id", "")
spn_id = dbutils.widgets.get("app_spn_id")

# COMMAND ----------

from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
DATABRICKS_HOST= w.config.host

import requests
import yaml

# Load config.yaml
with open("config.yaml") as f:
    config = yaml.safe_load(f)


resource_ids = config.get("resource_ids", {})
agent_name = resource_ids.get(f"agent_{env}")
app_name = resource_ids.get(f"app_name_{env}")

print(agent_name)
print(app_name)


# COMMAND ----------

import requests
import re

workspace_url = DATABRICKS_HOST
token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

endpoint_name = config["resource_ids"][f"agent_{env}"]

# Get endpoint info
response = requests.get(
    f"{workspace_url}/api/2.0/serving-endpoints/{endpoint_name}",
    headers=headers
)
endpoint_info = response.json()
served_models = (
    endpoint_info.get("pending_config", {}).get("served_models", [])
    or endpoint_info.get("config", {}).get("served_models", [])
)
if not served_models:
    print("No served models found for this endpoint.")
else:
    latest_model = max(served_models, key=lambda m: int(m.get("model_version", 0)))
    model_version = latest_model.get("model_version")
    served_model_name = latest_model.get("name")
    print(f"Served model name: {served_model_name}, version: {model_version}")

    import time
    max_wait_minutes = 30  
    waited_minutes = 0

    while True:
        state = endpoint_info.get("state", {})
        print(f"Endpoint state: {state}")
        if state.get("ready", False):
            print("Model state is ready.")
            break
        if waited_minutes >= max_wait_minutes:
            print("Max wait time reached. Exiting.")
            break
        print("Model state is not ready. Waiting 10 minutes before rechecking...")
        time.sleep(600)
        waited_minutes += 15
        response = requests.get(
            f"{workspace_url}/api/2.0/serving-endpoints/{endpoint_name}",
            headers=headers
        )
        endpoint_info = response.json()

# COMMAND ----------

import time 
#time.sleep(600)

# COMMAND ----------



import requests

token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

def grant_permission(resource_type, resource_id, principal_type, principal_id, permission):
    api_url = f"{DATABRICKS_HOST}/api/2.0/permissions/{resource_type}/{resource_id}"
    print(api_url)
    payload = {
        "access_control_list": [
            {
                principal_type: principal_id,
                "permission_level": permission
            }
        ]
    }
    try:
        response = requests.patch(api_url, headers=headers, json=payload)
        if response.status_code != 200:
            print(
                f"Failed to grant {permission} to {principal_id} on {resource_type} {resource_id}: {response.text}"
            )
        elif response.status_code == 200:
            print(
                f"granted {permission} to {principal_id} on {resource_type} {resource_id}: {response.text}"
            )            
    except Exception as e:
        print(
            f"Exception while granting {permission} to {principal_id} on {resource_type} {resource_id}: {e}"
        )



# COMMAND ----------

import traceback
import json

def get_app_id(app_name:str):
    api_url = f"{DATABRICKS_HOST}/api/2.0/apps/{app_name}"
    print(api_url)
    try:
        response = requests.get(api_url, headers=headers)
        if response.status_code != 200:
            print(response.text)
        elif response.status_code == 200: 
            data =json.loads(response.text)
            print(type(data ))
            if (
                data.get("compute_status", {}).get("state") == "ACTIVE"
                and data.get("app_status", {}).get("state") == "RUNNING"
            ):
                return data.get("id")
            return None

                        
    except Exception as e:
        print(e)
     

app_name=config["resource_ids"][f"app_name_{env}"]
nexus_app_id=get_app_id(app_name)     

print("Nexus- APP id is -->"+str(nexus_app_id))

# COMMAND ----------

def get_databricks_id(endpoint_name):
    import requests

    # Set your Databricks workspace URL and personal access token
    workspace_url =DATABRICKS_HOST
    token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    # List all serving endpoints
    response = requests.get(
        f"{workspace_url}/api/2.0/serving-endpoints",
        headers={"Authorization": f"Bearer {token}"}
    )
    endpoint_name = endpoint_name
    endpoints = response.json()

    model_id=''
    for endpoint in endpoints.get("endpoints", []):
        if endpoint.get("name") == endpoint_name:
            model_id=endpoint.get('id', 'N/A')
            return model_id
            break
    else:
        print("Endpoint not found.")

# COMMAND ----------

#get_latest_model_spn_id
def get_latest_model_spn_id(endpoint_name):
    import requests
    import re

    workspace_url = DATABRICKS_HOST
    token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    # Get endpoint info
    response = requests.get(
        f"{workspace_url}/api/2.0/serving-endpoints/{endpoint_name}",
        headers=headers
    )
    endpoint_info = response.json()
    served_models = (
        endpoint_info.get("pending_config", {}).get("served_models", [])
        or endpoint_info.get("config", {}).get("served_models", [])
    )
    if not served_models:
        print("No served models found for this endpoint.")
        return

    latest_model = max(served_models, key=lambda m: int(m.get("model_version", 0)))
    model_version = latest_model.get("model_version")
    served_model_name = latest_model.get("name")
    print(served_model_name)

    # Get response from model using provided payload
    payload = {
        "input": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_text",
                        "text": "what is the cost share for emergency room?"
                    }
                ]
            }
        ],
        "custom_inputs": {
            "user_id": "u-123",
            "username": "Priyanka",
            "session_id": "s-456",
            "question_id": "q-789",
            "facets_product_id": "MG011320",
            "effective_date": "20240101"
        }
    }
    response = requests.post(
        f"{workspace_url}/serving-endpoints/{endpoint_name}/invocations",
        headers=headers,
        json=payload
    )
    logs_t = response.json()
    #print(logs_t)

    # Try to extract the error message from the response
    error_message = ""
    if isinstance(logs_t, dict):
        
        error_message = logs_t.get("message", "") or logs_t.get("error", "") or logs_t.get("stack_trace", "")
        
        if not error_message:
            for v in logs_t.values():
                if isinstance(v, str) and "FATAL:" in v:
                    error_message = v
                    break
    elif isinstance(logs_t, str):
        error_message = logs_t

    # Fallback to empty string if nothing found
    if not error_message:
        error_message = ""

    # Extract role from error message
    role_pattern = r'FATAL:\s+role\s+"([^"]+)"'
    roles = re.findall(role_pattern, error_message)[:1]
    if roles:
        display(spark.createDataFrame([{"role": r} for r in roles]))
        return roles[0]
    else:
        print("No roles found in error message.")
        return None

# COMMAND ----------

# DBTITLE 1,Apps and Agnets access managemnet
# Grant access for app and agent
for resource, access_config in [
    ("apps", config.get(f"access_app_{env}")),
    ("serving-endpoints", config.get(f"access_agents_{env}"))
]:
    if not access_config:
        continue

    for principal_type in ["user_id_list", "service_list"]:
        principals = access_config.get(principal_type, {})

        # --- Start: Generic cleaning of all principal lists , LIKE removing None---
        for key, principal_list in principals.items():
            if principal_list is None:
                principals[key] = []
            else:
                principals[key] = [p for p in principal_list if p and p != "-"]
        # --- End cleaning ---

        if principal_type == "service_list" and (nexus_app_id is not None and nexus_app_id != ""):
            # Ensure 'CAN_MANAGE' key exists and is a list before appending
            if 'CAN_MANAGE' not in principals:
                principals['CAN_MANAGE'] = []
            principals['CAN_MANAGE'].append(nexus_app_id)
        

        print("principals: " + str(principals))

        for permission, ids in principals.items():
            if not ids:
                continue
            for principal_id in ids:
                # --- Filtering invalid principal_id ---
                if not principal_id or (isinstance(principal_id, str) and principal_id.strip() in ["", "-"]):
                    continue

                try:
                    # Map resource_type and resource_id as per your environment
                    resource_type = resource
                    resource_id = config["resource_ids"][f"agent_{env}"]
                    print(resource_id + " is the model name")

                    model_id = get_databricks_id(resource_id)
                    print(model_id + " is the model id")

                    resource_id = model_id if resource_type == "serving-endpoints" else app_name

                    grant_permission(
                        resource_type,
                        resource_id,
                        "user_name" if principal_type == "user_id_list" else "service_principal_name",
                        principal_id,
                        permission
                    )
                except Exception as e:
                    print(f"Error processing principal_id '{principal_id}': {e}")
                    continue

# COMMAND ----------

resource_id = config["resource_ids"][f"agent_{env}"]
model_served_spn_id = get_latest_model_spn_id(resource_id)

# COMMAND ----------

# MAGIC %md
# MAGIC Below is for the lakebase

# COMMAND ----------

# DBTITLE 1,Lakebase Access management

import yaml
with open("config.yaml") as f:
    config = yaml.safe_load(f)

lakebase_tables = config["lakebase_table_list"]

service_principals = config[f"access_lakebase_{env}"].get("service_list", [])
user_ids = config[f"access_lakebase_{env}"].get("user_id_list", [])

# Grant SELECT to each service principal and user for each table
sql_mandatory = "CREATE EXTENSION IF NOT EXISTS databricks_auth;"

sql_statements = [sql_mandatory]
#print(nexus_app_id)

if nexus_app_id != None and nexus_app_id != "":
    service_principals.append(nexus_app_id)



if model_served_spn_id != None and model_served_spn_id != "":
    service_principals.append(model_served_spn_id)

#Below is for the manual addition of the app SPN in the lakebase 
if ( spn_id !='' and spn_id != "None" ):
    service_principals.append(spn_id)
print(service_principals)
for sp in service_principals:
    if sp and sp != "-":
        sql_statements.append(
            f"SELECT databricks_create_role('{sp}','SERVICE_PRINCIPAL');"
        )
        for table in lakebase_tables:
            sql_statements.append(
                f'GRANT SELECT, INSERT, UPDATE ON "{table}" TO "{sp}";'
            )

for user in user_ids:
    if user and user != "-":
        sql_statements.append(
            f"SELECT databricks_create_role('{user}','USER');"
        )
        for table in lakebase_tables:
            sql_statements.append(
                f'GRANT SELECT, INSERT, UPDATE, DELETE ON "{table}" TO "{user}";'
            )

sql = "\n".join(sql_statements)


# COMMAND ----------

import pyspark.sql.functions as F

# Create a PySpark DataFrame with a single row and select the current user
df = spark.range(1).select(F.session_user().alias("current_user"))

# Convert the current user to a string
current_user_name = df.select("current_user").collect()[0]["current_user"]

# Print the current user name as a string
print(current_user_name)

# COMMAND ----------

import psycopg2, os

from databricks.sdk import WorkspaceClient
import psycopg
from psycopg.rows import tuple_row
import uuid


key = f"lakebase_db_instace_{env}"
lakebase_instance = config[key]["name"]
# ─── CONFIG ─────────────────────────────────────────────────────────
INSTANCE = lakebase_instance  # Lakebase instance name
USERNAME = current_user_name  # Postgres role (must exist in Lakebase)
DBNAME = "databricks_postgres"  # fixed name per docs
# ────────────────────────────────────────────────────────────────────
w = WorkspaceClient()

def _conn(autocommit=False):
    inst = w.database.get_database_instance(name=INSTANCE)
    print(inst)
    cred = w.database.generate_database_credential(
        request_id=str(uuid.uuid4()), instance_names=[INSTANCE]
    )
    return psycopg.connect(
        host=f"instance-{inst.uid}.database.azuredatabricks.net",
        port=5432,
        dbname="databricks_postgres",
        user=USERNAME,
        password=cred.token,
        sslmode="require",
        connect_timeout=10,
        autocommit=autocommit,
    )

# COMMAND ----------


with _conn(autocommit=True) as c:
    for statement in sql.split(";"):
        stmt = statement.strip()
        if stmt:
            try:
                c.execute(stmt)
            except Exception as e:
                print(f"Error executing statement: {stmt}\n{e}")
    try:
        c.execute("SELECT * FROM databricks_list_roles;")
        display(c.fetchall())
    except Exception as e:
        print(f"Error fetching roles: {e}")