import json, random, argparse, datetime
from collections import defaultdict

def pick(seq):
    return random.choice(seq)

def make_id(prefix, i, width=4):
    return f"{prefix}{i:0{width}d}"

def gen(args):
    random.seed(args.seed)

    # Entity pools
    cities = ["Walnut Creek","Oakland","San Jose","San Francisco","Sacramento","Fremont","San Mateo","Daly City","Hayward","San Ramon"]
    states = ["CA"]
    streets = ["Pringle Ave","Market St","Mission St","Broadway","El Camino Real","Shattuck Ave","Telegraph Ave","1st St","2nd St","3rd St"]
    first = ["Alex","Sam","Taylor","Jordan","Casey","Riley","Morgan","Avery","Jamie","Cameron","Devin","Parker","Reese"]
    last  = ["Chen","Patel","Garcia","Nguyen","Kim","Singh","Lopez","Wang","Brown","Martinez","Johnson","Lee","Davis"]
    banks = ["Chase","WellsFargo","BofA","Citi","CapitalOne","USAA","Discover","Amex"]
    devices = ["iPhone15","iPhone14","Pixel8","GalaxyS23","iPadPro","WindowsLaptop","MacBook","AndroidTablet"]
    isps = ["Comcast","AT&T","Verizon","TMobile","Sonic","Xfinity"]
    pharmacies = ["PharmacyA","PharmacyB","PharmacyC","PharmacyD","PharmacyE"]
    specialties = ["PrimaryCare","Dermatology","Radiology","PhysicalTherapy","Dental","UrgentCare","Orthopedics"]

    # Counts
    n_members = args.members
    n_providers = args.providers
    n_claims = args.claims
    n_devices = max(20, n_members // 2)
    n_addresses = max(30, n_members // 2)
    n_accounts = max(25, n_members // 3)
    n_ips = max(25, n_members // 3)
    n_pharm = max(10, n_providers // 2)

    # Create entities
    members = [make_id("M", i+1) for i in range(n_members)]
    providers = [make_id("P", i+1) for i in range(n_providers)]
    devices_ids = [make_id("D", i+1) for i in range(n_devices)]
    addr_ids = [make_id("A", i+1) for i in range(n_addresses)]
    acct_ids = [make_id("B", i+1) for i in range(n_accounts)]
    ip_ids = [make_id("IP", i+1, width=3) for i in range(n_ips)]
    pharm_ids = [make_id("PH", i+1, width=3) for i in range(n_pharm)]

    # Assign properties
    member_props = {}
    for m in members:
        nm = f"{pick(first)} {pick(last)}"
        member_props[m] = {
            "label": m,
            "entity_type": "member",
            "name": nm,
        }

    provider_props = {}
    for p in providers:
        provider_props[p] = {
            "label": p,
            "entity_type": "provider",
            "specialty": pick(specialties),
            "npi": str(random.randint(1000000000, 9999999999)),
        }

    address_props = {}
    for a in addr_ids:
        address_props[a] = {
            "label": a,
            "entity_type": "address",
            "line1": f"{random.randint(10,999)} {pick(streets)}",
            "city": pick(cities),
            "state": pick(states),
            "zip": str(random.randint(94000, 95999)),
        }

    device_props = {}
    for d in devices_ids:
        device_props[d] = {
            "label": d,
            "entity_type": "device",
            "device_model": pick(devices),
        }

    acct_props = {}
    for b in acct_ids:
        acct_props[b] = {
            "label": b,
            "entity_type": "bank_account",
            "bank": pick(banks),
            "last4": str(random.randint(1000,9999)),
        }

    ip_props = {}
    for ip in ip_ids:
        ip_props[ip] = {
            "label": ip,
            "entity_type": "ip",
            "isp": pick(isps),
            "ip": f"10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
        }

    pharm_props = {}
    for ph in pharm_ids:
        pharm_props[ph] = {
            "label": ph,
            "entity_type": "pharmacy",
            "name": pick(pharmacies),
        }

    # Mapping members to shared entities (normal baseline)
    m_to_addr = {}
    m_to_device = {}
    m_to_acct = {}
    m_to_ip = {}

    for m in members:
        # Mostly unique but with some reuse to look realistic
        m_to_addr[m] = pick(addr_ids)
        m_to_device[m] = pick(devices_ids)
        m_to_acct[m] = pick(acct_ids)
        m_to_ip[m] = pick(ip_ids)

    # Build fraud rings
    # Each ring shares address + bank + ip, and cycles through a small provider cluster.
    rings = []
    ring_size = max(4, args.ring_size)
    num_rings = max(2, args.rings)

    ring_members_used = set()
    for r in range(num_rings):
        ring_members = []
        attempts = 0
        while len(ring_members) < ring_size and attempts < 10000:
            m = pick(members)
            attempts += 1
            if m in ring_members_used:
                continue
            ring_members.append(m)
            ring_members_used.add(m)
        if len(ring_members) < ring_size:
            break
        shared_addr = pick(addr_ids)
        shared_acct = pick(acct_ids)
        shared_ip = pick(ip_ids)
        shared_device = pick(devices_ids)
        prov_cluster = random.sample(providers, k=min(3, len(providers)))
        rings.append({
            "members": ring_members,
            "shared_addr": shared_addr,
            "shared_acct": shared_acct,
            "shared_ip": shared_ip,
            "shared_device": shared_device,
            "providers": prov_cluster,
        })
        for m in ring_members:
            m_to_addr[m] = shared_addr
            m_to_acct[m] = shared_acct
            m_to_ip[m] = shared_ip
            # Not all share device, but some do
            if random.random() < 0.7:
                m_to_device[m] = shared_device

    # Provider collusion cluster: one provider connected to many ring members and pharmacies
    collude_provider = pick(providers)
    collude_pharm = pick(pharm_ids)

    # Build claims
    claims = []
    claim_props = {}
    edges = []
    nodes = {}

    def add_node(node_id, props):
        if node_id not in nodes:
            nodes[node_id] = props

    # Add base entities as nodes
    for m, props in member_props.items():
        add_node(m, props)
    for p, props in provider_props.items():
        add_node(p, props)
    for a, props in address_props.items():
        add_node(a, props)
    for d, props in device_props.items():
        add_node(d, props)
    for b, props in acct_props.items():
        add_node(b, props)
    for ip, props in ip_props.items():
        add_node(ip, props)
    for ph, props in pharm_props.items():
        add_node(ph, props)

    # Member links to shared entities
    for m in members:
        edges.append({"source": m, "target": m_to_addr[m], "label": "lives_at"})
        edges.append({"source": m, "target": m_to_device[m], "label": "uses_device"})
        edges.append({"source": m, "target": m_to_acct[m], "label": "uses_account"})
        edges.append({"source": m, "target": m_to_ip[m], "label": "seen_from_ip"})

    # Provider to pharmacy dispensing patterns
    for p in providers:
        if random.random() < 0.5:
            edges.append({"source": p, "target": pick(pharm_ids), "label": "prescribes_to"})
    # Collusion stronger
    edges.append({"source": collude_provider, "target": collude_pharm, "label": "prescribes_to"})

    # Helper to score risk
    def score_risk(m, p, amount, ring_flag, collude_flag):
        score = 5
        reasons = []
        if amount > 5000:
            score += 20
            reasons.append("high_amount")
        if ring_flag:
            score += 45
            reasons.append("shared_identity_artifacts")
        if collude_flag:
            score += 25
            reasons.append("provider_collusion_pattern")
        # small randomness
        score += random.randint(0, 10)
        score = min(100, score)
        if score >= 80:
            color = "red"
            level = "high"
        elif score >= 50:
            color = "yellow"
            level = "medium"
        else:
            color = "green"
            level = "low"
        return score, level, color, reasons

    # Determine ring membership lookup
    ring_lookup = {}
    ring_id_for_member = {}
    for i, ring in enumerate(rings):
        rid = f"R{i+1:02d}"
        for m in ring["members"]:
            ring_lookup[m] = ring
            ring_id_for_member[m] = rid

    start_date = datetime.date.today() - datetime.timedelta(days=180)

    for i in range(n_claims):
        cid = make_id("C", i+1)
        m = pick(members)
        # Choose provider: more likely collude provider for ring members
        if m in ring_lookup and random.random() < 0.55:
            p = pick(ring_lookup[m]["providers"])
        else:
            p = pick(providers)

        amount = int(max(50, random.gauss(1200, 900)))
        # Inject some high amounts
        if random.random() < 0.08:
            amount += random.randint(4000, 12000)

        svc = start_date + datetime.timedelta(days=random.randint(0, 180))
        ring_flag = (m in ring_lookup) and (random.random() < 0.85)
        collude_flag = (p == collude_provider) and (random.random() < 0.75)

        risk_score, risk_level, ui_color, reasons = score_risk(m, p, amount, ring_flag, collude_flag)

        claim_props[cid] = {
            "label": cid,
            "entity_type": "claim",
            "claimId": cid,
            "memberId": m,
            "providerId": p,
            "amount": amount,
            "serviceDate": str(svc),
            "risk_score": risk_score,
            "risk_level": risk_level,
            "ui_color": ui_color,
            "risk_reason": ",".join(reasons) if reasons else "baseline",
            "ring_id": ring_id_for_member.get(m, ""),
        }

        add_node(cid, claim_props[cid])
        # Connect claim to member and provider
        edges.append({"source": cid, "target": m, "label": "member"})
        edges.append({"source": cid, "target": p, "label": "provider"})

        # Collusion also links claim to pharmacy
        if collude_flag or random.random() < 0.2:
            edges.append({"source": cid, "target": pick(pharm_ids), "label": "dispensed_at"})

    # Add a few known fraud case nodes as anchors
    fraud_cases = []
    for i in range(max(2, args.cases)):
        fid = make_id("F", i+1, width=3)
        fraud_cases.append(fid)
        add_node(fid, {"label": fid, "entity_type": "fraud_case", "name": f"FraudCase {fid}"})

    # Link high risk claims into fraud cases
    high_claims = [c for c, props in claim_props.items() if props["risk_score"] >= 80]
    random.shuffle(high_claims)
    for idx, c in enumerate(high_claims[: max(10, len(fraud_cases)*6)]):
        edges.append({"source": c, "target": fraud_cases[idx % len(fraud_cases)], "label": "linked_to_case"})

    # Build output
    out = {
        "meta": {
            "seed": args.seed,
            "members": n_members,
            "providers": n_providers,
            "claims": n_claims,
            "rings": len(rings),
            "generated_at": datetime.datetime.utcnow().isoformat() + "Z",
        },
        "nodes": list(nodes.values()),
        "edges": edges,
    }
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--members", type=int, default=120)
    ap.add_argument("--providers", type=int, default=40)
    ap.add_argument("--claims", type=int, default=350)
    ap.add_argument("--rings", type=int, default=4)
    ap.add_argument("--ring_size", type=int, default=10)
    ap.add_argument("--cases", type=int, default=3)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", type=str, default="synthetic_graph.json")
    args = ap.parse_args()

    data = gen(args)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"Wrote {args.out} with {len(data['nodes'])} nodes and {len(data['edges'])} edges")

if __name__ == "__main__":
    main()