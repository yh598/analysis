Fraud Knowledge Graph Demo

This package includes:
1) A synthetic graph data generator
2) A professional looking interactive UI with pan and zoom
3) A local demo workflow and an API mode option

Folder structure
- index.html
- styles.css
- app.js
- synthetic_graph.json
- tools/generate_data.py

Quick start local demo
1) Unzip
2) Open a terminal in the folder
3) Start a local server
   python -m http.server 5500
4) Open
   http://127.0.0.1:5500
5) In the UI choose Data source Local JSON file and click Load

Generate a bigger dataset
python tools/generate_data.py --members 220 --providers 70 --claims 900 --rings 6 --ring_size 14 --cases 4 --seed 9 --out synthetic_graph.json

API mode
- Set your Azure Function base url in the UI
- Paste your function key
- Click Load

Notes
- Pan and zoom are enabled in Cytoscape by default
- Use mouse wheel to zoom, drag background to pan
- Use Export PNG for slides