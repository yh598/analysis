#!/usr/bin/env python3
"""
Generate synthetic healthcare insurance fraud graph data for the KG UI demo.

Output schema:
{
  "nodes": [{ "label": "...", "entity_type": "...", ... }],
  "edges": [{ "source": "...", "target": "...", "rel": "...", ... }]
}

Fraud patterns included:
- identity_theft
- phantom_billing
- kickback_ring
- upcoding
- unbundling
- dme_rental
"""
import argparse
import datetime as dt
import json
import random
import uuid


FRAUD_TYPES = [
    ("identity_theft", "Shared device and IP across members with rapid high cost claims"),
    ("phantom_billing", "Provider bills many high cost claims with weak supporting patterns"),
    ("kickback_ring", "Provider and pharmacy share a bank account and show referral loops"),
    ("upcoding", "Provider bills consistently higher severity with unusually high allowed amounts"),
    ("unbundling", "Many related claims split on the same date for the same member"),
    ("dme_rental", "Repeated DME rental claims tied to the same device signature"),
]


STATES = ["CA", "TX", "FL", "NY", "IL", "WA", "AZ", "NV", "NJ", "MA"]
CITIES = ["Walnut Creek", "San Ramon", "Austin", "Miami", "Brooklyn", "Chicago", "Seattle", "Phoenix", "Las Vegas", "Newark", "Boston"]
STREETS = ["Main", "Market", "Pringle", "Mission", "Broadway", "Oak", "Pine", "Cedar"]
STREET_TYPES = ["St", "Ave", "Blvd", "Rd"]


def _addr(rng, i):
    return {
        "line1": f"{100+i} {rng.choice(STREETS)} {rng.choice(STREET_TYPES)}",
        "city": rng.choice(CITIES),
        "state": rng.choice(STATES),
        "zip": f"{rng.randint(90000, 99999)}",
    }


def gen(
    seed=7,
    members=520,
    providers=140,
    devices=180,
    ips=140,
    addresses=220,
    banks=80,
    pharmacies=60,
    baseline_claims=1200,
):
    rng = random.Random(seed)

    nodes = []
    edges = []

    def add_node(label, entity_type, **props):
        node = {"label": label, "entity_type": entity_type}
        node.update(props)
        nodes.append(node)
        return label

    def add_edge(src, tgt, rel, **props):
        e = {"source": src, "target": tgt, "rel": rel}
        e.update(props)
        edges.append(e)

    # Infrastructure entities
    for i in range(1, devices + 1):
        add_node(f"D{i:04d}", "device", device_fp=str(uuid.uuid4())[:8], fraud=False)
    for i in range(1, ips + 1):
        add_node(f"IP{i:04d}", "ip", ip=f"10.{rng.randint(0,255)}.{rng.randint(0,255)}.{rng.randint(1,254)}", fraud=False)
    for i in range(1, addresses + 1):
        add_node(f"A{i:04d}", "address", fraud=False, **_addr(rng, i))
    for i in range(1, banks + 1):
        add_node(f"B{i:04d}", "bank_account", fraud=False, routing=f"{rng.randint(100000000,999999999)}", acct=f"{rng.randint(10000000,99999999)}")
    for i in range(1, pharmacies + 1):
        add_node(f"PH{i:04d}", "pharmacy", fraud=False, npi=f"{rng.randint(1000000000,9999999999)}", name=f"Pharmacy {i:03d}")

    # Providers and members
    for i in range(1, providers + 1):
        add_node(
            f"P{i:04d}",
            "provider",
            fraud=False,
            risk_level="low",
            npi=f"{rng.randint(1000000000,9999999999)}",
            name=f"Provider {i:03d}",
        )
    for i in range(1, members + 1):
        add_node(f"M{i:04d}", "member", fraud=False, risk_level="low", member_id=f"M{i:04d}")

    def pick(prefix, max_n):
        return f"{prefix}{rng.randint(1, max_n):04d}"

    base_date = dt.date(2026, 1, 1)

    def rand_date():
        d = base_date + dt.timedelta(days=rng.randint(0, 30))
        return str(d)

    def add_claim(cid, member, provider, amount, service_date, risk_score, risk_reason, risk_rule, ui_color, fraud=False, fraud_type=None):
        props = dict(
            id=cid,
            claimId=cid,
            memberId=member,
            providerId=provider,
            amount=amount,
            serviceDate=service_date,
            ui_color=ui_color,
            risk_score=risk_score,
            risk_reason=risk_reason,
            risk_rule=risk_rule,
            fraud=fraud,
        )
        if fraud_type:
            props["fraud_type"] = fraud_type
        add_node(cid, "claim", **props)
        add_edge(cid, member, "member")
        add_edge(cid, provider, "provider")

    def mark_fraud(label, fraud_type):
        for n in nodes:
            if n["label"] == label:
                n["fraud"] = True
                n["risk_level"] = "high"
                n["fraud_type"] = fraud_type
                return

    # Fraud case nodes
    fraud_cases = []
    for i, (ft, desc) in enumerate(FRAUD_TYPES, start=1):
        fc = f"F{i:03d}"
        add_node(fc, "fraud_case", fraud=True, fraud_type=ft, description=desc, risk_level="high")
        fraud_cases.append(fc)

    # Baseline claims
    claim_count = 0
    for _ in range(baseline_claims):
        claim_count += 1
        cid = f"C{claim_count:05d}"
        m = pick("M", members)
        p = pick("P", providers)
        amt = rng.randint(80, 1200)
        score = rng.randint(5, 35)
        ui_color = "green" if score < 15 else ("yellow" if score < 25 else "orange")
        add_claim(cid, m, p, amt, rand_date(), score, "baseline", "baseline", ui_color, fraud=False)

    # Pattern 1 identity theft clusters
    for _ in range(6):
        device = pick("D", devices)
        ip = pick("IP", ips)
        addr = pick("A", addresses)
        mems = rng.sample([f"M{i:04d}" for i in range(1, members + 1)], 6)
        provs = rng.sample([f"P{i:04d}" for i in range(1, providers + 1)], 3)

        for m in mems:
            add_edge(m, device, "uses_device")
            add_edge(m, ip, "uses_ip")
            add_edge(m, addr, "lives_at")

        for _ in range(30):
            claim_count += 1
            cid = f"C{claim_count:05d}"
            m = rng.choice(mems)
            p = rng.choice(provs)
            amt = rng.randint(2500, 9000)
            score = rng.randint(80, 99)
            add_claim(cid, m, p, amt, rand_date(), score, "identity_theft_cluster", "shared_device_ip", "red", fraud=True, fraud_type="identity_theft")
            add_edge(cid, fraud_cases[0], "flags")
            mark_fraud(m, "identity_theft")
            mark_fraud(p, "identity_theft")

        mark_fraud(device, "identity_theft")
        mark_fraud(ip, "identity_theft")
        mark_fraud(addr, "identity_theft")

    # Pattern 2 phantom billing bursts
    for _ in range(5):
        p = pick("P", providers)
        bank = pick("B", banks)
        add_edge(p, bank, "paid_to")
        mems = rng.sample([f"M{i:04d}" for i in range(1, members + 1)], 40)

        for _ in range(70):
            claim_count += 1
            cid = f"C{claim_count:05d}"
            m = rng.choice(mems)
            amt = rng.randint(1500, 12000)
            score = rng.randint(75, 98)
            add_claim(cid, m, p, amt, rand_date(), score, "phantom_billing_spike", "volume_anomaly", "red", fraud=True, fraud_type="phantom_billing")
            add_edge(cid, fraud_cases[1], "flags")
            mark_fraud(m, "phantom_billing")

        mark_fraud(p, "phantom_billing")
        mark_fraud(bank, "phantom_billing")

    # Pattern 3 kickback rings
    for _ in range(4):
        p = pick("P", providers)
        ph = pick("PH", pharmacies)
        bank = pick("B", banks)
        add_edge(p, ph, "refers_to")
        add_edge(ph, bank, "paid_to")
        add_edge(p, bank, "paid_to")

        mems = rng.sample([f"M{i:04d}" for i in range(1, members + 1)], 18)
        for m in mems:
            add_edge(m, ph, "fills_at")

        for _ in range(50):
            claim_count += 1
            cid = f"C{claim_count:05d}"
            m = rng.choice(mems)
            amt = rng.randint(900, 7000)
            score = rng.randint(70, 95)
            add_claim(cid, m, p, amt, rand_date(), score, "kickback_ring", "shared_bank_referral", "red", fraud=True, fraud_type="kickback_ring")
            add_edge(cid, fraud_cases[2], "flags")
            mark_fraud(m, "kickback_ring")

        mark_fraud(p, "kickback_ring")
        mark_fraud(ph, "kickback_ring")
        mark_fraud(bank, "kickback_ring")

    # Pattern 4 upcoding profiles
    for _ in range(6):
        p = pick("P", providers)
        mems = rng.sample([f"M{i:04d}" for i in range(1, members + 1)], 28)

        for _ in range(45):
            claim_count += 1
            cid = f"C{claim_count:05d}"
            m = rng.choice(mems)
            amt = rng.randint(2000, 15000)
            score = rng.randint(65, 92)
            add_claim(cid, m, p, amt, rand_date(), score, "upcoding_profile", "amount_outlier", "orange", fraud=True, fraud_type="upcoding")
            add_edge(cid, fraud_cases[3], "flags")
            mark_fraud(m, "upcoding")

        mark_fraud(p, "upcoding")

    # Pattern 5 unbundling same day
    for _ in range(6):
        p = pick("P", providers)
        m = pick("M", members)
        day = rand_date()

        for _ in range(12):
            claim_count += 1
            cid = f"C{claim_count:05d}"
            amt = rng.randint(300, 1500)
            score = rng.randint(60, 88)
            add_claim(cid, m, p, amt, day, score, "unbundling_same_day", "same_day_multi_claim", "orange", fraud=True, fraud_type="unbundling")
            add_edge(cid, fraud_cases[4], "flags")

        mark_fraud(m, "unbundling")
        mark_fraud(p, "unbundling")

    # Pattern 6 DME rental repeats
    for _ in range(4):
        p = pick("P", providers)
        device = pick("D", devices)
        mems = rng.sample([f"M{i:04d}" for i in range(1, members + 1)], 12)

        for m in mems:
            add_edge(m, device, "uses_device")

        for m in mems:
            for _ in range(6):
                claim_count += 1
                cid = f"C{claim_count:05d}"
                amt = rng.randint(600, 2200)
                score = rng.randint(62, 90)
                add_claim(cid, m, p, amt, rand_date(), score, "dme_rental_repeat", "repeat_rental", "orange", fraud=True, fraud_type="dme_rental")
                add_edge(cid, fraud_cases[5], "flags")
            mark_fraud(m, "dme_rental")

        mark_fraud(p, "dme_rental")
        mark_fraud(device, "dme_rental")

    return {"nodes": nodes, "edges": edges}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", type=str, default="synthetic_graph.json")
    ap.add_argument("--members", type=int, default=520)
    ap.add_argument("--providers", type=int, default=140)
    ap.add_argument("--baseline_claims", type=int, default=1200)
    args = ap.parse_args()

    data = gen(
        seed=args.seed,
        members=args.members,
        providers=args.providers,
        baseline_claims=args.baseline_claims,
    )
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"Wrote {args.out} with {len(data['nodes'])} nodes and {len(data['edges'])} edges")


if __name__ == "__main__":
    main()
