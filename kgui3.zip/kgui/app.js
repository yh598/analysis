  if (isFraud) {
    return { color: "#ff1a1a", size: 50,
  const fraudLabels = new Set(nodes.filter(n => n.fraud).map(n => n.label));
 border: "#ff1a1a" };
  }
const DEFAULT_BASE_URL = "https://YOUR_FUNCTION_APP.azurewebsites.net";
const DEFAULT_FUNCTION_KEY = "";

function $(id){ return document.getElementById(id); }

function setStatus(msg, tone="info"){
  const el = $("status");
  el.textContent = msg;
  if(tone === "ok"){ el.style.color = "var(--ok)"; }
  else if(tone === "warn"){ el.style.color = "var(--warn)"; }
  else if(tone === "bad"){ el.style.color = "var(--bad)"; }
  else { el.style.color = "var(--muted)"; }
}

function buildUrl(baseUrl, path, params){
  const u = new URL(baseUrl.replace(/\/$/,"") + path);
  Object.entries(params || {}).forEach(([k,v]) => {
    if(v !== undefined && v !== null && String(v).length > 0) u.searchParams.set(k, v);
  });
  return u.toString();
}

function safeJsonParse(s){
  try{ return JSON.parse(s); } catch(e){ return null; }
}

function normalizeToElements(payload, riskFilter){
  // payload can be:
  // A) { nodes: [...], edges: [...] }
  // B) Azure function list: { items: [...] } for claims and providers
  // C) Any plain list of objects with id fields
  if(payload && payload.nodes && payload.edges){
    // Filter by risk if requested (for claim nodes)
    if(riskFilter && riskFilter !== "all"){
      const allowedClaims = new Set(
        payload.nodes
          .filter(n => n.entity_type === "claim" && n.risk_level === riskFilter)
          .map(n => n.label || n.id)
      );
      const keepNode = (n) => n.entity_type !== "claim" || allowedClaims.has(n.label || n.id);
      const nodes = payload.nodes.filter(keepNode);
      const nodeSet = new Set(nodes.map(n => n.label || n.id));
      const edges = payload.edges.filter(e => nodeSet.has(e.source) && nodeSet.has(e.target));
      return { nodes, edges };
    }
    return payload;
  }
  // If this is Azure "items"
  if(payload && Array.isArray(payload.items)){
    return { nodes: payload.items.map(x => ({...x, label: x.id || x.claimId || x.providerId || x.memberId })), edges: [] };
  }
  if(Array.isArray(payload)){
    return { nodes: payload.map(x => ({...x, label: x.id || x.claimId || x.providerId || x.memberId })), edges: [] };
  }
  return { nodes: [], edges: [] };
}

function nodeStyleForType(type){
  // professional palette
  const map = {
    claim:     { color: "#6ea8fe", size: 34 },
    member:    { color: "#b197fc", size: 38 },
    provider:  { color: "#94d82d", size: 38 },
    address:   { color: "#ffd43b", size: 34 },
    device:    { color: "#ffa94d", size: 34 },
    bank_account: { color: "#74c0fc", size: 34 },
    ip:        { color: "#63e6be", size: 34 },
    pharmacy:  { color: "#ff8787", size: 34 },
    fraud_case:{ color: "#f06595", size: 42 },
    other:     { color: "#adb5bd", size: 34 },
  };
  return map[type] || map.other;
}

function makeCytoscapeElements(nodes, edges, limit){
  const outNodes = [];
  const outEdges = [];

  // Keep stable order: high risk claims first
  const sortedNodes = [...nodes].sort((a,b) => {
    const ar = (a.risk_score || 0), br = (b.risk_score || 0);
    return br - ar;
  }).slice(0, limit || 250);

  const idSet = new Set();
  sortedNodes.forEach(n => {
    const id = n.label || n.id;
    if(!id) return;
    idSet.add(id);

    const t = n.entity_type || "other";
    const st = nodeStyleForType(t);

    // If claim has ui_color red or yellow or green, map to border
    let border = "rgba(255,255,255,0.18)";
    if(t === "claim"){
      if(n.ui_color === "red") border = "rgba(255,107,107,0.9)";
      else if(n.ui_color === "yellow") border = "rgba(255,212,59,0.9)";
      else if(n.ui_color === "green") border = "rgba(56,211,159,0.9)";
    }

    outNodes.push({
      data: {
        id,
        label: id,
        entity_type: t,
        fill: st.color,
        size: st.size,
        border,
        props: n,
      }
    });
  });

  // Add edges only if both nodes exist in this limited set
  edges.forEach((e, idx) => {
    const s = e.source, t = e.target;
    if(!idSet.has(s) || !idSet.has(t)) return;
    outEdges.push({
      data: {
        id: e.id || `e${idx}`,
        source: s,
        target: t,
        label: e.label || "",
        props: e,
      }
    });
  });

  return { outNodes, outEdges };
}

let cy;

function initCy(){
  cy = cytoscape({
    container: $("cy"),
    elements: [],
    style: [
      {
        selector: "node",
        style: {
          "background-color": "data(fill)",
          "width": "data(size)",
          "height": "data(size)",
          "border-color": "data(border)",
          "border-width": 3,
          "label": "data(label)",
          "color": "#e8eefc",
          "text-outline-color": "rgba(0,0,0,0.35)",
          "text-outline-width": 3,
          "font-size": 11,
          "text-valign": "center",
          "text-halign": "center",
        }
      },
      {
        selector: "node[fraud]",
        style: {
          "background-color": "#ff1a1a",
          "text-outline-color": "#ff1a1a",
          "text-outline-width": 3,
          "color": "#ffffff",
          "border-width": 2,
          "border-color": "#ff1a1a",
          "font-weight": "bold",
          "z-index": 9999
        }
      },
      {
        selector: "edge[fraud]",
        style: {
          "line-color": "#ff1a1a",
          "target-arrow-color": "#ff1a1a",
          "width": 3,
          "opacity": 0.85
        }
      },
      {
        selector: "edge",
        style: {
          "curve-style": "bezier",
          "line-color": "rgba(232,238,252,0.25)",
          "width": 2,
          "target-arrow-shape": "triangle",
          "target-arrow-color": "rgba(232,238,252,0.35)",
          "label": "data(label)",
          "font-size": 10,
          "text-rotation": "autorotate",
          "text-background-color": "rgba(0,0,0,0.35)",
          "text-background-opacity": 1,
          "text-background-padding": 3,
          "text-background-shape": "round-rectangle",
          "color": "#cfe0ff",
        }
      },
      { selector: ".faded", style: { "opacity": 0.12 } },
      { selector: ".highlighted", style: { "opacity": 1 } },
      { selector: ":selected", style: { "border-width": 5, "border-color": "rgba(110,168,254,0.95)" } },
    ],
    layout: { name: "cose", animate: true, animationDuration: 500, randomize: true },
    wheelSensitivity: 0.18,
  });

  cy.on("tap", "node", (evt) => {
    const d = evt.target.data();
    $("selected").textContent = JSON.stringify(d.props || d, null, 2);
    focusNeighborhood(evt.target);
  });

  cy.on("tap", "edge", (evt) => {
    const d = evt.target.data();
    $("selected").textContent = JSON.stringify(d.props || d, null, 2);
  });

  cy.on("tap", (evt) => {
    if(evt.target === cy){
      cy.elements().removeClass("faded highlighted");
    }
  });
}

function runLayout(){
  const layout = cy.layout({
    name: "cose",
    animate: true,
    animationDuration: 650,
    randomize: true,
    nodeOverlap: 10,
    idealEdgeLength: 120,
    edgeElasticity: 0.25,
    gravity: 0.20,
    numIter: 1000,
  });
  layout.run();
}

function focusNeighborhood(node){
  const nhood = node.closedNeighborhood();
  cy.elements().addClass("faded");
  nhood.removeClass("faded");
  node.addClass("highlighted");
}

async function loadFromFile(fileName, riskFilter, limit){
  const res = await fetch(fileName, { cache: "no-store" });
  if(!res.ok) throw new Error(`Could not load ${fileName}: ${res.status}`);
  const data = await res.json();
  const norm = normalizeToElements(data, riskFilter);
  return makeCytoscapeElements(norm.nodes, norm.edges, limit);
}

async function loadFromApi(baseUrl, fnKey, riskFilter, limit){
  // Easiest: call a single endpoint you already have for "paths" or "claims"
  // For the synthetic demo, we usually use local file. For API mode, we load claims list only.
  const url = buildUrl(baseUrl, "/api/claims", { limit: limit || 250, color: "All", code: fnKey || "" });
  const res = await fetch(url, { cache: "no-store" });
  if(!res.ok){
    const t = await res.text();
    throw new Error(`API error ${res.status}: ${t}`);
  }
  const data = await res.json();
  const norm = normalizeToElements(data, riskFilter);
  // In API mode, we do not have edges unless your API returns them. Still useful for table style.
  return makeCytoscapeElements(norm.nodes, norm.edges || [], limit);
}

async function loadGraph(){
  const mode = $("sourceMode").value;
  const limit = parseInt($("limit").value || "250", 10);
  const riskFilter = $("riskFilter").value;

  setStatus("Loading data...", "info");
  try{
    let elements;
    if(mode === "file"){
      const fileName = $("localFile").value;
      elements = await loadFromFile(fileName, riskFilter, limit);
      setStatus(`Loaded local graph. Nodes ${elements.outNodes.length} Edges ${elements.outEdges.length}`, "ok");
    }else{
      const baseUrl = $("baseUrl").value || DEFAULT_BASE_URL;
      const fnKey = $("fnKey").value || DEFAULT_FUNCTION_KEY;
      elements = await loadFromApi(baseUrl, fnKey, riskFilter, limit);
      setStatus(`Loaded from API. Nodes ${elements.outNodes.length}`, "ok");
    }

    cy.elements().remove();
    cy.add([...elements.outNodes, ...elements.outEdges]);
    runLayout();
    cy.fit(undefined, 30);
  }catch(e){
    console.error(e);
    setStatus(String(e.message || e), "bad");
    alert(String(e.message || e));
  }
}

function focusById(){
  const q = ($("searchId").value || "").trim();
  if(!q){ setStatus("Enter an id to focus", "warn"); return; }

  const n = cy.getElementById(q);
  if(n && n.length){
    cy.center(n);
    cy.zoom({ level: Math.min(1.6, cy.zoom() * 1.25), renderedPosition: n.renderedPosition() });
    n.select();
    focusNeighborhood(n);
    $("selected").textContent = JSON.stringify(n.data().props || n.data(), null, 2);
    setStatus(`Focused ${q}`, "ok");
  }else{
    setStatus(`Not found: ${q}`, "warn");
  }
}

function exportPng(){
  const png64 = cy.png({ full: true, scale: 2, bg: "transparent" });
  const a = document.createElement("a");
  a.href = png64;
  a.download = "graph.png";
  a.click();
}

function wireUi(){
  $("baseUrl").value = DEFAULT_BASE_URL;
  $("fnKey").value = DEFAULT_FUNCTION_KEY;

  $("loadBtn").addEventListener("click", loadGraph);
  $("focusBtn").addEventListener("click", focusById);
  $("fitBtn").addEventListener("click", () => cy.fit(undefined, 30));
  $("layoutBtn").addEventListener("click", runLayout);
  $("exportBtn").addEventListener("click", exportPng);

  $("zoomInBtn").addEventListener("click", () => cy.zoom({ level: cy.zoom() * 1.15, renderedPosition: { x: cy.width()/2, y: cy.height()/2 } }));
  $("zoomOutBtn").addEventListener("click", () => cy.zoom({ level: cy.zoom() / 1.15, renderedPosition: { x: cy.width()/2, y: cy.height()/2 } }));

  $("sourceMode").addEventListener("change", () => {
    const mode = $("sourceMode").value;
    // Just update status, no hard disable to keep simple
    setStatus(mode === "file" ? "Local file mode selected" : "API mode selected", "info");
  });

  window.addEventListener("keydown", (e) => {
    if(e.key === "Enter") focusById();
  });
}

initCy();
wireUi();
setStatus("Ready. Choose mode, then Load.", "ok");