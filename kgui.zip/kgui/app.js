const BASE_URL = "https://fraud-drhrhnhhahedsbjfm.westus-01.azurewebsites.net";
const FUNCTION_KEY = "PASTE_YOUR_FUNCTION_KEY_HERE";

function buildUrl(path, params = {}) {
  const u = new URL(BASE_URL + path);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && String(v).length > 0) u.searchParams.set(k, v);
  });
  u.searchParams.set("code", FUNCTION_KEY);
  return u.toString();
}

const cy = cytoscape({
  container: document.getElementById("cy"),
  elements: [],
  style: [
    {
      selector: "node",
      style: {
        label: "data(label)",
        "background-color": "data(color)",
        "text-valign": "center",
        "text-halign": "center",
        "font-size": 10
      }
    },
    {
      selector: "edge",
      style: {
        width: 2,
        "line-color": "#999",
        "target-arrow-color": "#999",
        "target-arrow-shape": "triangle",
        "curve-style": "bezier",
        label: "data(label)",
        "font-size": 9
      }
    }
  ],
  layout: { name: "cose" }
});

function uiColorToHex(s) {
  const v = String(s || "").toLowerCase();
  if (v === "red") return "#e74c3c";
  if (v === "yellow") return "#f1c40f";
  if (v === "green") return "#2ecc71";
  return "#3498db";
}

function upsertNode(map, id, label, color, props) {
  if (!map.has(id)) map.set(id, { data: { id, label, color, props } });
  else {
    const cur = map.get(id);
    cur.data.props = { ...cur.data.props, ...props };
    if (label) cur.data.label = label;
    if (color) cur.data.color = color;
  }
}

function edgeId(a, b, label) {
  return `${a}__${label}__${b}`;
}

async function loadGraph() {
  const limit = Number(document.getElementById("limit").value || 50);
  const color = document.getElementById("color").value;

  const url = buildUrl("/api/claims", { limit, color });
  const resp = await fetch(url);
  if (!resp.ok) {
    const t = await resp.text();
    throw new Error(`claims failed: ${resp.status} ${t}`);
  }
  const payload = await resp.json();

  const nodes = new Map();
  const edges = [];

  const items = payload.items || payload || [];
  for (const it of items) {
    const claimVid = it.id || `c_${it.claimId}`;
    const memberVid = `m_${it.memberId}`;
    const providerVid = `p_${it.providerId}`;

    upsertNode(nodes, claimVid, it.claimId || claimVid, uiColorToHex(it.ui_color), it);
    upsertNode(nodes, memberVid, it.memberId || memberVid, "#9b59b6", { memberId: it.memberId });
    upsertNode(nodes, providerVid, it.providerId || providerVid, "#34495e", { providerId: it.providerId });

    edges.push({
      data: { id: edgeId(claimVid, memberVid, "member"), source: claimVid, target: memberVid, label: "member" }
    });
    edges.push({
      data: { id: edgeId(claimVid, providerVid, "provider"), source: claimVid, target: providerVid, label: "provider" }
    });
  }

  const elements = [...nodes.values(), ...edges];
  cy.elements().remove();
  cy.add(elements);

  cy.layout({ name: "cose", animate: false }).run();
}

function showDetails(obj) {
  document.getElementById("details").textContent = JSON.stringify(obj, null, 2);
}

cy.on("tap", "node", (evt) => showDetails(evt.target.data()));
cy.on("tap", "edge", (evt) => showDetails(evt.target.data()));

document.getElementById("load").addEventListener("click", async () => {
  try {
    await loadGraph();
  } catch (e) {
    alert(String(e.message || e));
  }
});

document.getElementById("focus").addEventListener("click", () => {
  const id = document.getElementById("search").value.trim();
  if (!id) return;
  const n = cy.getElementById(id);
  if (n && n.length) {
    cy.center(n);
    cy.zoom({ level: 1.5, renderedPosition: n.renderedPosition() });
    n.select();
    showDetails(n.data());
  } else {
    alert("Not found in current graph, load more or different filter");
  }
});
