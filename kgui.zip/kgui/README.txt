KG UI quick start

1) Open app.js and set FUNCTION_KEY
2) Enable CORS in your Function App for these origins
   http://localhost:5500
   http://127.0.0.1:5500
3) Open the folder in VS Code and use Live Server on index.html
4) Click Load graph

Notes
This UI calls /api/claims and draws claim to member and claim to provider edges.
If your function requires a key, the UI appends code=FUNCTION_KEY.
Do not publish this UI with a key embedded in app.js.
