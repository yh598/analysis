# Fraud KG Demo UI (Cosmos DB Gremlin) with Azure Functions + Static Web App

This is a small end to end demo UI:
1) Azure Functions (Python) exposes simple APIs that run Gremlin queries
2) A static web page calls those APIs and renders a claims table and details

## What you will build
UI page
  claims table with ui_color
  click a claim to see neighborhood and paths to known fraud

Backend APIs
  GET /api/claims?limit=200
  GET /api/neighborhood?claimId=C0008&hops=1
  GET /api/paths?claimId=C0008&hops=2&limit=5

## Azure deployment in portal only
Step 1 Create Function App
  Portal → Create a resource → Function App
  Runtime stack: Python
  Publish: Code
  Hosting: Consumption or Premium

Step 2 Add application settings
  Function App → Settings → Configuration → Application settings → New application setting
  COSMOS_ACCOUNT  your Cosmos DB account name (no https)
  COSMOS_KEY      primary key
  COSMOS_DB       your database id, for example pi_kg
  COSMOS_GRAPH    your graph id, for example claims

Step 3 Deploy the API code
  Easiest is GitHub deploy, or zip deploy
  If you want zip deploy: upload the ui.zip contents, but only the api folder and root function files matter for the Function App

Step 4 Create Static Web App
  Portal → Create a resource → Static Web App
  Deployment: Other (or GitHub if you want)
  Build preset: Custom

Step 5 Connect the Static Web App to your Functions
  Simplest is to create the Static Web App in the same repo structure where api is a sibling of the web files.
  SWA will automatically route /api/* to Azure Functions if configured with an api.
  If you deploy separately, just edit web/app.js to point to the Function App base URL.

## Local run (optional)
1) Install Azure Functions Core Tools
2) From this folder:
   pip install -r requirements.txt
   func start
3) Open web/index.html and it will call http://localhost:7071/api

## Notes
Cosmos Gremlin endpoint format
  wss://{account}.gremlin.cosmos.azure.com:443/
Gremlin username format
  /dbs/{db}/colls/{graph}

If your graph uses partition key /pk, your data load should set pk on every vertex and edge.


## Extra APIs for providers
  GET /api/providers?limit=200
  GET /api/provider/claims?providerId=P0002&limit=50
  GET /api/neighborhood?providerId=P0002&hops=1
  GET /api/paths?providerId=P0002&hops=2&limit=5
