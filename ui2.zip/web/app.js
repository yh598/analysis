const API_BASE = "";

let mode = "claims"; // claims or providers
let items = [];

function pill(color) {
  const c = (color || "missing").toLowerCase();
  const cls = ["red","yellow","blue","green"].includes(c) ? c : "green";
  return `<span class="pill ${cls}">${c}</span>`;
}

function toText(x) {
  return (x === null || x === undefined) ? "" : String(x);
}

async function apiGet(path) {
  const url = `${API_BASE}/api${path}`;
  const resp = await fetch(url);
  if (!resp.ok) {
    const t = await resp.text();
    throw new Error(`${resp.status} ${resp.statusText} :: ${t}`);
  }
  return await resp.json();
}

function setHeaders() {
  const h = (id, txt) => document.getElementById(id).textContent = txt;
  if (mode === "claims") {
    h("col1","claimId"); h("col2","memberId"); h("col3","providerId");
    h("col4","amount"); h("col5","serviceDate"); h("col6","color"); h("col7","risk_reason");
    document.getElementById("search").placeholder = "Search claimId or memberId";
  } else {
    h("col1","providerId"); h("col2","name"); h("col3","specialty");
    h("col4","fraud_case"); h("col5",""); h("col6","color"); h("col7","risk_reason");
    document.getElementById("search").placeholder = "Search providerId or name";
  }
}

function renderTable(rows) {
  const tb = document.querySelector("#claimsTable tbody");
  tb.innerHTML = "";
  for (const r of rows) {
    const tr = document.createElement("tr");
    if (mode === "claims") {
      tr.innerHTML = `
        <td>${toText(r.claimId)}</td>
        <td>${toText(r.memberId)}</td>
        <td>${toText(r.providerId)}</td>
        <td>${toText(r.amount)}</td>
        <td>${toText(r.serviceDate)}</td>
        <td>${pill(r.ui_color)}</td>
        <td>${toText(r.risk_reason)}</td>
      `;
    } else {
      tr.innerHTML = `
        <td>${toText(r.providerId)}</td>
        <td>${toText(r.name)}</td>
        <td>${toText(r.specialty)}</td>
        <td>${toText(r.fraud_case)}</td>
        <td></td>
        <td>${pill(r.ui_color)}</td>
        <td>${toText(r.risk_reason)}</td>
      `;
    }
    tr.addEventListener("click", () => selectRow(r));
    tb.appendChild(tr);
  }
}

function applySearch() {
  const q = document.getElementById("search").value.trim().toLowerCase();
  if (!q) return items;

  if (mode === "claims") {
    return items.filter(r =>
      toText(r.claimId).toLowerCase().includes(q) ||
      toText(r.memberId).toLowerCase().includes(q)
    );
  } else {
    return items.filter(r =>
      toText(r.providerId).toLowerCase().includes(q) ||
      toText(r.name).toLowerCase().includes(q)
    );
  }
}

async function loadItems() {
  document.getElementById("status").textContent = `Loading ${mode}...`;
  setHeaders();

  if (mode === "claims") {
    const data = await apiGet("/claims?limit=200");
    items = data.items || [];
  } else {
    const data = await apiGet("/providers?limit=200");
    items = data.items || [];
  }

  renderTable(applySearch());
  document.getElementById("status").textContent = `Loaded ${items.length} ${mode}`;
  clearDetails();
}

function clearDetails() {
  document.getElementById("selectedHint").textContent = "Click a row to view neighborhood and fraud paths.";
  document.getElementById("selectedBox").innerHTML = "";
  document.getElementById("neighborhood").textContent = "";
  document.getElementById("paths").textContent = "";
}

async function selectRow(r) {
  document.getElementById("selectedHint").textContent = "";
  const title = mode === "claims" ? `claimId ${toText(r.claimId)}` : `providerId ${toText(r.providerId)}`;
  document.getElementById("selectedBox").innerHTML = `
    <div><b>${title}</b> ${pill(r.ui_color)}</div>
    <div class="muted">risk_rule: ${toText(r.risk_rule)}  risk_score: ${toText(r.risk_score)}  reason: ${toText(r.risk_reason)}</div>
  `;

  document.getElementById("neighborhood").textContent = "Loading...";
  document.getElementById("paths").textContent = "Loading...";

  // Prefer vertex id if present
  const vid = r.id ? encodeURIComponent(r.id) : null;

  try {
    let nb;
    if (vid) nb = await apiGet(`/neighborhood?vid=${vid}&hops=1`);
    else if (mode === "claims") nb = await apiGet(`/neighborhood?claimId=${encodeURIComponent(r.claimId)}&hops=1`);
    else nb = await apiGet(`/neighborhood?providerId=${encodeURIComponent(r.providerId)}&hops=1`);
    document.getElementById("neighborhood").textContent = JSON.stringify(nb, null, 2);
  } catch (e) {
    document.getElementById("neighborhood").textContent = String(e);
  }

  try {
    let ps;
    if (vid) ps = await apiGet(`/paths?vid=${vid}&hops=2&limit=5`);
    else if (mode === "claims") ps = await apiGet(`/paths?claimId=${encodeURIComponent(r.claimId)}&hops=2&limit=5`);
    else ps = await apiGet(`/paths?providerId=${encodeURIComponent(r.providerId)}&hops=2&limit=5`);
    document.getElementById("paths").textContent = JSON.stringify(ps, null, 2);
  } catch (e) {
    document.getElementById("paths").textContent = String(e);
  }
}

document.getElementById("refresh").addEventListener("click", loadItems);
document.getElementById("search").addEventListener("input", () => renderTable(applySearch()));
document.getElementById("tabClaims").addEventListener("click", () => { mode = "claims"; loadItems(); });
document.getElementById("tabProviders").addEventListener("click", () => { mode = "providers"; loadItems(); });

loadItems().catch(e => {
  document.getElementById("status").textContent = String(e);
});
