import os
from gremlin_python.driver import client, serializer

def _env(name: str, default: str = "") -> str:
    v = os.environ.get(name, default)
    return v if v is not None else default

def get_gremlin_client():
    account = _env("COSMOS_ACCOUNT")
    key = _env("COSMOS_KEY")
    db = _env("COSMOS_DB")
    graph = _env("COSMOS_GRAPH")

    if not account or not key or not db or not graph:
        raise ValueError("Missing one of COSMOS_ACCOUNT, COSMOS_KEY, COSMOS_DB, COSMOS_GRAPH")

    endpoint = _env("COSMOS_GREMLIN_ENDPOINT", f"wss://{account}.gremlin.cosmos.azure.com:443/")
    username = f"/dbs/{db}/colls/{graph}"

    return client.Client(
        endpoint,
        "g",
        username=username,
        password=key,
        message_serializer=serializer.GraphSONSerializersV2d0()
    )
