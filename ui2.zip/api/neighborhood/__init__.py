import json
import azure.functions as func
from api.shared import get_gremlin_client

def _q(req, key, default=None):
    v = req.params.get(key)
    return v if v is not None and v != "" else default

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        vid = _q(req, "vid")
        claim_id = _q(req, "claimId")
        provider_id = _q(req, "providerId")

        hops = int(_q(req, "hops", "1"))
        hops = max(1, min(hops, 3))

        g = get_gremlin_client()

        if vid:
            start = "g.V('%s')" % vid.replace("'","\\'")
        elif claim_id:
            start = "g.V().hasLabel('claim').has('claimId','%s')" % claim_id.replace("'","\\'")
        elif provider_id:
            start = "g.V().hasLabel('provider').has('providerId','%s')" % provider_id.replace("'","\\'")
        else:
            return func.HttpResponse(json.dumps({"error":"Provide vid or claimId or providerId"}), mimetype="application/json", status_code=400)

        q = start + (""".
          repeat(bothE().otherV()).times(%d).
          dedup().
          valueMap(true)""" % hops)

        rs = g.submit(q).all().result()
        return func.HttpResponse(
            json.dumps({"vid": vid, "claimId": claim_id, "providerId": provider_id, "hops": hops, "items": rs}, default=str),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500
        )
