import json
import azure.functions as func
from api.shared import get_gremlin_client

def _q(req, key, default=None):
    v = req.params.get(key)
    return v if v is not None and v != "" else default

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        limit = int(_q(req, "limit", "200"))
        limit = max(1, min(limit, 500))
        color = _q(req, "color", None)

        g = get_gremlin_client()

        base = """g.V().hasLabel('provider')"""
        if color:
            base += ".has('ui_color','%s')" % color.replace("'","\\'")
        q = base + (""".
          project('id','providerId','name','specialty','ui_color','risk_reason','risk_rule','risk_score','fraud_case').
            by(id()).
            by(values('providerId')).
            by(values('name')).
            by(coalesce(values('specialty'), constant(''))).
            by(coalesce(values('ui_color'), constant('green'))).
            by(coalesce(values('risk_reason'), constant(''))).
            by(coalesce(values('risk_rule'), constant(''))).
            by(coalesce(values('risk_score'), constant(0))).
            by(coalesce(values('fraud_case'), constant(false))).
          limit(%d)""" % limit)

        rs = g.submit(q).all().result()
        return func.HttpResponse(
            json.dumps({"items": rs}, default=str),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500
        )
